import { Group, Text, Image } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $timelineCover: Group(
    {
      image: Image('Image', { width: 1920, height: 1080 }, [
        {
          name: 'medium',
          width: 1280,
          height: 720,
        },
        {
          name: 'small',
          width: 767,
          height: 700,
        },
      ]),
      title: Text('Title (Mandatory)'),
      subtitle: Text('Subtitle'),
      ctaLabel: Text('CTA Label'),
      periodListTitle: Text('Period list title'),
    },
    'Cover'
  ),
}

import React, { useRef } from 'react'
import { media } from '@axacom-client/base/style/variables'
import { StyledSlice, Content, CoverImage, SubTitle, Title, CoverCTA } from './TimelineCover.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { useScroll, useTransform, motion, circOut } from 'framer-motion/dist/framer-motion'

export default function TimelineCover({ image, title, subtitle, ctaLabel }) {
  const contentRef = useRef(null)

  // Calculate the scrollProgression while on cover & transform it to make parallax effect
  let { scrollYProgress } = useScroll({
    target: contentRef,
    offset: ['start start', 'end start'],
  })
  let y = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  let yy = useTransform(scrollYProgress, [0, 1], [0, '100%'], { ease: circOut })

  return (
    <StyledSlice key={title} data-testid="TimelineCover">
      <Content ref={contentRef}>
        <ResponsiveContainer tablet desktop largeDesktop>
          <motion.div style={{ y: yy }}>
            <Title data-testid="TimelineCover__Title">{title}</Title>
            <SubTitle data-testid="TimelineCover__SubTitle">{subtitle}</SubTitle>
            {ctaLabel && (
              <CoverCTA href="#TimelineSummary" target="_self" type="ghost" color="red" dataTestId="TimelineCover__Cta">
                {ctaLabel}
              </CoverCTA>
            )}
          </motion.div>
        </ResponsiveContainer>
      </Content>
      <picture>
        <source media={`(max-width: ${media.phoneMax}px)`} srcSet={image?.views?.small?.url} />
        <source media={`(max-width: ${media.tabletMax}px)`} srcSet={image?.views?.medium?.url} />
        <CoverImage style={{ y, translateX: '-50%' }} src={image?.main?.url} alt={image?.main?.alt} />
      </picture>
    </StyledSlice>
  )
}

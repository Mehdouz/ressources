import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { Slice } from '../SimpleSlice/SimpleSlice'
import { motion } from 'framer-motion/dist/framer-motion'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Typo10 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const StyledSlice = styled(Slice)`
  height: 100vh;
  position: relative;
  padding: 0;
  overflow: hidden;
  z-index: 0;
  background-color: ${colors.black};
`

export const Content = styled(motion.div)`
  max-width: 1170px;
  margin: 0 auto;
  padding-left: 20px;
  padding-right: 20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  padding-bottom: 30px;
  position: relative;
  z-index: 10;
  text-align: center;

  ${media.desktop`
    padding-bottom: 40px;
  `}
`

export const CoverImage = styled(motion.img)`
  position: absolute;
  top: -20%;
  left: 50%;
  height: 140%;
  width: auto;
  max-width: inherit;
  opacity: 0.5;
  z-index: 0;
`

export const Period = styled.h2`
  font-size: 1.5rem;
  line-height: 1.5rem;
  font-weight: ${font.weight.bold};
  color: ${colors.white};

  &:after {
    content: '';
    position: relative;
    display: block;
    top: 6px;
    left: -33px;
    height: 6px;
    border-radius: 3px;
    width: 190px;
    background: #9fd9b4;

    ${media.desktop`
      left: -45px;
      width: 200px;
  `}
  }

  ${media.desktop`
    font-size: 1.75rem;
    line-height: 3rem;
  `}
`

export const Title = styled.h2`
  font-size: 2rem;
  line-height: 2.125rem;
  font-weight: ${font.weight.bold};
  font-family: ${font.fontFamilyHeading};
  letter-spacing: 0.5px;
  color: ${colors.white};
  margin-top: 25px;
  text-align: center;

  ${media.tablet`
    font-size: 2.25rem;
    line-height: 2.5rem;
  `}

  ${media.desktop`
    font-size: 3rem;
    line-height: 3.125rem;
  `}
`

export const SubTitle = styled.p`
  ${Typo10}
  color: ${colors.white};
  margin-top: 24px;
  text-align: center;
`

export const CoverCTA = styled(Button)`
  margin-top: 48px;
`

export const CTAContainer = styled.div`
  background: red;
  text-align: center;
`

import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import {
  Organisation,
  Cta,
  PersonBlock,
  PersonInfos,
  PersonImage,
  PersonName,
  PersonRole,
  PersonBirthdate,
  PersonNationality,
  MediaItem,
  MediaLinks,
} from '@axacom-client/components/organisms/PersonHeader/PersonHeader.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { dateTime } from '@axacom-client/services/date-service'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { colors } from '@axacom-client/base/style/variables'
import capitalize from 'lodash/capitalize'

export default function PersonHeader({ avatar, birthdate, firstname, lastname, nationality, role, organizationLink, facebook, linkedin, twitter }) {
  const { i18n, currentLocale } = useGlobalContext()
  const formatedDate = birthdate ? dateTime(birthdate, 'LL', currentLocale) : null

  return (
    <Slice data-testid="PersonHeader">
      <ResponsiveContainer mobile>
        <CenteredReadingContainer>
          {organizationLink?.[0]?.organizationChart?.url && organizationLink?.[0]?.organizationChart?.title && (
            <Organisation>
              <Cta type="link" color="red" iconLeft="IconArrowLeft" href={organizationLink?.[0]?.organizationChart?.url} data-testid="PersonHeader__Organisation__Cta">
                {organizationLink?.[0]?.organizationChart?.title}
              </Cta>
            </Organisation>
          )}
        </CenteredReadingContainer>
      </ResponsiveContainer>
      <PersonBlock>
        <PersonImage>{avatar?.main?.url && <img src={avatar.main.url} alt={`${firstname} ${lastname}`} />}</PersonImage>
        <PersonInfos>
          <ResponsiveContainer mobile>
            <PersonName>
              {firstname && <p>{firstname}</p>}
              {lastname && <p>{lastname}</p>}
            </PersonName>
            {role && <PersonRole>{role}</PersonRole>}
            {birthdate && (
              <PersonBirthdate>
                {i18n.t('person.born')} {formatedDate}
              </PersonBirthdate>
            )}
            {nationality && <PersonNationality>{nationality}</PersonNationality>}
            <Links facebook={facebook} linkedin={linkedin} twitter={twitter} />
          </ResponsiveContainer>
        </PersonInfos>
      </PersonBlock>
    </Slice>
  )
}

const Links = ({ facebook, linkedin, twitter }) => {
  if (!facebook && !linkedin && !twitter) return null
  return (
    <MediaLinks>
      {facebook ? <LinkItem type="facebook" href={facebook} /> : null}
      {linkedin ? <LinkItem type="linkedin" href={linkedin} /> : null}
      {twitter ? <LinkItem type="twitter" href={twitter} /> : null}
    </MediaLinks>
  )
}

const LinkItem = ({ type, href }) => {
  return (
    <MediaItem type="link" href={href}>
      <Icon name={`Icon${capitalize(type)}`} width={20} height={20} color={colors.grey400} />
    </MediaItem>
  )
}

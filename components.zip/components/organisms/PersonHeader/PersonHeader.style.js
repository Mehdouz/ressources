import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import Button from '@axacom-client/components/atoms/Button/Button'
import { colors, font } from '@axacom-client/base/style/variables'

export const Organisation = styled.div`
  position: relative;
  margin-top: 20px;
  margin-bottom: 40px;

  & a {
    text-align: left;
  }

  ${media.tablet`
    max-width: 500px;
    margin: 20px auto 40px;
    display: flex;
    flex-direction: row;
  `}

  ${media.desktop`
    margin: 0 0 40px 0;
  `}
`

export const Cta = styled(Button)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 16px;
  letter-spacing: 1px;
  margin-bottom: 6px;
`

export const PersonBlock = styled.div`
  ${media.tablet`
    display: flex;
    flex-direction: row;
    max-width: 721px;
    margin: 0 auto;
  `}

  ${media.desktop`
    max-width: 866px;
  `}

  ${media.desktopLarge`
    max-width: 996px;
  `}
`

export const PersonInfos = styled.div`
  background: ${colors.grayLighter};
  padding-top: 70px;
  padding-bottom: 30px;
  font-family: 'Source Sans Pro', sans-serif;
  font-weight: 400;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;

  ${media.tablet`
    background: transparent;
    padding-top: 0;
    padding-bottom: 0;
  `}
`

export const PersonImage = styled.div`
  text-align: center;

  & img {
    border-radius: 50%;
    margin: 0 auto -50px auto;
  }

  ${media.tablet`
    min-width: 100px;
    margin-right: 25px;
  `}
`

export const PersonName = styled.h1`
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 28px;
  line-height: 31px;
  letter-spacing: 0.015em;
  text-transform: none;
  margin-bottom: 20px;

  ${media.tablet`
    font-size: 36px;
    line-height: 40px;
  `}

  ${media.desktopLarge`
    font-size: 48px;
    line-height: 50px;
  `}
`

export const PersonRole = styled.p`
  margin-bottom: 15px;

  ${media.tablet`
    max-width: 440px;
  `}
`

export const PersonBirthdate = styled.p`
  margin-bottom: 15px;
`
export const PersonNationality = styled.p`
  margin-bottom: 15px;
`

export const MediaLinks = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
  flex: 0 0 auto;
  display: flex;
  justify-content: flex-start;
`

export const MediaItem = styled(Button)`
  margin-right: 26px;
`

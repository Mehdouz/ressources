import React, { useRef } from 'react'
import { StyledSlice, MotionReferrer, BackgroundImage, Container, SectionTitle, Title, Subtitle } from './TabsPageBanner.style'
import { media } from '@axacom-client/base/style/variables'
import { useScroll, useTransform, circOut } from 'framer-motion/dist/framer-motion'

export default function TabsPageBanner({ title, bannerTitle, bannerSubtitle, bannerImage, children }) {
  const contentRef = useRef(null)

  // Calculate the scrollProgression while on cover & transform it to make parallax effect
  let { scrollYProgress } = useScroll({
    target: contentRef,
    offset: ['-115px start', 'end start'],
  })
  let y = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  let opacity = useTransform(scrollYProgress, [0, 1], [0.5, 0.1], { ease: circOut })

  return (
    <StyledSlice data-testid="FullBanner">
      <MotionReferrer ref={contentRef} />
      <Container>
        <SectionTitle>{title}</SectionTitle>
        <Title>{bannerTitle}</Title>
        <Subtitle>{bannerSubtitle}</Subtitle>
        {children}
      </Container>
      <picture>
        <source media={`(max-width: ${media.phoneMax}px)`} srcSet={bannerImage?.views?.small.url} />
        <source media={`(min-width: ${media.desktopMax}px)`} srcSet={bannerImage?.views?.medium.url} />
        <BackgroundImage data-testid="FullBanner_Image" style={{ y, opacity }} src={bannerImage?.main.url} alt={bannerImage?.main?.alt} />
      </picture>
    </StyledSlice>
  )
}

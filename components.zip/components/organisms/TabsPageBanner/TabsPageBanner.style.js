import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Slice } from '../SimpleSlice/SimpleSlice'
import { font, colors } from '@axacom-client/base/style/variables'
import { Typo15 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Button from '@axacom-client/components/atoms/Button/Button'
import { motion } from 'framer-motion/dist/framer-motion'

export const StyledSlice = styled(Slice)`
  position: relative;
  background-color: #000;

  ${media.desktop`
    padding-bottom: 0px;
  `}
`

export const MotionReferrer = styled.div`
  position: absolute;
  top: 0;
  bottom: 0;
  height: 100%;
  width: 100%;
`

export const Container = styled.div`
  padding-right: 15px;
  padding-left: 15px;
  position: relative;
  color: ${colors.white};
  z-index: 10;

  ${media.tablet`
    padding: 0 15px;
  `}

  ${media.desktop`
    padding: 0 15px;
  `}
`

export const TopBanner = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`

export const SectionTitle = styled.p`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.1em;
  line-height: 1.5;
  text-align: center;
  color: ${colors.white};
  letter-spacing: 0.08em;
  margin-top: 20px;

  ${media.tablet`
    ${Typo15}
  `}
`

export const Title = styled.h1`
  font-size: 32px;
  line-height: 34px;
  letter-spacing: 0.015em;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  text-align: center;
  display: block;
  margin: 30px 0;

  ${media.tablet`
    padding: 0 95px;
    font-size: 72px;
    line-height: 74px;
  `}
`

export const Subtitle = styled.span`
  text-align: center;
  color: ${colors.white};
  display: block;
  margin: 30px 0;
  margin-bottom: 70px;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  font-size: 18px;
  line-height: 24px;

  ${media.desktop`
    display: block;
    text-align: center;
    padding: 0 95px;
    font-size: 24px;
    line-height: 34px;
  `}
`

export const BackgroundImage = styled(motion.img)`
  position: absolute;
  top: -10%;
  left: 0;
  z-index: 0;
  height: 110%;
  object-fit: cover;
  opacity: 0.7;

  ${media.tablet`
    height: auto;
    width: 100%;
  `}
`

export const Cta = styled(Button)`
  margin-top: 20px;
`

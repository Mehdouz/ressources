import { Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  twoFiguresSlice: Slice(
    {
      anchorPoint: Text('Anchor ID (same as the anchors block)', 'my-anchor-id'),
      title: Text('Title', 'Write the title here'),
      subtitle: Text('Subtitle', 'Write the subtitle here'),
    },
    {
      number: Text('Figure number (mandatory)', 'Write the figure number here'),
      legend: Text('Figure legend', 'Write the figure legend here'),
      title: Text('Figure title (mandatory)', 'Write the figure title here'),
      subtitle: Text('Figure subtitle', 'Write the figure subtitle here'),
    },
    'Two Figures Block',
    'React component'
  ),
}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const MainTitle = styled.h2`
  text-align: center;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 1.75rem;
  line-height: 31px;
  letter-spacing: 0.015em;
  margin: 50px auto 15px;

  ${media.tablet`
    width: 90%;
    font-size: 2.25rem;
    line-height: 40px;
  `}

  ${media.desktop`
    width: 60%;
    font-size: 3rem;
    line-height: 50px;
  `}
`

export const FigureContainer = styled.div`
  padding-bottom: 75px;
  margin: 60px 0 0;
  border-bottom: 1px solid ${colors.gray};

  ${media.tablet`
    padding-bottom: 0;
    margin: 60px 40px 0;
    display: flex;
  `}

  ${media.desktopLarge`
    position: relative;
    margin: 0;
    border-bottom: 0;
  `}
`

export const NumberContainer = styled.div`
  margin-bottom: 15px;

  ${media.tablet`
    width: 50%;
    margin-right: 30px;
  `}

  ${media.desktopLarge`
    margin-right: 0;
    position: absolute;
    left: 0;
    top: 0;
  `}
`

export const Number = styled.p`
  color: #94c980;
  display: block;
  text-align: center;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  line-height: 1;
  font-size: 12.5rem;

  ${media.tablet`
    margin-bottom: 10px;
    font-size: 8.75rem;

  `}

  ${media.desktopLarge`
    font-size: 17.5rem;
  `}
`

export const NumberLegend = styled.p`
  color: #94c980;
  display: block;
  text-align: center;
  font-family: 'Source Sans Pro', sans-serif;
  font-weight: 600;
  font-size: 1.75rem;
  letter-spacing: 0.1em;
  line-height: 1.5;
  text-transform: uppercase;
  margin-bottom: 30px;

  ${media.tablet`
    font-size: 1.063rem;
  `}

  ${media.desktopLarge`
    font-size: 1.313rem;
  `}
`

export const Description = styled.div`
  ${media.tablet`
    margin-left: 30px;
    width: 50%;
    float: right;
    margin-bottom: 50px;
  `}

  ${media.desktopLarge`
    margin-left: 53%;
    padding-bottom: 40px;
    margin-bottom: 0;
    border-bottom: 1px solid ${colors.gray};
  `}
`

export const FigureTitle = styled.p`
  display: block;
  text-align: center;
  margin-bottom: 30px;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 2.75rem;
  letter-spacing: 0.015em;
  line-height: 1.5;

  ${media.tablet`
    text-align: left;
    margin-bottom: 10px;
    font-size: 1.625rem;
  `}

  ${media.desktopLarge`
    font-size: 1.75rem;
  `}
`

export const FigureSubtitle = styled.p`
  color: ${colors.grayDark};
  text-align: center;
  font-family: "Source Sans Pro", sans-serif;
  font-weight: ${font.weight.regular};
  font-size: ${font.fontSizeBase.mobile}
  line-height: 1.75rem;

  ${media.tablet`
    text-align: left;
  `}

  ${media.desktopLarge`
    font-size: 1.25rem;
    line-height: 2.125rem;
  `}
`

export const FigureContent = styled.div`
  ${FigureContainer}:nth-child(2) {
    border: 0;
    margin-top: 90px;

    ${media.tablet`
      flex-direction: row-reverse;
      margin-top: 50px;
    `}

    ${media.desktopLarge`
      margin-left: 53%;
      margin-top: 40px;
      justify-content: space-between;
    `}
  }

  ${FigureContainer}:nth-child(2) ${NumberContainer} {
    ${media.tablet`
      margin-left: 30px;
      margin-right: 0;
    `}

    ${media.desktopLarge`
      margin-left: 0;
      position: relative;
      flex-grow: 1;
    `}
  }

  ${FigureContainer}:nth-child(2) ${FigureTitle} {
    ${media.tablet`
      margin-left: 0;
      margin-right: 30px;
    `}

    ${media.desktopLarge`
      margin: 0;
      padding-right: 30px;
      border-bottom: 0;
    `}
  }

  ${FigureContainer}:nth-child(2) ${FigureSubtitle} {
    ${media.desktopLarge`
      width: 100%;
    `}
  }

  ${FigureContainer}:nth-child(2) ${Description} {
    ${media.tablet`
      margin-left: 0;
      margin-right: 30px;
    `}

    ${media.desktopLarge`
      margin: 0;
      padding-right: 30px;
      border-bottom: 0;
    `}
  }

  ${FigureContainer}:nth-child(2) ${Number} {
    font-size: 9.375rem;

    ${media.desktopLarge`
      font-size: 9.375rem;
    `}
  }
`

export const ErrorMessage = styled.p`
  padding: 150px 40px;
  color: ${colors.errorRed};
  ${Typo43}
`

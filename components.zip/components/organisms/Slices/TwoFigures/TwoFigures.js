import React from 'react'
import { Container } from 'reactstrap'
import { string, array } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Slice, SliceSubtitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import {
  Number,
  NumberLegend,
  NumberContainer,
  Description,
  FigureTitle,
  FigureSubtitle,
  FigureContainer,
  FigureContent,
  MainTitle,
  ErrorMessage,
} from '@axacom-client/components/organisms/Slices/TwoFigures/TwoFigures.style'

const TwoFigures = ({ items, anchorPoint, subtitle, title }) => {
  const mandatoryFields = [items[0].title, items[0].number, items[1].title, items[1].number]
  const { domain, currentLocale } = useGlobalContext()

  const errorMessages = {
    fr: 'Erreur, veuillez vérifier que tous les champs obligatoires sont bien remplis.',
    en: 'Something went wrong. Please check that all mandatory fields have been filled in.',
  }

  if (mandatoryFields.some((condition) => condition === undefined) && domain !== 'https://www.axa.com')
    return (
      <Container>
        <ErrorMessage>[Two Figures Block] : {currentLocale === 'en' ? errorMessages.en : errorMessages.fr}</ErrorMessage>
      </Container>
    )

  return (
    <Slice slugifiedAnchor={anchorPoint} fluid data-testid="TwoFigures">
      <Container>
        <div data-testid="TwoFigures__Header">
          {title && <MainTitle data-testid="MainTitle">{title}</MainTitle>}
          {subtitle && <SliceSubtitle>{subtitle}</SliceSubtitle>}
        </div>
        <FigureContent data-testid="TwoFigures__Content">
          {items.slice(0, 2).map(({ number: number, legend: legend, subtitle: subtitle, title: title }, index) => (
            <FigureContainer key={index}>
              <NumberContainer>
                <Number data-testid="TwoFigures__Number">{number}</Number>
                <NumberLegend data-testid="TwoFigures__NumberLegend">{legend}</NumberLegend>
              </NumberContainer>
              <Description data-testid="TwoFigures__Description">
                <FigureTitle data-testid="TwoFigures__FigureTitle">{title}</FigureTitle>
                <FigureSubtitle data-testid="TwoFigures__FigureSubtitle">{subtitle}</FigureSubtitle>
              </Description>
            </FigureContainer>
          ))}
        </FigureContent>
      </Container>
    </Slice>
  )
}

export default TwoFigures

TwoFigures.propTypes = {
  anchorPoint: string,
  items: array,
  subtitle: string,
  title: string,
}

import { Embed, Image, Link, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../SimpleSlice/SimpleSlice.types'

export default {
  cover: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title (Mandatory)', 'Select a title', true),
      subtitle: Text('Subtitle (Mandatory)', 'Select a subtitle'),
      shortTitle: Text('Short title', 'Select a short title'),
      video: Embed(),
      banner: Image(
        'Banner Image (Mandatory)',
        {
          width: 1920,
        },
        [
          {
            name: 'small',
            width: 768,
            height: 576,
          },
          {
            name: 'Medium',
            width: 970,
            height: 576,
          },
        ]
      ),
      backgroundVideoMp4: Link('Background vidéo (mp4)'),
      backgroundVideoWebm: Link('Background vidéo (webm)'),
    },
    {
      bannerButtonName: Text('Button Name', 'Button name'),
      bannerButtonLink: Link('Button Link'),
    },
    'Cover image or video loop',
    'React Component',
    'panorama'
  ),
}

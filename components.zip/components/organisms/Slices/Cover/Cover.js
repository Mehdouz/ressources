import { media } from '@axacom-client/base/style/variables'
import Button from '@axacom-client/components/atoms/Button/Button'
import YoutubePlayer from '@axacom-client/components/molecules/YoutubePlayer/YoutubePlayer'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { CoverSubtitle } from '@axacom-client/components/organisms/Slices/Cover/Cover.style'
import { circOut, useScroll, useTransform } from 'framer-motion/dist/framer-motion'
import React, { useRef } from 'react'
import {
  BackgroundImage,
  ButtonContainer,
  CoverContainer,
  CoverSection,
  CoverTitle,
  CoverWithVideoContainer,
  CoverWithVideoSection,
  SectionName,
  StyledResponsiveContainer,
  VideoContainer,
} from './Cover.style'

const Cover = (props) => {
  const { items, banner, sectionName, subtitle, video, title, slugifiedAnchor } = props

  const contentRef = useRef(null)

  // Calculate the scrollProgression while on cover & transform it to make parallax effect
  let { scrollYProgress } = useScroll({
    target: contentRef,
    offset: ['-115px start', 'end start'],
  })
  let y = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  let opacity = useTransform(scrollYProgress, [0, 1], [0.5, 0.1], { ease: circOut })

  if (video) {
    return (
      <Slice data-testid="CoverSection" slugifiedAnchor={slugifiedAnchor} className="py-0">
        <CoverWithVideoSection ref={contentRef} data-testid="CustomContainer" $bannerExist={banner}>
          <picture>
            <source media={`(min-width: ${media.desktopMin}px)`} srcSet={banner?.main.url} />
            <source media={`(min-width: ${media.tabletMin}px)`} srcSet={banner?.views?.medium.url} />
            <BackgroundImage data-testid="FullBanner_Image" style={{ y, opacity }} src={banner?.views?.small.url} alt={banner?.main?.alt} />
          </picture>

          <StyledResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
            <CoverWithVideoContainer>
              {title && <CoverTitle data-testid="CoverTitle">{title}</CoverTitle>}
              {subtitle && <CoverSubtitle data-testid="CoverSubtitle">{subtitle}</CoverSubtitle>}
              <Buttons items={items}></Buttons>
            </CoverWithVideoContainer>
            <VideoContainer>
              <YoutubePlayer {...video} />
            </VideoContainer>
          </StyledResponsiveContainer>
        </CoverWithVideoSection>
      </Slice>
    )
  } else {
    return (
      <Slice data-testid="CoverSection" slugifiedAnchor={slugifiedAnchor} className="py-0">
        <CoverSection ref={contentRef} data-testid="CustomContainer" $bannerExist={banner}>
          <picture>
            <source media={`(min-width: ${media.desktopMin}px)`} srcSet={banner?.main.url} />
            <source media={`(min-width: ${media.tabletMin}px)`} srcSet={banner?.views?.medium.url} />
            <BackgroundImage data-testid="FullBanner_Image" style={{ y, opacity }} src={banner?.views?.small.url} alt={banner?.main?.alt} />
          </picture>

          <CoverContainer>
            {sectionName && (
              <SectionName as="h1" data-testid="SectionName" className="text-center">
                {sectionName}
              </SectionName>
            )}
            {title && <CoverTitle data-testid="CoverTitle">{title}</CoverTitle>}
            {subtitle && <CoverSubtitle data-testid="CoverSubtitle">{subtitle}</CoverSubtitle>}
            <Buttons items={items}></Buttons>
          </CoverContainer>
        </CoverSection>
      </Slice>
    )
  }
}

function Buttons({ items }) {
  const hasButtons = items && !!items.length && !!Object.keys(items[0]).length
  if (!hasButtons) return null

  return (
    <ButtonContainer className="justify-content-center">
      {items.map((item, index) => {
        return (
          <Button
            key={index}
            size="large"
            type={index === 0 ? 'primary' : 'ghost'}
            color="white"
            url={item?.bannerButtonLink?.url}
            target={item?.bannerButtonLink?.target && item?.bannerButtonLink?.target === 'web' ? '_blank' : '_self'}
            ariaLabel={item?.bannerButtonName}
            data-testid="CoverButton"
          >
            {item?.bannerButtonName}
          </Button>
        )
      })}
    </ButtonContainer>
  )
}

export default Cover

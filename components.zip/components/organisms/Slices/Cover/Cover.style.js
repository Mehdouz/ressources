import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import Text from '@axacom-client/components/molecules/Text/Text'
import { motion } from 'framer-motion/dist/framer-motion'
import styled from 'styled-components'
import media from '../../../../base/style/media'
import { getSpacing } from '../../../../base/style/spacing'
import { Typo16, Typo20, Typo50 } from '../../../../base/style/typoStyle/typoStyle'
import { colors } from '../../../../base/style/variables'

export const CoverWithVideoContainer = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
  padding: 0 24px;
  ${media.desktop`
    width: 55%;
    text-align: left;
    align-items: flex-start;
    justify-content: center;
  `}
`

export const CoverContainer = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24px;
  padding: 0 24px;
  text-align: center;
`

export const StyledResponsiveContainer = styled(ResponsiveContainer)`
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 36px;
  ${media.desktop`
    flex-direction: row;
  `}
`

export const VideoContainer = styled.div`
  padding: 48px 24px 0 24px;
  max-width: 750px;
  ${media.desktop`
    margin: 0 auto;
    width: 45%;
    padding: 0;
  `}
`

export const CoverWithVideoSection = styled.section`
  position: relative;
  overflow: hidden;
  align-items: center;
  padding: 72px 0;
  background-color: ${(props) => (props.$bannerExist ? `#000` : `${colors.ocean200}`)};
  min-height: 400px;
`

export const CoverSection = styled.section`
  position: relative;
  align-items: center;
  padding: 72px 0;
  background-color: ${(props) => (props.$bannerExist ? `#000` : `${colors.ocean200}`)};
  min-height: 400px;

  display: flex;
  justify-content: center;
  align-items: center;
`

export const ButtonContainer = styled.div`
  display: flex;
  gap: 24px;
`

export const BackgroundImage = styled(motion.img)`
  position: absolute;
  top: -10%;
  left: 0;
  z-index: 0;
  height: 110%;
  width: 100%;
  object-fit: cover;
  opacity: 0.7;
`

export const SectionName = styled(Text)`
  ${Typo16}
  margin: 0 0 ${getSpacing(2)};
  color: ${colors.white};
  text-transform: uppercase;

  ${media.tablet`
    margin: 0 0 ${getSpacing(4)};
  `}

  &:after {
    content: ' ';
    position: absolute;
    top: ${getSpacing(4)};
    left: 50%;
    width: ${getSpacing(6)};
    border: 1px solid ${colors.white};
    transform: translateX(-50%);
  }
`

export const CoverTitle = styled(Text)`
  ${Typo50}
  color: ${colors.white};

  max-width: 750px;
  ${media.desktop`
    margin: 0;
  `}
`

export const CoverSubtitle = styled(Text)`
  ${Typo20}
  color: ${colors.white};
  margin: 0 auto;

  max-width: 750px;
  ${media.desktop`
    max-width: 500px;
    margin: 0;
  `}
`

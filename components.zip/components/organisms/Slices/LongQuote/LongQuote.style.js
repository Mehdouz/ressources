import styled from 'styled-components'
import Text from '@axacom-client/components/molecules/Text/Text'
import { Typo18, Typo24 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '../../../../base/style/media'

export const QuoteContent = styled(Text)`
  ${media.phone`
    ${Typo18};
    line-height: 28px;
  `}

  ${media.tablet`
    ${Typo18};
    line-height: 28px;
    padding-top: 30px;
  `}

  ${media.desktop`
    ${Typo24};
    line-height: 34px;
    padding-top: 20px;
  `}

  font-style: italic;
  font-weight: lighter !important;

  p :before,
  p :after {
    content: '\\201C';
    display: inline;
  }
`

export const Wrapper = styled.div`
  display: flex;
  flex-direction: column;

  ${media.tablet`
    flex-direction: row;
  `}
`
export const AuthorWrapper = styled.div`
  ${media.tablet`
    width: 40%;
    padding-right: 25px;
    margin-left: -85px;
  `}

  ${media.desktop`
    padding-right: 40px;
    margin-left: -100px;
  `}
`

export const QuoteWrapper = styled.div`
  ${media.tablet`
    width: 60%;
    flex-basis: fit-content;
  `}
`

import { Group, Image, Link, Text, StructuredText } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  'long-quote': Group(
    {
      anchorPoint: Text('Anchor Label', 'Anchor Label'),
      author: Link('Author', 'document', ['person']),
      authorPicture: Image('Author picture', { width: 100, height: 100 }),
      authorName: Text('Author name', 'Fill author name'),
      authorRole: Text('Author role', 'Fill author role'),
      quote: StructuredText('Structured text', 'Fill up your quote text'),
    },
    'Long quote',
    false,
    'Long quote',
    'React Component',
    'format_quote'
  ),
}

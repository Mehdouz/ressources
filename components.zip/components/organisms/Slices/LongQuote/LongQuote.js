import React from 'react'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import Author from '@axacom-client/components/molecules/Author/Author'
import { QuoteContent, Wrapper, AuthorWrapper, QuoteWrapper } from '@axacom-client/components/organisms/Slices/LongQuote/LongQuote.style'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'

const LongQuote = (props) => {
  const item = props[0] || props
  const { authorName, authorRole, slugifiedAnchor, author, authorPicture, quote } = item
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} data-testid="LongQuote">
      <Container>
        <CenteredReadingContainer>
          <Wrapper>
            <AuthorWrapper>
              <Author {...{ authorName, authorRole, slugifiedAnchor, author, authorPicture }} dataTestId="LongQuote" />
            </AuthorWrapper>
            <QuoteWrapper>
              <QuoteContent data-testid="LongQuoteContent">{quote}</QuoteContent>
            </QuoteWrapper>
          </Wrapper>
        </CenteredReadingContainer>
      </Container>
    </Slice>
  )
}

export default LongQuote

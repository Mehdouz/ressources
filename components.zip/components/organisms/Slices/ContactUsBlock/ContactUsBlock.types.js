import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'
import { Slice } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  contactUsBlock: Slice(
    {
      anchorId: simpleSlice.anchorId,
      sliceTitle: simpleSlice.title,
      sliceSubtitle: simpleSlice.subtitle,
    },
    {},
    'Contact Form Block. [To pre-fill the recipient in the form, please add #xxx at the end of the link to the contact form (#privacy #shareholders #investor #media #webmaster)]',
    'React component',
    'message'
  ),
}

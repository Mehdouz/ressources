export default {
  title: 'Exemple de titre',
  subtitle: 'Exemple de sous-titre',
}

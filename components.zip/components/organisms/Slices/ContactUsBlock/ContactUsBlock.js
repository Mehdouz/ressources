import React, { useEffect, useState } from 'react'
import { Col, Row, Container } from 'reactstrap'
import { array, object, oneOfType, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Slice, SliceTitle, SliceSubtitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import Form from '@axacom-client/components/molecules/Form/Form'
import { getRouterPushParams } from '@axacom-client/services/urlResolver'
import { fillTopicsWithThemes } from '@axacom-client/services/document-service'
import { contactUs } from '@axacom-client/repositories/contactUs'
import { dolistApiGet } from '@axacom-client/repositories/dolist'
import { TechnicalError } from '@axacom-client/domains/errors'
import { i18n } from '@i18n-axa'
import log from '@axacom-client/logger'
import { slugify } from '@axacom-client/services/string-service'

// TODO: use get query instead of hash. The control over the business value needs to be done by the <Select /> (by the user) and not directly in the URL
export default function ContactUsBlock({ sliceTitle, sliceSubtitle, slugifiedAnchor, countries }) {
  // get an array string country sorted alphabetically
  const countriesOptions = Object.entries(countries)
    .map((c) => c[1])
    .sort((a, b) => a.localeCompare(b))

  const { i18n, Router, currentLocale } = useGlobalContext()
  const [formFields, setFormFields] = useState()

  // force client side rendering as Router.asPath can't be used serverside
  useEffect(() => {
    const businessValue = Router.asPath.substring(Router.asPath.indexOf('#') + 1)

    const fieldConfig = {
      firstName: {
        required: true,
        maximumLength: 50,
        alphaSpecial: true,
      },
      lastName: {
        required: true,
        maximumLength: 50,
        alphaSpecial: true,
      },
      company: {},
      country: {
        required: true,
        options: countriesOptions,
        style: { width: '100%' },
      },
      email: {
        required: true,
        email: true,
      },
      phone: {
        required: false,
        phoneValidation: true,
      },
      businessTeam: {
        required: true,
        ...(businessValue ? { defaultValue: businessValue } : {}),
      },
      message: { required: true },
      textContent: { children: i18n.t('contact-us:policy') },
      recaptcha: {
        required: true,
      },
      submit: {
        label: i18n.t('form.contact.send'),
      },
    }
    setFormFields(fieldConfig)
  }, [])

  const handleSubmit = async (form) => {
    try {
      const cleanedForm = { ...form, country: Object.entries(countries).find((el) => slugify(el[1]) === form.country)[0] }
      await contactUs(currentLocale, cleanedForm)
      const [pathname, as] = getRouterPushParams('contactUs-confirmation', currentLocale)
      log.info('[ContactUs] successful, redirecting to confirmation', { pathname, as })
      Router.push(pathname, as).catch((e) => log.error('[Router] cannot redirect to confirmation page', e))
    } catch (e) {
      log.error('[ContactUs] error: ', e)
      throw new TechnicalError()
    }
  }

  return (
    <Slice dataTestid="ContactUsBlock" slugifiedAnchor={slugifiedAnchor}>
      <Container>
        <Row>
          <SliceTitle data-testid="ContactUsBlock_title" $textAlign="center">
            {sliceTitle}
          </SliceTitle>
          <SliceSubtitle $textAlign="center">{sliceSubtitle}</SliceSubtitle>
          <Col lg={{ size: 6, offset: 3 }}>{formFields && <Form fields={formFields} handleSubmit={handleSubmit} />}</Col>
        </Row>
      </Container>
    </Slice>
  )
}

ContactUsBlock.getInitialProps = async ({ req, document }) => {
  const language = (req || i18n).language
  document.items = await fillTopicsWithThemes(
    document.items.map(({ cardArticle }) => ({ reference: cardArticle })),
    language
  )
  document.countries = await dolistApiGet('/countries', { language })
  return document
}

ContactUsBlock.propTypes = {
  sliceTitle: oneOfType([string, array]),
  sliceSubtitle: oneOfType([string, array]),
  slugifiedAnchor: string,
  countries: object,
}

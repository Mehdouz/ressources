import styled, { css } from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { MotionText } from '@axacom-client/components/molecules/Text/Text'
import { Typo38 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const List = styled(motion.ul)`
  display: flex;
  padding: 0;
  gap: 24px;
  margin-bottom: 0;
  margin-left: 10px;

  ${media.tablet`
    margin-bottom: 48px;
  `}
`

export const Slide = styled(motion.li)`
  display: flex;
  list-style: none;
  width: calc(100vw - 96px);
  height: auto;
  aspect-ratio: 640/710;
  ${media.tablet`
    width: 320px;
  `}
  flex-shrink: 0;
  position: relative;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;
  overflow: hidden;
  cursor: pointer;
  border: 2px solid transparent;
  will-change: transition;
  transition: transform 0.3s;
  transform-origin: center center;
  ${({ $isActive }) =>
    !$isActive
      ? media.tablet`
          transform: scale(${$isActive ? 1 : 0.9});
        `
      : ''}

  &:hover {
    & img {
      transform: scale(1.08);
    }
  }
`

export const SlideImg = styled.img`
  transition: all 0.2s ease-in-out;
  position: absolute;
  top: 0;
  height: 100%;
  will-change: transform;
  mix-blend-mode: multiply;
  filter: brightness(50%);
  z-index: 0;
  pointer-events: none;
`

export const ButtonList = styled(motion.ul)`
  position: relative;
  display: flex;
  padding: 0;
  justify-content: center;
  transition: opacity 0.2s linear;
  margin: 0 auto;

  ${media.tablet`
    display: flex;
  `}
`

export const ButtonItem = styled.li`
  display: flex;
  justify-content: center;
  text-align: center;
  z-index: 0;
  opacity: 1;
  transition: opacity 0.2s linear;
  font-size: 0;
`

export const Stroke = styled(motion.div)`
  color: ${colors.grey800};
  font-size: 20px;
  margin-top: 5px;
  transform-origin: left;
`

export const SlideYear = styled.p`
  color: ${colors.white};
  position: relative;
  padding: 12px 20px;

  width: auto;
  font-size: 2rem;
  ${media.tablet`
    font-size: 22px;
  `}
  font-family: ${font.fontFamilyHeading};
  font-weight: 700;
  line-height: 2.33rem;
  z-index: 2;
  &:before {
    content: ' ';
    z-index: -1;
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    transform-origin: 0 0;
    transition: all 0.2s ease-in-out 0.1s;
    transform: scaleX(${({ $isActive }) => ($isActive ? 1 : 0)});
    background-color: ${({ $color }) => $color};
  }
`

export const SlideText = styled.h3`
  line-height: 24px;
  color: ${colors.white};
  position: relative;
  z-index: 0;
  padding: 24px;
  margin-bottom: 0;
`

export const Dot = styled(motion.button)`
  display: inline-block;
  position: relative;
  vertical-align: middle;
  padding: 7px;
  height: 40px;
  width: 40px;
  border-radius: 50%;
  border-width: 2px;
  border-style: solid;
  border-color: ${colors.grey800};
  margin: 0px 6px 30px;
  background: rgb(255, 255, 255);
  transition: all 0.2s linear;

  &:before {
    content: '';
    width: 100%;
    height: 100%;
    border-color: ${({ $color }) => $color};
    background: ${({ $color }) => $color};
    position: absolute;
    top: 0;
    left: 0;
    border-radius: 100%;
    opacity: 0;
    transform: scale(0);
    transition: all 0.2s ease-out 0.1s;
  }

  ${({ $isActive }) =>
    $isActive
      ? css`
          border: 2px solid ${({ $color }) => $color};
          &:before {
            opacity: 1;
            transform: scale(0.7);
          }
        `
      : ''}

  &:hover {
    &:before {
      opacity: ${({ $active }) => ($active ? 1 : 1)};
      transform: scale(${({ $active }) => ($active ? 0.7 : 0.7)});
    }
  }

  &:focus {
    outline: none;
    box-shadow: none;
  }
`

export const Label = styled.span`
  font-size: 1.33rem;
  font-weight: 700;
  line-height: 1.56rem;
  transition: color 0.3s ease-out;
  color: ${({ $isActive }) => ($isActive ? colors.textColor : colors.gray)};
  font-family: ${font.fontFamilyHeading};
  position: absolute;
  bottom: -35px;
  left: 50%;
  transform: translateX(-50%);
`

export const Border = styled.div`
  border-top: 1px solid ${colors.gray};
  margin-top: 15px;
  margin-bottom: 30px;

  ${media.tablet`
    margin-top: 0;
    margin-bottom: 36px;
  `}

  ${media.desktop`
    margin-left: 30px;
    margin-right: 30px;
  `}

  ${media.desktopLarge`
    margin-bottom: 56px;
  `}
`

export const Title = styled(MotionText)`
  ${Typo38}
  font-weight: bold;
  margin: 0;

  & h3 {
    margin-bottom: 32px;
  }
`

export const Subtitle = styled.p`
  font-family: ${font.fontFamilyBase};
  font-weight: 400;
  margin-bottom: 15px;

  ${media.tablet`
    margin-bottom: 30px;
  `}
`

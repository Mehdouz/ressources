import { Slice, Text, Image, StructuredText } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  keyDates: Slice(
    {
      title: StructuredText('Title', 'Write the title here', { single: 'heading3', label: 'Title' }),
      subtitle: Text('Subtitle', 'Subtitle'),
    },
    {
      year: Text('Year ', 'Year'),
      text: Text('Text', 'Max 60 characters'),
      image: Image('image', { width: 1920 }, [
        {
          name: 'small',
          width: 768,
          height: 432,
        },
        {
          name: 'Medium',
          width: 970,
          height: 545,
        },
      ]),
    },
    'Key Dates (Slider)',
    'React component'
  ),
}

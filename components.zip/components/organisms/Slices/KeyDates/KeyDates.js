import React, { useState, useRef } from 'react'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Subtitle, Title, Border, ButtonItem, ButtonList, Slide, List, SlideYear, SlideText, SlideImg, Dot, Stroke, Label } from './KeyDates.style'
import { useTimeline } from '@axacom-client/components/pages/timeline-v2/timeline-v2.page'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import useMeasure from 'react-use-measure'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'
import { mediaVariables } from '@axacom-client/base/style/media'
import { motion, useInView } from 'framer-motion/dist/framer-motion'

const variants = {
  visible: {
    transition: { staggerChildren: 0.1 },
  },
}

const itemsVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0 },
  scaled: { scale: 1.06, opacity: 1, x: 0 },
  unscaled: { scale: 1, opacity: 1, x: 0 },
}

const strokeVariants = {
  hidden: { scaleX: 0 },
  visible: { scaleX: 1, transition: { duration: 0.4 } },
}

const KeyDates = ({ title, subtitle, items, periodStep }) => {
  const [activeIndex, setActiveIndex] = useState(0)
  const { colors } = useTimeline()
  const isMobile = useBetterMediaQueries({ query: `(max-width: ${mediaVariables.phoneMax}px)` }, false)
  const [ref, bounds] = useMeasure()

  const offset = isMobile ? -bounds.width : -335 // arbitrary value

  let x = activeIndex * offset
  const isLast = items.length - 1 === activeIndex
  if (activeIndex === 1) {
    // 96 = margin-left + margin-right + space for the next element
    x = x + 96
  } else if (activeIndex > 1) {
    // numbers of slide * left-margin + (number of slice * space for the first and next element + margin-right)
    x = x + activeIndex * 24 + (activeIndex * 48 + (isLast ? 48 : 24))
  }

  const handlePanEnd = (e, info) => {
    const offsetX = info?.velocity?.x
    const val = reverseClamp(activeIndex + (offsetX > 0 ? -1 : 1), 0, items.length - 1)
    setActiveIndex(val)
  }

  const containerRef = useRef(null)
  const isInView = useInView(containerRef, { margin: '-100px', once: true })

  return (
    <Slice data-testid="Key_dates">
      <motion.div ref={ref}>
        <Container>
          <Border />
          <motion.div ref={containerRef} initial="hidden" animate={isInView ? 'visible' : 'hidden'} variants={variants}>
            <Title variants={itemsVariants}>{title}</Title>
            {subtitle ? <Subtitle>{subtitle}</Subtitle> : null}
            <List
              onPanEnd={handlePanEnd}
              animate={{
                x,
                transition: { duration: 0.3, ease: 'expoOut' },
              }}
            >
              {items.map((item, index) => {
                return (
                  <Slide key={index} onClick={() => setActiveIndex(index)} $isActive={activeIndex === index} animate={activeIndex === index ? 'scaled' : 'unscaled'} variants={itemsVariants}>
                    <SlideImg src={item?.image?.main?.url} alt={item?.image?.main?.alt} />
                    <SlideYear $color={colors[periodStep]} $isActive={activeIndex === index}>
                      {item?.year}
                    </SlideYear>
                    <SlideText>{item?.text}</SlideText>
                  </Slide>
                )
              })}
            </List>
            {!isMobile ? (
              <ButtonList initial="hidden" animate={isInView ? 'visible' : 'hidden'} variants={variants}>
                {items.map((item, indexButton) => (
                  <ButtonItem key={indexButton} onClick={() => setActiveIndex(indexButton)} $isActive={activeIndex === indexButton}>
                    <Dot data-testid="Slider-Dot" $color={colors[periodStep]} $isActive={activeIndex === indexButton} $indexbutton={indexButton} variants={itemsVariants}>
                      {`Slide ${indexButton}`}
                      {item?.year && (
                        <Label data-testid="Slider-DotLabel" $isActive={activeIndex === indexButton}>
                          {item?.year}
                        </Label>
                      )}
                    </Dot>
                    <Stroke variants={strokeVariants}>{items.length - 1 === indexButton ? '' : '......'}</Stroke>
                  </ButtonItem>
                ))}
              </ButtonList>
            ) : null}
          </motion.div>
        </Container>
      </motion.div>
    </Slice>
  )
}

export default KeyDates

function reverseClamp(value, min, max) {
  if (value > max) {
    return min
  } else if (value < min) {
    return max
  } else {
    return value
  }
}

import React from 'react'
import styled from 'styled-components'
import { object, string } from 'prop-types'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Typo28, Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'

import ContactItem from '@axacom-client/components/molecules/ContactItem/ContactItem'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

import { MinDesktop, MobilesDevices } from '@axacom-client/components/utils/Responsive'

import ContentCarousel, { Slide } from '@axacom-client/components/molecules/ContentCarousel/ContentCarousel'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'

const ContactsTitle = styled.h2`
  ${Typo43};
  text-align: left;
  margin: 0 0 ${getSpacing(4)};
`

const ContactSubtitle = styled.h4`
  ${Typo28};
  text-align: left;
`

const BorderBox = styled.div`
  box-sizing: border-box;
  height: 1px;
  width: 100%;
  border: 1px solid #cccccc;
  margin-bottom: ${getSpacing(3)};
`

const StyledContentCarousel = styled(ContentCarousel)`
  .carousel {
    & .carousel__inner-slide {
      padding-right: 15px;
    }
    & .carousel__slider {
      padding: 0;
    }
  }
`

const Contacts = ({ title, subtitle, link, linkName, slugifiedAnchor, ...contacts }) => {
  const ContactsItemsArr = contacts?.items.map((data) => data.contact)
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="Contacts">
      <Container>
        {title && <ContactsTitle data-testid="ContactsTitle">{title}</ContactsTitle>}
        <BorderBox />
        {subtitle && <ContactSubtitle data-testid="ContactSubtitle">{subtitle}</ContactSubtitle>}

        {/* Desktop version */}
        <MinDesktop>
          <div style={{ display: 'flex', gap: 24 }}>
            {ContactsItemsArr.map((ContactsItem, index) => (
              <ContactItem key={index} {...ContactsItem} style={{ width: '25%' }} />
            ))}
          </div>
        </MinDesktop>

        {/* Mobile version */}
        <MobilesDevices>
          <StyledContentCarousel showArrows={false} visibleSlides={2}>
            {Array.isArray(ContactsItemsArr) &&
              ContactsItemsArr.map((item, i) => (
                <Slide key={i} index={i}>
                  <ContactItem {...item}></ContactItem>
                </Slide>
              ))}
          </StyledContentCarousel>
        </MobilesDevices>

        {link && linkName && (
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <Button style={{ marginTop: 48 }} size="medium" type="ghost" color="red" href={link.url} data-testid="ContactButton">
              {linkName}
            </Button>
          </div>
        )}
      </Container>
    </Slice>
  )
}

Contacts.propTypes = {
  title: string,
  subtitle: string,
  link: object,
  linkName: string,
  anchorId: string,
  slugifiedAnchor: string,
}

export default Contacts

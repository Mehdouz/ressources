import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

// FIXME copy/paste this slice to contactsWithPhoto then update documents then remove slice contacts
export default {
  contacts: {
    type: 'Slice',
    fieldset: 'Contact with photo',
    icon: 'group_add',
    description: 'React component',
    'non-repeat': {
      anchorId: simpleSlice.anchorId,
      title: {
        type: 'Text',
        fieldset: 'contacts',
        config: {
          placeholder: 'Contact title',
          label: 'Contact title',
        },
      },
      subtitle: {
        type: 'Text',
        fieldset: 'Contacts',
        config: {
          placeholder: 'Contact subtitle',
          label: 'Contact subtitle',
        },
      },
      link: {
        type: 'Link',
        fieldset: 'Contact Link',
        config: {
          placeholder: 'Contact link',
        },
      },
      linkName: {
        type: 'Text',
        config: {
          label: 'Contact button name',
        },
      },
    },
    repeat: {
      contact: {
        type: 'Link',
        config: {
          select: 'document',
          masks: ['contact'],
          placeholder: 'Contact document',
        },
      },
    },
  },
}

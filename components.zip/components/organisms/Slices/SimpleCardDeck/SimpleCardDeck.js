import React from 'react'
import { array, bool, number, string } from 'prop-types'
import { Col, Row } from 'reactstrap'
import { Mobile, Tablet, MinDesktop } from '@axacom-client/components/utils/Responsive'
import Card from '@axacom-client/components/molecules/Card/Card'
import CardArticle from '@axacom-client/components/molecules/Card/CardArticle/CardArticle'
import { Slice, SliceSubtitle, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import ContentCarousel, { Slide } from '@axacom-client/components/molecules/ContentCarousel/ContentCarousel'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import Button from '@axacom-client/components/atoms/Button/Button'

export default function SimpleCardDeck({ title, subtitle, items, hideItemsSubtitle, itemPerLine, buttonLink, buttonText, bgColor, slugifiedAnchor }) {
  return (
    <Slice bgColor={bgColor} data-testid="SimpleCardDeck" slugifiedAnchor={slugifiedAnchor}>
      <Container>
        {title ? <SliceTitle $textAlign="center">{title}</SliceTitle> : null}
        {subtitle && subtitle.length > 0 ? <SliceSubtitle $textAlign="center">{subtitle}</SliceSubtitle> : null}
        {items && !!Object.keys(items[0]).length && (
          <>
            <Mobile>
              <ContentCarousel showArrows={false}>
                {items.map((item, i) => (
                  <Slide key={i} index={i}>
                    {items[0].reference?.type === 'article-v2' ? (
                      <CardArticle subtitle={hideItemsSubtitle && null} {...item} dataTestid="SimpleCardDeck_Card" />
                    ) : (
                      <Card subtitle={hideItemsSubtitle && null} {...item} dataTestid="SimpleCardDeck_Card" />
                    )}
                  </Slide>
                ))}
              </ContentCarousel>
            </Mobile>
            <Tablet>
              <ContentCarousel visibleSlides={2} showArrows={false}>
                {items.map((item, i) => (
                  <Slide key={i} index={i}>
                    {items[0].reference?.type === 'article-v2' ? (
                      <CardArticle subtitle={hideItemsSubtitle && null} {...item} dataTestid="SimpleCardDeck_Card" />
                    ) : (
                      <Card subtitle={hideItemsSubtitle && null} {...item} dataTestid="SimpleCardDeck_Card" />
                    )}
                  </Slide>
                ))}
              </ContentCarousel>
            </Tablet>
            <MinDesktop>
              <Row className="no-gutters">
                {items.map((item, index) => (
                  <Col key={index} sm={Math.ceil(12 / (itemPerLine || items.length))}>
                    {item.reference?.type === 'article-v2' ? (
                      <CardArticle key={index} reference={item.reference} subtitle={hideItemsSubtitle && null} dataTestid="SimpleCardDeck_Card" />
                    ) : (
                      <Card key={index} {...item} subtitle={hideItemsSubtitle && null} dataTestid="SimpleCardDeck_Card" />
                    )}
                  </Col>
                ))}
              </Row>
            </MinDesktop>
          </>
        )}
      </Container>

      {buttonLink && (
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: 32 }}>
          <Button url={buttonLink.url} type="ghost" color="red">
            {buttonText}
          </Button>
        </div>
      )}
    </Slice>
  )
}

SimpleCardDeck.propTypes = {
  title: string,
  subtitle: array,
  items: array.isRequired,
  hideItemsSubtitle: bool,
  itemPerLine: number,
  bgColor: string,
  anchorId: string,
  slugifiedAnchor: string,
}

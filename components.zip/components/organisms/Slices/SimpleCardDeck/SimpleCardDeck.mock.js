export default {
  items: [
    {
      image: {
        main: {
          dimensions: {
            width: 1920,
            height: 1152,
          },
          alt: '',
          copyright: '',
          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/7063133c41c70e52143088be8d8c947db90d4089_vivatech-banner-template.jpg',
        },
        views: {
          thumbnails: {
            dimensions: {
              width: 768,
              height: 432,
            },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/e0ac6a73e37c2eb21168a4ceca55265b9a72661a_vivatech-banner-template.jpg',
          },
        },
      },
      title: 'Accompagner le développement des entreprises',
      subtitle: [],
      text: [
        {
          type: 'paragraph',
          text: 'En couvrant l’entreprise contre les dégâts qu’elle pourrait subir ou causer, l’assurance dommages permet à celle-ci de se développer plus sereinement et d’investir pour l’avenir.',
          spans: [],
        },
      ],
      buttonText: 'Button text',
      buttonLink: {
        url: 'https://www.axa.com',
        target: 'web',
      },
      bgColor: '',
      borderColor: '',
    },
    {
      image: {
        main: {
          dimensions: {
            width: 1920,
            height: 1152,
          },
          alt: '',
          copyright: '',
          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/7063133c41c70e52143088be8d8c947db90d4089_vivatech-banner-template.jpg',
        },
        views: {
          thumbnails: {
            dimensions: {
              width: 768,
              height: 432,
            },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/e0ac6a73e37c2eb21168a4ceca55265b9a72661a_vivatech-banner-template.jpg',
          },
        },
      },
      title: 'Accompagner le développement des entreprises',
      subtitle: [],
      text: [
        {
          type: 'paragraph',
          text: 'En couvrant l’entreprise contre les dégâts qu’elle pourrait subir ou causer, l’assurance dommages permet à celle-ci de se développer plus sereinement et d’investir pour l’avenir.',
          spans: [],
        },
      ],
      buttonText: 'Button text',
      buttonLink: {
        url: 'https://www.axa.com',
        target: 'web',
      },
      bgColor: '',
      borderColor: '',
    },
    {
      image: {
        main: {
          dimensions: {
            width: 1920,
            height: 1152,
          },
          alt: '',
          copyright: '',
          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/7063133c41c70e52143088be8d8c947db90d4089_vivatech-banner-template.jpg',
        },
        views: {
          thumbnails: {
            dimensions: {
              width: 768,
              height: 432,
            },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/e0ac6a73e37c2eb21168a4ceca55265b9a72661a_vivatech-banner-template.jpg',
          },
        },
      },
      title: 'Accompagner le développement des entreprises',
      subtitle: [],
      text: [
        {
          type: 'paragraph',
          text: 'En couvrant l’entreprise contre les dégâts qu’elle pourrait subir ou causer, l’assurance dommages permet à celle-ci de se développer plus sereinement et d’investir pour l’avenir.',
          spans: [],
        },
      ],
      buttonText: 'Button text',
      buttonLink: {
        url: 'https://www.axa.com',
        target: 'web',
      },
      bgColor: '',
      borderColor: '',
    },
  ],
  bgColor: 'gray',
  title: 'The title',
  subtitle: [
    {
      type: 'paragraph',
      text: 'The subtitle',
      spans: [],
    },
  ],
  buttonText: 'The buttonText',
  buttonLink: {
    url: '/en/page/2018-integrated-report',
    url_en: '/en/page/2018-integrated-report',
    url_fr: '/fr/page/rapport-integre-2018',
  },
}

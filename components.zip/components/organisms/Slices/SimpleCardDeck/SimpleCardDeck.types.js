import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  simpleCardDeck: {
    type: 'Slice',
    fieldset: 'Simple Card Deck',
    description: 'React component',
    icon: 'view_week',
    'non-repeat': {
      anchorId: simpleSlice.anchorId,
      bgColor: {
        type: 'Select',
        fieldset: 'Background color',
        config: {
          label: 'Select a background color (default: white)',
          options: ['white', 'gray'],
          default_value: 'white',
        },
      },
      title: {
        type: 'Text',
        config: {
          label: 'Title',
          placeholder: 'Select a title',
        },
      },
      subtitle: {
        type: 'StructuredText',
        config: {
          label: 'Subtitle',
          placeholder: 'Select a subtitle',
        },
      },
      buttonText: {
        type: 'Text',
        config: {
          label: "Bottom Button's text",
          placeholder: 'Select a text',
        },
      },
      buttonLink: {
        type: 'Link',
        config: {
          label: 'Bottom Button Link',
          placeholder: 'Choose your link',
        },
      },
    },
    repeat: {
      image: {
        type: 'Image',
        config: {
          label: "Card's image",
          placeholder: 'Upload an image...',
          constraint: {
            width: 1920,
          },
          thumbnails: [
            {
              name: 'thumbnails',
              width: 768,
              height: 432,
            },
          ],
        },
      },
      title: {
        type: 'Text',
        config: {
          label: "Card's Title",
          placeholder: 'Select a Text',
        },
      },
      text: {
        type: 'StructuredText',
        config: {
          label: "Card's Text",
          placeholder: 'Select a StructuredText',
        },
      },
      buttonText: {
        type: 'Text',
        config: {
          label: "Button's Text",
          placeholder: 'Select a Text',
        },
      },
      buttonLink: {
        type: 'Link',
        config: {
          label: 'Button Link',
          placeholder: 'Choose your link',
        },
      },
    },
  },
}

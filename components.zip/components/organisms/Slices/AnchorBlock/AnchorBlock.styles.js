import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Typo14 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const AnchorWrapper = styled.div`
  background: ${colors.des_gray};
  padding: 15px;
  margin-bottom: 50px;
  ${media.tablet`padding: 30px;`}
`

export const Title = styled.div`
  ${Typo14}
  color: ${colors.grayDark};
  margin-bottom: 30px;
`

export const ParagraphWrapper = styled.div`
  margin-bottom: 50px;
`

export default {
  paragraph:
    "<p>Travailler dans l’assurance implique de comprendre les risques auxquels nous devons faire face aujourd’hui, mais aussi ceux auxquels nous serons confrontés demain. Afin de concevoir les outils dont nous aurons besoin pour nous preparer à ces risques, le rôle d’un assureur consiste à anticiper leur impact potentiel sur l’ensemble de la société. C’est dans cette optique qu’AXA a récemment publié son étude sur les risques émergents au cours des cinq dernières années. En complément des résultats de 2018, l’équipe d’AXA Emerging Risks vous invite à découvrir les principales conclusions qu'elle a tirées de l'évolution de ces risques.</p><p>Pendant trois années consécutives, les personnes interrogées ont placé les changements climatiques (n° 1) et la cybersécurité (n° 2) en tête de liste des risques émergents. Par ailleurs, la perception de ces risques a presque doublé en importance depuis l’année dernière, ces deux réponses apparaissant respectivement dans les proportions de 63% et 54%. </p>",
  title: 'Title',
  items: [
    {
      anchorLabel: 'Changement climatique et cyber-risques : des préoccupations constantes d’une année sur l’autre.',
      anchorSlugified: 'Changement-climatique-et-cyberrisques-des-preoccupations-constantes-dune-annee-sur-lautre',
    },
    {
      anchorLabel: 'Risques financiers et médicaux : deux angles morts?',
      anchorSlugified: 'Risques-financiers-et-medicaux-deux-angles-morts?',
    },
    {
      anchorLabel: 'Trois tendances majeures des risques émergents en 2018',
      anchorSlugified: 'Trois-tendances-majeures-des-risques-emergents-en-2018',
    },
  ],
}

import React, { useState } from 'react'
import { func, string } from 'prop-types'
import styled from 'styled-components'
import { Typo18 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { colors, font } from '@axacom-client/base/style/variables'
import { MinDesktop } from '@axacom-client/components/utils/Responsive'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

const Link = styled.a`
  ${Typo18}
  font-family: ${font.fontFamilyHeading};
  color: ${colors.textColor};
  display: flex;
  justify-content: space-between;
  padding-bottom: 15px;
`
const Arrow = styled.div`
  display: block;
  opacity: ${({ isHovered }) => (isHovered ? 1 : 0)};
  align-self: center;
`

const AnchorLink = ({ label, slug, onLinkClick }) => {
  const [isHovered, setHovered] = useState(false)

  return (
    <Link
      href={`#${slug}`}
      onClick={(e) => onLinkClick(e, slug)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onFocus={() => setHovered(true)}
      onBlur={() => setHovered(false)}
      data-testid="AnchorLink"
    >
      <div>{label}</div>
      <MinDesktop>
        <Arrow isHovered={isHovered}>
          <Icon name="IconArrowDown" color={colors.brandRed} width={16} height={16} />
        </Arrow>
      </MinDesktop>
    </Link>
  )
}

AnchorLink.propTypes = {
  label: string.isRequired,
  slug: string.isRequired,
  onLinkClick: func,
}

export default AnchorLink

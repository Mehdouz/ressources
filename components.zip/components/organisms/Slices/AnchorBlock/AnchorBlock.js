import React from 'react'
import { array, object, oneOfType, string } from 'prop-types'
import { Col, Row } from 'reactstrap'
import gsap, { TweenLite } from 'gsap/dist/gsap'
import ScrollToPlugin from 'gsap/dist/ScrollToPlugin'
import { createBrowserHistory } from 'history'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { getWindow } from '@axacom-client/services/window-service'
import Text from '@axacom-client/components/molecules/Text/Text'
import { AnchorWrapper, ParagraphWrapper, Title } from './AnchorBlock.styles'
import AnchorLink from './AnchorLink'

gsap.registerPlugin(ScrollToPlugin)

export default function AnchorBlock({ title, paragraph, items }) {
  const { i18n } = useGlobalContext()

  let history
  if (typeof document !== 'undefined') {
    history = createBrowserHistory()
    history.listen(onPushState)
  }

  const onLinkClick = (e, slug) => {
    e.preventDefault()
    history.push(`#${slug}`)
  }

  return (
    <Slice data-testid="AnchorBlock">
      <Row>
        <Col md={6} lg={{ size: 5, offset: 1 }}>
          <AnchorWrapper>
            <Title data-testid="AnchorBlock_Title">{title || i18n.t('story.anchors.title.placeholder')}</Title>
            {items.map((a, i) => (
              <AnchorLink key={i} onLinkClick={onLinkClick} label={a.anchorLabel} slug={a.anchorSlugified} />
            ))}
          </AnchorWrapper>
        </Col>
        <Col md={5}>
          <ParagraphWrapper>
            {/* TODO : NE PLUS UTILISER LE CLASSNAME "contrib-text" */}
            <div className="contrib-text">
              <Text>{paragraph}</Text>
            </div>
          </ParagraphWrapper>
        </Col>
      </Row>
    </Slice>
  )
}

AnchorBlock.propTypes = {
  items: array.isRequired,
  title: string,
  paragraph: oneOfType([string, object, array]),
}

// ********** PRIVATE **********

function onPushState({ location }) {
  let slug = location && location.hash ? location.hash.replace('#', '') : ''
  // eslint-disable-next-line no-undef
  if (slug && document.querySelector(`[id="${slug}"]`)) {
    TweenLite.to(getWindow(), 0.2, { scrollTo: `[id="${slug}"]` })
  }
}

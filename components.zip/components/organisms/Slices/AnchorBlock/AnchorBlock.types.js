import { Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

const anchorBlock = Slice(
  {
    title: Text('Anchor Title'),
    paragraph: {
      type: 'StructuredText',
      config: {
        multi: 'paragraph, preformatted, heading1, heading2, heading3, heading4, heading5, heading6, strong, em, hyperlink, image, embed, list-item, o-list-item, o-list-item',
        label: 'Anchor paragraph',
        placeholder: 'Anchor Paragraph',
      },
    },
  },
  {},
  'Anchor block',
  'React component',
  'attach_file'
)

export default anchorBlock

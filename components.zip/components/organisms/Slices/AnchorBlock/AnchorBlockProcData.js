import compact from 'lodash/fp/compact'
import slugify from 'slugify'
import get from 'lodash/fp/get'
import flow from 'lodash/fp/flow'
import map from 'lodash/fp/map'

/**
 * Create the anchor slice
 *
 * @returns {*} anchor slice
 */
export function buildAnchorSlice(slice, body) {
  return {
    ...slice,
    value: {
      paragraph: slice.value.paragraph,
      title: slice.value.title,
      items: flow(
        map((s) => {
          const anchorLabel =
            get('value[0].anchorPoint[0].text')(s) ||
            get('value[0].anchorPoint')(s) ||
            get('value[0].anchorId')(s) ||
            get('value.anchorId')(s) ||
            get('value.anchorPoint[0].text')(s) ||
            get('value.anchorPoint')(s)
          return anchorLabel ? { anchorLabel: anchorLabel, anchorSlugified: slugify(anchorLabel, { remove: /[$*_+~.()'"!\-:@]/g }) } : false
        }),
        compact
      )(body),
    },
  }
}

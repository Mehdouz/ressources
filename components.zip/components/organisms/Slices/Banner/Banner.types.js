export default {
  $video: {
    type: 'Embed',
    config: {
      label: 'Banner video',
      placeholder: 'Paste a video URL',
    },
  },
  $banner: {
    type: 'Image',
    config: {
      placeholder: 'Banner Image',
      constraint: {
        width: 1920,
      },
      thumbnails: [
        {
          name: 'small',
          width: 768,
          height: 432,
        },
        {
          name: 'Medium',
          width: 970,
          height: 545,
        },
      ],
    },
  },
  $bannerStyle: {
    type: 'Select',
    config: {
      options: ['Inside banner', 'Full banner', 'Light banner', 'Video banner'],
      label: 'Banner display',
      placeholder: 'Choose banner style',
    },
  },
  $bannerLink: {
    type: 'Link',
    config: {
      placeholder: 'Reference',
      select: 'document',
      masks: ['publication', 'press-release'],
    },
  },
  $sectionName: {
    type: 'Text',
    config: {
      placeholder: 'Your section name',
      label: 'Section name',
    },
  },
  $bannerButtonName: {
    type: 'Text',
    config: {
      label: 'Button name',
    },
  },
  $bannerButtonLink: {
    type: 'Link',
    config: {
      placeholder: 'Button Link',
    },
  },
}

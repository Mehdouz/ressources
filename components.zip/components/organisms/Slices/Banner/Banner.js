import React from 'react'
import { array, object, string } from 'prop-types'
import styled from 'styled-components'
import YoutubePlayer from '@axacom-client/components/molecules/YoutubePlayer/YoutubePlayer'
import { Col, Container, Row } from 'reactstrap'
import Button from '@axacom-client/components/atoms/Button/Button'
import Text from '@axacom-client/components/molecules/Text/Text'
import media from '@axacom-client/base/style/media'
import { Typo18, Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

const BannerSection = styled.section`
  background: linear-gradient(rgba(0, 0, 0, 0.66), rgba(0, 0, 0, 0.66)), ${(props) => `url(${props?.$imageUrl}) no-repeat center center`};
  background-size: cover;
  min-height: calc(100vh - 70px);
  align-items: center;
  display: flex;
  padding: 30px 0;

  ${media.tablet`
    max-height: 805px;
  `}

  ${media.desktop`
    min-height: 529px;
    padding: 50px 0;
  `}
`

const BannerRow = styled(Row)`
  flex-direction: column;

  ${media.desktop`
    flex-direction: row;
    align-items: center;
  `}
`

const BannerCol = styled(Col)`
  &:first-child {
    margin-bottom: 50px;
    text-align: center;

    ${media.tablet`
      margin-bottom: 60px;
    `}

    ${media.desktop`
      margin: 0;
      text-align: left;
    `}
  }
`

const BannerTitle = styled(Text)`
  ${Typo43}
  margin: 0 0 20px;
  color: white;

  ${media.tablet`
    margin: 0 0 30px;
  `}
`
const BannerSubtitle = styled(Text)`
  ${Typo18}
  font-weight: 400;
  margin: 0 0 30px;
  color: white;
`

const Banner = ({ title, subtitle, video, ctaLabel, ctaLink, image }) => {
  const { i18n } = useGlobalContext()
  return (
    <Slice data-testid="Banner" className="py-0">
      <BannerSection $imageUrl={image?.main?.url}>
        <Container>
          <BannerRow data-testid="BannerRow">
            <BannerCol md={{ size: 10, offset: 1 }} lg={6} xl={5}>
              <BannerTitle as="h1" data-testid="BannerTitle">
                {title}
              </BannerTitle>
              <BannerSubtitle data-testid="BannerSubtitle">{subtitle}</BannerSubtitle>
              <Button
                type="primary"
                color="red"
                size="large"
                url={ctaLink?.url}
                target={ctaLink?.target && ctaLink?.target === 'web' ? '_blank' : '_self'}
                ariaLabel={!ctaLabel ? `${i18n?.t('readmore')}, ${title}` : ''}
                data-testid="BannerButtonReadmore"
              >
                {ctaLabel || i18n?.t('readmore')}
              </Button>
            </BannerCol>
            <BannerCol md={{ size: 10, offset: 1 }} lg={{ size: 6, offset: 0 }} xl={{ size: 5, offset: 1 }}>
              <YoutubePlayer {...video} />
            </BannerCol>
          </BannerRow>
        </Container>
      </BannerSection>
    </Slice>
  )
}

export default Banner

Banner.propTypes = {
  title: string,
  subtitle: array,
  video: object,
  image: object,
  ctaLabel: string,
  ctaLink: object,
}

Banner.defaultProps = {}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { font, colors } from '@axacom-client/base/style/variables'
import Button from '@axacom-client/components/atoms/Button/Button'
import ContentCarousel from '@axacom-client/components/molecules/ContentCarousel/ContentCarousel'
import PublicationItem from '@axacom-client/components/molecules/PublicationItem/PublicationItem'
import { Typo38 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const HeadingContainer = styled.div`
  margin-bottom: 32px;
`

export const PublicationsTitle = styled.h2`
  ${Typo38}
  color: ${colors.grayDarker};
  margin-bottom: 8px;
`

export const StyledContentCarousel = styled(ContentCarousel)``

export const PublicationsButton = styled(Button)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 16px;
  letter-spacing: 1px;
`

export const PublicationsContainer = styled.div`
  display: flex;
  justify-content: space-between;

  ${media.tablet`
    flex-wrap: wrap;
    gap: 48px;
  `}

  ${media.desktopLarge`
    flex-wrap: nowrap;
  `}

  ${media.desktopVeryLarge`
  `}
`

export const StyledPublicationItem = styled(PublicationItem)`
  ${media.phone`
    margin-left: 32px;
    margin-right: 32px;
  `}

  ${media.phone`
    img {
      height: 100%;
    }
  `}

  ${media.tablet`
    flex: 0 1;
    flex: 0 1 calc(50% - 48px);
  `}

  ${media.desktopLarge`
    flex: 0 1 25%;
  `}
`

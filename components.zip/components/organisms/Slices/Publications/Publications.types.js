import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'
import { Text, Link, Group, Slice } from '../../../../../tools/prismic/backup-types/generic-type'

const getAsSlice = ({ withAnchor } = { withAnchor: true }) => {
  let nonRepeat = {
    title: Text('Publications Title', 'Write your title here'),
    // Label desynchronized from field name for `linkName` as part of AXACO-4112
    // WARNING: renaming this field in Prismic will impact existing documents in all environment including PROD
    linkName: Text('All Publications Link label', 'Write your text here'),
    link: Link('All Publications Link', null, null, true, 'Link (web/document/media)'),
  }

  if (withAnchor) {
    nonRepeat = {
      anchorId: simpleSlice.anchorId,
      ...nonRepeat,
    }
  }

  const repeat = {
    publication: Link('Publication', 'document', ['publication']),
  }

  return {
    publicationsSlice: Slice(nonRepeat, repeat, 'Publications', 'React component'),
  }
}

const getAsNonSlice = ({ withAnchor } = { withAnchor: true }) => {
  let fragment = {
    $publicationsTitle: Text('Publications Title', 'Write your title here'),
    $publicationsLinkLabel: Text('All Publications Link label', 'Write your text here'),
    $publicationsLink: Link('All Publications Link', null, null, true, 'Link (web/document/media)'),
    $publications: Group(
      {
        publication: Link('Publication', 'document', ['publication']),
      },
      'Publications (2 to 4 items)',
      true
    ),
  }

  if (withAnchor) {
    fragment = {
      anchorId: simpleSlice.anchorId,
      ...fragment,
    }
  }

  return fragment
}

export const getPublications = ({ asSlice, withAnchor } = { asSlice: true, withAnchor: true }) => {
  const getFunction = asSlice ? getAsSlice : getAsNonSlice

  return getFunction({ withAnchor })
}

export default getPublications

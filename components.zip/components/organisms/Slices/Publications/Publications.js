import React from 'react'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Slide } from '@axacom-client/components/molecules/ContentCarousel/ContentCarousel'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Mobile, MinTablet } from '@axacom-client/components/utils/Responsive'

import { HeadingContainer, PublicationsTitle, StyledContentCarousel, PublicationsButton, PublicationsContainer, StyledPublicationItem } from './Publications.style'

const Publications = ({ title, link, linkName: linkLabel, slugifiedAnchor, publications, ...publicationsItems }) => {
  let publicationsItemsArr

  if (publications) {
    // If data are retrieved from the Group in Home-v2
    publicationsItemsArr = publications.map((item) => item.publication)
  } else if (publicationsItems.items) {
    // If data are retrieved from the Slice in Page-v2
    publicationsItemsArr = publicationsItems.items.map((data) => data.publication)
  } else {
    // If data are retrieved from the Group in Page-v1
    publicationsItemsArr = Object.keys(publicationsItems).map((i) => publicationsItems[i])
  }

  publicationsItemsArr = publicationsItemsArr.slice(0, 4)

  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="Publications" bgColor="gray">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <HeadingContainer data-testid="Publications__HeadingContainer">
          {title && <PublicationsTitle data-testid="Publications__Title">{title}</PublicationsTitle>}
          {link && linkLabel && (
            <PublicationsButton type="link" color="red" iconRight="IconArrowRight" href={link.url} data-testid="Publications__Button">
              {linkLabel}
            </PublicationsButton>
          )}
        </HeadingContainer>
      </ResponsiveContainer>

      <Mobile>
        <StyledContentCarousel showArrows={false} data-testid="Publications__Carousel">
          {Array.isArray(publicationsItemsArr) &&
            publicationsItemsArr &&
            publicationsItemsArr.map((item, i) => (
              <Slide key={i} index={i} data-testid="Publications__PublicationItemSlide">
                <StyledPublicationItem data-testid="Publications__PublicationItem" {...item}></StyledPublicationItem>
              </Slide>
            ))}
        </StyledContentCarousel>
      </Mobile>

      <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
        <MinTablet>
          <PublicationsContainer data-testid="Publications__Container">
            {publicationsItemsArr && publicationsItemsArr.map((publicationsItem, index) => <StyledPublicationItem key={index} {...publicationsItem} data-testid="Publications__PublicationItem" />)}
          </PublicationsContainer>
        </MinTablet>
      </ResponsiveContainer>
    </Slice>
  )
}

// TODO: remove that props[0]
export default function PublicationsWrapper(props) {
  // eslint-disable-next-line react/prop-types
  return <Publications {...(props[0] || props)}></Publications>
}

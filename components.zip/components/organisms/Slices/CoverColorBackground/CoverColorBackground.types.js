import { Embed, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../SimpleSlice/SimpleSlice.types'

export default {
  coverColorBackground: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'Select a title', true),
      subtitle: Text('Subtitle (Mandatory)', 'Select a subtitle'),
      shortTitle: Text('Short title', 'Select a short title'),
      video: Embed(),
    },
    {},
    'Cover Color Background',
    'React Component'
  ),
}

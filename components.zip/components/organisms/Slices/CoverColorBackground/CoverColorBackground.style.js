import styled from 'styled-components'
import { Col, Container } from 'reactstrap'
import Text from '@axacom-client/components/molecules/Text/Text'
import media from '../../../../base/style/media'
import { getSpacing } from '../../../../base/style/spacing'
import { colors } from './../../../../base/style/variables'
import { Typo20, Typo50 } from '../../../../base/style/typoStyle/typoStyle'

const StyledContainer = styled(Container)`
  position: relative;
  z-index: 10;
`
const CoverSection = styled.section`
  position: relative;
  overflow: hidden;
  align-items: center;
  padding: ${getSpacing(6)} 0;
  background-color: ${colors.ocean200};

  ${media.tablet`
    max-height: 800px;
  `}

  ${media.desktop`
    max-height: ${(props) => props.maxHeight}px;
    padding: ${getSpacing(12)} 0;
  `}
`

const CoverCol = styled(Col)`
  &:first-child {
    text-align: center;
    margin-bottom: ${getSpacing(3)};

    ${media.desktop`
      margin: 0;
      text-align: left;
      margin-bottom: ${getSpacing(7)};
    `}

    ${media.tablet`
      margin-bottom: ${getSpacing(7)};
    `}
  }
`

const CoverTitle = styled(Text)`
  ${Typo50}
  /* haut | horizontal | bas */
  margin: ${(props) => (props.video ? `0 0 ${getSpacing(4)}` : `${getSpacing(3)} 0 ${getSpacing(8)}`)};
  color: ${colors.white};
`

const CoverSubtitle = styled(Text)`
  ${Typo20}
  margin: 0 0 ${getSpacing(4)};
  color: ${colors.white};

  ${media.phone`
     margin: 0 0 ${getSpacing(3)};
  `}
`

export { StyledContainer, CoverCol, CoverSection, CoverTitle, CoverSubtitle }

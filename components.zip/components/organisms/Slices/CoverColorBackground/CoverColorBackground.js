import React, { useRef } from 'react'
import { Col, Row } from 'reactstrap'
import { StyledContainer, CoverCol, CoverSection, CoverTitle, CoverSubtitle } from './CoverColorBackground.style'
import YoutubePlayer from '@axacom-client/components/molecules/YoutubePlayer/YoutubePlayer'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

const CoverColorBackground = ({ title, subtitle, video, slugifiedAnchor }) => {
  const contentRef = useRef(null)

  return (
    <Slice data-testid="CoverColorBackgroundSection" slugifiedAnchor={slugifiedAnchor} className="py-0">
      <CoverSection ref={contentRef} maxHeight={805} data-testid="CustomContainer">
        <StyledContainer>
          {video ? (
            <Row>
              <CoverCol lg={6} xl={6}>
                {title && (
                  <CoverTitle data-testid="CoverColorBackgroundTitle" xs={{ size: 8 }} md={{ size: 8 }} video={video}>
                    {title}
                  </CoverTitle>
                )}
                {subtitle && (
                  <CoverSubtitle data-testid="CoverColorBackgroundSubtitle" xs={{ size: 8 }} md={{ size: 8 }}>
                    {subtitle}
                  </CoverSubtitle>
                )}
              </CoverCol>
              <Col md={{ size: 10, offset: 1 }} lg={{ size: 5, offset: 1 }} xl={{ size: 5, offset: 1 }} xs={{ size: 10, offset: 1 }} sm={{ size: 10, offset: 1 }}>
                <YoutubePlayer {...video} />
              </Col>
            </Row>
          ) : (
            <Row className="justify-content-center">
              <CoverCol sm="12" md="10" lg="6">
                {title && (
                  <CoverTitle data-testid="CoverColorBackgroundTitle" video={video} className="text-center">
                    {title}
                  </CoverTitle>
                )}
                {subtitle && (
                  <CoverSubtitle data-testid="CoverColorBackgroundSubtitle" xs={{ size: 8 }} md={{ size: 8 }} className="text-center">
                    {subtitle}
                  </CoverSubtitle>
                )}
              </CoverCol>
            </Row>
          )}
        </StyledContainer>
      </CoverSection>
    </Slice>
  )
}

export default CoverColorBackground

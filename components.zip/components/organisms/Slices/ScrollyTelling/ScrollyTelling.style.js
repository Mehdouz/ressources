import styled, { css } from 'styled-components'

import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo12, Typo19, Typo25 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

export const StyledSlice = styled(Slice)`
  ${({ isFirstScrollytellingSlice }) => css`
    padding: ${isFirstScrollytellingSlice ? '0 0 60px 0' : '60px 0'};
  `}

  ${({ bgColor }) => css`
    color: ${bgColor ? 'white' : colors.grayDarker};
    background-color: ${bgColor ? bgColor : 'white'};
  `}

  & .container {
    padding: 0;
  }

  ${media.desktop`
    padding: 80px 0;
  `};
`

export const ScrollyTellingWrapper = styled.div`
  display: flex;
  flex-direction: column;

  ${media.desktop`
    flex-direction: row;
  `};
`

export const LeftContainer = styled.div`
  ${media.desktop`
    width: 40%;
  `};
`

export const Credit = styled.p`
  text-align: right;
  margin-top: 3px;
  color: ${colors.white};
  opacity: 0.6;
  margin-right: 8px;
  ${Typo25}
  letter-spacing: initial;

  &:before {
    content: '©';
    position: relative;
    font-weight: ${font.weight.bold};
    font-size: 1rem;
    top: 0.5px;
    margin-right: 5px;
  }

  ${media.tablet`
    margin-right: 8px;
  `}
`

export const VideoPlayer = styled.video`
  width: 100%;
`

export const VideoContainer = styled.div`
  width: 100%;
  height: auto;
  margin-bottom: 60px;

  ${media.tablet`
    width:87%;
    margin-top: ${({ isFirstScrollytellingSlice }) => (isFirstScrollytellingSlice ? '-30px' : '0')};
    margin-bottom: 30px;
  `};

  ${media.desktop`
    width: 100%;
    top: 20%;
    position: sticky;
    margin-bottom: 0;
    margin-top: ${({ isFirstScrollytellingSlice }) => (isFirstScrollytellingSlice ? '-110px' : '0')};
  `};
`

export const Image = styled.img`
  width: 100%;
`

export const ImageContainer = styled.div`
  width: 100%;
  height: auto;
  margin-bottom: 60px;

  ${media.tablet`
    width:87%;
    margin-top: ${({ isFirstScrollytellingSlice }) => (isFirstScrollytellingSlice ? '-30px' : '0')};
    margin-bottom: 30px;
  `};

  ${media.desktop`
    top: 20%;
    width: 100%;
    position: sticky;
    margin-bottom: 0px;
    margin-top: ${({ isFirstScrollytellingSlice }) => (isFirstScrollytellingSlice ? '-110px' : '0')};
  `};
`

export const RightContainer = styled.div`
  padding: 0 30px;
  ${Typo19}

  & a {
    color: ${({ textColor }) => (textColor ? textColor : '')};
    font-weight: ${font.weight.bold};
    text-decoration: underline;
  }

  & h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    margin-top: 100px;
    margin-bottom: 40px;
    ${Typo12}

    ${media.desktop`
      font-size: 2rem;
      line-height: 2.5rem;
    `}
  }

  & .contrib-text > :first-child {
    margin-top: 0;
  }

  ${media.tablet`
    padding: 0;
    margin: 40px auto 0;
    width: 75%;
  `};

  ${media.desktop`
    width: 60%;
    padding-left:120px;
    margin-top: ${({ isFirstScrollytellingSlice }) => (isFirstScrollytellingSlice ? '80px' : '0')};
  `};
`

export const Content = styled.div`
  ${media.desktop`
    width: 80%;
  `}
`

export const EmphasisWrapper = styled.div`
  width: 100%;
  order: 1;
  display: flex;
  position: relative;
  margin-top: ${({ isFirstScrollytellingSlice }) => (isFirstScrollytellingSlice ? '60px' : '0')};
  margin-bottom: 60px;

  ${media.tablet`
    justify-content: center;
    margin-bottom: 20px;
  `}

  ${media.desktop`
    position: sticky;
    top: 30%;
    justify-content: flex-end;
    order: 0;
    margin-top: ${({ isFirstScrollytellingSlice }) => (isFirstScrollytellingSlice ? '80px' : '0')};
    margin-bottom: 0px;
  `}
`

export const Emphasis = styled.figure`
  display: block;
  position: relative;
  padding: 0 30px;

  &:before {
    content: '';
    height: 100%;
    width: 4px;
    background: ${({ color }) => (color ? color : 'black')};
    position: absolute;
    display: block;
  }

  ${media.tablet`
    padding: 0;
    width: 75%;
  `}
`

export const EmphasisText = styled.blockquote`
  margin-top: 10px;
  margin-right: 0;
  margin-bottom: ${({ hasAuthor }) => (hasAuthor ? '30px' : '10px')};
  margin-left: 30px;
  ${Typo12}
`

export const EmphasisAuthor = styled.figcaption`
  margin: 10px 0 10px 30px;
  ${Typo19}
  font-weight: ${font.weight.semiBold};
`

import { Slice, Text, Link, Image, StructuredText, Select } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  scrollyTelling: Slice(
    {
      backgroundColor: Select(['yes', 'no'], 'Background color', '', 'yes'),
      image: Image('Image (800x450px)', {
        width: 800,
        height: 450,
      }),
      video: Link('Video Loop (mp4, webm)'),
      credit: Text('Photo Credits (© will be automatically added before your text)', 'Write your credit here'),
      emphasis: Text('Emphasis (170 characters recommended)', 'Write your emphasis here'),
      authorEmphasis: Text('Emphasis Author (Optional)', 'Write the emphasis author here'),
      text: StructuredText('Right-hand Text (Mandatory)', 'Write your text here'),
    },
    {},
    'Scrollytelling (upload an image, or a video loop or an emphasis)',
    'React component'
  ),
}

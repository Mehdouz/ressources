import { multipleMandatorySliceFieldRule, mandatorySliceFieldRule } from '../../../utils/FieldValidation'

export default [
  multipleMandatorySliceFieldRule({ mandatoryFields: ['image', 'emphasis', 'video'], sliceName: 'scrollyTelling' }),
  mandatorySliceFieldRule({ mandatoryFields: ['text'], sliceName: 'scrollyTelling', isRepeatable: false }),
]

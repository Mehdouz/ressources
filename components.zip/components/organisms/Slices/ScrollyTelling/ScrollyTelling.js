import React from 'react'
import { string, array, object, bool } from 'prop-types'
import {
  StyledSlice,
  LeftContainer,
  RightContainer,
  ScrollyTellingWrapper,
  VideoPlayer,
  VideoContainer,
  ImageContainer,
  Emphasis,
  EmphasisAuthor,
  EmphasisText,
  EmphasisWrapper,
  Credit,
  Image,
  Content,
} from '@axacom-client/components/organisms/Slices/ScrollyTelling/ScrollyTelling.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import Text from '@axacom-client/components/molecules/Text/Text'
import { truncate } from '@axacom-client/services/string-service'

export default function ScrollyTelling({ isFirstScrollytellingSlice, image, emphasis, backgroundColor, video, credit, authorEmphasis, text, storyColors }) {
  const background = backgroundColor === 'yes' ? storyColors.background : ''
  const textColor = backgroundColor === 'yes' ? storyColors.accent : ''
  const emphasisContent = truncate(emphasis, 170, 'en', '...”')

  return (
    <StyledSlice data-testid="ScrollyTelling" overflow fluid bgColor={background} isFirstScrollytellingSlice={isFirstScrollytellingSlice}>
      <ResponsiveContainer veryLargeDesktop>
        <ScrollyTellingWrapper>
          <LeftContainer data-testid="ScrollyTelling__LeftContainer">
            <LeftComponent
              video={video}
              image={image}
              emphasisContent={emphasisContent}
              credit={credit}
              authorEmphasis={authorEmphasis}
              storyColors={storyColors}
              isFirstScrollytellingSlice={isFirstScrollytellingSlice}
            />
          </LeftContainer>
          <RightContainer data-testid="ScrollyTelling__RightContainer" textColor={textColor} isFirstScrollytellingSlice={isFirstScrollytellingSlice}>
            <Content data-testid="ScrollyTelling__Content">
              <Text className="contrib-text">{text}</Text>
            </Content>
          </RightContainer>
        </ScrollyTellingWrapper>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

function LeftComponent({ video, image, emphasisContent, authorEmphasis, storyColors, credit, isFirstScrollytellingSlice }) {
  return video ? (
    <VideoComponent isFirstScrollytellingSlice={isFirstScrollytellingSlice} video={video} credit={credit} />
  ) : image ? (
    <ImageComponent isFirstScrollytellingSlice={isFirstScrollytellingSlice} image={image} credit={credit} />
  ) : (
    <EmphasisContainer emphasisContent={emphasisContent} authorEmphasis={authorEmphasis} storyColors={storyColors} isFirstScrollytellingSlice={isFirstScrollytellingSlice} />
  )
}

function VideoComponent({ video, credit, isFirstScrollytellingSlice }) {
  return (
    <VideoContainer isFirstScrollytellingSlice={isFirstScrollytellingSlice}>
      <VideoPlayer data-testid="ScrollyTelling__Video" src={video.file.url} muted autoPlay={'autoplay'} preLoad="auto" loop />
      {credit && <Credit data-testid="ScrollyTelling__Video_Copyright">{credit}</Credit>}
    </VideoContainer>
  )
}

function ImageComponent({ image, credit, isFirstScrollytellingSlice }) {
  return (
    <ImageContainer isFirstScrollytellingSlice={isFirstScrollytellingSlice}>
      <Image data-testid="ScrollyTelling__Image" src={image?.main?.url} alt={image?.main?.alt} />
      {credit && <Credit data-testid="ScrollyTelling__Image_Copyright">{credit}</Credit>}
    </ImageContainer>
  )
}
function EmphasisContainer({ emphasisContent, authorEmphasis, storyColors, isFirstScrollytellingSlice }) {
  return (
    <EmphasisWrapper isFirstScrollytellingSlice={isFirstScrollytellingSlice}>
      <Emphasis data-testid="ScrollyTelling__Emphasis" color={storyColors.accent}>
        <EmphasisText data-testid="ScrollyTelling__EmphasisText" hasAuthor={!!authorEmphasis}>
          {emphasisContent}
        </EmphasisText>
        {authorEmphasis && <EmphasisAuthor data-testid="ScrollyTelling__EmphasisAuthor">— {authorEmphasis}</EmphasisAuthor>}
      </Emphasis>
    </EmphasisWrapper>
  )
}
ScrollyTelling.propTypes = {
  anchorPoint: string,
  image: object,
  emphasis: string,
  credit: string,
  isFirstScrollytellingSlice: bool,
  backgroundColor: string,
  video: object,
  authorEmphasis: string,
  text: array,
  storyColors: object,
}

LeftComponent.propTypes = {
  image: object,
  emphasisContent: string,
  video: object,
  credit: string,
  authorEmphasis: string,
  storyColors: object,
  isFirstScrollytellingSlice: bool,
}

EmphasisContainer.propTypes = {
  emphasisContent: string,
  authorEmphasis: string,
  isFirstScrollytellingSlice: bool,
  storyColors: object,
}

VideoComponent.propTypes = {
  video: object,
  credit: string,
  isFirstScrollytellingSlice: bool,
}

ImageComponent.propTypes = {
  image: object,
  credit: string,
  isFirstScrollytellingSlice: bool,
}

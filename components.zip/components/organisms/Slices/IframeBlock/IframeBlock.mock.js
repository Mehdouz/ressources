import iframeMock from '@axacom-client/components/atoms/Iframe/Iframe.mock'
import simpleSliceMock from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice.mock'

export default {
  ...simpleSliceMock,
  ...iframeMock,
}

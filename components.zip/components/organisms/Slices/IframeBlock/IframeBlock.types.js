import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'
import iframe from '../../../atoms/Iframe/Iframe.types'
import { Group, Select } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  iframe: Group(
    {
      anchorId: simpleSlice.anchorId,
      bgColor: simpleSlice.bgColor,
      title: simpleSlice.title,
      subtitle: simpleSlice.subtitle,
      fullWidth: Select(['false', 'true'], 'Display in Full width ? (default: false)', undefined, 'false'),
      disableMargins: Select(['false', 'true'], 'Disable margins ? (default: false)', undefined, 'false'),
      allowScrollMessage: Select(['false', 'true'], 'Allow scroll message ? (default: false)', undefined, 'false'),
      ...iframe,
    },
    'Iframe block',
    false,
    'Iframe block',
    'React component',
    'attach_money'
  ),
}

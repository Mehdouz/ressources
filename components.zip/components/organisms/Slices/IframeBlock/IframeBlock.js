import React from 'react'
import { Slice, SliceSubtitle, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import Iframe from '@axacom-client/components/atoms/Iframe/Iframe'
import { Col, Row } from 'reactstrap'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'

const IframeBlock = (props) => {
  // eslint-disable-next-line react/prop-types
  const data = props[0] || props
  const { slugifiedAnchor, bgColor, title, subtitle, fullWidth, disableMargins, ...rest } = data

  const fluid = fullWidth === 'true'
  const Wrapper = fluid ? React.Fragment : Container
  return (
    <Slice className={disableMargins === 'true' ? 'p-0' : ''} slugifiedAnchor={slugifiedAnchor} bgColor={bgColor} data-testid="Iframe">
      <Wrapper>
        {title ? <SliceTitle $textAlign="center">{title}</SliceTitle> : null}
        {subtitle && subtitle?.[0]?.text?.length > 0 ? <SliceSubtitle $textAlign="center">{subtitle}</SliceSubtitle> : null}
        {fluid ? (
          <Row className="no-gutters" style={{ margin: '0 -15px' }}>
            <Col>
              <Iframe {...rest} />
            </Col>
          </Row>
        ) : (
          <Row>
            <Col sm={{ size: 10, offset: 1 }} md={{ size: 8, offset: 2 }}>
              <Iframe {...rest} />
            </Col>
          </Row>
        )}
      </Wrapper>
    </Slice>
  )
}

export default IframeBlock

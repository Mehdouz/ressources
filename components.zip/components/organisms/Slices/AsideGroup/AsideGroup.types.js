import simpleSlice from '../../SimpleSlice/SimpleSlice.types'
import asideBlock from '../../../molecules/AsideBlock/AsideBlock.types'
import { Slice } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  asideGroup: Slice(
    {
      anchorId: simpleSlice.anchorId,
      bgColor: simpleSlice.bgColor,
      title: simpleSlice.title,
      subtitle: simpleSlice.subtitle,
    },
    {
      ...asideBlock,
    },
    'Aside Group',
    'React component',
    'view_compact'
  ),
}

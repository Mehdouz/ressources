import React from 'react'
import { array, string } from 'prop-types'
import { Slice, SliceTitle, SliceSubtitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import AsideBlock from '@axacom-client/components/molecules/AsideBlock/AsideBlock'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export default function AsideGroup({ slugifiedAnchor, bgColor, items, title, subtitle }) {
  return (
    <Slice className="asideGroup" slugifiedAnchor={slugifiedAnchor} bgColor={bgColor} dataTestid="AsideGroup">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        {title ? <SliceTitle $textAlign="center">{title}</SliceTitle> : null}
        {subtitle ? <SliceSubtitle $textAlign="center">{subtitle}</SliceSubtitle> : null}
        {items.length && items.map((item, index) => <AsideBlock key={index} isReverse={index % 2 === 0} {...item} />)}
      </ResponsiveContainer>
    </Slice>
  )
}

AsideGroup.getInitialProps = async ({ document }) => {
  return document.value
}

AsideGroup.propTypes = {
  anchorId: string,
  slugifiedAnchor: string,
  bgColor: string,
  items: array,
  subtitle: array,
  title: string,
}

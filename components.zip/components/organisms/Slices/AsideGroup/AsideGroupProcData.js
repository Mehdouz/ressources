export function getAsideReferrer(items) {
  return items.map((item) => {
    if (!item.referrer) return item
    const findCover = item.referrer.body?.find((slice) => slice.sliceType === 'cover')
    if (findCover) {
      return { image: findCover.value.banner, title: findCover.value.title, text: findCover.value.subtitle, buttonLink: { url: item.referrer.url } }
    }
    return { image: item.referrer.banner || item.referrer.cover || item.referrer.sharingImage, title: item.referrer.title, text: item.referrer.summary, buttonLink: { url: item.referrer.url } }
  })
}

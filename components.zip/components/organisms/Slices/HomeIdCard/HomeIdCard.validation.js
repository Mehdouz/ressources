import { mandatoryFieldRule } from '../../../utils/FieldValidation'

export default [
  mandatoryFieldRule({ mandatoryFields: ['idCardBoxTitle', 'idCardBoxLinks', 'idCardSurtitle', 'idCardTitle', 'idCardLinkName', 'idCardLink', 'idCardFigures'] }),
  (document) => document.idCardBoxLinks.length > 0,
  (document) => document.idCardBoxLinks.every((item) => item?.boxLink?.url && item?.boxLinkName),
  (document) => document.idCardFigures.length > 0,
  (document) => document.idCardFigures.every((item) => item?.figure && item?.text),
]

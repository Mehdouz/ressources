import React from 'react'
import { string, array, object } from 'prop-types'

import {
  HomeIdCardContainer,
  Box,
  BoxTitle,
  BoxLinks,
  BoxLinkItem,
  BoxLink,
  TextContainer,
  Surtitle,
  Title,
  LinkButton,
  FiguresContainer,
  FigureContainer,
  FigureUnitContainer,
  Figure,
  FigureUnit,
  FigureText,
  TitleContainer,
} from './HomeIdCard.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export default function HomeIdCard({ idCardBoxTitle, idCardBoxLinks, idCardSurtitle, idCardTitle, idCardLinkName, idCardLink, idCardFigures }) {
  const boxLinks = idCardBoxLinks.slice(0, 4)
  const figures = idCardFigures.slice(0, 3)

  return (
    <HomeIdCardContainer data-testid="HomeIdCard">
      <Box data-testid="HomeIdCardBox">
        <ResponsiveContainer mobile tablet>
          <BoxTitle data-testid="HomeIdCardBoxTitle">{idCardBoxTitle}</BoxTitle>
          <BoxLinks data-testid="HomeIdCardBoxLinks">
            {boxLinks.map((item, index) => (
              <BoxLinkItem data-testid="HomeIdCardBoxLinkItem" key={`box-link-item-${index}-${item.boxLinkName}`}>
                <BoxLink data-testid="HomeIdCardBoxLink" href={item.boxLink.url} type="link" color="lightGrey" iconRight="IconArrowRight">
                  {item.boxLinkName}
                </BoxLink>
              </BoxLinkItem>
            ))}
          </BoxLinks>
        </ResponsiveContainer>
      </Box>
      <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
        <TextContainer data-testid="HomeIdCardTextContainer">
          <TitleContainer data-testid="HomeIdCardTitleContainer">
            <Surtitle data-testid="HomeIdCardSurtitle">{idCardSurtitle}</Surtitle>
            <Title data-testid="HomeIdCardTitle">{idCardTitle}</Title>
            <LinkButton data-testid="HomeIdCardLink" href={idCardLink?.url} type="ghost" color="white">
              {idCardLinkName}
            </LinkButton>
          </TitleContainer>
          <FiguresContainer data-testid="HomeIdCardFiguresContainer">
            {figures.map((item, index) => (
              <FigureContainer data-testid="HomeIdCardFigureContainer" key={`figure-${index}-${item.text}`}>
                <FigureUnitContainer data-testid="HomeIdCardFigureUnitContainer">
                  <Figure data-testid="HomeIdCardFigure">{item.figure}</Figure>
                  {item.unit && <FigureUnit data-testid="HomeIdCardFigureUnit">{item.unit}</FigureUnit>}
                </FigureUnitContainer>
                <FigureText data-testid="HomeIdCardFigureText">{item.text}</FigureText>
              </FigureContainer>
            ))}
          </FiguresContainer>
        </TextContainer>
      </ResponsiveContainer>
    </HomeIdCardContainer>
  )
}

HomeIdCard.propTypes = {
  idCardBoxTitle: string,
  idCardBoxLinks: array,
  idCardSurtitle: string,
  idCardTitle: string,
  idCardLinkName: string,
  idCardLink: object,
  idCardFigures: array,
}

import styled from 'styled-components'

import { colors, font } from '@axacom-client/base/style/variables'
import { Typo12 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'

import Button from '@axacom-client/components/atoms/Button/Button'

export const OCEAN_COLOR = 'hsla(216, 45%, 28%)'

export const HomeIdCardContainer = styled.div`
  position: relative;
  color: ${colors.white};
  background: ${colors.brandBlue};
  background-image: url('/base/images/world-map.svg');
  background-position: center bottom;
  background-repeat: no-repeat;
  background-size: 300% 66%;

  ${media.desktop`
    background-position: center;
    background-size: 100% 120%;
  `}
`

export const Box = styled.div`
  background: ${OCEAN_COLOR};
  padding: 65px 0;

  ${media.desktop`
    position: absolute;
    top: -45px;
    right: 0;
    width: 48%;
    padding: 65px;
    z-index: 10;
  `}
`

export const BoxTitle = styled.h3`
  text-transform: uppercase;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 18px;
  letter-spacing: 1px;
  margin-bottom: 15px;
`

export const BoxLinks = styled.ul`
  padding: 0;
`

export const BoxLink = styled(Button)`
  display: flex;
  justify-content: space-between;
  text-transform: none;
  text-align: left;
  ${Typo12}

  ${media.desktop`
    font-size: 32px;
    line-height: 40px;
  `}
`

export const BoxLinkItem = styled.li`
  list-style-type: none;
  padding: 20px 0;
  border-bottom: 1px solid hsla(215, 46%, 17%);

  &:last-child {
    border-bottom: none;
    padding-bottom: 0;
  }

  &:hover ${BoxLink} {
    color: hsl(0, 0%, 100%);
  }
`

export const TextContainer = styled.div`
  padding: 65px 32px;

  ${media.tablet`
    padding: 65px 0;
  `}
`

export const TitleContainer = styled.div`
  ${media.desktop`
    min-height: 400px;
  `}
`

export const Surtitle = styled.h3`
  text-transform: uppercase;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 18px;
  letter-spacing: 1px;
  padding: 1rem 0;

  ${media.desktop`
    width: 42%;
  `}
`

export const Title = styled.h2`
  ${Typo12}
  margin-bottom: 2rem;

  ${media.desktop`
    width: 42%;
    font-size: 32px;
    line-height: 40px;
  `}
`

export const LinkButton = styled(Button)`
  width: 100%;
  margin-bottom: 3rem;

  ${media.desktop`
    width: auto;
  `}
`

export const FiguresContainer = styled.div`
  ${media.tablet`
    display: flex;
    flex-direction: row;
    justify-content: center;
  `}
`

export const FigureContainer = styled.div`
  &::after {
    content: '';
    display: block;
    margin: 0 auto;
    width: 2rem;
    height: 0;
    border-bottom: 2px solid ${OCEAN_COLOR};
    padding-bottom: 2.5rem;
    margin-bottom: 2rem;
  }

  &:last-child::after {
    content: none;
  }

  ${media.tablet`
    position: relative;
    margin-left: 2rem;
    margin-right: 2rem;

    &:first-child {
      margin-left: 0;
    }

    &:last-child {
      margin-right: 0;
    }

    &::after {
      position: absolute;
      top: 0;
      right: -2rem;
      margin-top: 1.25rem;
      padding-bottom: 1.5rem;
      border-bottom: none;
      border-right: 2px solid ${OCEAN_COLOR};
      transform: translate(0, 50%);
    }
  `}

  ${media.desktopLarge`
    margin-left: 4rem;
    margin-right: 4rem;

    &::after {
      right: -4rem;
    }
  `}

  ${media.desktopVeryLarge`
    margin-left: 12rem;
    margin-right: 12rem;

    &::after {
      right: -12rem;
    }
  `}
`

export const Figure = styled.div`
  display: inline;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 48px;
  line-height: 56px;
  text-align: center;

  ${media.desktop`
    font-size: 72px;
    line-height: 80px;
  `}
`

export const FigureUnitContainer = styled.div`
  text-align: center;
`

export const FigureUnit = styled.div`
  display: inline;
  margin-left: 1rem;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 24px;
  line-height: 32px;
  text-align: center;
`

export const FigureText = styled.div`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  font-size: 20px;
  line-height: 28px;
  text-align: center;
`

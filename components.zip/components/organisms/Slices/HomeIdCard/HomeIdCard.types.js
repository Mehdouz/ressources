import { Group, Link, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  $idCardBoxTitle: Text('Id Card Box Title (Mandatory)', 'Write your title here'),
  $idCardBoxLinks: Group(
    {
      boxLinkName: Text('Box Link Name (Mandatory)', 'Write your text here'),
      boxLink: Link('Box Link (Mandatory)', null, null, true, 'Link (web/document/media)'),
    },
    'Id Card Box Links (Mandatory - Max 4 items)',
    true
  ),
  $idCardSurtitle: Text('Id Card Surtitle (Mandatory)', 'Write your title here'),
  $idCardTitle: Text('Id Card Title (Mandatory)', 'Write your title here'),
  $idCardLinkName: Text('Id Card Link Name (Mandatory)', 'Write your text here'),
  $idCardLink: Link('Id Card Link (Mandatory)', null, null, true, 'Link (web/document/media)'),
  $idCardFigures: Group(
    {
      figure: Text('Figure (Mandatory - Up to 6 digits with comma)', 'Write your figure here'),
      unit: Text('Unit (Optional)', 'Write your unit here'),
      text: Text('Text (Mandatory)', 'Write your text here'),
    },
    'Id Card Figures (Mandatory)',
    true
  ),
}

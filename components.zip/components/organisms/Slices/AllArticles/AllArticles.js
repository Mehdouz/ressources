import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import {
  ContentContainer,
  Articles,
  Sidebar,
  Title,
  Article,
  LoadMore,
  FilterContainer,
  FiltersTitle,
  ArticlesContainer,
  ArticleContent,
  ArticleDate,
  ArticleImage,
  ArticleTitle,
  ReadArticleLink,
  ImagePlaceholder,
  DesktopSubscription,
  MobileSubscription,
  TabletSubscription,
  ArticleSkeletonList,
  ArticleSkeleton,
  ArticleSkeletonImage,
  ArticleSkeletonGroup,
} from './AllArticles.style'
import useLoadMore from '@axacom-client/hooks/useLoadMore'
import FilterList from '@axacom-client/components/molecules/FilterList/FilterList'
import { mediaQueries } from '@axacom-client/base/style/media'
import { media } from '@axacom-client/base/style/variables'
import { useMediaQuery } from 'react-responsive'
import { getDateWithMonthAsString } from '@axacom-client/services/date-service'
import { Slice } from '../../SimpleSlice/SimpleSlice'

const DEVICES_PARAMS = {
  mobile: {
    querySize: 3,
    pageLimit: 33,
  },
  tabletAndMore: {
    querySize: 6,
    pageLimit: 16,
  },
}

export const MAX_TAGS_FILTERS = 12

export default function AllArticles(props) {
  const { title, tagTitle, subscriptionCta, subscriptionText, subscriptionTitle } = props
  const filters = props.items

  // // TODO: Since using maxWidth as a media query is not something we do
  // // as soon as we found the appropriate approch, rework this  (we are mobile first)
  const isMobile = useMediaQuery({ query: mediaQueries.phone })
  const breakpoint = isMobile ? 'mobile' : 'tabletAndMore'

  const { loading, data, hasMoreItems, activeFilters, setActiveFilters, loadMore, page } = useLoadMore({
    size: DEVICES_PARAMS[breakpoint].querySize,
    customType: 'articles',
  })

  async function handleLoadMoreClick() {
    loadMore()
  }

  function onFilterClick(activeFilters) {
    setActiveFilters(activeFilters)
  }

  const showLoadMore = hasMoreItems && !loading && page !== DEVICES_PARAMS[breakpoint].pageLimit

  return (
    <Slice overflow fluid data-testid="AllArticles">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <Title data-testid="AllArticles__title">{title}</Title>
        <ContentContainer>
          <ArticlesContainer>
            {data && data.length > 0 ? <ArticlesList articles={data} /> : null}
            {loading ? <SkeletonItems /> : null}
          </ArticlesContainer>
          <Sidebar>
            <FilterContainer data-testid="AllArticles__filters">
              {filters?.tagTitle && <FiltersTitle data-testid="AllArticles__subtitle">{tagTitle}</FiltersTitle>}
              {filters?.length > 0 ? <FilterList isLoading={loading} filters={filters} activeFilters={activeFilters} onFilterClick={onFilterClick} isSidebar /> : null}
              <DesktopSubscription title={subscriptionTitle} text={subscriptionText} ctaText={subscriptionCta} />
            </FilterContainer>
          </Sidebar>
        </ContentContainer>
        {showLoadMore ? <LoadMoreButton onClick={handleLoadMoreClick} disabled={loading} /> : null}
        <MobileSubscription title={subscriptionTitle} text={subscriptionText} ctaText={subscriptionCta} />
      </ResponsiveContainer>
      <TabletSubscription title={subscriptionTitle} text={subscriptionText} ctaText={subscriptionCta} />
    </Slice>
  )
}

function SkeletonItems({ count = 3 }) {
  return (
    <>
      {Array.from({ length: count }).map((_, index) => (
        <ArticleSkeletonList key={index}>
          <ArticleSkeletonImage />
          <ArticleSkeletonGroup>
            <ArticleSkeleton style={{ width: 120 }} />
            <ArticleSkeleton style={{ width: '80%' }} />
            <ArticleSkeleton style={{ width: 120 }} />
          </ArticleSkeletonGroup>
        </ArticleSkeletonList>
      ))}
    </>
  )
}

const container = {
  show: {
    transition: {
      duration: 0.2,
      staggerChildren: 0.04,
    },
  },
}

const cardListVariants = {
  hidden: { y: 20, opacity: 0, transition: { type: 'tween' } },
  show: { y: 0, opacity: 1, transition: { type: 'tween' } },
}

function ArticlesList({ articles }) {
  const { domain } = useGlobalContext()

  return (
    <Articles data-testid="AllArticles__articlesList" initial="hidden" animate={articles.length > 0 ? 'show' : 'hidden'} variants={container}>
      {articles.map((item, index) => {
        const title = item?.body?.[0]?.value?.title
        const image = item?.body?.[0]?.value?.banner
        const href = domain + item.url
        return <ArticleItem key={index} date={item.date} title={title} image={image} href={href} />
      })}
    </Articles>
  )
}

const PLACEHOLDER_NEWS_IMAGE_URL = '/base/images/placeholder-news.jpg'

function ArticleItem({ date, title, image, href }) {
  const { currentLocale, i18n } = useGlobalContext()

  const formatedDate = getDateWithMonthAsString(date, currentLocale)

  return (
    <Article data-testid="AllArticles__article" variants={cardListVariants} key={title}>
      <ArticleImage>
        <ImagePlaceholder>
          {image ? (
            <picture>
              <source media={`(max-width: ${media.phoneMax}px)`} srcSet={image?.views?.small?.url} />
              <source media={`(min-width: ${media.desktopMax}px)`} srcSet={image?.views?.medium.url} />
              <img data-testid="AllArticles__articleImage" src={image?.views?.medium.url} alt={image?.main?.alt} />
            </picture>
          ) : (
            <img data-testid="AllArticles__articleImage" src={PLACEHOLDER_NEWS_IMAGE_URL} alt={title} />
          )}
        </ImagePlaceholder>
      </ArticleImage>
      <ArticleContent>
        <ArticleDate>{formatedDate}</ArticleDate>
        <ArticleTitle>{title}</ArticleTitle>
        <ReadArticleLink iconRight="IconArrowRight" color="red" type="link" size="large" href={href} dataTestId="AllArticles__readMore">
          {i18n.t('allArticles.readNow')}
        </ReadArticleLink>
      </ArticleContent>
    </Article>
  )
}

function LoadMoreButton({ onClick, ...rest }) {
  const { i18n } = useGlobalContext()

  return (
    <LoadMore data-testid="AllArticles__loadMoreButton" type="primary" color="red" iconRight="IconPlus" size="large" onClick={onClick} {...rest}>
      {i18n.t('landingStories.allStories.loadMore')}
    </LoadMore>
  )
}

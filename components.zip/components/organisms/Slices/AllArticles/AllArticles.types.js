import { Slice, Text, Link } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  allArticles: Slice(
    {
      title: Text('Title (Mandatory)', 'Write your title here'),
      tagTitle: Text('Tag Title', 'Write your tag title here'),
      subscriptionTitle: Text('Subscription Title (Mandatory)', 'Write your Subscription title here'),
      subscriptionText: Text('Subscription Text (Mandatory)', 'Write your Subscription text here'),
      subscriptionCta: Text('Subscription Cta Text (Mandatory)', 'Write your Subscription cta text here'),
    },
    {
      tag: Link('Tag', 'document', ['tag']),
    },
    'All Articles',
    'React component'
  ),
}

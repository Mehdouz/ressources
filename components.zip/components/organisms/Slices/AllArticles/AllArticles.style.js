import styled from 'styled-components'
import { font, colors } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { motion } from 'framer-motion/dist/framer-motion'
import Button from '@axacom-client/components/atoms/Button/Button'
import Subscription from '@axacom-client/components/molecules/Subscription/Subscription'
import { Typo14, Typo32, Typo39 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Skeleton, SkeletonList } from '@axacom-client/components/atoms/Skeleton/Skeleton'

export const Article = styled(motion.a)`
  width: 100%;
  margin-right: 0;
  display: flex;
  flex-direction: column;
  margin-bottom: 25px;
  color: ${colors.textColor};

  &:last-child {
    margin-bottom: 0;
  }

  &:hover,
  &:focus {
    color: ${colors.grey600};

    img {
      transform: scale(1.03);
    }
  }

  ${media.tablet`
    flex-direction: row;
    margin-bottom: 40px;
  `}
`

export const ArticleSkeletonList = styled(SkeletonList)`
  display: flex;
  flex-direction: column;
  padding-bottom: 0;

  ${media.tablet`
    flex-direction: row;
    gap: 24px;
  `}
`

export const ArticleSkeletonImage = styled(Skeleton)`
  width: 100%;
  aspect-ratio: 31/14;
  ${media.tablet`
    aspect-ratio: 3/2;
  `}

  ${media.desktop`
    aspect-ratio: 23/16;
  `}

  ${media.desktop`
    aspect-ratio: 23/16;
  `}

  ${media.desktopLarge`
    aspect-ratio: 7/5;
  `}

  ${media.desktopVeryLarge`
    aspect-ratio: 37/20;
  `}
`

export const ArticleSkeletonGroup = styled.div`
  width: 100%;
`

export const ArticleSkeleton = styled(Skeleton)`
  &:last-child {
    display: none;
  }
  ${media.tablet`

  &:last-child {
    display: block;
  }
  `}
`

export const ImagePlaceholder = styled.div`
  height: auto;
  overflow: hidden;
  position: relative;
  aspect-ratio: 31/14;
  background-color: ${colors.grey200};
  & img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transform-origin: 50% 50%;
    transition: transform 0.2s ease-in-out;
    will-change: transform;
    transform: scale(1);
  }

  ${media.tablet`
    aspect-ratio: 3/2;
  `}

  ${media.desktop`
    aspect-ratio: 23/16;
  `}

  ${media.desktop`
    aspect-ratio: 23/16;
  `}

  ${media.desktopLarge`
    aspect-ratio: 7/5;
  `}

  ${media.desktopVeryLarge`
    aspect-ratio: 37/20;
  `}
`

export const ArticleContent = styled.div`
  ${media.tablet`
    width: calc(50% - 12px);
  `}
`

export const ArticleDate = styled.div`
  ${Typo32};
  line-height: 1;
  font-weight: ${font.weight.regular};
  text-transform: uppercase;
  color: ${colors.grey600};
  margin-bottom: 7px;
`

export const ArticleTitle = styled.h3`
  font-family: ${font.fontFamilyBase};
  font-size: 1.25rem; //20px
  line-height: 1.5rem; // 24px
  font-weight: ${font.weight.semiBold};

  ${media.tablet`
    font-size: 1.5rem; //24px
    line-height: 1.75rem; // 28px
    font-weight: ${font.weight.bold};
    margin-bottom: 15px;
  `}
`

export const ArticleImage = styled.div`
  width: 100%;
  margin-bottom: 24px;

  ${media.tablet`
    width: calc(50% - 12px);
    margin-right: 24px;
    margin-bottom: 0;
  `};
`

export const ReadArticleLink = styled(Button)`
  display: none;

  ${media.tablet`
    ${Typo14};
    color: ${colors.brandRed};
    text-align: left;
    text-transform: uppercase;
    padding: 0;
    display: inline-flex;
  `};
`

export const ContentContainer = styled.div`
  display: flex;
  flex-direction: column-reverse;
  margin: 40px auto 0;

  ${media.tablet`
    margin: 45px auto 0;
    align-content: flex-start;
  `}

  ${media.desktop`
    margin: 65px auto 0;
    flex-direction: row;
    justify-content: space-between;
  `}

  ${media.desktopLarge`
    margin: 80px auto 0;
  `}
`

export const ArticlesContainer = styled.div`
  ${media.desktop`
    width: calc(64% - 50px);
  `}

  ${media.desktopLarge`
    width: calc(64% - 60px);
  `}

  ${media.desktopVeryLarge`
    width: calc(64% - 90px);
  `}
`

export const Articles = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 40px;

  ${media.tablet`
    flex-direction: row;
    flex-wrap: wrap;
    margin: 75px auto 0;
    align-content: flex-start;
  `}

  ${media.desktop`
    margin-top: 0;
  `}
`

export const Title = styled.h2`
  ${Typo39}
  text-align: center;

  ${media.tablet`
    padding: 0 65px;
  `}
`

export const FilterContainer = styled.div`
  margin: 0 auto;
  display: block;

  ${media.tablet`
    max-width: 80%;
  `}

  ${media.desktop`
    max-width: 100%;
    position: sticky;
    top: 40px;
  `}

  ${media.desktopLarge`
    top: 50px;
  `}
`

export const Sidebar = styled.div`
  ${media.desktop`
    width: calc(35% - 50px);
  `}
`

export const FiltersTitle = styled.h3`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  color: ${colors.grayDarker};
  font-size: 1.25rem;
  text-align: center;
  line-height: 1.75rem;
  margin-bottom: 20px;

  ${media.desktop`
    text-align: left;
  `}

  ${media.desktopVeryLarge`
    font-size: 1.5rem; // 40px
    line-height: 1.75rem; // 48px
  `}
`

export const LoadMore = styled(Button)`
  width: 100%;
  margin-top: 40px;

  ${media.tablet`
    width: auto;
    display: flex;
    padding-right: 1rem;
    margin: 40px auto 0;
  `}
`

export const MobileSubscription = styled(Subscription)`
  display: block;
  margin-top: 65px;

  ${media.tablet`
    display: none;
  `}
`

export const TabletSubscription = styled(Subscription)`
  display: none;

  ${media.tablet`
    display: flex;
    margin-top: 65px;
  `}

  ${media.desktop`
    display: none;
  `}
`

export const DesktopSubscription = styled(Subscription)`
  display: none;

  ${media.desktop`
    display: block;
  `}
`

import { mandatorySliceFieldRule } from '../../../utils/FieldValidation'

export default [mandatorySliceFieldRule({ mandatoryFields: ['title', 'subscriptionTitle', 'subscriptionText', 'subscriptionCta'], sliceName: 'allArticles', isRepeatable: false })]

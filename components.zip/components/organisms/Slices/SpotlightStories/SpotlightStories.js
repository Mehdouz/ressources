import React, { useState } from 'react'
import { Tablet, Desktop, LargeDesktop, VeryLargeDesktop } from '@axacom-client/components/utils/Responsive/ResponsiveComponents'
import { colors as variablesColors, media } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import SliderProgressBar from '@axacom-client/components/molecules/SliderProgressBar/SliderProgressBar'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { AnimatePresence } from 'framer-motion/dist/framer-motion'
import { SpotlightStoriesContainer, ImageWrapper, Background, CoverImage, SummaryContainer, Title, ReadTime, Summary, CtaButtonContainer, CtaButton } from './SpotlightStories.style'

export const MAX_SPOTLIGHT_STORIES = 4

const imageVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
  exit: { opacity: 0 },
}

const textVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0 },
}

const bgVariants = {
  hidden: { width: 0 },
  visible: { width: '100%', transition: { duration: 0.3, delay: -0.2 } },
}

const containerVariants = {
  visible: { transition: { staggerChildren: 0.05, delayChildren: 0.25 } },
}

export default function SpotlightStories({ spotlightStories }) {
  const [selectedStoryIndex, setSelectedCurrentStoryIndex] = useState(0)

  const currentStory = spotlightStories[selectedStoryIndex]

  const nextIndex = (selectedStoryIndex + 1) % spotlightStories.length
  const prevIndex = selectedStoryIndex === 0 ? spotlightStories.length - 1 : (selectedStoryIndex - 1) % spotlightStories.length
  const nextStory = spotlightStories[nextIndex]
  const prevStory = spotlightStories[prevIndex]

  // get next story content title
  const nextStoryTitle = nextStory.title

  const coverImageSet = {
    main: currentStory.coverImage.main,
    desktop: currentStory.coverImage.views.desktop,
    tablet: currentStory.coverImage.views.tablet,
    mobile: currentStory.coverImage.views.mobile,
  }

  const currentColors = variablesColors.stories[currentStory.color.toLowerCase()]
  const prevColors = variablesColors.stories[prevStory.color.toLowerCase()]

  return (
    <SpotlightStoriesContainer key={selectedStoryIndex} data-testid="SpotlightStories">
      <AnimatePresence>
        <ImageContent key={`${selectedStoryIndex}-image`} {...coverImageSet}></ImageContent>
        <SummaryContent key={`${selectedStoryIndex}-summary`} prevColors={prevColors} {...currentStory} colors={currentColors}></SummaryContent>

        <SliderProgressBar
          key={`${selectedStoryIndex}-progress`}
          title={nextStoryTitle}
          prevColors={prevColors}
          colors={currentColors}
          progressBarColor={currentColors.progressBar}
          progressBarDarkColor={currentColors.progressBarDark}
          onComplete={() => setSelectedCurrentStoryIndex(nextIndex)}
        />
      </AnimatePresence>
    </SpotlightStoriesContainer>
  )
}

const ImageContent = ({ main, tablet, desktop, mobile, ...rest }) => {
  return (
    <ImageWrapper {...rest} initial="hidden" animate="visible" exit="exit">
      <CoverImage
        data-testid="SpotlightCoverImage"
        alt={main?.alt}
        sizes={`
            (max-width: ${media.phoneMax}) ${mobile.dimensions.width}px,
            (max-width: ${media.tabletMax}) ${tablet.dimensions.width}px,
            (max-width: ${media.desktopMax}) ${desktop.dimensions.width}px,
            (min-width: ${media.desktopXLMin}) ${main.dimensions.width}px,
          `}
        srcSet={`
            ${main.url} ${main.dimensions.width}w,
            ${desktop.url} ${desktop.dimensions.width}w,
            ${tablet.url} ${tablet.dimensions.width}w,
            ${mobile.url} ${mobile.dimensions.width}w,
            `}
        initial="hidden"
        animate="visible"
        exit="exit"
        variants={imageVariants}
      />
    </ImageWrapper>
  )
}

const SummaryContent = ({ prevColors, title, readTime, tabletSummary, desktopSummary, largeDesktopSummary, veryLargeDesktopSummary, url, colors, ...rest }) => {
  const { i18n } = useGlobalContext()

  return (
    <SummaryContainer {...rest} initial="hidden" animate="visible" variants={containerVariants} $backgroundColor={prevColors.accent} data-testid="SpotlightStoriesSummaryContainer">
      <Title data-testid="SpotlightStoriesTitle" variants={textVariants}>
        {title}
      </Title>
      <ReadTime data-testid="SpotlightStoriesReadTime" variants={textVariants}>
        <Icon name="IconAlarm" color={variablesColors.white} width={15} height={15} />
        {readTime}
      </ReadTime>
      <Summary data-testid="SpotlightStoriesSummary" variants={textVariants}>
        <Tablet>{tabletSummary}</Tablet>
        <Desktop>{desktopSummary}</Desktop>
        <LargeDesktop>{largeDesktopSummary}</LargeDesktop>
        <VeryLargeDesktop>{veryLargeDesktopSummary}</VeryLargeDesktop>
      </Summary>
      <CtaButtonContainer data-testid="SpotlightStoriesCtaButtonContainer" variants={textVariants}>
        <CtaButton data-testid="SpotlightStoriesCTA" href={url} iconRight="IconArrowRight" size="large" type="ghost" color="white" $hoverColor={colors.accent}>
          {i18n.t('landingStories.spotlight.readMore')}
        </CtaButton>
      </CtaButtonContainer>
      <Background $backgroundColor={colors.accent} variants={bgVariants} />
    </SummaryContainer>
  )
}

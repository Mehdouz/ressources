import styled, { css } from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Typo19, Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import Button from '@axacom-client/components/atoms/Button/Button'
import { motion } from 'framer-motion/dist/framer-motion'
import { Container as InnerResponsiveContainer } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'

export const SpotlightStoriesContainer = styled.div`
  position: relative;

  ${InnerResponsiveContainer} {
    position: relative;
  }
`

export const CoverImage = styled(motion.img)`
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
`

export const ImageWrapper = styled(motion.div)`
  background: #222;
  aspect-ratio: 16/9;
  position: relative;
  z-index: 10;

  ${media.desktop`
    width: 80%;
    z-index: 0;
  `}
`

export const SummaryContainer = styled(motion.div)`
  ${({ $backgroundColor }) => css`
    background-color: ${$backgroundColor};
    padding: 50px 30px;
    color: ${colors.white};

    ${media.tablet`
      padding: 50px 80px;
    `}

    ${media.desktop`
      display: flex;
      flex-direction: column;
      justify-content: center;
      position: absolute;
      top: 60px;
      right: 0;
      width: 55%;
      height: 320px;
      padding: 35px 80px;
    `}

    ${media.desktopLarge`
      height: 400px;
      padding: 40px 100px;
    `}

    ${media.desktopVeryLarge`
      height: 520px;
    `}
  `}
`

export const Background = styled(motion.div)`
  position: absolute;
  width: 100%;
  height: 100%;
  background: ${({ $backgroundColor }) => $backgroundColor};
  left: 0;
  top: 0;
  z-index: 0;
`

export const Title = styled(motion.h2)`
  ${Typo43}
  position: relative;
  z-index: 10;
  margin-bottom: 16px;

  ${media.desktop`
    font-size: 1.375rem;
    line-height: 1.625rem;
  `}

  ${media.desktopLarge`
    font-size: 1.8rem;
    line-height: 1.8rem;
  `}

  ${media.desktopVeryLarge`
    font-size: 2.75rem;
    line-height: 2.75rem;
  `}
`

export const ReadTime = styled(motion.p)`
  position: relative;
  z-index: 10;
  margin-bottom: 1.5rem;
  text-transform: uppercase;
  font-size: 12px;
  display: inline-flex;
  align-items: center;

  ${media.tablet`
    margin-bottom: 16px;
  `}

  ${media.desktop`
    margin-bottom: 0.5rem;
  `}

  svg {
    margin-right: 5px;
  }
`

export const Summary = styled(motion.div)`
  position: relative;
  z-index: 10;
  margin-bottom: 16px;
  ${Typo19}

  ${media.phone`
    display: none;
  `}

  ${media.desktop`
    margin: 0 0 16px;
    max-height: 4.5rem;
    overflow: hidden;
    text-overflow: ellipsis;
  `}

  ${media.desktopLarge`
    max-height: 9rem;
  `}

  ${media.desktopVeryLarge`
    max-height: 21rem;
  `}
`

export const CtaButtonContainer = styled(motion.div)`
  position: relative;
  z-index: 10;
`

export const CtaButton = styled(Button)`
  width: 100%;

  &:hover {
    color: ${({ $hoverColor }) => $hoverColor};

    & svg path {
      stroke: ${({ $hoverColor }) => $hoverColor};
    }
  }

  ${media.tablet`
    width: auto;
    padding-right: 16px;
  `}
`

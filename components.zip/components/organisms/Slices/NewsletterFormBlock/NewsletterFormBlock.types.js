import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'
import { Slice } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  newsletterFormBlock: Slice(
    {
      anchorId: simpleSlice.anchorId,
      sliceTitle: simpleSlice.title,
      sliceSubtitle: simpleSlice.subtitle,
    },
    {},
    'Newsletter Form Block',
    'React component',
    'message'
  ),
}

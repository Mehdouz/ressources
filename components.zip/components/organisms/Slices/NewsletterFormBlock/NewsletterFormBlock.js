import React from 'react'
import { Col, Row, Container } from 'reactstrap'
import { array, oneOfType, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { getRouterPushParams } from '@axacom-client/services/urlResolver'
import { subscribeNewsletter } from '@axacom-client/repositories/newsletter'
import { Slice, SliceTitle, SliceSubtitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import NewsletterForm from '@axacom-client/components/molecules/Form/NewsletterForm'
import log from '@axacom-client/logger'
import { TechnicalError } from '@axacom-client/domains/errors'

export default function NewsletterFormBlock({ sliceTitle, sliceSubtitle, slugifiedAnchor }) {
  const { currentLocale, Router } = useGlobalContext()
  const defaultValue = {}

  const handleSubmit = async (form) => {
    try {
      await subscribeNewsletter(currentLocale, form)
      const [pathname, as] = getRouterPushParams('newsletterForm-confirmation', currentLocale)
      log.info('[Newsletter] subscription successful, redirecting to confirmation', { pathname, as })
      Router.push(pathname, as).catch((e) => log.error('[Router] cannot redirect to confirmation page', e))
    } catch (e) {
      log.error('[Newsletter] subscription error: ', e)
      throw new TechnicalError()
    }
  }

  return (
    <Slice dataTestid="NewsletterFormBlock" slugifiedAnchor={slugifiedAnchor}>
      <Container>
        <Row>
          <SliceTitle data-testid="NewsletterFormBlock_title" $textAlign="center">
            {sliceTitle}
          </SliceTitle>
          <SliceSubtitle data-testid="NewsletterFormBlock_subtitle" $textAlign="center">
            {sliceSubtitle}
          </SliceSubtitle>
          <Col lg={{ size: 6, offset: 3 }}>
            <NewsletterForm handleSubmit={handleSubmit} defaultValue={defaultValue} />
          </Col>
        </Row>
      </Container>
    </Slice>
  )
}

NewsletterFormBlock.propTypes = {
  sliceTitle: oneOfType([string, array]),
  sliceSubtitle: oneOfType([string, array]),
  anchorId: string,
  slugifiedAnchor: string,
}

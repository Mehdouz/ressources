import React from 'react'
import { TopBanner, Title, Subtitle } from './CoverTextOnly.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Slice } from '../../SimpleSlice/SimpleSlice'

export default function CoverTextOnly({ title, subtitle }) {
  return (
    <Slice>
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <TopBanner>
          {title && <Title>{title}</Title>}
          {subtitle && <Subtitle>{subtitle}</Subtitle>}
        </TopBanner>
      </ResponsiveContainer>
    </Slice>
  )
}

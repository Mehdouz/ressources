import { Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../SimpleSlice/SimpleSlice.types'

export default {
  coverTextOnly: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'Select a title', true),
      subtitle: Text('Subtitle (Mandatory)', 'Select a subtitle'),
      shortTitle: Text('Short title', 'Select a short title'),
    },
    {},
    'Cover text only',
    'React Component'
  ),
}

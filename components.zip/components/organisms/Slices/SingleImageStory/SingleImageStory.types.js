import { Image, Text, Slice } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  singleImageStory: Slice(
    {
      image: Image('Image (1920x1038) (Mandatory)', { width: 1920, height: 1038 }, [
        {
          name: 'desktop',
          width: 1200,
          height: 648,
        },
        {
          name: 'tablet',
          width: 992,
          height: 536,
        },
        {
          name: 'mobile',
          width: 768,
          height: 416,
        },
      ]),
      credits: Text('Photo Credits (Optional)', `Photo credits`),
    },
    {},
    'Single Image Stories',
    'React Component',
    'image'
  ),
}

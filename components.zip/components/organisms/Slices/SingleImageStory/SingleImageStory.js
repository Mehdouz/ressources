import React from 'react'
import { object, string } from 'prop-types'

import { media } from '@axacom-client/base/style/variables'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

import { StyledSlice, Image, ImageContainer, Credits } from './SingleImageStory.style'

const SingleImageStory = ({ storyColors, image, credits }) => {
  const imageSet = {
    main: image.main,
    desktop: image.views.desktop,
    tablet: image.views.tablet,
    mobile: image.views.mobile,
  }

  return (
    <StyledSlice data-testid="SingleImageStory" $storyColors={storyColors}>
      <ResponsiveContainer veryLargeDesktop>
        <ImageContainer>
          <Image
            data-testid="SingleImageStoryImage"
            alt={imageSet?.main?.alt}
            sizes={`
            (max-width: ${media.phoneMax}) ${imageSet.mobile.dimensions.width}px,
            (max-width: ${media.tabletMax}) ${imageSet.tablet.dimensions.width}px,
            (max-width: ${media.desktopMax}) ${imageSet.desktop.dimensions.width}px,
            (min-width: ${media.desktopXLMin}) ${imageSet.main.dimensions.width}px,
          `}
            srcSet={`
            ${imageSet.main.url} ${imageSet.main.dimensions.width}w,
            ${imageSet.desktop.url} ${imageSet.desktop.dimensions.width}w,
            ${imageSet.tablet.url} ${imageSet.tablet.dimensions.width}w,
            ${imageSet.mobile.url} ${imageSet.mobile.dimensions.width}w,
            `}
          />
          {credits && <Credits data-testid="SingleImageStoryCredits">{credits}</Credits>}
        </ImageContainer>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

SingleImageStory.propTypes = {
  storyColors: object,
  image: object,
  credits: string,
}

export default SingleImageStory

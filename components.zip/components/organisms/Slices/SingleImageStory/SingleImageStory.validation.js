import { mandatorySliceFieldRule } from '../../../utils/FieldValidation'

export default [mandatorySliceFieldRule({ mandatoryFields: ['image'], sliceName: 'singleImageStory', isRepeatable: false })]

import styled, { css } from 'styled-components'

import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo25 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

export const StyledSlice = styled(Slice)`
  ${({ $storyColors }) => css`
    color: ${colors.white};
    background-color: ${$storyColors.background};
  `}
`

export const ImageContainer = styled.div`
  ${media.desktop`
    width: 80%;
    margin: auto;
  `}
`

export const Image = styled.img`
  width: 100%;
`

export const Credits = styled.div`
  color: ${colors.white};
  opacity: 0.6;
  text-align: right;
  margin-top: 3px;
  margin-right: 8px;
  ${Typo25}

  &:before {
    content: '©';
    position: relative;
    font-weight: ${font.weight.bold};
    font-size: 1rem;
    top: 0.5px;
    margin-right: 5px;
  }

  ${media.tablet`
    margin-right: 10px;
  `}

  ${media.desktop`
    margin-right: 0;
  `}
`

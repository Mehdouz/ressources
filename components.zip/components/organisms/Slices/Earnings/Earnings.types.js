import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'
import { Image, Link, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  earnings: {
    type: 'Slice',
    fieldset: 'Earnings',
    description: 'React component',
    icon: 'attach_money',
    'non-repeat': simpleSlice,
    repeat: {
      thumbnail: Image('Image', { width: 300 }, [{ name: 'thumbnails', width: 145, height: 145 }]),
      title: Text('Title', 'Select the title', true),
      link: Link('Link'),
    },
  },
}

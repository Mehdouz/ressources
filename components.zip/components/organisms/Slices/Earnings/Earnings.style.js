import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo18, Typo20Bold } from '@axacom-client/base/style/typoStyle/typoStyle'
import { lighten } from 'polished'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

export const EarningsList = styled.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 32px;
  &:last-child {
    margin-bottom: 0;
  }
  ${media.tablet`
    flex-wrap: wrap;
    flex-direction: row;
    gap: 32px;
  `}
  ${media.desktop`
    gap: 48px;
  `}
`

export const ItemImage = styled.img`
  aspect-ratio: 1/1;
`

export const ImageWrapper = styled.div`
  padding: 16px;
  width: 100px;
  height: 100px;

  ${media.desktop`
    padding: 24px;
    width: 145px;
    height: 145px;
  `}

  border-radius: 50%;
  box-shadow: 0 14px 26px 4px rgba(0, 0, 0, 0.1);
  margin: 0 auto ${getSpacing(3)} auto;
`

export const Content = styled.div`
  text-align: center;
  margin-bottom: 48px;
  ${media.tablet`
    flex: 1 1 calc(50% - 32px);
  `}

  ${media.desktop`
    flex: 1 1 calc(25% - 48px);
  `}
`

export const ButtonWrapper = styled.div`
  text-align: center;
`

export const ItemLink = styled(SmartLink)`
  text-align: center;
  font-family: ${font.fontFamilyBase};
  ${media.phone`
    ${Typo18};
  `}

  ${media.desktop`
    ${Typo20Bold};
  `}
  color: ${colors.textColor};
  cursor: pointer;
  font-weight: bold !important;

  &:hover,
  &:focus {
    color: ${lighten(0.25, colors.textColor)};
  }
`

export const ItemWithoutLink = styled.div`
  text-align: center;
  font-family: ${font.fontFamilyBase};
  ${media.phone`
    ${Typo18};
  `}

  ${media.desktop`
    ${Typo20Bold};
  `}
  color: ${colors.textColor};
  font-weight: bold !important;
`

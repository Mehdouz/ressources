import React from 'react'
import { Slice, SliceTitle, SliceSubtitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import Button from '@axacom-client/components/atoms/Button/Button'
import { EarningsList, Content, ImageWrapper, ItemImage, ItemLink, ButtonWrapper, ItemWithoutLink } from './Earnings.style'

const Earnings = ({ items, slugifiedAnchor, bgColor, title, subtitle, buttonText, buttonLink }) => {
  const { i18n } = useGlobalContext()
  return (
    <Slice dataTestid="Earnings" slugifiedAnchor={slugifiedAnchor} bgColor={bgColor}>
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <SliceTitle data-testid="Earnings_title" $textAlign="center">
          {title}
        </SliceTitle>
        {subtitle && (
          <SliceSubtitle data-testid="Earnings_subtitle" $textAlign="center">
            {subtitle}
          </SliceSubtitle>
        )}
        {/* Items */}
        {items.length > 0 ? (
          <EarningsList>
            {items.map((item, i) => (
              <SingleEarning {...item} key={i} />
            ))}
          </EarningsList>
        ) : null}

        {buttonLink ? (
          <ButtonWrapper>
            <Button
              url={buttonLink?.url}
              target={buttonLink?.target && buttonLink?.target === 'web' ? '_blank' : '_self'}
              type="ghost"
              color="red"
              ariaLabel={!buttonText && title ? `${i18n.t('readmore')}, ${title}` : ''}
            >
              {buttonText || i18n.t('readmore')}
            </Button>
          </ButtonWrapper>
        ) : null}
      </ResponsiveContainer>
    </Slice>
  )
}

export default Earnings

const SingleEarning = ({ thumbnail, title, link, ...rest }) => {
  if (!thumbnail || !title) return null
  return (
    <Content data-testid="ColRoundItem" {...rest}>
      {thumbnail ? (
        <ImageWrapper className="text-center d-flex">
          <ItemImage className="d-block m-auto my-auto" src={thumbnail.views?.thumbnails?.url} />
        </ImageWrapper>
      ) : null}
      {title ? link ? <ItemLink href={link?.url}>{title}</ItemLink> : <ItemWithoutLink>{title}</ItemWithoutLink> : null}
    </Content>
  )
}

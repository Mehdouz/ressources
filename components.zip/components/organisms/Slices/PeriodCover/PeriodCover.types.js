import { Slice, Text, Image } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  periodCover: Slice(
    {
      period: Text('Period (Mandatory)', 'Write here the period here'),
      title: Text('Title (Mandatory)', 'Write here the title here'),
      image: Image('Image', { width: 1920, height: 1080 }, [
        {
          name: 'medium',
          width: 1280,
          height: 720,
        },
        {
          name: 'small',
          width: 767,
          height: 700,
        },
      ]),
    },
    {},
    'Period Cover',
    'React Component',
    'image'
  ),
}

import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { motion } from 'framer-motion/dist/framer-motion'

export const StyledSlice = styled(Slice)`
  background-color: ${colors.black};
  height: 100vh;
  position: relative;

  margin-bottom: 32px;

  ${media.tablet`
    margin-bottom: 48px;
  `}

  ${media.desktopVeryLarge`
    margin-bottom: 64px;
  `}
`

export const Content = styled(motion.div)`
  display: flex;
  flex-direction: column;
  justify-content: end;
  height: 100vh;
  padding-bottom: 32px;
  position: relative;
  z-index: 10;

  ${media.desktop`
    padding-bottom: 32px;
  `}
`

export const Period = styled(motion.h2)`
  font-size: 1.5rem;
  line-height: 1.5rem;
  font-weight: ${font.weight.bold};
  color: ${colors.white};

  ${media.desktop`
    font-size: 1.75rem;
    line-height: 3rem;
  `}
`

export const Line = styled(motion.div)`
  position: relative;
  display: block;
  top: 6px;
  left: -33px;
  height: 6px;
  border-radius: 3px;
  background: ${(props) => props.$color};

  ${media.desktop`
      left: -45px;
      width: 200px;
  `}
`

export const Title = styled(motion.h3)`
  font-size: 2rem;
  line-height: 2.125rem;
  font-weight: ${font.weight.bold};
  font-family: ${font.fontFamilyHeading};
  letter-spacing: 0.5px;
  color: ${colors.white};
  margin-top: 25px;

  ${media.desktop`
    font-size: 3rem;
    line-height: 3.125rem;
  `}
`

export const CoverImage = styled(motion.img)`
  position: absolute;
  top: -20%;
  left: 50%;
  width: auto;
  height: 110%;
  max-width: inherit;
  opacity: 0.8;
  z-index: 0;
  object-fit: cover;

  ${media.desktop`
    top: -20%;
    width: 110%;
  `}

  ${media.desktopLarge`
    top: -25%;
  `}
`

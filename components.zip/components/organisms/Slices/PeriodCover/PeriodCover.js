import React, { useRef } from 'react'
import { useInView, useScroll, useTransform } from 'framer-motion/dist/framer-motion'
import { StyledSlice, Content, Period, Title, CoverImage, Line } from '@axacom-client/components/organisms/Slices/PeriodCover/PeriodCover.style'
import { media } from '@axacom-client/base/style/variables'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { useTimeline } from '@axacom-client/components/pages/timeline-v2/timeline-v2.page'

const variants = {
  visible: {
    transition: { ease: 'easeInOut', staggerChildren: 0.1 },
  },
}

const titleVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { delay: -0.1 } },
}

const periodVariants = {
  hidden: { opacity: 0, x: -30 },
  visible: { opacity: 1, x: 0 },
}

const lineVariants = {
  hidden: { width: 0 },
  visible: { width: '200px' },
}

export default function PeriodCover({ period, title, image, periodStep }) {
  const { colors } = useTimeline()

  const contentRef = useRef(null)
  const containerRef = useRef(null)
  const contentIsInView = useInView(containerRef, { margin: '-100px', once: true })

  // Calculate the scrollProgression while on cover & transform it to make parallax effect
  let { scrollYProgress } = useScroll({
    target: contentRef,
    offset: ['start end', 'end start'],
  })
  let y = useTransform(scrollYProgress, [0, 1], ['0%', '35%'])
  let opacity = useTransform(scrollYProgress, [0, 0.5], ['1', '0.7'])

  return (
    <StyledSlice key={period} data-testid="PeriodCover" className="p-0">
      <Content ref={contentRef} initial="hidden" animate={contentIsInView ? 'visible' : 'hidden'} variants={variants}>
        <Container ref={containerRef}>
          <Period data-testid="PeriodCover__Period" variants={periodVariants}>
            {period}
          </Period>
          <Line $color={colors[periodStep]} variants={lineVariants} />
          <Title data-testid="PeriodCover__Title" variants={titleVariants}>
            {title}
          </Title>
        </Container>
      </Content>
      <picture>
        <source media="(max-width: 600px)" srcSet={image?.views?.small?.url} />
        <source media={`(max-width: ${media.desktopMax}px)`} srcSet={image?.views?.medium?.url} />
        <CoverImage style={{ y, translateX: '-50%', opacity }} src={image?.main?.url} alt={image?.main?.alt} />
      </picture>
    </StyledSlice>
  )
}

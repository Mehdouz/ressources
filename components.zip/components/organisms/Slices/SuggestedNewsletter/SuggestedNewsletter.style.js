import styled from 'styled-components'

import media from '@axacom-client/base/style/media'
import { Typo5, Typo8, Typo10, Typo15 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { colors } from '@axacom-client/base/style/variables'
import Text from '@axacom-client/components/molecules/Text/Text'

export const AnchorContainer = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: column;
  margin-bottom: 50px;

  ${media.tablet`
    margin-bottom: 70px;
  `}

  ${media.desktopLarge`
    margin-bottom: 90px;
  `}
`

export const Newsletter = styled.div`
  display: block;
  color: ${colors.textColor};
  margin: 40px 15px;
  background: #f0f4f6;
  padding: 30px;
  border: 0;

  ${media.tablet`
    float: left;
    width: 30%;
    margin: 0 60px 30px 0;
  `}
`

export const Title = styled.h3`
  ${Typo8}

  margin-top: 0;
  margin-bottom: 20px;
`

export const Subtitle = styled.p`
  ${Typo15}

  margin-bottom: 20px;
  display: block;
`

export const StyledText = styled(Text)`
  h2 {
    ${Typo5}
  }

  p {
    ${Typo10}

    margin-bottom: 50px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  li {
    ${Typo10}

    margin: 15px;
  }

  ${media.phone`
    padding-left: 15px;
    padding-right: 15px;

    ul {
      padding-left: 0;
    }
  `}

  ${media.desktop`
    margin-left: 100px;
  `}
`

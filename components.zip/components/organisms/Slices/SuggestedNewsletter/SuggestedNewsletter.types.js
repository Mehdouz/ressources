import { Group, StructuredText } from '../../../../../tools/prismic/backup-types/generic-type'

const fields = {
  anchorPoint: StructuredText('Anchor ID (same as the anchors block)', 'my-anchor-id'),
  paragraph: StructuredText('Right-hand paragraph (MANDATORY)', 'Paragraph'),
}

const suggestedNewsletter = {
  suggestedNewsletter: Group(fields, 'Paragraph with newsletter module', false, 'Suggested Newsletter', 'React component'),
}

export default suggestedNewsletter

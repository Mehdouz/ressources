import React from 'react'
import { string, array } from 'prop-types'
import { Col, Row, Container } from 'reactstrap'

import { useGlobalContext } from '@axacom-client/store/GlobalContext'

import ModalNewsletter from '@axacom-client/components/organisms/ModalNewsletter/ModalNewsletter'

import { AnchorContainer, Newsletter, Title, Subtitle, StyledText } from './SuggestedNewsletter.style'

export const SuggestedNewsletter = (props) => {
  // eslint-disable-next-line react/prop-types
  const { slugifiedAnchor, paragraph } = props[0] || props
  const { i18n } = useGlobalContext()

  const modalNewsletterProps = {
    buttonLabel: i18n.t('pressrelease.newsletter.button'),
    width: '100%',
    textContent: i18n.t('newsletterSubscription.policy'),
    checkboxGDPR: i18n.t('newsletterSubscription.checkboxGDPR'),
    defaultValue: { newsletterChoice: ['article'] },
  }

  return (
    <AnchorContainer id={slugifiedAnchor} data-testid="SuggestedNewsletter">
      <Container>
        <Row>
          <Col md={{ size: 10, offset: 1 }} lg="9">
            <Newsletter>
              <Title data-testid="SuggestedNewsletterTitle">{i18n.t('suggested.newsletter.title')}</Title>
              <Subtitle data-testid="SuggestedNewsletterSubtitle">{i18n.t('suggested.newsletter.subtitle')}</Subtitle>
              <ModalNewsletter data-testid="SuggestedNewsletterModal" {...modalNewsletterProps} />
            </Newsletter>
            <StyledText data-testid="SuggestedNewsletterParagraph">{paragraph}</StyledText>
          </Col>
        </Row>
      </Container>
    </AnchorContainer>
  )
}

SuggestedNewsletter.propTypes = {
  slugifiedAnchor: string,
  paragraph: array,
}

export default SuggestedNewsletter

import React, { useRef } from 'react'
import { ReadingContainer, LinkButton } from '@axacom-client/components/organisms/Slices/Link/Link.style'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { motion, useInView } from 'framer-motion/dist/framer-motion'

const variants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0 },
}

export default function Link({ items }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { margin: '-100px', once: true })

  return (
    <Slice className="p-0" data-testid="LinkSlice">
      <Container>
        <ReadingContainer>
          {items.length > 0 &&
            items.map((item, index) => (
              <motion.div ref={ref} key={index}>
                <LinkButton
                  key={index}
                  data-testid="LinkSlice__Button"
                  href={item?.link?.url}
                  type="link"
                  color="red"
                  iconRight="IconArrowRight"
                  initial="hidden"
                  animate={isInView ? 'visible' : 'hidden'}
                  variants={variants}
                >
                  {item?.text}
                </LinkButton>
              </motion.div>
            ))}
        </ReadingContainer>
      </Container>
    </Slice>
  )
}

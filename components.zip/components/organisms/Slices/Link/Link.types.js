import { Slice, Text, Link } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  linkSlice: Slice(
    {},
    {
      text: Text('Text', 'Write your text here'),
      link: Link('Link'),
    },
    'Link',
    'React component',
    'link'
  ),
}

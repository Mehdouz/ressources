import styled from 'styled-components'
import Button from '@axacom-client/components/atoms/V2Button/ArrowRightButton'
import media from '@axacom-client/base/style/media'
import { font } from '@axacom-client/base/style/variables'
import { Typo15 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'

export const LinkButton = styled(Button)`
  ${Typo15}
  font-weight: ${font.weight.bold};
  margin: 15px 0;

  ${media.desktop`
    font-size: 0.8125rem;
`}
`

export const ReadingContainer = styled(CenteredReadingContainer)`
  display: flex;
  flex-direction: column;
  align-items: flex-start;

  margin: 0 auto;
  max-width: 470px;
  ${media.desktop`
    max-width: 620px;
 `}
  ${media.desktopLarge`
    max-width: 750px;
  `}
`

import React from 'react'
import { string, array, func } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import FilterList from '@axacom-client/components/molecules/FilterList/FilterList'
import { StyledSlice, CardsContainer, Title, StyledCard, FilterContainer, LoadMore, FiltersTitle, SkeletonCard } from './AllStories.style'
import useLoadMore from '@axacom-client/hooks/useLoadMore'
import { mediaQueries, mediaVariables } from '@axacom-client/base/style/media'
import { useMediaQuery } from 'react-responsive'

const DEVICES_PARAMS = {
  mobile: {
    querySize: 3,
    pageLimit: 33,
  },
  tablet: {
    querySize: 9,
    pageLimit: 11,
  },
  desktop: {
    querySize: 12,
    pageLimit: 8,
  },
}

export const MAX_TAGS_FILTERS = 12

export default function AllStories(props) {
  const { title, tagTitle } = props
  const filters = props.items

  // TODO: Since using maxWidth as a media query is not something we do
  // as soon as we found the appropriate approch, rework this  (we are mobile first)
  const isMobile = useMediaQuery({ query: mediaQueries.phone })
  const isTablet = useMediaQuery({ query: `(max-width: ${mediaVariables.tabletMax}px)` })
  const breakpoint = isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop'

  const { loading, data, hasMoreItems, activeFilters, setActiveFilters, loadMore, page } = useLoadMore({
    size: DEVICES_PARAMS[breakpoint].querySize,
    customType: 'stories',
  })

  async function handleLoadMoreClick() {
    loadMore()
  }

  function onFilterClick(activeFilters) {
    setActiveFilters(activeFilters)
  }

  const canLoadMore = hasMoreItems && !loading && page !== DEVICES_PARAMS[breakpoint].pageLimit

  return (
    <StyledSlice fluid data-testid="AllStories">
      <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
        <Title data-testid="AllStories__title">{title}</Title>
        <FiltersTitle data-testid="AllStories__subtitle">{tagTitle}</FiltersTitle>
        {filters ? (
          <FilterContainer>
            <FilterList isLoading={loading} filters={filters} activeFilters={activeFilters} onFilterClick={onFilterClick} />
          </FilterContainer>
        ) : null}
        {data && data.length > 0 ? <CardList cards={data} /> : null}
        {loading ? <SkeletonContainer /> : null}
        {canLoadMore ? <LoadMoreButton onClick={handleLoadMoreClick} disabled={loading} /> : null}
      </ResponsiveContainer>
    </StyledSlice>
  )
}

function SkeletonContainer() {
  return (
    <CardsContainer>
      {Array.from({ length: 8 }).map((_, index) => (
        <SkeletonCard key={index} />
      ))}
    </CardsContainer>
  )
}

const container = {
  show: {
    transition: {
      duration: 0.2,
      staggerChildren: 0.04,
    },
  },
}

const cardListVariants = {
  hidden: { y: 20, opacity: 0, transition: { type: 'tween' } },
  show: { y: 0, opacity: 1, transition: { type: 'tween' } },
}

function CardList({ cards }) {
  const { domain } = useGlobalContext()
  return (
    <CardsContainer data-testid="AllStories__cardList" initial="hidden" animate={cards.length > 0 ? 'show' : 'hidden'} variants={container}>
      {cards.map((item, index) => {
        const title = item?.cover[0]?.title
        const image = item?.cover[0]?.image?.main?.url
        const readTime = item?.readTime
        const href = domain + item.url
        return <StyledCard data-testid="AllStories__storyCard" variants={cardListVariants} key={`${title}-${index}`} title={title} image={image} readTime={readTime} href={href} />
      })}
    </CardsContainer>
  )
}

function LoadMoreButton({ onClick, ...rest }) {
  const { i18n } = useGlobalContext()

  return (
    <LoadMore data-testid="AllStories__loadMoreButton" type="primary" color="red" iconRight="IconPlus" size="large" onClick={onClick} {...rest}>
      {i18n.t('landingStories.allStories.loadMore')}
    </LoadMore>
  )
}

AllStories.propTypes = {
  title: string,
  tagTitle: string,
  cards: array,
  items: array,
}

CardList.propTypes = {
  cards: array,
}

LoadMoreButton.propTypes = {
  onClick: func,
}

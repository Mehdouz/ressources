import { mandatorySliceFieldRule } from '../../../utils/FieldValidation'

export default [mandatorySliceFieldRule({ mandatoryFields: ['title'], sliceName: 'allStories', isRepeatable: false })]

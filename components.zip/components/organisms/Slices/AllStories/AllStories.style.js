import styled from 'styled-components'
import { font, colors } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import CardStories from '@axacom-client/components/molecules/CardStories/CardStories'
import { motion } from 'framer-motion/dist/framer-motion'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Typo19, Typo39 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Skeleton } from '@axacom-client/components/atoms/Skeleton/Skeleton'

export const StyledSlice = styled(Slice)`
  padding: 65px 30px;

  ${media.tablet`
    width: 80%;
    padding: 65px 0;
    margin: auto;
  `}

  ${media.desktop`
    padding: 80px 0;
  `};
`
export const SkeletonCard = styled(Skeleton)`
  width: 100%;
  aspect-ratio: 1/1;
  ${media.tablet`
  width: calc(33% - 9px);
  max-width: calc(33% - 9px);
  margin-right: 15px;

  &:nth-child(3n) {
    margin-right: 0;
  }
`}

  ${media.desktop`
  width: calc(25% - 15px);
  max-width: calc(25% - 15px);
  margin-right: 20px;
  margin-bottom: 20px;
  flex: 1 0 auto;

  &:nth-child(3n) {
    margin-right: 20px;
  }

  &:nth-child(4n) {
    margin-right: 0;
  }
`}
`
export const StyledCard = styled(CardStories)`
  width: 100%;
  margin-right: 0;
  display: flex;
  align-items: flex-end;
  margin-bottom: 15px;

  &:before {
    content: '';
    float: left;
    padding-top: 100%;
  }

  ${media.tablet`
    width: calc(33% - 9px);
    max-width: calc(33% - 9px);
    margin-right: 15px;

    &:nth-child(3n) {
      margin-right: 0;
    }
  `}

  ${media.desktop`
    width: calc(25% - 15px);
    max-width: calc(25% - 15px);
    margin-right: 20px;
    margin-bottom: 20px;
    flex: 1 0 auto;

    &:nth-child(3n) {
      margin-right: 20px;
    }

    &:nth-child(4n) {
      margin-right: 0;
    }
  `}
`

export const CardsContainer = styled(motion.div)`
  display: flex;
  flex-direction: column;
  margin-top: 32px;

  ${media.tablet`
    flex-direction: row;
    flex-wrap: wrap;
    margin: 0 auto 0;
    min-height: 500px;
    align-content: flex-start;
  `}
`

export const Title = styled.h2`
  ${Typo39}
  text-align: center;
`

export const FilterContainer = styled.div`
  display: flex;
  justify-content: center;

  ${media.desktopLarge`
    margin: 0 auto;
    max-width: 80%;
  `}

  ${media.desktopVeryLarge`
    max-width: 70%;
  `}
`

export const FilterContent = styled.div`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 16px;
`

export const FiltersTitle = styled.h3`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  color: ${colors.grayDarker};
  font-size: 1.25rem;
  margin: 35px 0 25px;
  text-align: center;

  ${media.desktopVeryLarge`
    font-size: 1.5rem; // 40px
    line-height: 1.75rem; // 48px
  `}
`

export const Filter = styled(Button)`
  display: block;
  border: 1px solid #e5e5e5;
  color: ${({ $isActive }) => ($isActive ? 'white' : '#757575')};
  opacity: ${({ $isLoading }) => ($isLoading ? '0.5' : '1')};
  padding: 8px 16px;
  ${Typo19}
  line-height: 0;
  font-weight: ${font.weight.semiBold};
  background-color: ${({ $isActive }) => ($isActive ? colors.AXABlue : 'white')};
  transition: border 0.3s ease-out;

  & span {
    text-transform: capitalize;
    padding: 0;
    margin: 0;
  }

  &:active,
  &:focus {
    outline: 0;
    color: ${({ $isActive }) => ($isActive ? 'white' : '#757575')};
    &:after {
      width: 0;
      color: white;
    }
  }

  &:after {
    background-color: ${colors.AXABlue};
  }

  &:hover {
    color: ${({ $isActive }) => ($isActive ? 'white' : '#757575')};
    border-color: ${colors.AXABlue};
    background-color: ${({ $isActive }) => ($isActive ? colors.AXABlue : 'white')};

    &:after {
      width: ${({ $isActive }) => ($isActive ? '125%' : '0')};
    }
  }

  ${media.desktop`
    line-height: 0;
  `}
`

export const LoadMore = styled(Button)`
  width: 100%;
  margin-top: 40px;

  ${media.tablet`
    width: auto;
    display: flex;
    padding-right: 1rem;
    margin: 40px auto 0;
  `}
`

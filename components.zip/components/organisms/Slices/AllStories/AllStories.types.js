import { Slice, Text, Link } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  allStories: Slice(
    {
      title: Text('Title (Mandatory)', 'Write your title here'),
      tagTitle: Text('Tag Title', 'Write your tag title here'),
    },
    {
      tag: Link('Tag', 'document', ['tag']),
    },
    'All Stories',
    'React component'
  ),
}

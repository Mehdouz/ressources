import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { bool, func, object, string } from 'prop-types'
import { CloseCross, Content, ImageDescription, ThumbnailsInfos, TitleContent } from '@axacom-client/components/organisms/Slices/ThumbnailGallery/ThumbnailGallery.style'
import Button from '@axacom-client/components/atoms/Button/Button'

export default function ThumbnailContent({ show, content, imageContent, responsive, title, link, target, onThumbClick }) {
  const { i18n } = useGlobalContext()

  function handleThumbClick() {
    onThumbClick(-1)
  }

  return (
    <ThumbnailsInfos hide={!show}>
      <div className="content">
        <CloseCross className="close" onClick={handleThumbClick} />
        {imageContent && imageContent[responsive] ? <ImageDescription src={imageContent[responsive]} alt={title} /> : null}
        {title && <TitleContent as="h3">{title}</TitleContent>}
        {content && <Content dangerouslySetInnerHTML={{ __html: content }} />}
        {link ? (
          <Button type="link" href={link} target={target} dataTestId="TextWithThumbnail_Link" color="red" iconRight="IconArrowRight" className="mt-3">
            {i18n.t('readmore')}
          </Button>
        ) : null}
      </div>
    </ThumbnailsInfos>
  )
}

ThumbnailContent.propTypes = {
  show: bool,
  content: string,
  imageContent: object,
  responsive: string,
  title: string,
  link: string,
  target: string,
  onThumbClick: func,
}

import { Group, Image, Link, Slice, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../../components/organisms/SimpleSlice/SimpleSlice.types'

Group(
  {
    anchorPoint: simpleSlice.anchorId,
    title: Text('title', '#1 My title'),
    content: StructuredText('Content (1300 characters recommended)', 'Lorem ipsum content'),
    link: Link('Link'),
    image_content: Image(
      'Image content (16/9) minimum width: 768px',
      {
        width: 768,
        height: 432,
      },
      [
        {
          name: 'tablet',
          width: 470,
          height: 265,
        },
        {
          name: 'desktop',
          width: 456,
          height: 257,
        },
      ]
    ),
    thumbnails: Image(
      'Thumbnail (square) minimum width: 361px',
      {
        width: 361,
        height: 361,
      },
      [
        {
          name: 'tablet',
          width: 184,
          height: 184,
        },
        {
          name: 'desktop',
          width: 178,
          height: 178,
        },
      ]
    ),
    thumbnails_hover: Image(
      'Hoverstate thumbnail (square) minimum width: 361px',
      {
        width: 361,
        height: 361,
      },
      [
        {
          name: 'tablet',
          width: 184,
          height: 184,
        },
        {
          name: 'desktop',
          width: 178,
          height: 178,
        },
      ]
    ),
  },
  'OLD - Thumbnail Gallery',
  true,
  'OLD - Thumbnail Gallery',
  'React Component',
  'view_comfy'
)

export const thumbnailGallery = {
  thumbnailGallery: Slice(
    {
      anchorPoint: simpleSlice.anchorId,
      title: Text('Title'),
      subtitle: Text('Subtitle'),
    },
    {
      title: Text('title', '#1 My title'),
      content: StructuredText('Content (1300 characters recommended)', 'Lorem ipsum content'),
      link: Link('Link'),
      image_content: Image(
        'Image content (16/9) minimum width: 768px',
        {
          width: 768,
          height: 432,
        },
        [
          {
            name: 'tablet',
            width: 470,
            height: 265,
          },
          {
            name: 'desktop',
            width: 456,
            height: 257,
          },
        ]
      ),
      thumbnails: Image(
        'Thumbnail (square) minimum width: 361px',
        {
          width: 361,
          height: 361,
        },
        [
          {
            name: 'tablet',
            width: 184,
            height: 184,
          },
          {
            name: 'desktop',
            width: 178,
            height: 178,
          },
        ]
      ),
      thumbnails_hover: Image(
        'Hoverstate thumbnail (square) minimum width: 361px',
        {
          width: 361,
          height: 361,
        },
        [
          {
            name: 'tablet',
            width: 184,
            height: 184,
          },
          {
            name: 'desktop',
            width: 178,
            height: 178,
          },
        ]
      ),
    },
    'Thumbnail Gallery',
    'React Component',
    'view_comfy'
  ),
}

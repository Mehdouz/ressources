import React, { useState } from 'react'
import _compact from 'lodash/compact'
import _every from 'lodash/every'

import { spring, StaggeredMotion } from 'react-motion'
import Thumbnail from '@axacom-client/components/organisms/Slices/ThumbnailGallery/Thumbnail'
import ThumbnailContent from '@axacom-client/components/organisms/Slices/ThumbnailGallery/ThumbnailContent'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { array, object, oneOfType } from 'prop-types'
import { Content, ImageFullWidth, ModalContent, ModalCustom, ThumbnailsBoard, TitleContent } from '@axacom-client/components/organisms/Slices/ThumbnailGallery/ThumbnailGallery.style'
import Button from '@axacom-client/components/atoms/Button/Button'

const opacitySpring = { stiffness: 300, damping: 40 }

export default function ThumbBoard({ items, size }) {
  const { i18n } = useGlobalContext()
  // eslint-disable-next-line no-unused-vars
  const [itemsState, setItemsState] = useState(updateItems(items, size.modulo))
  // eslint-disable-next-line no-unused-vars
  const [boxes, setBoxes] = useState(_compact(itemsState.map((item, i) => (item.type === 'box' ? i : false))))
  const [selected, setSelected] = useState(-2)
  const [modal, setModal] = useState(false)
  const [datas, setDatas] = useState({})

  const toggle = () => setModal(!modal)

  function updateItems(items, modulo) {
    const newItems = [...items]
    for (let index = items.length - 1; index >= 0; index--) {
      if (index !== 0 && index % modulo === 0) newItems.splice(index, 0, { type: 'box', show: false })
    }

    newItems.push({ type: 'box', show: false })

    return newItems
  }
  function appendBoxMobile(itemId) {
    const newItems = [...itemsState]
    let idFound = getIdBox(itemId)
    if (selected === itemId || itemId === -1) {
      boxes.forEach((boxId) => {
        newItems[boxId].show = false
      })
      setItemsState(newItems)
      setSelected(-1)
    } else {
      newItems[idFound] = { ...newItems[idFound], ...itemsState[itemId], ...{ show: true } }

      boxes.forEach((boxId) => {
        if (boxId !== idFound) newItems[boxId].show = false
      })
      setItemsState(newItems)
      setSelected(itemId)
    }
  }
  function getIdBox(itemId) {
    let idFound = boxes[0]
    _every(boxes, (boxId) => {
      if (itemId > boxId) {
        return true
      } else {
        idFound = boxId
        return false
      }
    })
    return idFound
  }
  function onThumbClick(id) {
    if (size.responsive === 'mobile') {
      setModal(!modal)
      setDatas(itemsState[id])
    } else {
      appendBoxMobile(id)
    }
  }

  function getStyles(prevStyles) {
    return prevStyles.map((item, i) => {
      return i === 0 ? { opacity: 1 } : { opacity: spring(prevStyles[i - 1].opacity, opacitySpring) }
    })
  }

  function getDefaultStyles() {
    return itemsState.map(() => ({ opacity: 0 }))
  }

  return (
    <ThumbnailsBoard data-testid="ThumbBoard">
      <StaggeredMotion defaultStyles={getDefaultStyles()} styles={(prevStyles) => getStyles(prevStyles)}>
        {(config) => {
          return (
            <>
              {config.map((itemConfig, i) => {
                if (itemsState && itemsState[i]) {
                  if (itemsState[i].type === `box`) {
                    return <ThumbnailContent key={`box_${i}`} {...itemsState[i]} identifier={i} responsive={size.responsive} onThumbClick={onThumbClick} />
                  } else {
                    return (
                      <Thumbnail
                        {...itemsState[i]}
                        identifier={i || itemsState[i].defaultIndex}
                        key={i}
                        style={itemConfig}
                        responsive={size.responsive}
                        selected={selected}
                        onThumbClick={onThumbClick}
                      />
                    )
                  }
                }
              })}
            </>
          )
        }}
      </StaggeredMotion>
      <ModalCustom isOpen={modal} toggle={toggle} padding={0} scrollable={true}>
        {datas.imageContent && datas.imageContent['mobile'] ? <ImageFullWidth src={datas.imageContent['mobile']} alt={datas.title} /> : null}
        <ModalContent>
          <TitleContent className="title mb-4" as="h3">
            {datas.title}
          </TitleContent>
          <Content dangerouslySetInnerHTML={{ __html: datas.content }} />
          {datas.link ? (
            <Button type="link" href={datas.link} target={datas.target} dataTestId="TextWithThumbnail_Link" color="red" iconRight="IconArrowRight" className="mt-3">
              {i18n.t('readmore')}
            </Button>
          ) : null}
        </ModalContent>
      </ModalCustom>
    </ThumbnailsBoard>
  )
}

ThumbBoard.propTypes = { items: oneOfType([object, array]), size: object }

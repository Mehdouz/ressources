import styled from 'styled-components'
import { colors } from '../../../../base/style/variables'
import { timingFunctions } from 'polished'
import media from '@axacom-client/base/style/media'
import Modal from '@axacom-client/components/molecules/Modal/Modal'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Typo18, Typo28 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const ModalCustom = styled(Modal)`
  top: 30px;
  left: 30px;
  right: 30px;
  bottom: 30px;
  .content {
    padding: 30px;
  }
`
export const ThumbnailsBoard = styled.div`
  display: flex;
  flex-flow: row wrap;
  margin-bottom: 30px;
  padding-left: 15px;
  padding-right: 15px;
  ${media.tablet`padding-left: 7px;
      padding-right: 7px;
      margin: 0 auto 50px;
      width: 750px;`}
  ${media.desktop`width: 970px;margin: 0 auto 50px;`}
  ${media.desktopLarge`
      width: 1200px;
      padding-left: 22px;
      padding-right: 22px;
      margin: 0 auto 50px;
  `}
`
export const ThumbnailsInfos = styled.div`
    height: 100%;
    margin: 0 15px;
    overflow: hidden;
    width: 100%;
    display: block;
    transition: max-height ${timingFunctions('easeOutExpo')} 0.5s};

    ${media.tablet`
      .show {
        max-height: 970px;
        margin-bottom: 20px;
      }
      .content {
        width: 470px;
        margin: 20px auto 30px;
      }
     .close {
      top: 30px;
      right: 30px;
      text-align: right;
      padding: 15px;
      padding-right: 0px;
      cursor: pointer;
    }
      `}

  ${media.desktop`
    .show {
      max-height: 650px;
    }
    .content {
        width: 100%;
        margin: 20px 0 30px;
        min-height: 360px;
     }
        .image {
          float: left;
          display: block;
          width: 50%;
          margin-right: 30px;
          margin-bottom: 30px;
        }
     .close {
      top: 30px;
      right: 30px;
      text-align: right;
      padding: 15px;
      cursor: pointer;
    }
      `}
    ${(props) =>
      props.hide &&
      `min-height: 0px;
      max-height: 0px;`};
`

export const ModalContent = styled.div`
  padding: ${getSpacing(4)};
`

export const ImageDescription = styled.img`
  ${media.desktop`
      float: left;
      display: block;
      width: 50%;
      margin-right: 30px;
      margin-bottom: 30px;
  `}
`

export const CloseCross = styled.div`
  &:before {
    content: '\\2716';
    font-size: 22px;
  }
`

export const Paragraph = styled.p`
  padding-right: -32px;
`

export const ImageFullWidth = styled.img`
  margin-top: 75px;
  width: 100%;
`

export const ThumbnailsItem = styled.div`
  display: block;
  width: 50%;
  padding: 5px 0 0;

  &:nth-child(3n + 1) {
    padding-right: 7px;
  }

  &:nth-child(3n + 2) {
    padding-left: 7px;
  }

  ${media.tablet`width: 25%;padding: 3px 7px;`}
  ${media.desktop`width: 16.6%;`}
`

export const Content = styled.p`
  ${Typo18}
  margin: 0;
`
export const TitleContent = styled.h3`
  ${Typo28}
  margin: 0 0 20px 0;
  ${media.tablet`margin-top: 10px;`}
`

export const ThumbnailsItemWrapper = styled.div`
      cursor: pointer;
      display: block;
      position: relative;
      &:hover,
      &:active,
      &:focus {
        .imageHover {
          opacity: 1;
        }
      }

      &:after {
        content: '';
        display: block;
        position: absolute;
        height: ${(props) => (props.isSelected ? '5px;' : '0px')};
        width: 100%;
        bottom: 0;
        left: 0;
        right: 0;

        background-color: ${colors.brandRed};
        @include acceleration(height, 'yes');
        transition: height ${timingFunctions('easeOutQuart')} 0.3s};
      }

      .noLink {
        cursor: default;
        &:after {
          background-color: transparent;
        }
      }

      .image {
      margin-bottom: 10px;
      border: 1px solid #cccccc;
      }

    .imageHover {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      opacity: 0;

      border: 1px solid #cccccc;
      transition: opacity 0.3s;
      &:hover,
      &:active,
      &:focus {
        border: 1px solid #cccccc;
      }
    }
`

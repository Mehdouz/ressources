import React from 'react'
import ThumbBoard from '@axacom-client/components/organisms/Slices/ThumbnailGallery/ThumbBoard'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Slice, SliceSubtitle, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { MinDesktop, Mobile, Tablet } from '@axacom-client/components/utils/Responsive'
import { array, object, oneOfType, string } from 'prop-types'

const ThumbnailGallery = (props) => {
  const { currentLocale } = useGlobalContext()

  function addDefaultIndex(items) {
    return items.map((item, i) => {
      if (item?.link?.url) item.link = item.link.url
      if (item.link) {
        item.target = getTargetFromLink(item.link)
      }
      return {
        ...item,
        defaultIndex: i,
      }
    })
  }

  function getTargetFromLink(link) {
    // link is obj
    if (link['url_' + currentLocale]) return '_blank'
    const innerLink = link ? ['localhost', 'uat', 'www.axa.com'].find((env) => link && link?.indexOf(env) !== -1) : false
    return link && link?.indexOf('http') !== -1 && !innerLink ? '_blank' : '_self'
  }

  const title = props.value?.title || props?.title
  const subtitle = props.value?.subtitle || props.subtitle
  return (
    <Slice data-testid="Thumbnail_Gallery" slugifiedAnchor={props.value?.slugifiedAnchor || props.slugifiedAnchor}>
      {title ? <SliceTitle>{title}</SliceTitle> : null}
      {subtitle && subtitle.length > 0 ? <SliceSubtitle>{subtitle}</SliceSubtitle> : null}
      <MinDesktop>
        <ThumbBoard items={addDefaultIndex(props.gridDatas)} size={{ responsive: 'desktop', modulo: 6 }} />
      </MinDesktop>
      <Tablet>
        <ThumbBoard items={addDefaultIndex(props.gridDatas)} size={{ responsive: 'tablet', modulo: 4 }} />
      </Tablet>
      <Mobile>
        <ThumbBoard items={addDefaultIndex(props.gridDatas)} size={{ responsive: 'mobile', modulo: 2 }} />
      </Mobile>
    </Slice>
  )
}

// TODO needed?
ThumbnailGallery.getInitialProps = async ({ document }) => {
  return document
}

ThumbnailGallery.propTypes = { gridDatas: oneOfType([object, array]), value: object, slugifiedAnchor: string, anchorPoint: string, title: string, subtitle: string }

export default ThumbnailGallery

import React from 'react'
import { ThumbnailsItem, ThumbnailsItemWrapper } from '@axacom-client/components/organisms/Slices/ThumbnailGallery/ThumbnailGallery.style'
import { object, string } from 'prop-types'
import { func } from 'prop-types'

const Thumbnail = ({ selected, identifier, style, thumbnails, thumbnailsHover, responsive, title, onThumbClick }) => {
  function onThumbnailClick() {
    if (thumbnailsHover[responsive]) {
      onThumbClick(identifier)
    }
  }

  function renderLink() {
    let isClickable = !!thumbnailsHover[responsive]
    if (isClickable) {
      return (
        <ThumbnailsItemWrapper onClick={onThumbnailClick} isSelected={selected === identifier}>
          <img className="imageHover" src={thumbnailsHover[responsive]} alt={title} />
          <img className="image" src={thumbnails[responsive]} alt={title} />
        </ThumbnailsItemWrapper>
      )
    } else {
      return (
        <ThumbnailsItemWrapper className="noLink" onClick={onThumbnailClick}>
          <img className="image" src={thumbnails[responsive]} alt={title} />
        </ThumbnailsItemWrapper>
      )
    }
  }

  return <ThumbnailsItem style={style}>{renderLink()}</ThumbnailsItem>
}

Thumbnail.propTypes = {
  selected: object,
  identifier: object,
  style: object,
  thumbnails: object,
  thumbnailsHover: object,
  responsive: string,
  title: string,
  onThumbClick: func,
}
export default Thumbnail

import html from 'cnc-structured-text'

export function buildGrid(slice) {
  const items = Array.isArray(slice.value) ? slice.value : slice.value && slice.value.items
  if (items) {
    slice.gridDatas = items.map((s) => ({
      title: s.title || '',
      content: html(s.content) || '',
      link: s.link || '',
      thumbnails: getResponsiveImages(s.thumbnails),
      thumbnailsHover: getResponsiveImages(s.thumbnails_hover),
      imageContent: getResponsiveImages(s.image_content),
    }))
  }
  return slice
}

// ********** PRIVATE **********

function getResponsiveImages(images) {
  return {
    mobile: (images && images.main && images.main.url) || '',
    tablet: (images && images.views && images.views.tablet && images.views.tablet.url) || '',
    desktop: (images && images.views && images.views.desktop && images.views.desktop.url) || '',
  }
}

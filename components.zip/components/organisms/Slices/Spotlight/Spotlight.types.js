import { Image, Link, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  spotLight: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'A general information title...'),
      subtitle: Text('Subtitle', 'A general information subtitle...'),
      item1Image: Image('Item1 Image', { width: 1920, height: 1080 }, [
        {
          name: 'small',
          width: 768,
          height: 432,
        },
        {
          name: 'Medium',
          width: 970,
          height: 545,
        },
      ]),
      item1surtitle: Text('Item1 Surtitle', 'Surtitle...'),
      item1title: Text('Item1 Title', 'Title...'),
      item1subtitle: Text('Item1 Subtitle', 'Subtitle...'),
      item1primaryButtonName: Text('Item1 Primary button name', 'Button name...'),
      item1primaryButtonLink: Link('Item1 Primary button Link'),
      item1secondaryButtonName: Text('Item1 Secondary button name', 'Button name...'),
      item1secondaryButtonLink: Link('Item1 Secondary button Link'),
    },
    {
      surtitle: Text('Surtitle', 'Surtitle...'),
      date: Text('Date', 'Date...'),
      surtitleLink: Link('Surtitle Link'),
      title: Text('Title', 'Title...'),
      titleLink: Link('Title Link'),
      image: Image('Image', { width: 1920, height: 1080 }, [
        {
          name: 'small',
          width: 768,
          height: 432,
        },
        {
          name: 'Medium',
          width: 970,
          height: 545,
        },
      ]),
    },
    'Spotlight',
    'React component',
    'art_track'
  ),
}

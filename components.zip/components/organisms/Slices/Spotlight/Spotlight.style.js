import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Typo14, Typo18, Typo20Bold, Typo24, Typo28, Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import Text from '@axacom-client/components/molecules/Text/Text'
import Button from '@axacom-client/components/atoms/Button/Button'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { lighten } from 'polished'
import { Col } from 'reactstrap'

export const SpotlightTitle = styled.h2`
  ${Typo43};
  text-align: center;
  margin: 0 0 ${getSpacing(4)};
  ${media.phone`
    text-align: left;
    margin-top: 0;
    margin-bottom: ${getSpacing(2)};
  `}
`

export const SpotlightSubtitle = styled(Text)`
  ${Typo18};
  text-align: center;
  margin-bottom: ${getSpacing(6)};
  ${media.phone`
    text-align: left;
  `}
`

export const ItemSurtitle = styled(Text)`
  ${Typo20Bold};
  color: ${colors.gray};
  text-align: left;
  margin-bottom: ${getSpacing(1)};
  margin-top: ${getSpacing(2)};
`

export const ItemTitle = styled(Text)`
  ${Typo28};
  text-align: left;
  margin-bottom: ${getSpacing(1)};
`

export const ItemSubtitle = styled(Text)`
  ${Typo18};
  text-align: left;
  margin-bottom: ${getSpacing(5)};
`

export const BorderBox = styled.div`
  box-sizing: border-box;
  height: 1px;
  width: 100%;
  border: 1px solid #cccccc;
  margin-bottom: ${getSpacing(3)};
  margin-top: ${getSpacing(6)};
`

export const SurtitleLink = styled.a`
  ${Typo14};
  text-align: left;
  text-transform: uppercase;
  margin-bottom: ${getSpacing(1)};
`

export const SecondaryButton = styled(Button)``
export const PrimaryButton = styled(Button)`
  margin-bottom: ${getSpacing(2)};
`

export const TitleLink = styled.div`
  ${Typo24};
  ${media.phone`
    ${Typo20Bold};
    margin-bottom: ${getSpacing(3)};
  `}
  ${media.tablet`
    margin-bottom: ${getSpacing(3)};
  `}
  text-align: left;
  margin-top: ${getSpacing(1)};

  a {
    color: ${colors.black};
    &:hover,
    &:focus {
      color: ${lighten(0.25, colors.textColor)};
    }
  }
`

export const ColImage = styled(Col)`
  ${media.phone`
    margin-bottom: ${getSpacing(3)} !important;
  `}
  ${media.tablet`
    margin-bottom: ${getSpacing(4)} !important;
  `}
`

export const DateSurtitle = styled.span`
  color: ${colors.creditColor};
  text-transform: uppercase;
`

export const SpotlightMock = {
  title: "Highlights: What's new at AXA ?",
  subtitle: "Discover our last contents to stay connect  to the group's up-to-dateness",
  item1surtitle: 'Breaking event',
  item1title: 'Full year 2019 earnings: press presentation webcast',
  item1subtitle: 'Follow the webcast of 2019 FYE presentation to the journalists and the Q&A sessions',
  item1primaryButtonName: 'Read the press release',
  item1secondaryButtonName: 'See the sum-up',
  item1primaryButtonLink: { url: 'https://www.google.fr', target: 'web' },
  item1secondaryButtonLink: { url: 'https://www.google.fr', target: 'web' },
  item1Image: {
    main: {
      dimensions: { width: 1920, height: 1080 },
      alt: '',
      copyright: '',
      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/aa734dcbfeea63bc7d3c8ecd89224785861eb596_women-two-women.jpg',
    },
    views: {
      small: {
        dimensions: { width: 768, height: 432 },
        alt: '',
        copyright: '',
        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/7624b154cefd37061ca43652ad548b69b92a23da_women-two-women.jpg',
      },
      medium: {
        dimensions: { width: 970, height: 545 },
        alt: '',
        copyright: '',
        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d716280b5aa257e218e3979c11f46cea31242bbe_women-two-women.jpg',
      },
    },
  },
  items: [
    {
      surtitle: 'Press release',
      date: '01/02/20',
      surtitleLink: { url: 'https://www.google.fr', target: 'web' },
      title: 'Full year 2019 earnings : on track to achieve Ambition 2020',
      titleLink: { url: 'https://blabla.fr', target: 'web' },
      image: {
        main: {
          dimensions: { width: 1920, height: 1080 },
          alt: '',
          copyright: '',
          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/16c0b084c2a7b7b474936d3030d74006c0361d80_8f0f3f01-9e90-442b-baac-dfa616fddad7_nigeria-web-1.jpg',
        },
        views: {
          medium: {
            dimensions: { width: 970, height: 545 },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/5d93957d6fd382d784e523d37204f0de3b2056c3_8f0f3f01-9e90-442b-baac-dfa616fddad7_nigeria-web-1.jpg',
          },
          small: {
            dimensions: { width: 768, height: 432 },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/0094574a0abf92a01acc9b42d8604f0c02cdd359_8f0f3f01-9e90-442b-baac-dfa616fddad7_nigeria-web-1.jpg',
          },
        },
      },
    },
    {
      surtitle: 'Insights',
      date: '01/02/20',
      surtitleLink: { url: 'https://www.google.fr', target: 'web' },
      title: 'Full yeaLaurentr 2019 earnings: interview with Etienne Bouas',
      titleLink: { url: 'https://blabla.fr', target: 'web' },
      image: {
        main: {
          dimensions: { width: 1920, height: 1080 },
          alt: '',
          copyright: '',
          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/1e29c9f0388f67370efccb29beca3765322038ba_7e7e739b-b307-4fb5-886f-38caee166dfd_axa-egypt-2.jpg',
        },
        views: {
          medium: {
            dimensions: { width: 970, height: 545 },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f5f96319e8b09f0bd9c6e6d31a858e46bc4ea416_7e7e739b-b307-4fb5-886f-38caee166dfd_axa-egypt-2.jpg',
          },
          small: {
            dimensions: { width: 768, height: 432 },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f0061f6d3ef09024d289584e281c8b6dccbc48ef_7e7e739b-b307-4fb5-886f-38caee166dfd_axa-egypt-2.jpg',
          },
        },
      },
    },
    {
      surtitle: 'Publications',
      date: '01/02/20',
      surtitleLink: { url: 'https://www.google.fr', target: 'web' },
      title: 'Full year 2019 earnings: press presentation deck',
      titleLink: { url: 'https://blabla.fr', target: 'web' },
      image: {
        main: {
          dimensions: { width: 1920, height: 1080 },
          alt: '',
          copyright: '',
          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/eb0eb8f010922d92672807a0bc5c35e94f2741c1_wilder2.jpg5e5105286405b.jpg',
        },
        views: {
          small: {
            dimensions: { width: 768, height: 432 },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/684dc18a59cc8b5e4eb0f7d57781ffed77e21faa_wilder2.jpg5e5105286405b.jpg',
          },
          medium: {
            dimensions: { width: 970, height: 545 },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/16d03938a51c566f3cef84068a342c3511f8a7a6_wilder2.jpg5e5105286405b.jpg',
          },
        },
      },
    },
  ],
}

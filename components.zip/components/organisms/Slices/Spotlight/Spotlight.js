import React from 'react'
import { Col, Row } from 'reactstrap'
import { arrayOf, object, shape, string } from 'prop-types'
import Image from '@axacom-client/components/atoms/Image/Image'
import { MinDesktop, Mobile, MobilesDevices, Tablet } from '@axacom-client/components/utils/Responsive'
import {
  BorderBox,
  ColImage,
  DateSurtitle,
  ItemSubtitle,
  ItemSurtitle,
  ItemTitle,
  PrimaryButton,
  SecondaryButton,
  SurtitleLink,
  TitleLink,
} from '@axacom-client/components/organisms/Slices/Spotlight/Spotlight.style'
import { Slice, SliceSubtitle, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { getSpacing } from '@axacom-client/base/style/spacing'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

const Spotlight = (props) => {
  const {
    title,
    subtitle,
    item1surtitle,
    item1title,
    item1subtitle,
    item1primaryButtonName,
    item1secondaryButtonName,
    item1primaryButtonLink,
    item1secondaryButtonLink,
    item1Image,
    items,
    slugifiedAnchor,
  } = props
  const primaryButton = () =>
    item1primaryButtonName &&
    item1primaryButtonLink && (
      <Col lg={8} md={5} sm={12} xs={12}>
        <PrimaryButton
          size="large"
          type="primary"
          width="100%"
          color="red"
          url={item1primaryButtonLink.url}
          target={item1primaryButtonLink.target === 'web' ? '_blank' : '_self'}
          ariaLabel={item1primaryButtonName}
          dataTestId="SpotlightButtonPrimary"
        >
          {item1primaryButtonName}
        </PrimaryButton>
      </Col>
    )

  const secondaryButton = () =>
    item1secondaryButtonName &&
    item1secondaryButtonLink && (
      <Col lg={8} md={5} sm={12} xs={12}>
        <SecondaryButton
          size="large"
          type="ghost"
          color="red"
          width="100%"
          url={item1secondaryButtonLink.url}
          target={item1secondaryButtonLink.target === 'web' ? '_blank' : '_self'}
          ariaLabel={item1secondaryButtonName}
          dataTestId="SpotlightButtonSecondary"
        >
          {item1secondaryButtonName}
        </SecondaryButton>
      </Col>
    )

  const ButtonLineBreak = (
    <>
      <Row>{primaryButton()}</Row>
      <Row>{secondaryButton()}</Row>
    </>
  )
  return (
    <Slice className="spotLight" dataTestid="spotLight" slugifiedAnchor={slugifiedAnchor}>
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        {title ? <SliceTitle $textAlign="center">{title}</SliceTitle> : null}
        {subtitle ? <SliceSubtitle $textAlign="center">{subtitle}</SliceSubtitle> : null}
        <Row>
          <Col lg={7} md={12} sm={12} xs={12}>
            {item1Image && <Image src={item1Image?.views?.medium?.url} ratio="16:9" />}
          </Col>
          <Col lg={5} md={12} sm={12} xs={12}>
            <Row>
              <Col lg={12} md={12} sm={12} xs={12}>
                <ItemSurtitle>{item1surtitle || ''}</ItemSurtitle>
                <ItemTitle data-testid="SpotlightTitle">{item1title || ''}</ItemTitle>
                <ItemSubtitle data-testid="SpotlightSubtitle">{item1subtitle || ''}</ItemSubtitle>
              </Col>
            </Row>
            <Tablet>
              <Row>
                {primaryButton()} {secondaryButton()}
              </Row>
            </Tablet>
            <MinDesktop>{ButtonLineBreak}</MinDesktop>
            <Mobile>{ButtonLineBreak}</Mobile>
          </Col>
          <BorderBox />
        </Row>
        <Row>
          {items &&
            items.map((item, index) => {
              const image = (
                <>{item.image && <Image src={item.image?.views?.small?.url} ratio="16:9" animation="scale" alt={item.image.views?.small?.alt} style={{ marginBottom: `${getSpacing(2)}` }} />}</>
              )
              const description = (
                <>
                  {item && item.surtitleLink && (
                    <SurtitleLink href={item.surtitleLink?.url}>
                      {item.surtitle}
                      <DateSurtitle>{` - ${item.date}`}</DateSurtitle>
                    </SurtitleLink>
                  )}
                  {item && item.titleLink && (
                    <TitleLink>
                      <a href={item.titleLink?.url}>{item.title}</a>
                    </TitleLink>
                  )}
                </>
              )
              return (
                <div style={{ display: 'contents' }} key={index}>
                  <MobilesDevices>
                    <ColImage xs={3}>{image}</ColImage>
                    <Col xs={9}>{description}</Col>
                  </MobilesDevices>
                  <MinDesktop>
                    <Col lg={4}>
                      {image}
                      {description}
                    </Col>
                  </MinDesktop>
                </div>
              )
            })}
        </Row>
      </ResponsiveContainer>
    </Slice>
  )
}

const articlesPropTypes = {
  surtitle: string,
  date: string,
  surtitleLink: object,
  title: string,
  titleLink: object,
  image: object,
}

Spotlight.propTypes = {
  title: string,
  subtitle: string,
  items: arrayOf(shape(articlesPropTypes)),
  item1surtitle: string,
  item1title: string,
  item1subtitle: string,
  item1primaryButtonName: string,
  item1secondaryButtonName: string,
  item1primaryButtonLink: object,
  item1secondaryButtonLink: object,
  item1Image: object,
  anchorId: string,
  slugifiedAnchor: string,
}

export default Spotlight

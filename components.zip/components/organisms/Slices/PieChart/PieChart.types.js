import { Link, Select, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  pieChart: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'Select a title', false),
      subtitle: Text('Subtitle', 'Select a subtitle', false),
      unit: Select(['%', '€'], 'Unit', '', '%'),
      csv: Link('Link (csv file)'),
      legend: Text('Legend', 'Select a legend'),
    },
    {},
    'Pie Chart',
    'React Component',
    'pie_chart'
  ),
}

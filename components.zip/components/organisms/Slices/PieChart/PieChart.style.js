import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import Text from '@axacom-client/components/molecules/Text/Text'
import { Typo18, Typo34, Typo35, Typo15 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import { motion } from 'framer-motion/dist/framer-motion'

export const GraphWrapper = styled.div`
  display: flex;
  flex-direction: column;

  ${media.tablet`
    flex-direction: row;
    justify-content: center;
    margin-top: 20px;
  `}
`

export const GraphContainer = styled.div`
  width: 100%;

  ${media.tablet`
    display: flex;
    flex-direction: column;
    width: 40%;
    margin-right: 50px;
  `}
`

export const Title = styled.div`
  ${Typo34};
  text-align: center;
  margin-bottom: 5px;
`

export const Subtitle = styled.div`
  ${Typo18};
  text-align: center;
`

export const NumberWrapper = styled.div`
  position: absolute;
  width: ${({ width }) => `${width}px`};
  height: ${({ height }) => `${height}px`};
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
`

export const Number = styled(motion.p)`
  ${Typo35};
`

export const DesktopListWrapper = styled.div`
  display: flex;
  align-items: center;
`

export const DesktopList = styled.ul`
  display: flex;
  flex-direction: column;
  list-style: none;
  padding-left: 0;
  margin-right: 15px;
`

export const DesktopListItem = styled(motion.li)`
  ${Typo15};
  font-weight: ${({ isSelected }) => (isSelected ? font.weight.bold : font.weight.regular)};
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 15px 0;
  cursor: pointer;
  position: relative;
  display: inline-flex;
  flex-direction: row;

  &:last-child {
    padding: 15px 0 0;
  }
`

export const ItemText = styled.span`
  display: inline-flex;
  flex-direction: column;
  align-items: left;
  justify-content: space-between;

  &:after {
    content: '${({ $text }) => $text}';
    display: block;
    height: 0;
    overflow: hidden;
    visibility: hidden;
    font-weight: ${font.weight.bold};

    @media speech {
      display: none;
    }
  }
`

export const DotLabel = styled(motion.span)`
  width: 18px;
  height: 18px;
  display: block;
  border-radius: 50%;
  background-color: ${({ color }) => color};
  left: -40px;
  top: 1px;
  margin-right: 20px;
`

export const MobileList = styled.select`
  display: flex;
  align-items: center;
  ${Typo15};
  letter-spacing: 0.1em;
  font-weight: ${font.weight.bold};
  background: ${colors.grayLighter};
  padding: 0px 60px;
  width: 100%;
  height: 60px;
  text-transform: uppercase;
  border: none;
  -webkit-appearance: none;
  -moz-appearance: none;
`

export const SelectWrapper = styled.div`
  position: relative;
  display: block;

  &:before {
    content: '';
    background-color: ${({ color }) => color};
    position: absolute;
    top: 20px;
    left: 20px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    z-index: 2;
  }
`

export const SelectIconWrapper = styled.div`
  position: absolute;
  right: 20px;
  top: 15px;
`

export const MobileListItem = styled.option`
  &::before {
    content: '';
    background: black;
    width: 50px;
    height: 50px;
  }
`

export const Legend = styled(Text)`
  ${Typo15}
  text-align:center;
  max-width: 80%;
  margin: 20px auto 0;

  ${media.tablet`
    margin: 0 auto;
  `}
`

export const SvgWrapper = styled.div`
  position: relative;
  width: 100%;
  height: auto;
  aspect-ratio: 1/1;
`

export const Svg = styled.svg`
  color: ${({ color }) => color};
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
`

export const ArcPath = styled(motion.path)`
  cursor: pointer;
`

export const AnimatedCircle = styled(motion.circle)`
  transition: fill 0.3s, stroke 0.3s;
`

import React, { useState } from 'react'
import { array, number, func, object, string } from 'prop-types'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import dynamic from 'next/dynamic'
import { format, formatDefaultLocale } from 'd3-format'
import { useMediaQuery } from 'react-responsive'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { mediaVariables } from '@axacom-client/base/style/media'
import useMeasure from 'react-use-measure'
import { colors } from '@axacom-client/base/style/variables'
import {
  GraphContainer,
  GraphWrapper,
  Title,
  Subtitle,
  MobileList,
  DesktopList,
  DesktopListWrapper,
  MobileListItem,
  ItemText,
  DesktopListItem,
  DotLabel,
  SelectWrapper,
  SelectIconWrapper,
  SvgWrapper,
  Number,
  NumberWrapper,
  Legend,
} from './PieChart.style'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

const PieChartInner = dynamic(() => import('./PieChartInner'), { ssr: false })

const chartColors = [colors.tosca400, colors.teal100, colors.apache100, colors.ocean400, colors.tosca100, colors.teal400, colors.viridian100, colors.ocean100]

export default function PieChart({ anchorId, title, subtitle, unit, csv, legend }) {
  const [selectedIndex, setSelectedIndex] = useState(null)
  const [ref, bounds] = useMeasure()
  const { currentLocale } = useGlobalContext()

  const isMobile = useMediaQuery({ maxWidth: mediaVariables.phoneMax })

  const { datas, headers } = csv

  const totalData = datas.reduce((acc, d) => +d[headers[1]] + acc, 0)

  // Parse the data in an array of objects and convert the string with the value to numbers with the trick +`${}`
  const data = datas?.map((d) => ({
    [headers[0]]: d[headers[0]],
    [headers[1]]: +`${d[headers[1]]}`,
  }))

  if (currentLocale === 'fr') {
    formatDefaultLocale({
      thousands: ' ',
      grouping: [3],
      decimal: ',',
    })
  }

  // Check if number has decimal and convert it to the good format
  function formatNumber(number) {
    return !(number % 1) ? format(',')(number) : format(',.1f')(number)
  }

  return (
    <Slice slugifiedAnchor={anchorId} dataTestid="PieChartSlice">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <Title data-testid="PieChart__Title">{title}</Title>
        <Subtitle data-testid="PieChart__Subtitle">{subtitle}</Subtitle>
        <GraphWrapper>
          <GraphContainer>
            <SvgWrapper ref={ref}>
              {selectedIndex !== null && (
                <NumberWrapper width={bounds.width} height={bounds.height}>
                  <Number key={selectedIndex} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                    {unit === '%' ? `${Math.round((data[selectedIndex][headers[1]] / totalData) * 100)}%` : `${formatNumber(data[selectedIndex][headers[1]])}€`}
                  </Number>
                </NumberWrapper>
              )}
              {/* Pie chart */}
              {bounds.width > 0 && (
                <PieChartInner
                  data={data}
                  totalData={totalData}
                  headers={headers}
                  colors={chartColors}
                  height={bounds.height}
                  width={bounds.width}
                  selectedIndex={selectedIndex}
                  onSelect={setSelectedIndex}
                  isMobile={isMobile}
                />
              )}
            </SvgWrapper>
            {!isMobile && <Legend>{legend}</Legend>}
          </GraphContainer>
          {isMobile ? (
            <HeaderListMobile items={data} headers={headers} selectedIndex={selectedIndex} onSelect={setSelectedIndex} chartColors={chartColors} />
          ) : (
            <HeaderListDesktop items={data} headers={headers} selectedIndex={selectedIndex} onSelect={setSelectedIndex} chartColors={chartColors} />
          )}
        </GraphWrapper>
        {isMobile && <Legend>{legend}</Legend>}
      </ResponsiveContainer>
    </Slice>
  )
}

function HeaderListDesktop({ items, headers, selectedIndex, onSelect, chartColors }) {
  return (
    <DesktopListWrapper>
      <DesktopList data-testid="PieChart__List">
        {items.map((header, i) => (
          <DesktopListItem
            key={i}
            data-testid="PieChart__List__Item"
            isSelected={selectedIndex === i}
            onMouseEnter={() => onSelect(i)}
            onMouseLeave={() => onSelect(null)}
            animate={() => labelAnimation(selectedIndex, i)}
          >
            <DotLabel color={chartColors[i]} animate={selectedIndex === i ? { scale: 1.5 } : { scale: 1 }} />
            <ItemText data-testid="PieChart__List__Item__Text" $text={header[headers[0]]}>
              {header[headers[0]]}
            </ItemText>
          </DesktopListItem>
        ))}
      </DesktopList>
    </DesktopListWrapper>
  )
}

function labelAnimation(selectedIndex, i) {
  if (selectedIndex === i) return { opacity: 1 }
  if (selectedIndex === null) return { x: 0, opacity: 1 }
  return { opacity: 0.5 }
}

function HeaderListMobile({ items, headers, selectedIndex, onSelect, chartColors }) {
  return (
    <SelectWrapper color={selectedIndex ? chartColors[selectedIndex] : chartColors[0]}>
      <MobileList value={selectedIndex ? selectedIndex : ''} onChange={(e) => onSelect(parseInt(e.target.value))} data-testid="PieChartList">
        {items.map((header, i) => (
          <MobileListItem key={i} data-testid="PieChartListItem" value={i}>
            {header[headers[0]]}
          </MobileListItem>
        ))}
      </MobileList>
      <SelectIconWrapper>
        <Icon name="IconSmallArrowBottom" color={colors.brandRed} width={32} height={32} />
      </SelectIconWrapper>
    </SelectWrapper>
  )
}

PieChart.getInitialProps = async ({ document }) => {
  return document
}

PieChart.propTypes = {
  anchorId: string,
  title: string,
  subtitle: string,
  color: string,
  unit: string,
  csv: object,
  legend: string,
}

HeaderListDesktop.propTypes = {
  items: array,
  headers: array,
  selectedIndex: number,
  onSelect: func,
  chartColors: array,
}

HeaderListMobile.propTypes = {
  items: array,
  headers: array,
  selectedIndex: number,
  onSelect: func,
  chartColors: array,
}

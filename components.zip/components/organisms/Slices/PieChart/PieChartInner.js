import React from 'react'
import { arc as d3arc } from 'd3-shape'
import { scaleLinear } from 'd3-scale'
import { Svg, ArcPath } from './PieChart.style'
import { motion } from 'framer-motion/dist/framer-motion'
import { array, func, number, bool } from 'prop-types'
import { useMemo } from 'react'

export default function PieChartInner({ data, headers, colors, width, height, selectedIndex, onSelect, isMobile }) {
  // Generate initial arc paths & animated arc paths
  const initialArcs = useMemo(() => generateArcs({ data, headers, width, outerRadius: width * 0.1 }), [width, data, headers])
  const animatedArcs = useMemo(() => generateArcs({ data, headers, width, outerRadius: width * 0.1 + 20 }), [width, data, headers])

  return (
    <>
      <Svg viewBox={`0 0 ${width} ${height}`} data-testid="PieChart_Svg">
        <motion.g transform={`translate(${width / 2}, ${height / 2})`}>
          {initialArcs.map((d, i) => (
            <ArcPath
              key={i}
              d={initialArcs[i]}
              onMouseEnter={() => onSelect(i)}
              onMouseLeave={() => !isMobile && onSelect(null)}
              animate={selectedIndex === i ? { d: animatedArcs[i] } : { d: initialArcs[i] }}
              fill={colors[i]}
            ></ArcPath>
          ))}
        </motion.g>
      </Svg>
    </>
  )
}

function generateArcs({ data, headers, width, outerRadius }) {
  const totalData = data.reduce((acc, d) => d[headers[1]] + acc, 0)

  // create and apply radiusScale based totalSum of the data
  let radiusScale = scaleLinear()
    .domain([0, totalData])
    .range([0, 2 * Math.PI])

  let totalSum = 0

  let arcs = data.map((d) => {
    let previousEndAngle = totalSum
    totalSum += d[headers[1]]

    return d3arc()({
      innerRadius: width / 3.1,
      outerRadius: width / 3.1 + outerRadius,
      startAngle: 0.0000001 + radiusScale(previousEndAngle),
      endAngle: radiusScale(totalSum),
    })
  })

  return arcs
}

PieChartInner.propTypes = {
  data: array,
  headers: array,
  colors: array,
  width: number,
  height: number,
  selectedIndex: number,
  onSelect: func,
  isMobile: bool,
}

import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Col, Row } from 'reactstrap'
import { getSpacing } from '@axacom-client/base/style/spacing'
import media from '@axacom-client/base/style/media'
import Text from '@axacom-client/components/molecules/Text/Text'

const CustomRow = styled(Row)`
  background: linear-gradient(90deg, ${colors.grayLighter} 50%, #ffffff 50%);
`

const CustomCol = styled(Col)`
  background: ${colors.grayLighter};

  ${media.phone`
    padding: ${getSpacing(6)} ${getSpacing(4)};
  `};

  ${media.tablet`
    padding-top: ${getSpacing(6)};
    padding-right: ${getSpacing(6)};
    padding-bottom: ${getSpacing(6)};
  `};

  p {
    margin-bottom: ${getSpacing(6)};

    &:last-child {
      margin-bottom: 0;
    }
  }
`

const HighlightText = styled(Text)`
  background: ${colors.grayLighter};
  //TODO check for right fonts

  ${media.phone`
    font-size: 16px;
    line-height: 28px;
  `};

  ${media.tablet`
    font-size: 16px;
    line-height: 28px;
  `};

  ${media.desktop`
    font-size: 20px;
    line-height: 34px;
  `};

  p {
    margin-bottom: ${getSpacing(6)};
  }

  div[data-oembed-type='video'] {
    position: relative;
    padding-top: 57%;
    overflow: hidden;

    iframe {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 0;
      height: 100%;
      width: 100%;
    }
  }
`

const GrayBackgroundWrapper = styled.div`
  background: linear-gradient(90deg, ${colors.grayLighter} 50%, #ffffff 50%);
  width: 100%;

  ${media.phone`
    background: ${colors.grayLighter};
  `};
`

export { CustomRow, HighlightText, GrayBackgroundWrapper, CustomCol }

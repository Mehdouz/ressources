import { Group, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  highlight: Group(
    {
      anchorPoint: Text('Anchor Label', 'Anchor Label'),
      text: StructuredText('Highlighted paragraph content', 'Write here your highlight block'),
    },
    'Highlight',
    true,
    'Highlight',
    'React Component',
    'star_half'
  ),
}

import React from 'react'
import { CustomCol, CustomRow, GrayBackgroundWrapper, HighlightText } from '@axacom-client/components/organisms/Slices/Highlight/Highlight.style'
import { array, oneOfType, string } from 'prop-types'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Container } from 'reactstrap'

const Highlight = (props) => {
  // eslint-disable-next-line react/prop-types
  const item = props[0] || props
  const { slugifiedAnchor, text } = item
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="Highlight">
      <GrayBackgroundWrapper>
        <Container>
          <CustomRow>
            <CustomCol xl={{ size: 8, offset: 2 }} lg={{ size: 8, offset: 2 }} md={{ size: 10, offset: 1 }}>
              {/* TODO : NE PLUS UTILISER LE CLASSNAME "contrib-text" */}
              <HighlightText data-testid="Highlight_Text" className="contrib-text">
                {text}
              </HighlightText>
            </CustomCol>
          </CustomRow>
        </Container>
      </GrayBackgroundWrapper>
    </Slice>
  )
}

export default Highlight

Highlight.propTypes = {
  anchorPoint: oneOfType([array, string]),
  slugifiedAnchor: string,
  text: array,
}

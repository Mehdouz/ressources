import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { motion } from 'framer-motion/dist/framer-motion'
import { colors, font } from '@axacom-client/base/style/variables'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { Typo27, Typo34 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const IconWrapper = styled(motion.span)`
  transform-origin: center;
  display: flex;
  align-items: center;
`

export const SectionBloc = styled.div`
  margin: 1px 0;
`

export const Title = styled.h2`
  ${Typo34}
  margin-bottom: 30px;
`

export const SectionTitle = styled.h3`
  display: flex;
  justify-content: space-between;
  background: #eeeeee;
  padding: 15px 20px;
  margin: 0;
  cursor: pointer;
  ${Typo27};
  letter-spacing: 1px;
  color: ${colors.brandRed};
  text-transform: uppercase;
  letter-spacing: 0.1em;
  line-height: 1.8;
  font-weight: ${font.weight.bold};
`

export const ContactsList = styled(motion.ul)`
  list-style: none;
  padding: 0;
  margin: 0;
  overflow: hidden;
`

export const ContactItem = styled(motion.li)`
  padding: 15px 20px;
  gap: 5px;
  ${Typo27};
  letter-spacing: 1px;
  font-weight: ${font.weight.regular};
  text-transform: uppercase;
  display: flex;
  flex-direction: column;
  border-bottom: 1px solid ${colors.grayLighter};

  &:last-child {
    border: 0;
  }

  ${media.desktop`
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    height: 50px;
    padding: 0 20px;
    gap: 20px;
  `}
`

export const Email = styled(SmartLink)`
  color: ${colors.des_blue};
`
export const Phone = styled(SmartLink)`
  color: ${colors.textColor};

  &:hover {
    color: ${colors.textColor};
  }
`

export const ContactInfos = styled.div`
  display: flex;
  flex-direction: column;
  gap: 5px;

  ${media.desktop`
    flex-direction: row;
    gap: 20px;
    align-items: center;
  `}
`

import { Slice, Link } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  contactList: Slice(
    {},
    {
      contact: Link('Contact', 'document', ['contact'], false, 'Contact Link'),
    },
    'Contact List',
    'React component',
    'person'
  ),
}

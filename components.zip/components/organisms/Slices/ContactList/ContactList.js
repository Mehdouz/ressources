import React, { useMemo, useState } from 'react'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'
import { colors } from '@axacom-client/base/style/variables'
import { SectionBloc, Title, ContactItem, SectionTitle, ContactsList, ContactInfos, Email, Phone, IconWrapper } from '@axacom-client/components/organisms/Slices/ContactList/ContactList.style'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { mediaQueries } from '@axacom-client/base/style/media'
import { useMediaQuery } from 'react-responsive'

export default function ContactList({ items }) {
  const { i18n } = useGlobalContext()
  const isMobile = useMediaQuery({ query: mediaQueries.phone })

  const contactsBySection = useMemo(
    () =>
      items.reduce((acc, item) => {
        const { contact } = item

        // Si la section n'est pas encore dans l'objet de sections, on l'ajoute
        if (!acc[contact?.section]) {
          acc[contact?.section] = {
            title: contact?.section,
            contacts: [],
          }
        }
        // On ajoute le contact à la section correspondante
        acc[contact?.section].contacts.push(contact)
        return acc
      }, {}),
    [items]
  )

  return (
    <Slice data-testid="ContactList" slugifiedAnchor="contacts">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <CenteredReadingContainer>
          <Title data-testid="ContactList__Title">{i18n.t('contactlist.title')}</Title>
          {contactsBySection && Object.keys(contactsBySection).map((section, index) => <ContactsSection key={index} section={section} contactsBySection={contactsBySection} isMobile={isMobile} />)}
        </CenteredReadingContainer>
      </ResponsiveContainer>
    </Slice>
  )
}

const listVariants = {
  open: {
    height: 'auto',
    transition: {
      staggerChildren: 0.05,
    },
  },
  close: { height: 0 },
}

const iconVariants = {
  open: {
    rotate: 180,
  },
  close: { rotate: 0 },
}

const itemVariants = {
  open: {
    y: 0,
    opacity: 1,
  },
  close: { y: 20, opacity: 0 },
}

function ContactsSection({ section, contactsBySection, isMobile }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <SectionBloc>
      <SectionTitle data-testid="ContactList__Section__Title" onClick={() => setIsOpen(!isOpen)}>
        {section}
        <IconWrapper animate={isOpen ? 'open' : 'close'} variants={iconVariants}>
          <Icon name="IconSmallArrowBottom" color={colors.brandRed} width={20} height={20} />
        </IconWrapper>
      </SectionTitle>
      <ContactsList data-testid="ContactList__Section__List" initial="close" animate={isOpen ? 'open' : 'close'} variants={listVariants}>
        {contactsBySection[section].contacts.map((contact, index) => (
          <ContactItem data-testid="ContactList__Section__List__Item" key={index} variants={itemVariants}>
            <p data-testid="ContactList__Section__List__Item__Name">{contact?.name}</p>
            <ContactInfos>
              {contact?.email && (
                <Email data-testid="ContactList__Section__List__Item__Email" href={`mailto:${contact.email}`}>
                  {contact.email}
                </Email>
              )}
              {contact?.phoneImage ? (
                <Phone data-testid="ContactList__Section__List__Item__Phone" href={isMobile ? `tel:${contact.phone}` : ''}>
                  <img src={contact?.phoneImage.main.url} alt={contact?.name} />
                </Phone>
              ) : (
                contact?.phone && (
                  <Phone data-testid="ContactList__Section__List__Item__Phone" href={isMobile ? `tel:${contact.phone}` : ''}>
                    {contact.phone}
                  </Phone>
                )
              )}
            </ContactInfos>
          </ContactItem>
        ))}
      </ContactsList>
    </SectionBloc>
  )
}

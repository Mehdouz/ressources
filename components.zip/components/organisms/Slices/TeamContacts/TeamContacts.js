import React from 'react'
import styled from 'styled-components'
import { Col, Row } from 'reactstrap'
import { object, string } from 'prop-types'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Typo28, Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Highlight } from '../../../../base/style/typography'
import Text from '@axacom-client/components/molecules/Text/Text'

import media from '@axacom-client/base/style/media'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'

const ContactsTitle = styled.h2`
  ${Typo43};
  text-align: left;
  margin: 0 0 ${getSpacing(1)};
`

const BorderBox = styled.div`
  box-sizing: border-box;
  height: 1px;
  width: 100%;
  border: 1px solid #cccccc;
  margin-bottom: ${getSpacing(3)};
  margin-top: ${getSpacing(3)};
`

const ContactSubtitle = styled.h4`
  ${Typo28};
  text-align: left;
  margin: ${getSpacing(3)} 0;
`

const ContactWrapper = styled.div`
  display: flex;
  padding: ${getSpacing(1)} 0;
  flex-direction: column;
  ${media.desktop`
    flex-direction: row;
  `}
`

const ContactItem = styled.a`
  margin-left: ${getSpacing(0)};
  ${media.desktop`
    margin-left: ${getSpacing(4)};
  `}
`

const PhoneImage = styled.img`
  height: ${getSpacing(3)};
  ${media.tablet`
    height: ${getSpacing(4)};
  `};
`

const TeamContacts = (props) => {
  const { title, anchorId, slugifiedAnchor, items } = props

  return (
    <Slice slugifiedAnchor={slugifiedAnchor || anchorId} dataTestid="Contacts">
      <Container>
        <Row>
          <Col sm={{ size: 8, offset: 2 }} md={{ size: 8, offset: 2 }} lg={{ size: 10, offset: 1 }}>
            {title && <ContactsTitle data-testid="ContactsTitle">{title}</ContactsTitle>}
          </Col>
        </Row>
        {items.map((item, index) => (
          <Row key={index}>
            <Col sm={{ size: 8, offset: 2 }} md={{ size: 8, offset: 2 }} lg={{ size: 10, offset: 1 }}>
              <BorderBox />
              {item.subtitle !== 'EMPTY' && <ContactSubtitle data-testid="ContactSubtitle">{item.subtitle || item.teamContacts.name}</ContactSubtitle>}
              {item.teamContacts.contacts.map((contact, index) => {
                return (
                  <ContactWrapper key={index}>
                    <Highlight>
                      <Text>{contact.label}</Text>
                    </Highlight>
                    {contact.email ? (
                      <ContactItem href={`mailto:${contact.email}`}>
                        <Highlight>{contact.email}</Highlight>
                      </ContactItem>
                    ) : (
                      (contact.phone_number || contact.phone_image) && (
                        <ContactItem href={contact.phone_number && `tel:${contact.phone_number}`}>
                          {contact.phone_image ? <PhoneImage src={contact.phone_image?.main?.url} alt={contact.phone_image?.main?.alt} /> : <Highlight>{contact.phone_number}</Highlight>}
                        </ContactItem>
                      )
                    )}
                  </ContactWrapper>
                )
              })}
            </Col>
          </Row>
        ))}
      </Container>
    </Slice>
  )
}

TeamContacts.propTypes = {
  title: string,
  anchorId: string,
  slugifiedAnchor: string,
  items: object,
}

export default TeamContacts

import { Link, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../SimpleSlice/SimpleSlice.types'

export default {
  teamContacts: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'Title...'),
    },
    {
      subtitle: Text("Subtitle, Only fill this field if you want to replace the team name. Or write EMPTY in the field if you don't want to display any team name."),
      teamContacts: Link('Select a team contact', 'document', ['team_contact']),
    },
    'Team Contacts',
    'React component',
    'contact_mail'
  ),
}

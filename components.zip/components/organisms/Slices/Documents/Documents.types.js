import { Link, Slice, Text, Select } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  documentsSlice: Slice(
    {
      anchorPoint: Text('Anchor Label', 'Anchor Label'),
      reverse: Select(['yes', 'no'], 'Latest first', 'Choose reverse', 'no'),
      blockTitle: Text('Document title', 'Block title'),
    },
    {
      target: Link('Target'),
      title: Text('Title', 'Title'),
      label: Text('Description', 'Label'),
    },
    'Documents',
    'React Component'
  ),
}

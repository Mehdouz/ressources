import { array, string } from 'prop-types'
import React, { useEffect, useState } from 'react'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { useGlobalContext } from '../../../../store/GlobalContext'
import { Info, Item, Label, LinkTitle, Title } from './Documents.style'
import Button from '../../../atoms/Button/Button'
import { bytesToSize } from '@axacom-client/services/string-service'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'

function checkUrlHost(doc) {
  if (doc.target) {
    const innerLink = doc.url ? ['localhost', 'uat', 'www.axa.com', 'cdn.axa.com'].find((env) => doc.url.indexOf(env) !== -1) : false
    if (innerLink) return 'reference'
    if (doc.target === 'web') return 'web'
  }
  return 'reference'
}

const Documents = ({ items, anchorPoint, reverse, blockTitle }) => {
  const { i18n, currentLocale } = useGlobalContext()
  const [documents, setDocuments] = useState(() => [])

  useEffect(() => setDocuments(reverse === 'yes' ? items.reverse() : items), [items, reverse])

  return (
    <Slice data-testid="Documents" slugifiedAnchor={anchorPoint}>
      <Container>
        <CenteredReadingContainer>
          <Title as="h2" data-testid="DocumentListTitle">
            {blockTitle ? blockTitle : i18n?.t('documentlist.title')}
          </Title>
          {documents.map(({ label, target, title }, index) => {
            const isFile = ['file', 'image'].includes(target.target)
            const labelFile = isFile ? target?.file?.name?.split('.')[1] || target?.image?.name?.split('.')[1] : ''
            const customTarget = checkUrlHost(target)
            return (
              <React.Fragment key={index}>
                <Item>
                  <Info>
                    <LinkTitle
                      type="link"
                      url={target?.file?.url || target.url}
                      target={isFile ? '_blank' : customTarget === 'reference' ? '_self' : '_blank'}
                      color={customTarget === ('reference' || 'file') ? 'red' : 'blue'}
                      data-analytics={{ block_name: 'document_list::document_title', event_type: 'N' }}
                    >
                      {title || target.title}
                    </LinkTitle>
                    <Label>{isFile ? labelFile + ' ' + bytesToSize(target?.image?.size || target?.file?.size, currentLocale) : label}</Label>
                  </Info>
                  <Button
                    dataTestId="Item_Download"
                    url={target?.file?.url || target.url}
                    type="link"
                    aria-label={i18n?.t('ariaLabelLoadMore') || 'Read More'}
                    iconRight={isFile ? 'IconDownload' : 'IconArrowRight'}
                    color={customTarget === ('reference' || 'file') ? 'red' : 'blue'}
                    target={isFile ? '_blank' : customTarget === 'reference' ? '_self' : '_blank'}
                    dataAnalytics={{
                      block_name: 'document_list::document_download',
                      label: title || target.title,
                      event_type: 'T',
                    }}
                  >
                    &nbsp;
                  </Button>
                </Item>
              </React.Fragment>
            )
          })}
        </CenteredReadingContainer>
      </Container>
    </Slice>
  )
}

Documents.getInitialProps = ({ document }) => {
  return document
}

Documents.propTypes = { items: array, anchorPoint: string, title: string, reverse: string, slugifiedAnchor: string, blockTitle: string }

export default Documents

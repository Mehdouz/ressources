import styled from 'styled-components'
import media from '../../../../base/style/media'
import { colors, font } from '../../../../base/style/variables'
import { Typo16, Typo24, Typo28 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Button from '../../../atoms/Button/Button'

export const Title = styled.h2`
  text-align: left;
  font-weight: ${font.weight.semiBold};
  ${media.phone`
    ${Typo24}
  `}

  ${media.tablet`
  ${Typo24}
  `}

  ${media.desktop`
  ${Typo28}
  `}
`

export const Item = styled.li`
  list-style: none;
  padding: 15px 0;
  border-top: 1px solid ${colors.grayLight};
  display: flex;
  justify-content: space-between;
  align-items: center;

  &:last-child {
    border-bottom: 1px solid ${colors.grayLight};
  }
  ${media.tablet`padding-left: 7px;
      padding: 15px 20px 15px 0;
  `}
`

export const Info = styled.div`
  width: 90%;
`

export const Label = styled.div`
  ${Typo16}
  color: ${colors.gray};
  text-transform: uppercase;
`

export const LinkTitle = styled(Button)`
  ${Typo16}
  font-weight: ${font.weight.semiBold};
  overflow: hidden;
  text-transform: uppercase;
  display: block;
  text-align: left;
`

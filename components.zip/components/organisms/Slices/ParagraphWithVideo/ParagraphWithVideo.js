import React, { useRef } from 'react'
import { ReadingContainer, Title, DescriptionVideo, StyledPlayer, StyledText } from '@axacom-client/components/organisms/Slices/ParagraphWithVideo/ParagraphWithVideo.style'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { useInView } from 'framer-motion/dist/framer-motion'

const variants = {
  visible: {
    transition: { staggerChildren: 0.1 },
  },
}

const itemsVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0 },
}

export default function ParagraphWithVideo({ text, surtitle, video }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { margin: '-100px', once: true })

  return (
    <Slice data-testid="ParagraphWithVideo">
      <Container ref={ref} initial="hidden" animate={isInView ? 'visible' : 'hidden'} variants={variants}>
        <Title variants={itemsVariants}>{surtitle}</Title>
        <DescriptionVideo>
          <ReadingContainer>
            <StyledText variants={itemsVariants}>{text}</StyledText>
          </ReadingContainer>
          <StyledPlayer {...video} variants={itemsVariants} />
        </DescriptionVideo>
      </Container>
    </Slice>
  )
}

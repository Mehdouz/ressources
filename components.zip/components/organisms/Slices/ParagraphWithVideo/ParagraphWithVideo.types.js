import { Slice, StructuredText, Text, Embed } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  paragraphWithVideo: Slice(
    {
      surtitle: Text('Surtitle', 'Write here your surtitle here'),
      text: StructuredText('Text', 'Write here your paragraph here'),
      video: Embed(),
    },
    {},
    'Paragraph with video',
    'React Component',
    'subject'
  ),
}

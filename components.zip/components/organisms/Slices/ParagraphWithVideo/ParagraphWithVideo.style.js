import styled from 'styled-components'
import { Typo10, Typo38 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import { MotionText } from '@axacom-client/components/molecules/Text/Text'
import YoutubePlayer from '@axacom-client/components/molecules/YoutubePlayer/YoutubePlayer'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'
import { motion } from 'framer-motion/dist/framer-motion'

export const Title = styled(motion.h3)`
  ${Typo38}
  margin-bottom: 40px;
`

export const StyledText = styled(MotionText)`
  ${Typo10}
  ${media.desktop`
    padding-right: 30px;
  `}

  ${media.desktopLarge`
    padding-right: 50px;
  `}
`

export const ReadingContainer = styled(CenteredReadingContainer)`
  margin: 0 auto;
  max-width: 470px;
  margin-top: 32px;
  margin-bottom: 32px;

  ${media.desktop`

    margin-top: 0;
    margin-bottom: 0;
    width: 40%;
    max-width: 620px;
 `}
  ${media.desktopLarge`
    max-width: 750px;
  `}
`

export const StyledPlayer = styled(YoutubePlayer)`
  ${media.desktop`
    margin-bottom: 24px;
    width: 60%;
  `}
`

export const DescriptionVideo = styled.div`
  display: flex;
  flex-direction: column-reverse;

  ${media.desktop`
    flex-direction: row;
  `}
`

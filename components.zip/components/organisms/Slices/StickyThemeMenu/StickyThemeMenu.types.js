import { Link, Select, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  stickyThemeMenu: Slice(
    { anchorId: simpleSlice.anchorId, activateNewsletterButton: Select(['Yes', 'No'], 'Activate newsletter button', 'Yes or No', 'Yes') },
    {
      themeText: Text('Theme text', 'Fill theme text'),
      theme: Link('Thèmes', 'document', ['theme-v2']),
    },
    'Sticky Theme Menu',
    'React component',
    'menu'
  ),
}

import React from 'react'
import { arrayOf, object, string } from 'prop-types'
import StickySlice from '@axacom-client/components/molecules/StickySlice/StickySlice'
import { getComponentProps } from '@axacom-client/services/component-service'
import log from '@axacom-client/logger'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

export default function StickyThemeMenu({ items, slugifiedAnchor, activateNewsletterButton }) {
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="StickyThemeMenu">
      <StickySlice menuItems={items} activateNewsletterButton={activateNewsletterButton} />
    </Slice>
  )
}

StickyThemeMenu.getInitialProps = async ({ document, ...context }) => {
  log.debug('[StickyThemeMenu] getInitialProps')
  document.items = await getComponentProps('StickyThemeMenu', StickySlice, context, document.items)
  return document
}

StickyThemeMenu.propTypes = {
  items: arrayOf(object).isRequired,
  anchorId: string,
  slugifiedAnchor: string,
  activateNewsletterButton: string,
}

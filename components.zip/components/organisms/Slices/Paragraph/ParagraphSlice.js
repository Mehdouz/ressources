import React, { useRef } from 'react'
import { Typo10 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { MotionText } from '@axacom-client/components/molecules/Text/Text'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { array, object, oneOfType, string } from 'prop-types'
import styled from 'styled-components'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'
import { useInView } from 'framer-motion/dist/framer-motion'

const ParagraphText = styled(MotionText)`
  ${Typo10}
  display: block;
  p {
    margin-bottom: 48px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  div[data-oembed-type='video'] {
    position: relative;
    padding-top: 57%;
    overflow: hidden;

    iframe {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 0;
      height: 100%;
      width: 100%;
    }
  }
`

const paragraphVariants = {
  hidden: { opacity: 0, y: -20 },
  visible: { opacity: 1, y: 0 },
}

export default function ParagraphSlice({ slugifiedAnchor, ...rest }) {
  const ref = useRef()
  const isInView = useInView(ref, { margin: '-100px', once: true })

  return (
    <Slice slugifiedAnchor={slugifiedAnchor} data-testid="Paragraph">
      <Container>
        <CenteredReadingContainer>
          <ParagraphText ref={ref} data-testid="Paragraph_Text" initial="hidden" animate={isInView ? 'visible' : 'hidden'} variants={paragraphVariants}>
            {rest}
          </ParagraphText>
        </CenteredReadingContainer>
      </Container>
    </Slice>
  )
}

ParagraphSlice.propTypes = {
  anchorPoint: oneOfType([array, string]),
  slugifiedAnchor: string,
  text: oneOfType([object, array]),
}

import { Group, Slice, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  paragraph: Group(
    {
      anchorPoint: Text('Anchor Label', 'Anchor Label'),
      text: StructuredText('Text', 'Write here your text block'),
    },
    'Paragraph',
    false,
    'Paragraph',
    'React Component (Group)',
    'subject'
  ),
}
// TODO: remove Group() type for Slice() in order to prevenet having props[0] in components
export const paragraphSlice = {
  paragraphSlice: Slice(
    {
      anchorPoint: Text('Anchor Label', 'Anchor Label'),
      text: StructuredText('Text', 'Write here your text block'),
    },
    {},
    'Paragraph',
    'React component (Slice)',
    'subject'
  ),
}

import React from 'react'
import { array, object, oneOfType, string } from 'prop-types'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { ParagraphText } from '@axacom-client/components/organisms/Slices/Paragraph/Paragraph.style'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'

export default function Paragraph(props) {
  // eslint-disable-next-line react/prop-types
  const item = props[0] || props
  return (
    <Slice slugifiedAnchor={item.slugifiedAnchor} data-testid="Paragraph">
      <CenteredReadingContainer>
        <ParagraphText data-testid="Paragraph_Text" className="contrib-text">
          {item}
        </ParagraphText>
      </CenteredReadingContainer>
    </Slice>
  )
}

Paragraph.propTypes = {
  anchorPoint: oneOfType([array, string]),
  slugifiedAnchor: string,
  text: oneOfType([object, array]),
}

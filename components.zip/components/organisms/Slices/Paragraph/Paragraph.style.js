import styled from 'styled-components'
import Text from '@axacom-client/components/molecules/Text/Text'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Typo10 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'

const ParagraphText = styled(Text)`
  ${Typo10}
  padding: 0 32px;
  display: block;
  div[data-oembed-type='video'] {
    position: relative;
    padding-top: 57%;
    overflow: hidden;

    iframe {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 0;
      height: 100%;
      width: 100%;
    }
  }
  p {
    margin-bottom: ${getSpacing(6)};
    &:last-child {
      margin-bottom: 0;
    }
  }

  ${media.tablet`
    padding: 0;
  `}
`

export { ParagraphText }

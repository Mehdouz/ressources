import React from 'react'
import { array, object, oneOfType, string } from 'prop-types'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Col, Row } from 'reactstrap'
import CaptionedImage from '@axacom-client/components/molecules/CaptionedImage/CaptionedImage'
import styled from 'styled-components'
import media from '@axacom-client/base/style/media'

const ColLeft = styled(Col)`
  ${media.phone`
    padding-right: 5px;
  `}
  ${media.tablet`
    padding-right: 5px;
  `}
  ${media.desktop`
    padding-right: 10px;
  `}
`
const ColRight = styled(Col)`
  ${media.phone`
    padding-left: 5px;
  `}
  ${media.tablet`
    padding-left: 5px;
  `}
  ${media.desktop`
    padding-left: 10px;
  `}
`
const DoubleImage = (props) => {
  // eslint-disable-next-line react/prop-types
  const item = props[0] || props
  const { slugifiedAnchor, illustration1, illustration2, credit1, credit2 } = item
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="DoubleImage">
      <Row>
        <ColLeft xs={{ size: 6 }} fluid={true}>
          <CaptionedImage caption={credit1} image={illustration1} dataTestid="first" />
        </ColLeft>
        <ColRight xs={{ size: 6 }} fluid={true}>
          <CaptionedImage caption={credit2} image={illustration2} dataTestid="second" />
        </ColRight>
      </Row>
    </Slice>
  )
}

export default DoubleImage

DoubleImage.propTypes = {
  anchorPoint: oneOfType([array, string]),
  slugifiedAnchor: string,
  illustration1: object,
  illustration2: object,
  credit1: string,
  credit2: string,
}

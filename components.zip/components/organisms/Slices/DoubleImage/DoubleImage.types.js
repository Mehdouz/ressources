import { Group, Image, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  'double-image': Group(
    {
      anchorPoint: Text('Anchor Label', 'Anchor Label'),
      illustration1: Image('illustration1', { width: 1920 }, [
        { name: 'small', width: 768, height: 432 },
        { name: 'Medium', width: 970, height: 545 },
      ]),
      credit1: Text('credit', 'Put your image credit here'),
      illustration2: Image('illustration2', { width: 1920 }, [
        { name: 'small', width: 768, height: 432 },
        { name: 'Medium', width: 970, height: 545 },
      ]),
      credit2: Text('credit', 'Put your image credit here'),
    },
    'Double Image',
    false,
    'Double Image',
    'React Component',
    'image'
  ),
}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Typo16, Typo28 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { colors, font } from '@axacom-client/base/style/variables'

export const ThreeFiguresHeader = styled.div`
  margin: auto;
`

export const SliderInner = styled.div`
  display: flex;
  justify-content: space-between;
`

export const ThreeFiguresDiv = styled.div`
  display: flex;
  flex-direction: column;
  background: ${colors.grayLighter};
  padding: 0 0 50px 0;
`

export const SliderItem = styled.div`
  text-align: center;
  ${media.tablet`
    width: 33%;
  `}
`

export const ItemNumber = styled.div`
  font-family: ${font.fontFamilyHeading};
  font-weight: 400;
  letter-spacing: -0.01em;
  line-height: 1;
  color: ${colors.des_blue};

  ${media.phone`
    font-size: 130px;
  `}

  ${media.tablet`
    font-size: 108px;
  `}

  ${media.desktopLarge`
    font-size: 130px;
  `}
`

export const ItemValue = styled.span`
  font-size: 0.3em;
  margin: 0 0 0 0.1em;
`

export const ItemTitle = styled.div`
  margin-bottom: 20px;
  color: ${colors.textColor};
  ${Typo28}

  &:hover,
  &:focus {
    color: darken(${colors.textColor}, 10%);
  }
`

export const Subtitle = styled.div`
  ${Typo16}
  ${media.phone`margin-left: 0;`}
`

export const All = styled.div`
  text-align: center;
  width: 100%;
  ${media.tablet`
    text-align: right;
    padding: 60px 0 0;
  `}
`

export const Container = styled.div`
  padding: 0 30px;
`

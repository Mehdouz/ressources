import React from 'react'
import { string, object, array } from 'prop-types'

import { useGlobalContext } from '@axacom-client/store/GlobalContext'

import Button from '@axacom-client/components/atoms/Button/Button'
import ContentCarousel, { Slide } from '@axacom-client/components/molecules/ContentCarousel/ContentCarousel'
import { Slice, SliceTitle, SliceSubtitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { ThreeFiguresHeader, ItemNumber, ItemTitle, ItemValue, SliderInner, SliderItem, Subtitle, All, Container } from '@axacom-client/components/organisms/Slices/ThreeFigures/ThreeFigures.style'
import { MinTablet, Mobile } from '@axacom-client/components/utils/Responsive'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

function ThreeFigures({ items, anchorPoint, link, linkName, subtitle, title }) {
  const { i18n } = useGlobalContext()

  return (
    <Slice data-testid="threeFiguresSlice" data-slice="threeFiguresSlice" slugifiedAnchor={anchorPoint} bgColor="gray" fluid>
      <ResponsiveContainer desktop largeDesktop veryLargeDesktop>
        <Container>
          {(title || subtitle) && (
            <ThreeFiguresHeader data-testid="Header">
              {title && <SliceTitle $textAlign="center">{title}</SliceTitle>}
              {subtitle && <SliceSubtitle $textAlign="center">{subtitle}</SliceSubtitle>}
            </ThreeFiguresHeader>
          )}
          {/* Mobile version */}
          <Mobile>
            <ContentCarousel showArrows={false} dataTestid="SliderMobile">
              {items.map((item, i) => (
                <Slide key={i} index={i}>
                  <ItemSlider link={link} {...item} />
                </Slide>
              ))}
            </ContentCarousel>
          </Mobile>
          {/* other breakpoints */}
          <div data-testid="threeFiguresSlice__SliderWrapper">
            <MinTablet>
              <SliderInner data-testid="threeFiguresSlice__SliderInner">
                {items.length &&
                  items.map((item, index) => (
                    <SliderItem key={index} data-testid={`threeFiguresSlice__SliderInner_${index}`}>
                      <ItemNumber data-testid="ItemNumber">
                        <span data-testid="ItemNumber">{item.number}</span>
                        <ItemValue data-testid="ItemValue">{item.legend}</ItemValue>
                      </ItemNumber>
                      <ItemTitle data-testid="ItemTitle">{item.title}</ItemTitle>
                      {item?.subtitle && <Subtitle data-testid="Subtitle">{item.subtitle}</Subtitle>}
                    </SliderItem>
                  ))}
              </SliderInner>
            </MinTablet>
          </div>
          {linkName && (
            <All>
              <Button iconRight="IconArrowRight" type="link" color="red" url={link?.url}>
                {linkName || i18n.t('keyFigures.viewAllFigures')}
              </Button>
            </All>
          )}
        </Container>
      </ResponsiveContainer>
    </Slice>
  )
}

export const ItemSlider = ({ number, legend, title, subtitle, link }) => {
  return (
    <SliderItem data-testid="MSliderItem">
      <ItemNumber data-testid="MItemNumber">
        <span data-testid="MSliderNumber">{number}</span>
        <ItemValue data-testid="MItemValue">{legend}</ItemValue>
      </ItemNumber>
      <a href={link?.url} data-testid="MSliderUrl">
        <ItemTitle data-testid="MItemTitle">{title}</ItemTitle>
      </a>
      {subtitle && <Subtitle data-testid="MSubtitle">{subtitle}</Subtitle>}
    </SliderItem>
  )
}

ItemSlider.propTypes = {
  number: string,
  legend: string,
  title: string,
  subtitle: string,
  link: object,
}

export default ThreeFigures

ThreeFigures.propTypes = {
  anchorPoint: string,
  items: array,
  link: object,
  linkName: string,
  subtitle: string,
  title: string,
}

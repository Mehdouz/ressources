import { Link, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  threeFiguresSlice: Slice(
    {
      anchorPoint: Text('Anchor ID (same as the anchors block)', 'my-anchor-id'),
      title: Text('Title', 'Title...'),
      subtitle: Text('Subtitle', 'Subtitle...'),
      link: Link('Button link'),
      linkName: Text('button Link name', 'button Link name'),
    },
    {
      number: Text('Figure number', 'Figure number'),
      legend: Text('Figure legend', 'Figure legend'),
      title: Text('Figure title', 'Figure title'),
      subtitle: Text('Figure subtitle', 'Figure subtitle'),
    },
    'Three Figures Block',
    'React component'
  ),
}

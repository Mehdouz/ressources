import { Group, Image, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  breakpointsImages: Group(
    {
      anchorPoint: Text('Anchor Label', 'Lorem ipsum label'),
      title: Text('Title', 'Title'),
      subtitle: Text('Subtitle', 'Subtitle'),
      smallImage: Image('small image (max width 768px)', { width: 768 }),
      mediumImage: Image('medium image (max width 1024px)', { width: 1024 }),
      largeImage: Image('large image (max width 1920px)', { width: 1920 }),
    },
    'Breakpoints Images',
    false,
    'Breakpoints Images',
    'React Component',
    'dashboard'
  ),
}

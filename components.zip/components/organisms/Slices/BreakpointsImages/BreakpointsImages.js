import React from 'react'
import { Slice, SliceSubtitle, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { object, string } from 'prop-types'
import { MinDesktop, Mobile, Tablet } from '@axacom-client/components/utils/Responsive'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'

export default function BreakpointsImages(props) {
  // eslint-disable-next-line react/prop-types
  const item = props[0] || props
  const { title, subtitle, smallImage, mediumImage, largeImage, slugifiedAnchor } = item

  return (
    <Slice slugifiedAnchor={slugifiedAnchor} data-testid="BreakpointsImages">
      <Container>
        {title ? <SliceTitle $textAlign="center">{title}</SliceTitle> : null}
        {subtitle && subtitle.length > 0 ? <SliceSubtitle $textAlign="center">{subtitle}</SliceSubtitle> : null}
        <Mobile>
          <img src={smallImage?.main?.url} data-testid="smallImage" alt={smallImage?.main?.alt} />
        </Mobile>
        <Tablet>
          <img src={mediumImage?.main?.url} data-testid="mediumImage" alt={mediumImage?.main?.alt} />
        </Tablet>
        <MinDesktop>
          <img src={largeImage?.main?.url} data-testid="largeImage" alt={largeImage?.main?.alt} />
        </MinDesktop>
      </Container>
    </Slice>
  )
}

BreakpointsImages.propTypes = {
  slugifiedAnchor: string,
  title: string,
  subtitle: string,
  smallImage: object,
  mediumImage: object,
  largeImage: object,
}

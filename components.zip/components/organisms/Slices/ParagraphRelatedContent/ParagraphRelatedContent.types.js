import { Slice, Link, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  paragraphRelatedContent: Slice(
    {
      anchorPoint: Text('Anchor ID (same as the anchors block)', 'my-anchor-id'),
      content: Link('Link', 'document', ['article-v2', 'publication'], false, 'Article or Publication'),
      paragraph: StructuredText('Right-hand paragraph (Mandatory)', 'Write your paragraph here'),
      title: Text('Replacement title', 'Write your title'),
    },
    {},
    'Paragraph with related content or publication',
    'React component'
  ),
}

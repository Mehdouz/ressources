import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Typo15, Typo7, Typo10, Typo17, Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const RelatedContainer = styled.div`
  color: ${colors.textColor};
  padding: 30px 0 20px;
  border-top: 1px solid ${colors.grayLight};
  border-bottom: 1px solid ${colors.grayLight};

  ${media.tablet`
    width: 40%;
    float: left;
    padding: ${({ isPublication }) => (isPublication ? '20px 0 25px' : '20px 0 0')};
    font-size: 2.25rem;
    line-height: 40px;
    margin: 0 60px 30px 0;
  `}

  ${media.desktop`
    width: 36%;
    font-size: 3rem;
    line-height: 50px;
  `}
`

export const ParagraphRelatedContentContainer = styled.div`
  display: flex;
  flex-direction: column;
  padding: 0 20px;
  margin-bottom: 20px;

  ${media.tablet`
    display:block;
  `}

  ${media.desktop`
    max-width: 85%;
    margin: 0 auto;
    padding:0 15px;
  `}
`

export const RelatedContent = styled.div`
  ${media.desktop`
    width: 40%;
  `}
`

export const ParagraphContainer = styled.div`
  margin-top: 40px;
  ${Typo10}

  p {
    margin-bottom: 48px;
  }

  ${media.tablet`
    margin-top: 0;
    width: 80%;
    margin: 0 auto;
  `}
`

export const ImageBlocContent = styled.div`
  display: flex;
  flex-direction: column;
`

export const ButtonContainer = styled.div`
  width: 100%;
  clear: both;

  a {
    width: 100%;
  }

  ${media.tablet`
    width: 80%;
  `}
`

export const ImageBloc = styled.div`
  ${media.desktop`
    display: block;
  `}
`

export const RelatedTitle = styled.h2`
  text-transform: uppercase;
  margin-bottom: 20px;
  ${Typo17}
`

export const RelatedContentTitle = styled.h3`
  color: ${colors.textColor};
  margin-bottom: 15px;
  ${Typo7}
`

export const RelatedImage = styled.img`
  display: ${({ isPublication }) => (isPublication ? 'none' : 'block')};
  width: 100%;

  ${media.tablet`
    display: block;
    width: 100%;
  `}
`

export const ImageLink = styled.a`
  margin-bottom: 20px;
  display: block;

  ${media.tablet`
    width: 50%;
    margin-right: 20px;
    margin-bottom: 10px;
  `}

  ${media.desktop`
    float:left;
    width: ${({ isPublication }) => (isPublication ? '27%' : '50%')};
  `}
`

export const PublicationSize = styled.p`
  color: ${colors.creditColor};
  letter-spacing: 0.08em;
  margin-bottom: 20px;
  ${Typo15}

  ${media.tablet`
    font-size: 0.75rem;
  `}
`
export const ErrorMessage = styled.p`
  padding: 150px 40px;
  color: ${colors.errorRed};
  ${Typo43}
`

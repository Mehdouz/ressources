import React from 'react'
import { object, string, array } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Text from '@axacom-client/components/molecules/Text/Text'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import {
  RelatedContainer,
  RelatedTitle,
  ParagraphContainer,
  ParagraphRelatedContentContainer,
  RelatedContentTitle,
  PublicationSize,
  RelatedImage,
  ImageBlocContent,
  ButtonContainer,
  ImageBloc,
  ImageLink,
  ErrorMessage,
} from '@axacom-client/components/organisms/Slices/ParagraphRelatedContent/ParagraphRelatedContent.style'
import { getArticleMeta } from '@axacom-client/services/document-service'
import Button from '@axacom-client/components/atoms/Button/Button'
import { bytesToSize } from '@axacom-client/services/string-service'

export default function ParagraphRelatedContent(props) {
  const { anchorPoint, content, paragraph, title } = props
  const { i18n, domain, currentLocale } = useGlobalContext()

  const isPublication = content.type === 'publication'
  const isEnglish = currentLocale === 'en' ? true : false
  const isParagraphEmpty = paragraph[0].text.length === 0
  const domainIsNotProd = domain !== 'https://www.axa.com'

  const errorMessage = {
    fr: 'Erreur, veuillez vérifier que tous les champs obligatoires sont bien remplis',
    en: 'Something went wrong. Please check that all mandatory fields have been filled in',
  }

  if (isParagraphEmpty && domainIsNotProd) return <ErrorMessage>[Paragraph with related article or publication] : {isEnglish ? errorMessage.en : errorMessage.fr}</ErrorMessage>

  return (
    <Slice slugifiedAnchor={anchorPoint} data-testid="ParagraphRelatedContent">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <ParagraphRelatedContentContainer>
          <div>
            <RelatedContainer isPublication={isPublication}>
              <RelatedTitle data-testid="RelatedTitle">{i18n.t('suggested.article.title')}</RelatedTitle>
              <RelatedContent content={content} title={title} />
            </RelatedContainer>
          </div>
          <ParagraphContainer>
            <Text className="contrib-text">{paragraph}</Text>
          </ParagraphContainer>
        </ParagraphRelatedContentContainer>
      </ResponsiveContainer>
    </Slice>
  )
}

function RelatedContent({ content, title }) {
  return content.type === 'publication' ? <Publication publication={content} title={title} /> : <Article article={content} title={title} />
}

function Publication({ publication, title }) {
  const { i18n, currentLocale, domain } = useGlobalContext()
  const publicationLink = domain + publication.url
  const publicationtitle = title ? title : publication.title

  return (
    <ImageBloc>
      <ImageLink isPublication href={publicationLink}>
        <RelatedImage isPublication src={publication.cover.main.url} alt="" data-testid="RelatedImteamage" />
      </ImageLink>
      <ImageBlocContent>
        <RelatedContentTitle data-testid="RelatedContentTitle">{publicationtitle}</RelatedContentTitle>
        <PublicationSize data-testid="RelatedPublicationSize">PDF {bytesToSize(publication.document.file.size, currentLocale)}</PublicationSize>
      </ImageBlocContent>
      <ButtonContainer>
        <Button href={publication.document.url} iconRight="IconDownload" type="primary" color="red" data-testid="RelatedButton">
          {i18n.t('investorPublications.download')}
        </Button>
      </ButtonContainer>
    </ImageBloc>
  )
}

function Article({ article, title }) {
  const articleTitle = getArticleMeta('title', article)
  const image = getArticleMeta('cover', article)
  const { i18n } = useGlobalContext()

  return (
    <ImageBloc>
      <ImageLink href={article?.url}>
        <RelatedImage src={image?.views?.small.url ? image?.views?.small.url : image?.main.url} isArticle={true} data-testid="RelatedImage" />
      </ImageLink>
      <div>
        <RelatedContentTitle data-testid="RelatedContentTitle">{title ? title : articleTitle}</RelatedContentTitle>
        <Button href={article?.url} iconRight="IconArrowRight" type="link" color="red" data-testid="RelatedButton">
          {i18n.t('suggested.article.read')}
        </Button>
      </div>
    </ImageBloc>
  )
}

ParagraphRelatedContent.propTypes = {
  anchorPoint: string,
  content: object,
  paragraph: array,
  title: string,
}

RelatedContent.propTypes = {
  content: object,
  title: string,
}

Publication.propTypes = {
  publication: object,
  title: string,
}

Article.propTypes = {
  article: object,
  title: string,
}

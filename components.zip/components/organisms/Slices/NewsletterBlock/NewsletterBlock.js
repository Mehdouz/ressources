import React from 'react'
import styled from 'styled-components'
import { Col, Container, Row } from 'reactstrap'
import { object, string } from 'prop-types'
import media from '@axacom-client/base/style/media'
import { Typo18, Typo36 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Image from '@axacom-client/components/atoms/Image/Image'
import { MinDesktop, MinTablet, Mobile } from '@axacom-client/components/utils/Responsive'
import { getSpacing } from '@axacom-client/base/style/spacing'
import ModalNewsletter from '@axacom-client/components/organisms/ModalNewsletter/ModalNewsletter'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

const ContactsTitle = styled.h2`
  ${Typo36};
  text-align: left;
  margin-bottom: ${getSpacing(2)};
`

const ContactSubtitle = styled.h4`
  ${Typo18};
  text-align: left;
  margin-bottom: ${getSpacing(4)};
`
const CustomContainer = styled(Container)`
  background-color: #ffffff;
  box-shadow: 0 4px 62px 5px rgba(0, 0, 0, 0.06);

  ${media.tablet`padding: ${getSpacing(4)};`}
  ${media.phone`padding: ${getSpacing(3)};`}

  flex-direction: column !important;
  align-items: center !important;
  ${media.desktop`
    padding: ${getSpacing(5)} ${(props) => props.imgwidth + 24}px ${getSpacing(4)} ${getSpacing(5)} !important;
    min-height: ${(props) => props.imgheight}px !important;
    flex-direction: row !important;
    align-items: center !important;
  `}
`

const NewsletterBlock = ({ title, subtitle, buttonName, image, slugifiedAnchor }) => {
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="NewsletterBlock">
      <Row>
        <Col xl={{ size: 10, offset: 1 }} lg={{ size: 10, offset: 1 }} md={{ size: 10, offset: 1 }} xs={{ size: 12 }}>
          <CustomContainer imgwidth={image.views.thumbnails.dimensions.width} imgheight={image.views.thumbnails.dimensions.height}>
            {image && (
              <MinDesktop>
                <Image
                  src={image.views.thumbnails.url}
                  style={{
                    width: image.views.thumbnails.dimensions.width,
                    height: image.views.thumbnails.dimensions.height,
                    marginTop: '-40px',
                    marginLeft: '24px',
                    marginRight: `-${image.views.thumbnails.dimensions.width + 24}px`,
                  }}
                  ratio="3:2"
                  data-testid="NewsletterImage"
                  alt="newsletter-image"
                  className="float-right"
                  isBackground={false}
                />
              </MinDesktop>
            )}
            {title && <ContactsTitle data-testid="NewsletterTitle">{title}</ContactsTitle>}
            {subtitle && <ContactSubtitle data-testid="NewsletterSubtitle">{subtitle}</ContactSubtitle>}
            {buttonName && (
              <Row>
                <Col sm={12}>
                  <Mobile>
                    <ModalNewsletter buttonLabel={buttonName} buttonColor="red" width="100%" defaultValue={{ newsletterChoice: ['article', 'pressRelease'] }} />
                  </Mobile>
                  <MinTablet>
                    <ModalNewsletter buttonLabel={buttonName} buttonColor="red" defaultValue={{ newsletterChoice: ['article', 'pressRelease'] }} />
                  </MinTablet>
                </Col>
              </Row>
            )}
          </CustomContainer>
        </Col>
      </Row>
    </Slice>
  )
}

NewsletterBlock.propTypes = {
  title: string,
  subtitle: string,
  buttonName: string,
  image: object,
  anchorId: string,
  slugifiedAnchor: string,
}
export default NewsletterBlock

import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  newsletterBlock: {
    type: 'Slice',
    fieldset: 'Newsletter',
    icon: 'send',
    description: 'React component',
    'non-repeat': {
      anchorId: simpleSlice.anchorId,
      title: {
        type: 'Text',
        fieldset: 'newsletter',
        config: {
          placeholder: 'Newsletter title',
          label: 'Newsletter title',
        },
      },
      subtitle: {
        type: 'Text',
        fieldset: 'newsletter',
        config: {
          placeholder: 'Newsletter subtitle',
          label: 'Newsletter subtitle',
        },
      },
      image: {
        type: 'Image',
        config: {
          label: 'Right Side image',
          placeholder: 'Upload an image...',
          constraint: {
            width: 600,
          },
          thumbnails: [
            {
              name: 'thumbnails',
              width: 300,
              height: 300,
            },
          ],
        },
      },
      buttonName: {
        type: 'Text',
        config: {
          label: 'Newsletter button name',
        },
      },
    },
  },
}

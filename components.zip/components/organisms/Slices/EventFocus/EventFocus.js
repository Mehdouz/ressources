import React, { useRef } from 'react'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'
import { mediaQueries } from '@axacom-client/base/style/media'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Content, TextWrapper, Text, Image } from '@axacom-client/components/organisms/Slices/EventFocus/EventFocus.style'
import { useTimeline } from '@axacom-client/components/pages/timeline-v2/timeline-v2.page'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { useInView } from 'framer-motion/dist/framer-motion'

const variants = {
  visible: {
    transition: { staggerChildren: 0.1, staggerDirection: -1 },
  },
}

const textContainerVariants = {
  hidden: { opacity: 0, x: 20 },
  visible: { opacity: 1, x: 0 },
}

const textVariants = {
  hidden: { opacity: 0, x: 20 },
  visible: { opacity: 1, x: 0, transition: { delay: 0.2 } },
}

const imageVariants = {
  hidden: { opacity: 0, x: 20 },
  visible: { opacity: 1, x: 0 },
}

export default function EventFocus({ text, image, periodStep }) {
  const { colors } = useTimeline()

  const isTablet = useBetterMediaQueries({ query: mediaQueries.tablet }, false)

  const ref = useRef(null)
  const isInView = useInView(ref, { margin: '-100px', once: true })

  return (
    <Slice dataTestid="EventFocus">
      <Container ref={ref}>
        <Content initial="hidden" animate={isInView ? 'visible' : 'hidden'} variants={variants}>
          <TextWrapper $color={colors[periodStep]} variants={textContainerVariants}>
            <Text data-testid="EventFocus_Text" variants={textVariants}>
              {text}
            </Text>
          </TextWrapper>
          {isTablet && <Image data-testid="EventFocus_Image" src={image?.main?.url} alt={image?.alt} variants={imageVariants} />}
        </Content>
      </Container>
    </Slice>
  )
}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Typo10 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'

export const Content = styled(motion.div)`
  display: flex;
  align-items: center;
`

export const TextWrapper = styled(motion.div)`
  flex: 55%;
  border-left: solid 6px ${(props) => props.$color};
  box-shadow: 0px 4px 8px rgb(0 0 0 / 20%);
`

export const Text = styled(motion.div)`
  ${Typo10}

  padding: 24px;
`

export const Image = styled(motion.img)`
  display: none;
  aspect-ratio: 4/3;
  ${media.tablet`
    display: block;
  `};
`

import { Slice, Image, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  eventFocus: Slice(
    {
      text: Text('Summary (Mandatory)', 'Max 257 characters'),
      image: Image('Image (320 x 240px) (Mandatory)', { width: 320, height: 240 }),
    },
    {},
    'Event Focus',
    'React component'
  ),
}

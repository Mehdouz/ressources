import React from 'react'
import { array, string } from 'prop-types'
import SimpleCardDeck from '../SimpleCardDeck/SimpleCardDeck'

import { fillTopicsWithThemes } from '@axacom-client/services/document-service'
import { i18n } from '@i18n-axa'

export default function ArticleSeries({ title, subtitle, items, bgColor, slugifiedAnchor }) {
  return <SimpleCardDeck slugifiedAnchor={slugifiedAnchor} title={title} subtitle={subtitle} items={items} hideItemsSubtitle={true} itemPerLine={3} bgColor={bgColor} dataTestid="ArticleSeries" />
}

ArticleSeries.getInitialProps = async ({ req, document }) => {
  const locale = (req || i18n).language

  document.items = await fillTopicsWithThemes(
    document.items.map(({ cardArticle }) => ({ reference: cardArticle })),
    locale
  )
  return document
}

ArticleSeries.propTypes = {
  title: string,
  subtitle: array,
  items: array.isRequired,
  bgColor: string,
  anchorId: string,
  slugifiedAnchor: string,
}

import { Slice } from '../../../../../tools/prismic/backup-types/generic-type'

import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'
import cardArticle from '../../../molecules/Card/CardArticle/CardArticle.types'

export default {
  articleSeries: Slice(
    {
      anchorId: simpleSlice.anchorId,
      bgColor: simpleSlice.bgColor,
      title: simpleSlice.title,
      subtitle: simpleSlice.subtitle,
    },
    {
      ...cardArticle,
    },
    'Article Series',
    'React component',
    'apps'
  ),
}

import React from 'react'
import { Col, Container, Row } from 'reactstrap'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Button from '@axacom-client/components/atoms/Button/Button'
import { colors } from '@axacom-client/base/style/variables'
import {
  CtaBlockLink,
  CtaBlockSection,
  CtaBlockSubtitle,
  CtaBlockSubtitleMgBottom,
  CtaBlockTitle,
  CtaBlockTitleMgBottom,
  Img,
} from '@axacom-client/components/organisms/Slices/CtaBlock/CtaBlock.style'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

const CtaBlock = (props) => {
  const item = props[0] || props
  const { i18n } = useGlobalContext()
  const { ctaBackgroundImage = 'yes', ctalUrl, externalCtaImage, ctaSubTitle, ctaTitle, ctaUrlTitle, slugifiedAnchor } = item
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} data-testid="CtaBlock">
      <CtaBlockSection image={externalCtaImage ? externalCtaImage.main.url : ''} $isBackgroundImage={ctaBackgroundImage === 'yes'}>
        <Container>
          <Row className={ctaBackgroundImage === 'no' ? 'justify-content-md-center' : ''}>
            {ctaBackgroundImage === 'no' && (
              <>
                <Col xs={{ size: 12 }} xl={{ size: 10 }} lg={{ size: 10 }} md={{ size: 10 }}>
                  <Row className="align-items-center">
                    <Col xs={{ size: 8 }} xl={{ size: 5 }} lg={{ size: 5 }} md={{ size: 5 }}>
                      {ctaBackgroundImage && <Img src={externalCtaImage?.main?.url} alt={externalCtaImage?.main?.alt} />}
                    </Col>
                    <Col xs={{ size: 12 }} xl={{ size: 7 }} lg={{ size: 7 }} md={{ size: 7 }} className="text-left">
                      {ctaTitle && (
                        <CtaBlockTitleMgBottom as="h2" style={{ color: colors.textColor }}>
                          {ctaTitle}
                        </CtaBlockTitleMgBottom>
                      )}
                      {ctaSubTitle && (
                        <CtaBlockSubtitleMgBottom as="h3" style={{ color: colors.textColor }}>
                          {ctaSubTitle}
                        </CtaBlockSubtitleMgBottom>
                      )}
                      {ctalUrl && ctaUrlTitle && (
                        <CtaBlockLink
                          width="100%"
                          size="large"
                          color="red"
                          url={ctalUrl.url}
                          target={ctalUrl.target && ctalUrl.target === 'web' ? '_blank' : '_self'}
                          ariaLabel={!ctaUrlTitle ? `${i18n.t('readmore')}, ${ctaTitle}` : ''}
                        >
                          {ctaUrlTitle || i18n.t('readmore')}
                        </CtaBlockLink>
                      )}
                    </Col>
                  </Row>
                </Col>
              </>
            )}
            {ctaBackgroundImage === 'yes' && (
              <Col md={{ size: 10, offset: 1 }}>
                {ctaTitle && <CtaBlockTitle as="h2">{ctaTitle}</CtaBlockTitle>}
                {ctaSubTitle && <CtaBlockSubtitle>{ctaSubTitle}</CtaBlockSubtitle>}
                {ctalUrl && ctaUrlTitle && (
                  <Button
                    size="large"
                    color="red"
                    url={ctalUrl.url}
                    target={ctalUrl.target && ctalUrl.target === 'web' ? '_blank' : '_self'}
                    ariaLabel={!ctaUrlTitle ? `${i18n.t('readmore')}, ${ctaTitle}` : ''}
                  >
                    {ctaUrlTitle || i18n.t('readmore')}
                  </Button>
                )}
              </Col>
            )}
          </Row>
        </Container>
      </CtaBlockSection>
    </Slice>
  )
}

export default CtaBlock

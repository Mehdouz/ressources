import { Group, Image, Link, Select, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

const nonRepeatFields = {
  anchorPoint: Text('Anchor ID (same as the anchors block)', 'my-anchor-id'),
  ctaTitle: Text('Title', 'CTA title'),
  ctaSubTitle: Text('SubTitle', 'CTA SubTitle'),
  ctaForm: Select(['no', 'yes'], 'Form', 'Yes or no'),
  externalCtaImage: Image(
    'Image',
    {
      width: 1920,
    },
    [
      {
        name: 'small',
        width: 768,
        height: 432,
      },
      {
        name: 'Medium',
        width: 970,
        height: 545,
      },
    ]
  ),
  ctaBackgroundImage: Select(['no', 'yes'], 'Background image', 'Yes or no'),
  ctalUrl: Link('Link'),
  ctaUrlTitle: Text('Link title', 'Link title'),
}

export const ctaBlockGroup = { ctaBlock: Group(nonRepeatFields, 'CTA block', false, 'CTA block', 'React component', 'short_text') }

export const ctaBlockSlice = { ctaBlock: Slice(nonRepeatFields, {}, 'CTA block', 'React component', 'short_text') }

import styled from 'styled-components'

import Text from '@axacom-client/components/molecules/Text/Text'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Typo18, Typo36 } from '../../../../base/style/typoStyle/typoStyle'
import { colors } from './../../../../base/style/variables'
import media from './../../../../base/style/media'
import { getSpacing } from '@axacom-client/base/style/spacing'

export const CtaBlockSection = styled.section`
  background: ${(props) => {
    if (props.image.length > 0 && props.$isBackgroundImage) {
      return `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)) , url(${props.image}) no-repeat center center;`
    } else if (!props.image) {
      return colors.teal
    } else {
      return ''
    }
  }};
  background-size: cover;
  align-items: center;
  display: flex;
  min-height: 335px;
  text-align: center;
  color: white;

  :after {
    content: '';
    display: block;
    min-height: inherit;
    font-size: 0;
  }

  ${media.tablet`min-height: 410px;`};
`

export const CtaBlockTitle = styled(Text)`
  ${Typo36};
  margin: 0 0 15px;

  ${media.tablet`margin: 0 0 25px;`}

  ${media.desktop`margin: 0 0 35px;`}
`

export const CtaBlockSubtitle = styled(Text)`
  ${Typo18};
  margin: 0 0 25px;

  ${media.desktop`margin: 0 0 35px;`}
`
export const CtaBlockLink = styled(Button)`
  ${media.phone`width: 100%;margin-bottom: ${getSpacing(3)};`}
  ${media.tablet`
    width: auto};
  `}
`

export const Img = styled.img`
  ${media.phone`margin-bottom: ${getSpacing(3)};margin-top: ${getSpacing(3)};`}
  ${media.tablet`
    margin-bottom: ${getSpacing(4)};
  `}
`

export const CtaBlockTitleMgBottom = styled(Text)`
  ${Typo36};
  ${media.phone`margin-bottom: ${getSpacing(3)};`}
  ${media.tablet`
    margin-bottom: ${getSpacing(4)};
  `}
`

export const CtaBlockSubtitleMgBottom = styled(Text)`
  ${Typo18};
  ${media.phone`margin-bottom: ${getSpacing(3)};`}
  ${media.tablet`
    margin-bottom: ${getSpacing(4)};
  `}
`

import React from 'react'
import capitalize from 'lodash/capitalize'

import { colors } from '@axacom-client/base/style/variables'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

import { StyledSlice, CoverWithSocialMediaContainer, Title, SocialContainer, SocialMediaTitle, SocialMediaLinks, SocialMediaLinkListItem, SocialMediaLink } from './CoverWithSocialMedia.style'
import { listIsEmpty } from '@axacom-client/services/list-service'

export default function CoverWithSocialMedia({ title, socialMediaTitle, items }) {
  const socialMediaLinks = items?.slice(0, 4)

  return (
    <StyledSlice data-testid="CoverWithSocialMedia">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <CoverWithSocialMediaContainer>
          <Title data-testid="CoverWithSocialMedia__Title">{title}</Title>
          {listIsEmpty(socialMediaLinks) ? null : (
            <SocialContainer data-testid="CoverWithSocialMedia__SocialContainer">
              <SocialMediaTitle data-testid="CoverWithSocialMedia__SocialMediaTitle">{socialMediaTitle}</SocialMediaTitle>
              <SocialMediaLinks data-testid="CoverWithSocialMedia__SocialMediaLinks">
                {socialMediaLinks?.map(
                  ({ socialMedia, link }) =>
                    link?.url && (
                      <SocialMediaLinkListItem key={socialMedia} data-testid="CoverWithSocialMedia__SocialMediaLinkListItem">
                        <SocialMediaLink type="link" href={link.url} data-testid="CoverWithSocialMedia__SocialMediaLink">
                          <Icon name={`Icon${capitalize(socialMedia)}`} width={20} height={20} color={colors.AXABlue} data-testid="CoverWithSocialMedia__SocialMediaLinkIcon" />
                        </SocialMediaLink>
                      </SocialMediaLinkListItem>
                    )
                )}
              </SocialMediaLinks>
            </SocialContainer>
          )}
        </CoverWithSocialMediaContainer>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

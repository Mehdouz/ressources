import styled from 'styled-components'

import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Slice } from '../../SimpleSlice/SimpleSlice'

export const StyledSlice = styled(Slice)`
  padding-bottom: 0px;
  ${media.tablet`
  `}
`
export const CoverWithSocialMediaContainer = styled.div`
  ${media.desktopLarge`
    display: flex;
    justify-content: space-between;
  `}
`

export const Title = styled.h2`
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 48px;
  line-height: 56px;
  color: ${colors.grayDarker};
  margin-bottom: 15px;

  ${media.phone`
    font-size: 32px;
    line-height: 40px;
  `}

  ${media.desktop`
    flex: 0 0 60%;
    margin-bottom: 25px;
  `}
  ${media.desktopLarge`
    margin-bottom: 0px;
  `}

  ${media.desktopVeryLarge`
    font-size: 72px;
    line-height: 80px;
  `}
`

export const SocialContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: baseline;

  ${media.desktopLarge`
    flex: 0 0 40%;
    justify-content: flex-end;
    align-items: center;
  `}
`

export const SocialMediaTitle = styled.h5`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 18px;
  letter-spacing: 1px;
  text-transform: uppercase;
  color: ${colors.AXABlue};
  flex: 0 0 auto;
  margin-right: 26px;

  ${media.desktopLarge`
    margin-bottom: 0;
  `}
`

export const SocialMediaLinks = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
  flex: 0 0 auto;
  display: flex;
  justify-content: flex-start;
`

export const SocialMediaLinkListItem = styled.li`
  margin-right: 26px;
`

export const SocialMediaLink = styled(Button)``

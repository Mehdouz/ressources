import { Slice, Text, Select, Link } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  coverWithSocialMedia: Slice(
    {
      title: Text('Title (Mandatory)', 'Write your title here'),
      socialMediaTitle: Text('Social Media Title', 'Write your title here'),
    },
    {
      socialMedia: Select(['Twitter', 'LinkedIn', 'Instagram', 'YouTube'], 'Select a Social Media'),
      link: Link('Link'),
    },
    'Cover Social Media',
    'React Component'
  ),
}

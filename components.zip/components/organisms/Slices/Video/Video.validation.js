import { mandatorySliceFieldRule } from '../../../utils/FieldValidation'

export default [mandatorySliceFieldRule({ mandatoryFields: ['image', 'title', 'video'], sliceName: 'video', isRepeatable: false })]

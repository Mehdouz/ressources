import { Slice, Text, Image } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  video: Slice(
    {
      image: Image(
        'Image (1920x915px) (Mandatory)',
        {
          width: 1920,
          height: 915,
        },
        [
          {
            name: 'small',
            width: 768,
            height: 423,
          },
          {
            name: 'medium',
            width: 1200,
            height: 572,
          },
        ]
      ),
      title: Text('Title (Mandatory)', 'Write your title here'),
      subtitle: Text('Subtitle (Optional)', 'Write your subtitle here'),
      video: Text('Video URL (Youtube only)', 'Put the url of your youtube video here'),
    },
    {},
    'Video',
    'React component'
  ),
}

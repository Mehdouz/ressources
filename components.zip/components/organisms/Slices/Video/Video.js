import React, { useState } from 'react'
import { string, object, bool, func } from 'prop-types'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import {
  VideoContainer,
  Image,
  Title,
  Subtitle,
  PlayerContainer,
  ContentContainer,
  TextContainer,
  ForegroundImage,
  TitleContainer,
  ModalCustom,
  IconContainer,
} from '@axacom-client/components/organisms/Slices/Video/Video.style'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { mediaQueries } from '@axacom-client/base/style/media'
import { useMediaQuery } from 'react-responsive'
import { truncate } from '@axacom-client/services/string-service'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
export default function Video({ image, title, subtitle, video }) {
  const [modal, setModal] = useState(false)
  const toggle = () => setModal(!modal)
  const { currentLocale } = useGlobalContext()

  const mobileTitle = truncate(title, 100, currentLocale)
  const isMobile = useMediaQuery({ query: mediaQueries.phone })

  const iconSize = isMobile ? 40 : 65
  const videoUrl = getEmbedSrc(video)

  return (
    <Slice fluid className="p-0" data-testid="VideoStory">
      <VideoPlayer modal={modal} toggle={toggle} videoUrl={videoUrl} />
      <VideoContainer data-testid="VideoStory__Container" bgUrl={video} onClick={toggle}>
        <ContentContainer>
          <TitleContainer>
            <IconContainer>
              <Icon name="IconPlayVideo" ariaExpanded={modal} color="white" width={iconSize} height={iconSize} />
            </IconContainer>
            <TextContainer>
              <Title data-testid="VideoStory__Title">{isMobile ? mobileTitle : title}</Title>
              <Subtitle data-testid="VideoStory__Subtitle">{subtitle}</Subtitle>
            </TextContainer>
          </TitleContainer>
        </ContentContainer>
        <div>
          <ForegroundImage />
          <Image
            data-testid="VideoStory__Image"
            srcSet={`
            ${image.main.url} 800w,
            ${image.views.small.url} 500w,
            ${image.views.medium.url} 375w,
            `}
            sizes="40vmin"
            alt={image.main.alt}
          />
        </div>
      </VideoContainer>
    </Slice>
  )
}

function VideoPlayer({ videoUrl, modal, toggle }) {
  return (
    <ModalCustom size="xl" isOpen={modal} toggle={toggle} scrollable={false}>
      <PlayerContainer isVisible={modal}>
        <iframe
          data-testid="VideoStory__VideoPlayer"
          className="embedVideo"
          src={videoUrl}
          title="YouTube video player"
          frameBorder="0"
          autoPlay="1"
          allow="autoplay; encrypted-media; fullscreen"
        ></iframe>
      </PlayerContainer>
    </ModalCustom>
  )
}

function getEmbedSrc(url) {
  if (url.includes('/watch')) {
    return url.replace(/.*\?v=(.*)$/, 'https://www.youtube.com/embed/$1?autoplay=1&start=0')
  } else if (url.includes('youtu.be')) {
    return url.replace(/.*\/([^/]*)$/, 'https://www.youtube.com/embed/$1?autoplay=1&start=0')
  }

  return ''
}

Video.propTypes = {
  image: object,
  title: string,
  subtitle: string,
  video: string,
}
VideoPlayer.propTypes = {
  videoUrl: string,
  modal: bool,
  toggle: func,
}

VideoPlayer.defaultProps = {
  modal: false,
  toggle: false,
}

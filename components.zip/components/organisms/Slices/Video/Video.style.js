import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import Modal from '@axacom-client/components/molecules/Modal/Modal'
import { Typo25, Typo12 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const VideoContainer = styled.div`
  position: relative;
  overflow: hidden;
  max-height: 450px;

  ${media.tablet`
    max-height: 750px;
  `}
`

export const PlayerContainer = styled.div`
  overflow: hidden;
  margin-top: 45px;
  padding-bottom: 56.25%;
  position: relative;
  height: 0;

  & .embedVideo {
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    position: absolute;
  }
`

export const ModalCustom = styled(Modal)`
  & .modal-dialog {
    max-width: 80%;
  }
`

export const ContentContainer = styled.div`
  position: absolute;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 5;
  color: #fff;
  padding: 0 30px;
  ${media.tablet`
  width: 80%;
  top: 0;
  left: 50%;
  margin-left: -40%;
  padding: 0 40px;
  `}
  ${media.desktop`
    width: 60%;
    margin-left: -30%;
  `}
`

export const Title = styled.h2`
  ${Typo12}

  ${media.desktop`
    font-size: 2rem;
    line-height: 2.5rem;
  `}
`

export const Subtitle = styled.p`
  text-transform: uppercase;
  margin-top: 20px;
  ${Typo25}
`

export const Image = styled.img`
  width: 135%; // permet d'avoir l'image qui rempli le container tout en gardant son ratio
  position: relative;
  max-width: inherit;

  ${media.tablet`
    width: 100vw;
    height:inherit;
    left: 50%;
    right: 50%;
    margin-left: -50vw;
    margin-right: -50vw;
  `}
`

export const TextContainer = styled.div`
  &:hover,
  &:focus,
  &:active {
    cursor: pointer;
  }
`

export const IconContainer = styled.div`
  margin-bottom: 15px;
  &:hover,
  &:focus,
  &:active {
    cursor: pointer;
  }
  ${media.tablet`
    margin-bottom: 0;
    margin-right: 20px;
  `}
`

export const ForegroundImage = styled.div`
  background: rgba(0, 0, 0, 0.6);
  width: 100%;
  top: 0;
  left: 0;
  height: 150%;
  position: absolute;
  display: block;
  z-index: 2;
`

export const TitleContainer = styled.div`
  ${media.tablet`
    display: flex;
    align-items: flex-start;
  `}
`

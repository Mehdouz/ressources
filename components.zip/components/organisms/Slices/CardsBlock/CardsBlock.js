import React, { useState } from 'react'
import { array, string } from 'prop-types'
import styled from 'styled-components'
import { Col, Row } from 'reactstrap'
import media from '@axacom-client/base/style/media'
import { MinTablet, Mobile } from '@axacom-client/components/utils/Responsive'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import LoadMoreButton from '@axacom-client/components/atoms/Button/LoadMoreButton'
import CardCovered from '@axacom-client/components/molecules/CardCovered/CardCovered'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

const CardsBlockCol = styled(Col)`
  margin: 0 0 15px;

  &:last-child {
    margin: 0;
  }

  ${media.tablet`
    margin: 0 0 25px;

    &:last-child {
      margin: 0 0 25px;
    }
  `};
`

const LoadMoreContainer = styled(Col)`
  text-align: center;
  margin: 30px 0 0;
`

export const StyledSlice = styled(Slice)`
  max-width: 1170px;
  margin: 0 auto;
`

function CardsBlock({ items, slugifiedAnchor }) {
  const [visible, setVisible] = useState(3)

  function onLoadMore(e) {
    e.preventDefault()
    setVisible(visible + 3)
  }

  return (
    <StyledSlice data-testid="CardsBlock" slugifiedAnchor={slugifiedAnchor}>
      <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
        <div className="px-4">
          <Row>
            <Mobile>
              {items.length &&
                items.slice(0, visible).map((item, index) => (
                  <CardsBlockCol key={index} lg="4" md="6">
                    <CardCovered text={item.text} image={item.image} ctaLabel={item.ctaLabel} ctaLink={item.ctaLink} dataTestid="CardsBlock_Cover" as="a" />
                  </CardsBlockCol>
                ))}
              {visible < items.length && (
                <LoadMoreContainer>
                  <LoadMoreButton onClick={(e) => onLoadMore(e)} />
                </LoadMoreContainer>
              )}
            </Mobile>
            <MinTablet>
              {items.map((item, index) => (
                <CardsBlockCol key={index} lg="4" md="6">
                  <CardCovered text={item.text} image={item.image} ctaLabel={item.ctaLabel} ctaLink={item.ctaLink} dataTestid="CardsBlock_Cover" as="a" />
                </CardsBlockCol>
              ))}
            </MinTablet>
          </Row>
        </div>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

CardsBlock.propTypes = { items: array, anchorId: string, slugifiedAnchor: string }

export default CardsBlock

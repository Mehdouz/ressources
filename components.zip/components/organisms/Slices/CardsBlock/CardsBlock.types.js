import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  cardsBlock: {
    type: 'Slice',
    fieldset: 'Cards block',
    description: 'React component',
    icon: 'crop_7_5',
    repeat: {
      anchorId: simpleSlice.anchorId,
      text: {
        type: 'StructuredText',
        config: {
          label: 'text',
          placeholder: '',
        },
      },
      ctaLabel: {
        type: 'Text',
        fieldset: 'Link button',
        config: {
          label: 'Link name',
          placeholder: '',
        },
      },
      ctaLink: {
        type: 'Link',
        config: {
          label: 'Link reference',
        },
      },
      image: {
        type: 'Image',
        config: {
          placeholder: 'Image',
          constraint: {
            width: 1920,
          },
          thumbnails: [
            {
              name: 'small',
              width: 768,
              height: 432,
            },
            {
              name: 'Medium',
              width: 970,
              height: 545,
            },
          ],
        },
      },
    },
  },
}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Typo22, Typo23 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const KeyFiguresContainer = styled.div`
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  margin: 0 30px;
  align-items: center;

  ${media.tablet`
    margin: 0 auto;
    width: 80%;
    justify-content: ${({ hasThreeFigures }) => (hasThreeFigures ? 'space-between' : 'space-evenly')};
    flex-direction: row;
    align-items: flex-start;
  `};
`

export const KeyFigures = styled.div`
  width: 100%;
  background: ${({ bgColor }) => (bgColor ? bgColor : 'black')};
  padding: 80px 0;
`

export const FigureContainer = styled.div`
  display: flex;
  flex-direction: column;
  text-align: center;
  color: #fff;
  position: relative;
  padding: 0 15px;
`

export const Separator = styled.div`
  width: 82px;
  height: 1px;
  margin: 45px 0;
  background: ${({ color }) => (color ? color : 'white')};
  display: block;
  position: relative;
  align-self: center;

  ${media.tablet`
    width: 1px;
    height: 82px;
    margin: 0;
  `};
`
export const Figure = styled.p`
  margin-bottom: 20px;
  ${Typo22}
`

export const Title = styled.p`
  ${Typo23}

  ${media.desktop`
      max-width: 200px;
  `};

  ${media.desktopLarge`
      max-width: 270px;
  `};
`

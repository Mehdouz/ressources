import { mandatorySliceFieldRule } from '../../../utils/FieldValidation'

export default [mandatorySliceFieldRule({ mandatoryFields: ['figure', 'text'], sliceName: 'keyFiguresStory', isRepeatable: true })]

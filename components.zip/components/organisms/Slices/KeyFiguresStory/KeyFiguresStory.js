import React from 'react'
import { string, array, object, bool } from 'prop-types'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { KeyFigures, KeyFiguresContainer, FigureContainer, Figure, Title, Separator } from '@axacom-client/components/organisms/Slices/KeyFiguresStory/KeyFiguresStory.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export default function KeyFiguresStory({ anchorPoint, items, storyColors }) {
  return (
    <Slice dataTestid="KeyFigures" slugifiedAnchor={anchorPoint} noPaddings fluid>
      <KeyFigures data-testid="KeyFiguresContainer" bgColor={storyColors.background}>
        <ResponsiveContainer veryLargeDesktop>
          <KeyFiguresContainer hasThreeFigures={items.length >= 3}>
            {items &&
              items.map(({ figure, text: title, isLastElement }, index) => {
                return <KeyFiguresItem key={index} storyColor={storyColors.accent} isLastElement={isLastElement} figure={figure} title={title} />
              })}
          </KeyFiguresContainer>
        </ResponsiveContainer>
      </KeyFigures>
    </Slice>
  )
}

KeyFiguresStory.propTypes = {
  anchorPoint: string,
  items: array,
  storyColors: object,
}

const KeyFiguresItem = ({ isLastElement, figure, title, storyColor }) => (
  <>
    <FigureContainer>
      <Figure data-testid="KeyFiguresNumber">{figure}</Figure>
      <Title data-testid="KeyFiguresTitle">{title}</Title>
    </FigureContainer>
    {!isLastElement && <Separator color={storyColor} />}
  </>
)

KeyFiguresItem.propTypes = {
  isLastElement: bool,
  figure: string,
  title: string,
  storyColor: string,
}

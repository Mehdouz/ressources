import { Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  keyFiguresStory: Slice(
    {},
    {
      figure: Text('Figure (Mandatory) (4 digit max)', 'Write your figure here'),
      text: Text('Text (Mandatory)', 'Write your text here'),
    },
    'Key Figures',
    'React component',
    'format_list_numbered'
  ),
}

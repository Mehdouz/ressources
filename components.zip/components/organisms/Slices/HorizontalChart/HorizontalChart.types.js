import { Group, PrismicNumber, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  'horizontal-chart': Group(
    {
      anchorPoint: StructuredText('Anchor ID (same as the anchors block)', 'my-anchor-id'),
      first_legend: Text('First legend'),
      first_data: PrismicNumber('First data', 0, 100),
      second_legend: Text('Second legend'),
      second_data: PrismicNumber('Second data', 0, 100),
      chart_legend: Text('Chart legend'),
    },
    'Horizontal bar chart',
    false,
    'Horizontal bar chart',
    'React Component',
    'short_text'
  ),
}

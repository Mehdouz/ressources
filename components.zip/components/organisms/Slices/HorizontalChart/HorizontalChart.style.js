import styled from 'styled-components'
import Text from '@axacom-client/components/molecules/Text/Text'
import { Typo28 } from '../../../../base/style/typoStyle/typoStyle'
import { Typo16, Typo36 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import { font } from '@axacom-client/base/style/variables'

export const GraphBarLeft = styled.div`
  background-color: #f2af4d;
  float: right;
  width: 100%;
  height: 55px;
`

export const GraphBarRight = styled.div`
  background-color: #f36a6e;
  width: 100%;
  height: 55px;
`

const commonText = `
  ${Typo16}
  text-transform: uppercase;
  font-weight: bold;
  display: block;
  margin-top: 10px;
  hyphens: auto;
  padding-bottom: 8px;
  min-width: min-content;

    ${media.phone`
      height: 55px;
      display: flex;
      margin-top: 45px;
      align-items: center;
      text-align: center;
      min-width: 100px;
      flex: initial;
      min-width: min-content;

`}`

export const FirstLegend = styled(Text)`
  ${commonText}
  padding-right: 15px;
`

export const SecondLegend = styled(Text)`
  ${commonText}
  padding-left: 15px;
`

export const Label = styled(Text)`
  margin-bottom: 15px;
  font-family: ${font.fontFamilyHeading};
  ${media.phone`
    ${Typo28}
      font-family: ${font.fontFamilyHeading};
  `}

  ${media.tablet`
    ${Typo28}
      font-family: ${font.fontFamilyHeading};
  `}

  ${media.desktop`
      ${Typo28}
        font-family: ${font.fontFamilyHeading};
  `}

   ${media.desktopLarge`
      ${Typo36}
  `}
`

export const Legend = styled(Text)`
  ${Typo16}
  margin-top: 20px;
  text-align: center;
  width: 100%;
`

import React from 'react'
import { number, string } from 'prop-types'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Col, Row } from 'reactstrap'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { FirstLegend, GraphBarLeft, GraphBarRight, Label, Legend, SecondLegend } from '@axacom-client/components/organisms/Slices/HorizontalChart/HorizontalChart.style'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'

export default function HorizontalChart(props) {
  // eslint-disable-next-line react/prop-types
  const item = props[0] || props
  const { first_legend, first_data, second_legend, second_data, chart_legend, slugifiedAnchor } = item
  const { currentLocale } = useGlobalContext()

  return (
    first_data + second_data === 100 && (
      <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="horizontalChart">
        <Container>
          <Row>
            <Col md={{ size: 10, offset: 1 }} lg={{ size: 8, offset: 2 }}>
              <div className="d-flex">
                <FirstLegend className="d-none d-sm-flex align-items-end text-center">{first_legend}</FirstLegend>
                <div className="d-flex w-100">
                  <div className="text-center" style={{ width: `${first_data}%` }}>
                    <Label>{currentLocale === 'fr' ? first_data.toString().replace('.', ',') + '%' : first_data.toString().replace(',', '.') + '%'}</Label>
                    <GraphBarLeft />
                  </div>

                  <div className="text-center" style={{ width: `${second_data}%` }}>
                    <Label>{currentLocale === 'fr' ? second_data.toString().replace('.', ',') + '%' : second_data.toString().replace(',', '.') + '%'}</Label>
                    <GraphBarRight />
                  </div>
                </div>

                <SecondLegend className="d-none d-sm-flex align-items-end text-center">{second_legend}</SecondLegend>
              </div>
            </Col>
          </Row>
          <Row>
            <Col xs="6" className="d-md-none">
              <FirstLegend className="mt-2 text-left">{first_legend}</FirstLegend>
            </Col>
            <Col xs="6" className="d-md-none">
              <SecondLegend className="mt-2 text-right">{second_legend}</SecondLegend>
            </Col>
          </Row>
          {chart_legend && (
            <Row>
              <Col lg="12">
                <Legend>{chart_legend}</Legend>
              </Col>
            </Row>
          )}
        </Container>
      </Slice>
    )
  )
}

HorizontalChart.propTypes = {
  slugifiedAnchor: string,
  first_legend: string,
  first_data: number,
  second_legend: string,
  second_data: number,
  chart_legend: string,
}

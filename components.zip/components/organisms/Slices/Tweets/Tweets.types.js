import { Group } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../SimpleSlice/SimpleSlice.types'
import tweetEmbed from '../../../molecules/TweetEmbed/TweetEmbed.type'

export default {
  tweets: Group(
    {
      anchorPoint: simpleSlice.anchorId,
      ...tweetEmbed,
    },
    'Tweets',
    false,
    'Tweets',
    'React Component',
    'ondemand_video'
  ),
}

import React from 'react'
import { array, string } from 'prop-types'
import { Col, Row } from 'reactstrap'

import TweetEmbed from '@axacom-client/components/molecules/TweetEmbed/TweetEmbed'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

function Tweets(props) {
  let items = props

  return (
    <Slice slugifiedAnchor={items[0]?.anchorPoint} data-testid="Tweets">
      {items && !!Object.keys(items).length && (
        <Row>
          {Object.keys(items).map((item, index) => {
            // All data's document are send to component on page-v2. We need to return only if tweets' data.
            if (items[item]?.tweet_id) {
              return (
                <Col key={index} sm={'12'}>
                  <TweetEmbed key={index} {...items[item]} />
                </Col>
              )
            }
          })}
        </Row>
      )}
    </Slice>
  )
}

Tweets.propTypes = {
  title: string,
  subtitle: array,
  bgColor: string,
  anchorId: string,
  slugifiedAnchor: string,
}

export default Tweets

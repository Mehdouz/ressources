import { Image, Slice, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

const nonRepeat = {
  anchorId: simpleSlice.anchorId,
  title: Text('Title', 'Title of the slice'),
  subtitle: Text('Subtitle'),
}

const repeat = {
  image: Image('Image'),
  title: Text('Title'),
  paragraph: StructuredText('Description'),
}

const carousel = {
  carousel: Slice(nonRepeat, repeat, '∞ Carousel - 8 items max', 'React Component', 'view_column'),
}

export default carousel

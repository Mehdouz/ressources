import styled from 'styled-components'
import Text from '@axacom-client/components/molecules/Text/Text'

import { Typo18, Typo20, Typo28 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { getSpacing } from '@axacom-client/base/style/spacing'

export const Subtitle = styled(Text)`
  ${Typo18};
  text-align: center;
  white-space: pre-wrap;
  margin-bottom: ${getSpacing(4)};
`

// <CarouselItem />

export const Wrapper = styled.div`
  position: relative;
  word-wrap: break-word;
  background-color: #fff;
  background-clip: border-box;
  border: 1px solid rgba(0, 0, 0, 0.125);
  border-radius: 0.25rem;
`

export const Content = styled.div`
  padding: 30px;
`

export const ItemTitle = styled(Text)`
  ${Typo28}
  text-align: center;
  margin-bottom: ${getSpacing(3)};
`

export const ItemParagraph = styled(Text)`
  ${Typo20}
`

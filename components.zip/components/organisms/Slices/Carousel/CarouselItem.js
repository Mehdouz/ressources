import React from 'react'
import styled from 'styled-components'
import { oneOfType, node, string, array, object } from 'prop-types'
import { Typo18, Typo28 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Text from '@axacom-client/components/molecules/Text/Text'
import { getSpacing } from '@axacom-client/base/style/spacing'
import media from '@axacom-client/base/style/media'

const CarouselItem = ({ image, title, paragraph, ...rest }) => {
  return (
    <Wrapper {...rest}>
      <ImageWrapper>
        <ImageCover url={image?.main?.url} data-testid="CarouselImage"></ImageCover>
      </ImageWrapper>
      <Content>
        <ItemTitle data-testid="CarouselTitle">{title}</ItemTitle>
        <ItemParagraph data-testid="CarouselParagraph">{paragraph}</ItemParagraph>
      </Content>
    </Wrapper>
  )
}

CarouselItem.propTypes = {
  image: object,
  title: string,
  paragraph: oneOfType([node, array, string]),
}

export default CarouselItem

export const Wrapper = styled.div`
  position: relative;
  background-clip: border-box;
  height: 100%;
  display: flex;
  flex-direction: column;
  ${media.desktop`
    flex-direction: row;
  `}
`

const ImageWrapper = styled.div`
  height: 200px;
  ${media.tablet`
      height: 350px;
    `}
  ${media.desktop`
      width: 50%;
    `}
`

const ImageCover = styled.div`
  background-image: url('${(props) => props.url}');
  height: 100%;
  background-size: cover;
  background-position: center;
`

export const Content = styled.div`
  padding: 30px 15px;
  text-align: center;
  background-color: #fff;
  flex: 1;
  ${media.tablet`
      padding: ${getSpacing(4)}
    `}
  ${media.desktop`
      width: 50%;
      padding: ${getSpacing(5)}
  `}
`

export const ItemTitle = styled(Text)`
  ${Typo28}
  text-align: center;
  margin-bottom: ${getSpacing(3)};
  ${media.desktop`
    text-align: left;
  `}
`

export const ItemParagraph = styled(Text)`
  ${Typo18}
  margin-bottom: ${getSpacing(2)};
  ${media.desktop`
    padding-right: ${getSpacing(5)};
    text-align: left;
  `}
  ${media.desktopLarge`
  padding-right: ${getSpacing(10)}`}
`

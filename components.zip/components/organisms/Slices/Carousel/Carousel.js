import React from 'react'
import { oneOfType, node, string, array, arrayOf, shape } from 'prop-types'
import styled from 'styled-components'
import ContentCarousel, { Slide } from '@axacom-client/components/molecules/ContentCarousel/ContentCarousel'
import { Slice, SliceTitle as Title, SliceSubtitle as Subtitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Container, Row } from 'reactstrap'
import CarouselItem from './CarouselItem'
import media, { mediaQueries } from '@axacom-client/base/style/media'
import { useMediaQuery } from 'react-responsive'

// TODO: remove that props[0]
export default function CarouselWrapper(props) {
  // eslint-disable-next-line react/prop-types
  return <Carousel {...(props[0] || props)}></Carousel>
}

const Wrapper = styled.div`
  width: 100%;
  padding: 0 15px;
  & .carousel__inner-slide {
    padding: 7px;
  }
  ${media.tablet`
    padding: 0;
    & .carousel__container {
      max-width: 100%;
      margin: auto;
    }
    & .carousel__inner-slide {
      padding: 20px;
    }
  `}
`

const Carousel = ({ anchorId, items, title, subtitle }) => {
  const isMobile = useMediaQuery({ query: mediaQueries.phone })
  return (
    <Slice slugifiedAnchor={anchorId} dataTestid="CarouselSlice" bgColor="gray">
      <Container>
        <Row>
          {title && (
            <Title data-testid="CarouselTitle" $textAlign="center">
              {title}
            </Title>
          )}
          {subtitle && (
            <Subtitle data-testid="CarouselSubtitle" $textAlign="center">
              {subtitle}
            </Subtitle>
          )}
        </Row>
      </Container>
      <Container fluid>
        <Row>
          <Wrapper>
            <ContentCarousel showArrows={!isMobile}>
              {Array.isArray(items) &&
                items.slice(0, 8).map((item, i) => (
                  <Slide key={i} index={i}>
                    <CarouselItem {...item}></CarouselItem>
                  </Slide>
                ))}
            </ContentCarousel>
          </Wrapper>
        </Row>
      </Container>
    </Slice>
  )
}

Carousel.propTypes = {
  anchorId: string,
  title: string,
  subtitle: oneOfType([node, array, string]),
  items: arrayOf(shape(CarouselItem.propTypes)),
}

export default {
  items: [],
  anchorPoint: 'single image',
  slugifiedAnchor: 'single image',
  illustration: {
    main: {
      dimensions: { width: 1920, height: 1280 },
      alt: '',
      copyright: '',
      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/fae596c46f045c3ffa09e74b426bb0c33002a13f_axa_ag_ebl.jpg',
    },
    views: {
      small: {
        dimensions: { width: 768, height: 432 },
        alt: '',
        copyright: '',
        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/7eb0c65a2a6264f50aff446c8251a577a85bb65c_axa_ag_ebl.jpg',
      },
      medium: {
        dimensions: { width: 970, height: 545 },
        alt: '',
        copyright: '',
        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/e936e25c62d1c84de64bc6cc20b8558943699ec1_axa_ag_ebl.jpg',
      },
    },
  },
  caption: ['credit trop cool'],
  credit: 'credit trop cool',
}

import React from 'react'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import SingleMedia from '@axacom-client/components/molecules/SingleMedia/SingleMedia'

const SingleImage = (props) => {
  // eslint-disable-next-line react/prop-types
  const item = props[0] || props
  const { slugifiedAnchor, illustration } = item
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="SingleImage">
      {illustration && <SingleMedia {...item} />}
    </Slice>
  )
}
export default SingleImage

import { Group, Image, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  'single-image': Group(
    {
      anchorPoint: simpleSlice.anchorId,
      illustration: Image('Illustration picture', { width: 1920 }, [
        {
          name: 'small',
          width: 768,
          height: 432,
        },
        {
          name: 'Medium',
          width: 970,
          height: 545,
        },
      ]),
      caption: Text('Caption text', 'Fill-in your caption here'),
      credit: Text('Credit', 'Fill-in the credit here'),
    },
    'Single Image',
    false,
    'Single Image',
    'React Component',
    'image'
  ),
}

import React from 'react'
import { string, object } from 'prop-types'

import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

import { Title, Cta, PressReleaseBlock, PressReleaseContainer, PressRelease, PressReleaseDate, PressReleaseTitle, PressReleaseContent } from './PressReleaseList.style'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { dateTime } from '@axacom-client/services/date-service'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

export default function PressReleaseList({ pressReleaseListTitle, pressReleaseListLink, pressReleaseListLinkName, items }) {
  const { currentLocale } = useGlobalContext()

  return (
    <Slice data-testid="PressReleaseList">
      <Container>
        {pressReleaseListTitle && <Title data-testid="PressReleaseList__Title">{pressReleaseListTitle}</Title>}
        {pressReleaseListLink?.url && pressReleaseListLinkName && (
          <Cta type="link" color="red" iconRight="IconArrowRight" href={pressReleaseListLink.url} data-testid="PressReleaseList__Button">
            {pressReleaseListLinkName}
          </Cta>
        )}
      </Container>
      {items.length > 0 && (
        <PressReleaseContainer data-testid="PressReleaseList__Releases">
          {items.map((item, i) => {
            const formatedDate = dateTime(item.date, 'LL', currentLocale)

            return (
              <PressRelease key={i} href={item.url} data-testid="PressReleaseList__Release">
                <Container>
                  <PressReleaseBlock>
                    <PressReleaseDate data-testid="PressReleaseList__Release__Date">{formatedDate}</PressReleaseDate>
                    <PressReleaseContent>
                      <PressReleaseTitle data-testid="PressReleaseList__Release__Title">{item.title}</PressReleaseTitle>
                    </PressReleaseContent>
                  </PressReleaseBlock>
                </Container>
              </PressRelease>
            )
          })}
        </PressReleaseContainer>
      )}
    </Slice>
  )
}

PressReleaseList.getInitialProps = async ({ document }) => {
  return document
}

PressReleaseList.propTypes = {
  latestPressReleasesTitle: string,
  latestPressReleasesLinkName: string,
  latestPressReleasesLink: object,
}

import { Slice, Link, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  pressReleaseList: Slice(
    {
      pressReleaseListTitle: Text('Latest Press Releases Title (Mandatory)', 'Write your title here'),
      pressReleaseListLinkName: Text('Latest Press Releases Link Name', 'Write your link name here'),
      pressReleaseListLink: Link('Latest Press Releases Link', null, null, true, 'Link (web/document/media)'),
    },
    {},
    'Press Release List',
    'React Component',
    'library_books'
  ),
}

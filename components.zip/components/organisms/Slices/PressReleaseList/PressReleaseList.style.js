import styled from 'styled-components'

import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'

import Button from '@axacom-client/components/atoms/Button/Button'
import { Typo36 } from '@axacom-client/base/style/typoStyle/typoStyle'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

export const Title = styled.h2`
  ${Typo36}
`

export const PressReleaseBlock = styled.div`
  display: flex;
  flex-direction: column;

  ${media.tablet`
    flex-direction: row;
  `}
`

export const PressReleaseContainer = styled.div`
  margin-top: 32px;

  ${media.desktopLarge`
    margin-top: 40px;
  `}
`

export const PressRelease = styled(SmartLink)`
  color: ${colors.black};
  border-bottom: 1px solid ${colors.grayLighter};
  padding: 24px 0;
  display: block;

  &:hover {
    background-color: ${colors.grayLighter};
    color: ${colors.black};
  }

  &:last-child {
    border: 0;
  }

  ${media.desktop`
    padding: 32px 0;
  `}
`

export const PressReleaseDate = styled.p`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  text-transform: uppercase;
  font-size: 0.75rem;
  letter-spacing: 0.08em;

  ${media.tablet`
    width: 20%;
  `}

  ${media.desktopLarge`
    font-size: 0.813rem;
  `}
`

export const PressReleaseContent = styled.div`
  ${media.tablet`
    width: 80%;
  `}
`

export const PressReleaseTitle = styled.h3`
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 1.375rem; // 22px
  line-height: 1.625rem; // 26px
  letter-spacing: 0.015em;
  display: inline-block;
  margin: 8px 0;

  ${media.tablet`
    margin: 0;
  `}

  ${media.desktopLarge`
    font-size: 1.5rem; // 28px;
    line-height: 1.75rem; // 28px;
  `}
`

export const Cta = styled(Button)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 16px;
  letter-spacing: 1px;
`

import { Link, Select, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  lineChart: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'Select a title', false),
      subtitle: Text('Subtitle', 'Select a subtitle', false),
      color: Select(['blue', 'green', 'yellow', 'red'], 'Graph color', '', 'blue'),
      graphLegend: Text('Graph legend', 'Dollards per year', false),
      csv: Link('CSV file', '', undefined, undefined, 'revenus.csv'),
      legend: Text('Legend', '(c) dataset from the internet'),
    },
    {},
    'Line Chart',
    'React Component',
    'show_chart'
  ),
}

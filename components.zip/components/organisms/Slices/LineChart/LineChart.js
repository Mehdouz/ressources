import React from 'react'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import dynamic from 'next/dynamic'
import useMeasure from 'react-use-measure'
import { SliceSubtitle, SliceTitle } from '../../SimpleSlice/SimpleSlice'
import { GraphLegend, StyledSlice, SvgWrapper, Legend } from './LineChart.style'
import { object, string } from 'prop-types'
import { colors } from '@axacom-client/base/style/variables'

const LineChartInner = dynamic(() => import('./LineChartInner'), { ssr: false })

// TODO: remove or update colors based on the new design
const chartColors = {
  blue: colors.ocean200,
  green: colors.viridian200,
  yellow: colors.apache200,
  red: colors.tosca200,
}

function LineChart({ title, subtitle, color, csv, graphLegend, legend, slugifiedAnchor }) {
  const [ref, bounds] = useMeasure()
  const { datas, headers } = csv

  // We parseInt() every single value since all datas has to be integers
  const data = datas?.map((d) => ({
    [headers[0]]: parseInt(d[headers[0]]),
    [headers[1]]: parseInt(d[headers[1]]),
  }))

  const chartColor = chartColors[color] || chartColors.blue

  return (
    <StyledSlice fluid data-testid="LineChartSlice" slugifiedAnchor={slugifiedAnchor}>
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        {title && <SliceTitle $textAlign="center">{title}</SliceTitle>}
        {subtitle && <SliceSubtitle $textAlign="center">{subtitle}</SliceSubtitle>}
        <GraphLegend color={chartColor}>{graphLegend}</GraphLegend>

        <SvgWrapper ref={ref}>
          {/* Line chart */}
          {bounds.width > 0 && <LineChartInner data={data} headers={headers} color={chartColor} height={bounds.height} width={bounds.width} />}
        </SvgWrapper>
        <Legend>{legend}</Legend>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

LineChart.getInitialProps = async ({ document }) => {
  return document
}

LineChart.propTypes = {
  title: string,
  subtitle: string,
  color: string,
  csv: object,
  graphLegend: string,
  legend: string,
  slugifiedAnchor: string,
}

export default LineChart

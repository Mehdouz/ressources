import React from 'react'
import { curveMonotoneX, line as d3line } from 'd3-shape'
import { scaleLinear } from 'd3-scale'
import { extent } from 'd3-array'
import { format, formatDefaultLocale } from 'd3-format'
import { G, Svg, StyledTextGrid } from './LineChart.style'
import { colors } from '@axacom-client/base/style/variables'
import { motion } from 'framer-motion/dist/framer-motion'
import { useMediaQuery } from 'react-responsive'
import { mediaVariables } from '@axacom-client/base/style/media'
import DotLabel from './DotLabel'
import { array, number, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

const marginMobile = {
  top: 50,
  right: 30,
  bottom: 50,
  left: 30,
}

const marginDesktop = {
  top: 50,
  right: 50,
  bottom: 100,
  left: 100,
}

function TextGrid(props) {
  return <StyledTextGrid fill={colors.grey400} {...props}></StyledTextGrid>
}

export default function LineChartInner({ data, headers, color, width, height }) {
  const { currentLocale } = useGlobalContext()
  const isMobile = useMediaQuery({ maxWidth: mediaVariables.phoneMax })
  const margin = isMobile ? marginMobile : marginDesktop

  const showYLabel = !isMobile

  // create and apply xscale based on the user screen width
  let xScale = scaleLinear()
    .domain(extent(data.map((d) => d[headers[0]])))
    .range([margin.left, width - margin.right])

  // create and apply yscale based on the height of the element
  let yScale = scaleLinear()
    .domain(extent(data.map((d) => d[headers[1]])))
    .range([height - margin.bottom, margin.top])

  // generate line values based on the current scale
  let line = d3line()
    .x((d) => xScale(d[headers[0]]))
    .y((d) => yScale(d[headers[1]]))
    .curve(curveMonotoneX)

  // generate d attribute of <path />
  let d = line(data)

  // since we have only 2 locales, set a default format for french (space instead of comma)
  // big numbers in french should be in the following format 3,000.00 => 3 000,00
  if (currentLocale === 'fr') {
    formatDefaultLocale({
      thousands: ' ',
      grouping: [3],
    })
  }
  // ChatGPT: @La version 1.4.4 de la bibliothèque d3-format prend en charge les formatteurs de nombre "d" (pour "integer"),
  // "n" (pour "number") et "g" (pour "general").
  // Vous pouvez utiliser l'un de ces formatteurs pour formater un nombre entier sans décimales.
  const f = format(',d')

  return (
    <>
      <Svg color={color} viewBox={`0 0 ${width} ${height}`}>
        {/* bolder left line */}
        <G>
          <line x1={margin.left} x2={margin.left} y1={margin.top} y2={height - margin.bottom + 15} strokeWidth={1} stroke={colors.grey400} />
        </G>

        {/* y scale */}
        {yScale.ticks(6).map((max, i) => (
          <G key={i} transform={`translate(0, ${yScale(max)})`}>
            <line x1={margin.left - 15} x2={width - margin.right} strokeWidth={1} stroke="currentColor" />
            {showYLabel ? (
              <TextGrid alignmentBaseline="middle" textAnchor="end" x={margin.left - 30}>
                {f(max)}
              </TextGrid>
            ) : null}
          </G>
        ))}

        {/* bolder bottom line */}
        <G>
          <line x1={margin.left - 15} x2={width - margin.right + 15} y1={height - margin.bottom} y2={height - margin.bottom} strokeWidth={1} stroke={colors.grey400} />
        </G>

        {/* x scale */}
        {xScale.ticks(showYLabel ? 6 : 3).map((min, i) => (
          <G key={i} transform={`translate(${xScale(min)}, 0)`}>
            <line y1={margin.top} y2={height - margin.bottom + 15} stroke="currentColor" strokeWidth={1}></line>
            <TextGrid y={height - margin.bottom + 30} textAnchor="middle" alignmentBaseline="hanging">
              {/* business needs: x axis are always dates so no need to format them */}
              {min}
            </TextGrid>
          </G>
        ))}

        {/* the curve */}
        <motion.path
          d={d}
          fill="none"
          stroke="currentColor"
          strokeWidth={2.5}
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1, type: 'spring', delay: 0.5 }}
        ></motion.path>

        {/* dots with labels */}
        {data.map((d, i) => {
          return (
            <DotLabel index={i} color={color} x={xScale(d[headers[0]])} y={yScale(d[[headers[1]]])} key={i} isLast={data.length - 1 === i}>
              {f(d[headers[1]])}
            </DotLabel>
          )
        })}
      </Svg>
    </>
  )
}

LineChartInner.propTypes = {
  data: array,
  headers: array,
  color: string,
  width: number,
  height: number,
}

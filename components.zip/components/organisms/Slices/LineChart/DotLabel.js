import React, { useState } from 'react'
import { G, AnimatedCircle, StyledTextCurve } from './LineChart.style'
import { mediaVariables } from '@axacom-client/base/style/media'
import { useMediaQuery } from 'react-responsive'
import { any, bool, number, string } from 'prop-types'

function TextCurve(props) {
  return <StyledTextCurve fill="currentColor" {...props}></StyledTextCurve>
}

export default function DotLabel({ color, x, y, isLast, index, children }) {
  const [isHovered, setHovered] = useState(false)
  const isMobile = useMediaQuery({ maxWidth: mediaVariables.phoneMax })

  return (
    <G color={color} onMouseEnter={() => isMobile && setHovered(true)}>
      {/* dot circle */}
      <AnimatedCircle
        r={6}
        cx={x}
        cy={y}
        fill="currentColor"
        strokeWidth={3}
        stroke="white"
        initial={{ scale: 0 }}
        animate={{ scale: 1, ...((isMobile && isLast) || isHovered ? { fill: 'white', stroke: color } : {}) }}
        transition={{ duration: 0.5, type: 'spring', ...(isHovered ? { delay: 0 } : { delay: index * 0.05 }) }}
      ></AnimatedCircle>

      {/* text */}
      <TextCurve
        x={x}
        fill="currentColor"
        textAnchor="middle"
        alignmentBaseline="baseline"
        initial={{ y, opacity: 0 }}
        animate={{
          ...(isMobile ? (isLast || isHovered ? { opacity: 1, y: y - 20 } : { opacity: 0 }) : { opacity: 1, y: y - 20 }),
        }}
        transition={{ duration: 0.5, type: 'spring', ...(isHovered ? { delay: 0 } : { delay: 0.5 + index * 0.1 }) }}
      >
        {children}
      </TextCurve>
    </G>
  )
}

DotLabel.propTypes = {
  color: string,
  x: number,
  y: number,
  isLast: bool,
  index: number,
  children: any,
}

import styled from 'styled-components'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { colors } from '@axacom-client/base/style/variables'
import Text from '@axacom-client/components/molecules/Text/Text'
import { Typo17, Typo20Bold, Typo25, Typo32 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import { motion } from 'framer-motion/dist/framer-motion'

export const StyledSlice = styled(Slice)`
  max-width: 1170px;
  margin: 0 auto;
`
export const G = styled(motion.g)`
  color: ${({ color = colors.grey200 }) => color};
`
export const Legend = styled(Text)`
  color: ${colors.grey500};
  /* margin-top: 3px;
  margin-right: 8px; */
  ${Typo25}
`

export const StyledTextGrid = styled(motion.text)`
  ${Typo17}
`
export const StyledTextCurve = styled(motion.text)`
  ${Typo20Bold}
`

export const GraphLegend = styled(Text)`
  ${Typo32}
  display: flex;
  align-items: center;
  &:before {
    content: '';
    display: block;
    background-color: ${({ color = colors.grey600 }) => color};
    ${media.phone`
      width: 25px;
      height: 25px;
    `}
    width: 15px;
    height: 15px;
    border-radius: 50%;
    margin-right: 15px;
  }
  padding: 15px 15px 15px;
  margin-bottom: 30px;
  justify-content: center;
  ${media.phone`
    justify-content: start;
    background-color: ${colors.grey200};
  `}
`

export const SvgWrapper = styled.div`
  position: relative;
  margin-bottom: 30px;
  ${media.phone`
  padding-bottom: 100%;
  `}
  ${media.tablet`
  padding-bottom: 75%;
  `}
  ${media.desktop`
  padding-bottom: 56.25%;
  `}
`

export const Svg = styled.svg`
  color: ${({ color }) => color};
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
`

export const AnimatedCircle = styled(motion.circle)`
  transition: fill 0.3s, stroke 0.3s;
`

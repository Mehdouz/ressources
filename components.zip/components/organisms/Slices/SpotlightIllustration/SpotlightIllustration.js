import React from 'react'
import { oneOfType, string, array } from 'prop-types'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { Container, Col, Row } from 'reactstrap'
import { Paragraph } from './SpotlightIllustration.style'
import { default as ImageContent, imageObject, videoObject } from './SpotlightImageContent'

const SpotlightIllustration = ({ anchorPoint, image, videoMp4, videoWebm, paragraph }) => {
  const hasParagraph = !!paragraph?.[0]?.text
  return (
    <Slice slugifiedAnchor={anchorPoint}>
      <Container fluid={!hasParagraph}>
        <Row>
          {hasParagraph ? (
            <Col md={{ size: 5, offset: 1 }} lg={{ size: 4, offset: 2 }}>
              <Paragraph>{paragraph}</Paragraph>
            </Col>
          ) : null}
          {hasParagraph ? (
            <Col md="6" lg="6">
              <ImageContent hasLeftParagraph={hasParagraph} image={image} videoMp4={videoMp4} videoWebm={videoWebm}></ImageContent>
            </Col>
          ) : (
            <ImageContent hasLeftParagraph={hasParagraph} image={image} videoMp4={videoMp4} videoWebm={videoWebm}></ImageContent>
          )}
        </Row>
      </Container>
    </Slice>
  )
}

SpotlightIllustration.propTypes = {
  anchorPoint: string,
  image: imageObject,
  videoMp4: videoObject,
  videoWebm: videoObject,
  paragraph: oneOfType([array, string]),
}

// TODO: remove that props[0]
export default function SpotlightIllustrationWrapper(props) {
  // eslint-disable-next-line react/prop-types
  return <SpotlightIllustration {...(props[0] || props)}></SpotlightIllustration>
}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Typo10 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Text from '@axacom-client/components/molecules/Text/Text'

export const SpotlightImageBloc = styled.div`
  overflow: hidden;
  position: relative;
  ${(props) => (props.hasVideo ? 'height: 300px;' : '')}
  ${(props) => (props.hasLeftParagraph ? `height: 200px;` : '')}
  ${media.tablet`height: 350px;`}
  ${media.desktop`
    height: auto;
    img {
      position: relative;
      top: 0;
      left: 0;
      width: 100%;
      height: auto;
      transform: none;
    }
  `}
  video {
    min-width: 100%;
    max-width: none;
    min-height: 100%;
    width: auto;
    height: 100%;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
`

export const Paragraph = styled(Text)`
  ${Typo10}
`

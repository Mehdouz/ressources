import { Image, Link, Group, StructuredText } from '../../../../../tools/prismic/backup-types/generic-type'

import simpleSlice from '../../SimpleSlice/SimpleSlice.types'
// export const Group = (fields, label, repeat = false, fieldset = '', description = '', icon = '') => {
const spotlightIllustration = {
  'spotlight-illustration': Group(
    {
      anchorPoint: simpleSlice.anchorId,
      image: Image(
        'Image',
        {
          width: 1920,
        },
        [
          {
            name: 'tablet',
            width: 768,
            height: 480,
          },
          {
            name: 'mobile',
            width: 640,
            height: 600,
          },
        ]
      ),
      paragraph: StructuredText('Left paragraph (Optional)', 'lorem...'),
      videoMp4: Link('Video link (MP4)', 'web', undefined, undefined, 'Video link (MP4)'),
      videoWebm: Link('Video Link (WEBM)', 'web', undefined, undefined, 'Video Link (WEBM)'),
    },
    '',
    false,
    'Spotlight Illustration',
    'React component',
    'featured_play_list'
  ),
}

export default spotlightIllustration

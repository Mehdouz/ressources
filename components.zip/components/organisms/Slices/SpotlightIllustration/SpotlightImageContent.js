import React from 'react'
import { SpotlightImageBloc } from './SpotlightIllustration.style'
import { LargeDesktop, Mobile, MinTablet, SmallDesktopAndMobile } from '@axacom-client/components/utils/Responsive'
import { string, bool, number, shape } from 'prop-types'

const defaultVideoOpts = {
  loop: true,
  preload: 'none',
  autoPlay: true,
  muted: true,
  webkitplaysinline: 'true',
}

export default function SpotlightImageContent({ hasLeftParagraph, image, videoMp4, videoWebm, ...rest }) {
  if (!image) return null
  return (
    <SpotlightImageBloc hasVideo={videoMp4?.url} hasLeftParagraph={hasLeftParagraph} {...rest}>
      {/* Conditional paragraph */}
      {hasLeftParagraph ? (
        <img src={image?.views?.tablet?.url} alt="" />
      ) : (
        <>
          <LargeDesktop>
            <img src={image?.main?.url} alt="" />
          </LargeDesktop>
          <MinTablet>
            <SmallDesktopAndMobile>
              <img src={image?.main?.url} alt="" />
            </SmallDesktopAndMobile>
          </MinTablet>
          <Mobile>
            <img src={image?.views?.mobile?.url} alt="" />
          </Mobile>
        </>
      )}
      {/* Conditional video */}
      {videoMp4?.url ? (
        <video {...defaultVideoOpts}>
          <source src={videoWebm.url} type="video/webm" />
          <source src={videoMp4?.url} type="video/mp4" />
        </video>
      ) : null}
    </SpotlightImageBloc>
  )
}

export const prismicImageObject = shape({
  alt: string,
  copyright: string,
  url: string,
  dimensions: shape({ width: number, height: number }),
})

export const imageObject = shape({
  main: prismicImageObject,
  tablet: prismicImageObject,
  mobile: prismicImageObject,
})

export const videoObject = shape({
  target: string,
  url: string,
})

SpotlightImageContent.propTypes = {
  hasLeftParagraph: bool,
  image: imageObject.isRequired,
  videoMp4: videoObject,
  videoWebm: videoObject,
}

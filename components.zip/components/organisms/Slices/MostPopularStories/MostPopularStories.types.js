import { Slice, Text, Link } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  mostPopularStories: Slice(
    {
      title: Text('Title', 'Write your title here'),
    },
    {
      story: Link('Stories', 'document', ['stories']),
    },
    'Most Popular Stories (2 items min and max)',
    'React component'
  ),
}

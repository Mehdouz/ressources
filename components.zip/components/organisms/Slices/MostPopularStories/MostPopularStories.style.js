import styled from 'styled-components'

import media from '@axacom-client/base/style/media'
import { font } from '@axacom-client/base/style/variables'
import { Typo19, Typo36 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

export const StyledSlice = styled(Slice)`
  padding: 65px 30px;

  ${media.tablet`
    width: 80%;
    padding: 65px 0;
    margin: auto;
  `}

  ${media.desktop`
    padding: 80px 0;
  `};
`

export const SliceTitle = styled.h2`
  margin-bottom: 3rem;

  font-size: 2rem; // 24px
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  line-height: 2.5rem; // 32px
  text-align: center;

  ${media.tablet`
    font-size: 2.5rem; // 40px
    line-height: 3rem; // 48px
  `}

  ${media.desktopVeryLarge`
    font-size: 3rem; // 40px
    line-height: 3.5rem; // 48px
  `}
`

export const StoriesContainer = styled.div`
  ${media.tablet`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
  `}
`

export const StoryContainer = styled.div`
  ${media.tablet`
    width: 50%;
  `}

  &:first-child {
    margin-bottom: 3rem;

    ${media.tablet`
      margin-right: 15px;
      margin-bottom: 0;
    `}

    ${media.desktop`
      margin-right: 20px;
    `}
  }
`

export const CoverImage = styled.img`
  margin-bottom: 2rem;
`

export const StoryTitle = styled.h3`
  ${Typo36}

  ${media.phone`
    font-size: 1.5rem; //24px
    line-height: 2rem; // 32px
  `}
`

export const ReadTime = styled.p`
  margin: 1rem 0;

  ${media.desktop`
  margin: 1rem 0 1rem;
`}

  svg {
    margin-top: -2px;
    margin-right: 5px;
  }
`

export const Summary = styled.div`
  ${Typo19}
`

export const CtaButton = styled(Button)`
  margin-top: 1rem;
`

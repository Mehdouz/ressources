import React from 'react'
import { string, array } from 'prop-types'

import { colors, media } from '@axacom-client/base/style/variables'
import { Mobile, Tablet, Desktop, LargeDesktop, VeryLargeDesktop } from '@axacom-client/components/utils/Responsive/ResponsiveComponents'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

import { StyledSlice, SliceTitle, StoriesContainer, StoryContainer, CoverImage, StoryTitle, ReadTime, Summary, CtaButton } from './MostPopularStories.style'

export const MIN_MAX_MOST_POPULAR_STORIES = 2

export default function MostPopularStories({ title, stories }) {
  const { i18n } = useGlobalContext()

  if (!stories || stories.length < 2) {
    return null
  }

  return (
    <StyledSlice fluid dataTestid="MostPopularStories">
      <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop data-testid="MostPopularStoriesResponsiveContainer">
        {title && <SliceTitle data-testid="MostPopularStoriesSliceTitle">{title}</SliceTitle>}
        <StoriesContainer data-testid="MostPopularStoriesStoriesContainer">
          {stories.map((story) => (
            <StoryContainer key={story.title} data-testid="MostPopularStoriesStoryContainer">
              <CoverImage
                data-testid="MostPopularStoriesCoverImage"
                alt={story.coverImage?.main?.alt}
                sizes={`
                  (max-width: ${media.phoneMax}) ${story.coverImage.mobile.dimensions.width}px,
                  (max-width: ${media.desktopMax}) ${story.coverImage.desktop.dimensions.width}px,
                  (min-width: ${media.desktopXLMin}) ${story.coverImage.main.dimensions.width}px,
                `}
                srcSet={`
                  ${story.coverImage.main.url} ${story.coverImage.main.dimensions.width}w,
                  ${story.coverImage.desktop.url} ${story.coverImage.desktop.dimensions.width}w,
                  ${story.coverImage.mobile.url} ${story.coverImage.mobile.dimensions.width}w,
                `}
              />
              <StoryTitle data-testid="MostPopularStoriesStoryTitle">{story.title}</StoryTitle>
              <ReadTime data-testid="MostPopularStoriesReadTime">
                <Icon name="IconAlarm" color={colors.black} width={15} height={15} />
                {story.readTime}
              </ReadTime>
              <Summary data-testid="MostPopularStoriesSummary">
                <Mobile>{story.summary.mobile}</Mobile>
                <Tablet>{story.summary.tablet}</Tablet>
                <Desktop>{story.summary.desktop}</Desktop>
                <LargeDesktop>{story.summary.largeDesktop}</LargeDesktop>
                <VeryLargeDesktop>{story.summary.veryLargeDesktop}</VeryLargeDesktop>
              </Summary>
              <CtaButton href={story.url} type="link" iconRight="IconArrowRight" size="large" color="red" data-testid="MostPopularStoriesCTA">
                {i18n.t('landingStories.mostPopular.readMore')}
              </CtaButton>
            </StoryContainer>
          ))}
        </StoriesContainer>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

MostPopularStories.propTypes = {
  title: string,
  stories: array,
}

export default [
  (document) => {
    const sliceMostPopularStories = document.body.find((slice) => slice.sliceType === 'mostPopularStories')

    return !sliceMostPopularStories || sliceMostPopularStories.value.items.length >= 2
  },
]

import styled from 'styled-components'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo9, Typo19, Typo12 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const StyledSlice = styled(Slice)`
  padding-bottom: 60px;

  ${media.tablet`
    padding-bottom: 100px;
  `};

  ${media.desktop`
    padding-top: 160px;
    padding-bottom: 200px;
  `};
`

export const FirstContentContainer = styled.div`
  display: flex;
  flex-direction: column;
  color: ${colors.grayDarker};
  padding: 0 30px;

  ${media.tablet`
    padding: 0;
  `}

  ${media.desktop`
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  `}
`

export const EmphasisWrapper = styled.div`
  width: 100%;
  order: 1;
  display: flex;
  position: relative;

  ${media.tablet`
    justify-content: center;
  `}

  ${media.desktop`
    width: 40%;
    justify-content: flex-end;
    order: 0;
  `}
`

export const Emphasis = styled.figure`
  display: block;
  position: relative;

  &:before {
    content: '';
    height: 100%;
    width: 4px;
    background: ${({ color }) => (color ? color : 'black')};
    position: absolute;
    display: block;
  }

  ${media.tablet`
    width: 75%;
  `}
`

export const EmphasisText = styled.blockquote`
  margin-top: 10px;
  margin-right: 0;
  margin-bottom: ${({ hasAuthor }) => (hasAuthor ? '30px' : '10px')};
  margin-left: 30px;
  ${Typo12}
`

export const EmphasisAuthor = styled.figcaption`
  margin: 10px 0 10px 30px;
  ${Typo19}
  font-weight: ${font.weight.semiBold};
`

export const ContentWrapper = styled.div`
  order: 0;
  width: 100%;
  display: flex;
  justify-content: center;

  ${media.desktop`
    width: 60%;
    justify-content: flex-start;
  `}
`

export const Content = styled.div`
  ${media.tablet`
    width: 75%;
  `}

  ${media.desktop`
    width: 83.33%;
    margin: 0;
    padding-left: 120px;
  `}
`

export const Summary = styled.h2`
  margin-bottom: 40px;
  ${Typo9}
`

export const ContentParagraph = styled.div`
  margin-bottom: 65px;
  ${Typo19}

  & p:not(:last-child) {
    margin-bottom: 25px;
  }

  ${media.desktop`
    margin-bottom: 0;
  `}
`

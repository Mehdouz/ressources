import React from 'react'
import { string, array, object } from 'prop-types'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import Text from '@axacom-client/components/molecules/Text/Text'
import {
  StyledSlice,
  FirstContentContainer,
  Emphasis,
  EmphasisAuthor,
  EmphasisText,
  Content,
  Summary,
  ContentParagraph,
  EmphasisWrapper,
  ContentWrapper,
} from '@axacom-client/components/organisms/Slices/FirstContents/FirstContents.style'

export default function FirstContents({ anchorPoint, summary, content, emphasis, authorEmphasis, storyColors }) {
  return (
    <StyledSlice slugifiedAnchor={anchorPoint} fluid data-testid="FirstContent">
      <ResponsiveContainer veryLargeDesktop>
        <FirstContentContainer>
          <EmphasisWrapper>
            <Emphasis data-testid="FirstContent__Emphasis" color={storyColors.accent}>
              <EmphasisText data-testid="FirstContent__EmphasisText" hasAuthor={!!authorEmphasis}>
                {emphasis}
              </EmphasisText>
              {authorEmphasis && <EmphasisAuthor data-testid="FirstContent__EmphasisAuthor">— {authorEmphasis}</EmphasisAuthor>}
            </Emphasis>
          </EmphasisWrapper>
          <ContentWrapper>
            <Content data-testid="FirstContent__Content">
              <Summary data-testid="FirstContent__Summary">{summary}</Summary>
              <ContentParagraph data-testid="FirstContent__ContentParagraph">
                <Text className="contrib-text">{content}</Text>
              </ContentParagraph>
            </Content>
          </ContentWrapper>
        </FirstContentContainer>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

FirstContents.getInitialProps = async ({ document }) => {
  return document
}

FirstContents.propTypes = {
  anchorPoint: string,
  summary: string,
  content: array,
  emphasis: string,
  authorEmphasis: string,
  storyColors: object,
}

import { Slice, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  storyFirstContents: Slice(
    {
      summary: Text('Summary (Mandatory)', 'Write your summary here'),
      content: StructuredText('Content (Mandatory)', 'Write your paragraph here'),
      emphasis: Text('Emphasis (Mandatory)', 'Write your emphasis here'),
      authorEmphasis: Text('Emphasis Author (Optional)', 'Write the emphasis author here'),
    },
    {},
    'First Contents',
    'React component'
  ),
}

import { mandatorySliceFieldRule } from '../../../utils/FieldValidation'

export default [mandatorySliceFieldRule(['summary', 'content', 'emphasis'], 'storyFirstContents')]

import React from 'react'
import { array, object, string } from 'prop-types'
import {
  Content,
  BackgroundImage,
  Surtitle,
  Title,
  LinkButton,
  StoriesPromotionWrapper,
  StoriesPromotionContainer,
} from '@axacom-client/components/organisms/Slices/StoriesPromotion/StoriesPromotion.style'
import { media } from '@axacom-client/base/style/variables'
import ResponsiveContainer from '../../../atoms/ResponsiveContainer/ResponsiveContainer'

export default function StoriesPromotion({ storiesPromotion }) {
  const { image, surtitle, title, link, linkName } = storiesPromotion[0]

  return (
    <StoriesPromotionWrapper>
      <StoriesPromotionContainer>
        <Content>
          <ResponsiveContainer mobile tablet>
            <Surtitle data-testid="StoriesPromotion__surtitle">{surtitle}</Surtitle>
            <Title data-testid="StoriesPromotion__title">{title}</Title>
            <LinkButton data-testid="StoriesPromotion__button" url={link.url} color="white" type="ghost" target={link.target === 'web' || link.target === 'file' ? '_blank' : '_self'}>
              {linkName}
            </LinkButton>
          </ResponsiveContainer>
        </Content>
        <picture>
          <source media={`(max-width: ${media.phoneMax}px)`} srcSet={image.views.mobile.url} />
          <source media={`(max-width: ${media.tabletMax}px)`} srcSet={image.views.tablet.url} />
          <source media={`(max-width: ${media.desktopMax}px)`} srcSet={image.views.desktop.url} />
          <source media={`(min-width: ${media.desktopXLMin}px)`} srcSet={image.main.url} />
          <BackgroundImage data-testid="StoriesPromotion__image" src={image.main.url} alt={image?.main?.alt} />
        </picture>
      </StoriesPromotionContainer>
    </StoriesPromotionWrapper>
  )
}

StoriesPromotion.propTypes = {
  storiesPromotion: array,
  image: object,
  link: object,
  linkName: string,
  surtitle: string,
  title: string,
}

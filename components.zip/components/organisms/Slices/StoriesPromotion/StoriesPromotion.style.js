import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo25, Typo12 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'

import Button from '@axacom-client/components/atoms/Button/Button'

export const StoriesPromotionWrapper = styled.div`
  position: relative;
  overflow: hidden;
`

export const StoriesPromotionContainer = styled.div`
  ${media.desktop`
    margin-top: 45px;
  `}

  ${media.desktopVeryLarge`
    margin-top: 80px;
  `}
`

export const BackgroundImage = styled.img`
  width: 100%;

  ${media.desktop`
    width: auto;
    max-width: fit-content;
  `}

  ${media.desktopLarge`
    width: 100%;
    max-width: 100%;
  `}
`
export const Content = styled.div`
  background-color: ${colors.stories.apache.progressBar};
  padding: 65px 0;

  ${media.tablet`
    padding: 65px 0;
  `}

  ${media.desktop`
    position: absolute;
    top: 0;
    right: 0;
    width: 48%;
    padding: 50px 65px;
    max-height: 100%;
  `}

  ${media.desktopVeryLarge`
    padding: 80px;
    top: 30px;
  `}
`

export const Surtitle = styled.p`
  color: ${colors.white};
  ${Typo25};
  font-weight: ${font.weight.semiBold};
  text-transform: uppercase;
`

export const Title = styled.h1`
  color: ${colors.white};
  ${Typo12}
  margin-top: 15px;

  ${media.desktop`
    font-size: 2rem;
    line-height: 2.5rem;
  `}

  ${media.desktopVeryLarge`
    font-size: 3rem;
    line-height: 3.5rem;
  `}
`

export const LinkButton = styled(Button)`
  color: ${colors.white};
  margin-top: 40px;
  width: 100%;
  border-width: 1px;

  &:hover {
    color: ${colors.stories.apache.progressBar};
  }

  ${media.tablet`
    width: auto;
  `}
`

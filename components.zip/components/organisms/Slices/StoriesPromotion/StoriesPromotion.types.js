import { Group, Link, Text, Image } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  $storiesPromotion: Group(
    {
      image: Image('Image (1920x560px) (Mandatory)', { width: 1920, height: 560 }, [
        {
          name: 'desktop',
          width: 1200,
          height: 440,
        },
        {
          name: 'tablet',
          width: 768,
          height: 440,
        },
        {
          name: 'mobile',
          width: 375,
          height: 270,
        },
      ]),
      surtitle: Text('Surtitle (Mandatory)'),
      title: Text('Title (Mandatory)'),
      linkName: Text('Link name (Mandatory)'),
      link: Link('Link (Mandatory)', null, null, true, 'Link (web/document/media)'),
    },
    'Stories Promotion'
  ),
}

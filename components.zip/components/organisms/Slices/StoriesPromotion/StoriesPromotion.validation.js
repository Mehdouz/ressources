import { mandatorySliceFieldRule } from '../../../utils/FieldValidation'

export default [mandatorySliceFieldRule({ mandatoryFields: ['image', 'surtitle', 'title', 'link', 'linkName'], sliceName: 'storiesPromotion', isRepeatable: false, isRealSlice: false })]

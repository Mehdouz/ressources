import React from 'react'
import { string, object } from 'prop-types'
import { FlexContainer, ImageCover, RightContent, Duration, TitleCover } from '@axacom-client/components/organisms/Slices/CoverStory/CoverStory.style'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { colors } from '@axacom-client/base/style/variables'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export default function CoverStory({ cover, readTime }) {
  const { image, title } = cover

  return (
    <ResponsiveContainer veryLargeDesktop data-testid="CoverStoryContainer">
      <FlexContainer>
        <ImageCover data-testid="CoverStory__ImageCover" src={image.main.url} sizes="40vmin" alt={image?.main?.alt} />
        <RightContent>
          <TitleCover data-testid="CoverStory__TitleCover">{title}</TitleCover>
          <Duration>
            <Icon name="IconAlarm" color={colors.textColor} width={15} height={15} /> {readTime}
          </Duration>
        </RightContent>
      </FlexContainer>
    </ResponsiveContainer>
  )
}

CoverStory.propTypes = {
  cover: object,
  image: object,
  title: string,
  readTime: string,
}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Typo21 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const FlexContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100;

  ${media.tablet`
    flex-direction: row;
    align-items: center;
  `}
`
export const ImageCover = styled.img`
  width: 100%;

  ${media.tablet`
    width: 50%;
  `}

  ${media.desktop`
    width: 40%;
  `}
`
export const RightContent = styled.div`
  margin: 64px 0 32px;
  padding: 0 35px;

  ${media.tablet`
    width: 50%;
  `}

  ${media.desktop`
    width: 60%;
    padding-left: 120px;
  `}
`

export const Duration = styled.p`
  svg {
    margin-top: -2px;
    margin-right: 5px;
  }
`

export const TitleCover = styled.h1`
  margin-bottom: 32px;
  ${Typo21}

  ${media.tablet`
    max-width: 80%;
  `}
`

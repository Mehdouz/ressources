export default {
  items: [
    {
      iconImage: 'IconValidation',
      iconColor: 'white',
      text: [
        {
          type: 'paragraph',
          text: '4 numéros de la lettre des actionnaires',
          spans: [],
        },
      ],
    },
    {
      iconImage: 'IconValidation',
      iconColor: 'white',
      text: [
        {
          type: 'paragraph',
          text: 'Un accès privilégié au rendez-vous organisés par le groupe',
          spans: [],
        },
      ],
    },
    {
      iconImage: 'IconValidation',
      iconColor: 'white',
      text: [
        {
          type: 'paragraph',
          text: 'Des tarifs préférentiels sur les grands crus AXA',
          spans: [],
        },
      ],
    },
  ],
  bgColor: 'blue',
  title: 'Les avantages du cercle AXA',
}

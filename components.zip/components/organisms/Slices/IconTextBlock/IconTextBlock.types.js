import icons from '../../../atoms/Icon/Icon.types'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  iconTextBlock: {
    type: 'Slice',
    fieldset: 'Icon Text Block',
    icon: 'art_track',
    description: 'React component',
    'non-repeat': {
      anchorId: simpleSlice.anchorId,
      bgColor: {
        type: 'Select',
        fieldset: 'Background color',
        config: {
          label: 'Select a background color (default: white)',
          options: ['white', 'gray', 'blue'],
          default_value: 'white',
        },
      },
      title: {
        type: 'Text',
        config: {
          label: 'Title',
          placeholder: 'Select a title',
        },
      },
    },
    repeat: {
      ...icons,
      text: {
        type: 'StructuredText',
        config: {
          label: 'text',
          placeholder: '',
        },
      },
    },
  },
}

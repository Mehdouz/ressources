import React from 'react'
import { array, bool, string } from 'prop-types'
import styled from 'styled-components'
import { Col, Row } from 'reactstrap'
import media from '@axacom-client/base/style/media'
import { Typo18 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Card from '@axacom-client/components/molecules/Card/Card'
import { MinDesktop, Mobile, MobilesDevices, Tablet } from '@axacom-client/components/utils/Responsive'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import Text from '@axacom-client/components/molecules/Text/Text'
import { Slice, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { colors } from '@axacom-client/base/style/variables'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

const CardsBlockCol = styled(Col)`
  margin: 0 0 15px;

  &:last-child {
    margin: 0;
  }

  ${media.tablet`
    margin: 0 0 25px;

    &:last-child {
      margin: 0 0 25px;
    }
  `};
`

const FilteredRow = ({ ...otherProps }) => <Row {...otherProps} />
FilteredRow.propTypes = { isReverse: bool }
const AsideRow = styled(FilteredRow)`
  padding-top: 30px;

  ${media.tablet` padding-top: 40px;`}
  ${media.desktop` padding-top: 50px;`}

  &:first-child {
    padding-top: 0;
  }
`

const Content = styled(Text)`
  ${Typo18}
  margin: 0;
  color: ${(props) => (props.bgColor === 'blue' ? colors.white : colors.textColor)};
`

const IconTextBlock = ({ items, title, bgColor, slugifiedAnchor }) => {
  return (
    <Slice dataTestid="IconTextBlock" bgColor={bgColor} slugifiedAnchor={slugifiedAnchor}>
      <ResponsiveContainer desktop largeDesktop veryLargeDesktop>
        {title ? <SliceTitle $textAlign="center">{title}</SliceTitle> : null}
        <MinDesktop>
          <Row>
            {items &&
              !!Object.keys(items[0]).length &&
              items.map((item, index) => (
                <CardsBlockCol lg="4" md="4" key={`#col${index}`}>
                  <Card
                    key={`#card${index}`}
                    parentColor={bgColor}
                    borderColor="transparent"
                    bgColor="transparent"
                    center={true}
                    data-testid="IconTextBlockCard"
                    icon={{ image: item.iconImage, color: item.iconColor, size: 64 }}
                    text={item.text}
                    display="block"
                    fontColor="#ffffff"
                  />
                </CardsBlockCol>
              ))}
          </Row>
        </MinDesktop>
        <MobilesDevices>
          {items &&
            !!Object.keys(items[0]).length &&
            items.map((item, index) => (
              <AsideRow key={`#row${index}`}>
                <Col xs={{ size: 'auto', offset: 1 }} sm={{ size: 'auto', offset: 1 }} key={`#colIcon${index}`}>
                  {item && item.iconImage && (
                    <>
                      <Mobile>
                        <Icon
                          key={`#icon${index}`}
                          name={item.iconImage}
                          color={item.iconColor}
                          width="33px"
                          height="33px"
                          animation="scale"
                          ratio="1:1"
                          className="text-center"
                          dataTestid="CardIcon"
                        />
                      </Mobile>
                      <Tablet>
                        <Icon
                          key={`#icon${index}`}
                          name={item.iconImage}
                          color={item.iconColor}
                          width="39px"
                          height="39px"
                          animation="scale"
                          ratio="1:1"
                          className="text-center"
                          dataTestid="CardIcon"
                        />
                      </Tablet>
                    </>
                  )}
                </Col>
                <Col xs="8" sm="8" key={`#colCon${index}`} className="justify-content-center align-self-center">
                  {item && item.text && (
                    <Content key={`#content${index}`} bgColor={bgColor}>
                      {item.text[0].text}
                    </Content>
                  )}
                </Col>
              </AsideRow>
            ))}
        </MobilesDevices>
      </ResponsiveContainer>
    </Slice>
  )
}

IconTextBlock.propTypes = {
  items: array.isRequired,
  title: string,
  bgColor: string,
  anchorId: string,
  slugifiedAnchor: string,
}

export default IconTextBlock

export default function mock() {
  return {
    sliceType: 'ctaBlock',
    sliceLabel: null,
    value: [
      {
        anchorPoint: [
          {
            type: 'paragraph',
            text: 'accessible-ri',
            spans: [],
          },
        ],
        slugifiedAnchor: 'accessible-ri',
        ctaTitle: 'Retrouvez le RI en version 100% accessible',
        ctaSubTitle: 'Sae doles accaecerspe eicatus unto dolorro exerehent. voluptatem incius ellab iliqui voluptaqui cullaboEcepudae voluptia velesseque',
        ctaForm: 'no',
        ctalUrl: {
          url: 'https://www.google.com/',
          target: 'web',
        },
        ctaUrlTitle: 'Découvrir',
      },
    ],
  }
}

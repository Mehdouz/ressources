import React from 'react'
import styled from 'styled-components'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Slice, SliceSubtitle, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

import media from './../../../../base/style/media'
import { getSpacing } from '../../../../base/style/spacing'
import Text from '../../../molecules/Text/Text'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'

const Content = styled(Text)`
  margin-bottom: ${getSpacing(4)};
  text-align: center;
`

const HeadSubtitle = styled(SliceSubtitle)`
  display: none;
  margin: 0 auto ${getSpacing(3)} auto;
  ${media.tablet`
    display: block;
  `}
`

const ButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  flex-direction: column;
  gap: 24px;
  ${media.tablet`
  gap: 32px;
    flex-direction: row ;
  `}
`

const CtaDoubleBlock = (props) => {
  const { i18n } = useGlobalContext()
  const { ctaDoubletitle, ctaDoubleSubtitle, ctaDoubleSummary, ctaDoublelinkTitle1, ctaDoublelinkUrl1, ctaDoublelinkTitle2, ctaDoublelinkUrl2, slugifiedAnchor } = props[0]

  return (
    <Slice slugifiedAnchor={slugifiedAnchor} data-testid="CtaDoubleBlock">
      <Container>
        {(ctaDoubletitle || ctaDoubleSubtitle) && (
          <>
            {ctaDoubletitle && (
              <SliceTitle $textAlign="center" data-testid="SimpleSlice_title">
                {ctaDoubletitle}
              </SliceTitle>
            )}
            {ctaDoubleSubtitle && <HeadSubtitle $textAlign="center">{ctaDoubleSubtitle}</HeadSubtitle>}
          </>
        )}
        {ctaDoubleSummary && (
          <CenteredReadingContainer>
            <Content>{ctaDoubleSummary}</Content>
          </CenteredReadingContainer>
        )}
        <ButtonContainer>
          {ctaDoublelinkTitle1 && ctaDoublelinkUrl1 && (
            <Button
              size="large"
              color={ctaDoublelinkUrl1.target && ctaDoublelinkUrl1.target === 'web' ? 'blue' : 'red'}
              href={ctaDoublelinkUrl1.url}
              ariaLabel={!ctaDoublelinkTitle1 ? `${i18n.t('readmore')}, ${ctaDoublelinkTitle1}` : ''}
            >
              {ctaDoublelinkTitle1}
            </Button>
          )}
          {ctaDoublelinkTitle2 && ctaDoublelinkUrl2 && (
            <Button
              size="large"
              color={ctaDoublelinkUrl2.target && ctaDoublelinkUrl2.target === 'web' ? 'blue' : 'red'}
              type="ghost"
              href={ctaDoublelinkUrl2.url}
              ariaLabel={!ctaDoublelinkTitle2 ? `${i18n.t('readmore')}, ${ctaDoublelinkTitle2}` : ''}
            >
              {ctaDoublelinkTitle2}
            </Button>
          )}
        </ButtonContainer>
      </Container>
    </Slice>
  )
}

export default CtaDoubleBlock

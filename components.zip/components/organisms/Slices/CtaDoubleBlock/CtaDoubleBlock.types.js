import { Group, Link, Text, StructuredText } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  ctaDouble: Group(
    {
      anchorPoint: Text('Anchor ID (same as the anchors block)', 'my-anchor-id'),

      ctaDoubletitle: Text('CTA double title', 'Title of your CTA block'),
      ctaDoubleSubtitle: Text('CTA double subtitle', 'Subtitle of your CTA block'),
      ctaDoubleSummary: StructuredText('CTA double summary', 'Summary of your CTA block'),

      ctaDoublelinkTitle1: Text('Link 1 title', 'Link title 1'),
      ctaDoublelinkUrl1: Link(),

      ctaDoublelinkTitle2: Text('Link 2 title', 'Link title 2'),
      ctaDoublelinkUrl2: Link(),
    },
    'CTA double block',
    false,
    'CTA double block',
    'React component',
    'short_text'
  ),
}

import marked from 'marked'

export default function getTableBlockProcData(string) {
  return typeof string === 'string' ? marked(string) : null
}

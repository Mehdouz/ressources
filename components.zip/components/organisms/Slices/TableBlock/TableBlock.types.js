import { Select, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  tableBlockSlice: Slice(
    {
      anchorID: Text('Anchor ID (same as the anchors block)', 'my-anchor-id'),
      markdownTitle: Text('Markdown Title', 'Enter your markdown title...'),
      markdownTablePosition: Select(['left', 'center', 'right'], 'Markdown table position', undefined, 'center'),
      markdown: Text('Markdown', 'Enter your markdown...'),
      legendMarkdownTable: Text('Legend markdown table', 'Enter your markdown legend...'),
    },
    {},
    'Table Block',
    'React component'
  ),
}

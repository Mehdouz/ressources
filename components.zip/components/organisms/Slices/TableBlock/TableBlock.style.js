import styled, { css } from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { colors } from '@axacom-client/base/style/variables'
import { Typo36, Typo32, Typo15 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const StyledSlice = styled(Slice)`
  max-width: 1170px;
  margin: 0 auto;
`

export const Container = styled.div`
  padding: 0 15px;
`

export const Legend = styled.p`
  color: ${colors.creditColor};
  ${Typo15};
  margin: 0 30px 20px;

  ${media.desktop`
    margin: 0 60px 30px;
  `}
`

export const Title = styled.h2`
  text-align: center;
  ${Typo36}
`

export const MarkdownTable = styled.div`
  margin: 45px 0 20px;
  overflow-x: auto;
  border: 1px solid #dfe5ea;
  width: 100%;

  ::-webkit-scrollbar {
    padding-top: 10px;
    height: 7px;
  }

  ::-webkit-scrollbar-track {
    background: #b2b2b2;
  }

  ::-webkit-scrollbar-thumb {
    background: ${colors.brandBlue};
  }

  ::-webkit-scrollbar-thumb:hover {
    background: #3a5e95;
  }

  & table {
    width: 100%;
    ${media.desktop`
      border: 1px solid #dee2e6;
    `}
  }

  & thead {
    border-bottom: 2px solid #dee2e6;

    & tr {
      background: ${colors.white};
    }
  }

  & th,
  & td {
    padding-top: 40px;
    padding-bottom: 40px;
    padding-right: 15px;
    white-space: normal;
    vertical-align: top;
    padding-left: 15px;
    ${Typo32}
    font-weight: 400;
    text-align: ${({ markdownTablePosition }) => markdownTablePosition};
    white-space: normal;

    ${({ markdownTablePosition }) => {
      if (markdownTablePosition === 'left')
        return css`
          &:first-child {
            padding-left: 30px;

            ${media.desktop`
              padding-left: 60px;
            `}
          }
        `

      if (markdownTablePosition === 'right')
        return css`
          &:last-child {
            padding-right: 30px;

            ${media.desktop`
              padding-right: 60px;
            `}
          }
        `
    }}
  }

  & th {
    color: #4975ba;
  }

  & td {
    padding-top: 28px;
    padding-bottom: 28px;
    height: 85px;
    border-top: 1px solid #dee2e6;

    &:first-child {
      color: #333;
      white-space: normal;
    }
  }

  & tbody > tr {
    &:nth-of-type(odd) {
      background-color: ${colors.grayLighter};
    }
  }
`

export const ItemNumber = styled.div`
  ${media.phone`
    font-size: 130px;
  `}

  ${media.tablet`
    font-size: 108px;
  `}

  ${media.desktopLarge`
    font-size: 130px;
  `}
`

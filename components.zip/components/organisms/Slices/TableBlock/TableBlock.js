import React from 'react'
import { string } from 'prop-types'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { StyledSlice, Title, MarkdownTable, Container, Legend } from '@axacom-client/components/organisms/Slices/TableBlock/TableBlock.style'

export default function TableBlock({ anchorID, legendMarkdownTable, markdown, markdownTablePosition, markdownTitle }) {
  return (
    <StyledSlice>
      <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
        <Container id={anchorID}>
          <Title>{markdownTitle}</Title>
          <MarkdownTable markdownTablePosition={markdownTablePosition}>
            <div dangerouslySetInnerHTML={{ __html: markdown }} />
          </MarkdownTable>
          <Legend>{legendMarkdownTable}</Legend>
        </Container>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

TableBlock.propTypes = {
  anchorID: string,
  legendMarkdownTable: string,
  markdown: string,
  markdownTablePosition: string,
  markdownTitle: string,
}

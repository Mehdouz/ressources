import { Slice, Link } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  relatedStories: Slice(
    {},
    {
      stories: Link('Link', 'document', ['stories'], false, 'Story'),
    },
    'Related Stories',
    'React component'
  ),
}

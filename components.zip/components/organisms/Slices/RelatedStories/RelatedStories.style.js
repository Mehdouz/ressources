import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { font, colors } from '@axacom-client/base/style/variables'
import CardStories from '@axacom-client/components/molecules/CardStories/CardStories'

export const StyledCard = styled(CardStories)`
  &:not(:last-child) {
    margin-right: 25px;
  }

  ${media.tablet`
    width: auto;
    flex-grow: 1;
    flex-shrink: 1;
    flex-basis: 0;
    margin-right: 15px;


    &:nth-of-type(4) {
      display: none;
    }

    &:nth-child(3)  {
      margin: 0;
    }

    &:before {
      padding-top: 100%;
    }
  `}

  ${media.desktop`
    &:nth-of-type(4) {
      display: inherit;
      margin: 0;
    }

    &:not(:last-child) {
      margin-right: 20px;
    }
  `}

  ${media.desktopVeryLarge`
    &:not(:last-child) {
      margin-right: 45px;
    }
  `}
`

export const Container = styled.div`
  background: ${colors.grayLighter};
  padding: 60px 0;

  ${media.tablet`
    padding: 55px 0;
  `}

  ${media.desktopVeryLarge`
    padding: 85px 0;
  `}
`

export const Title = styled.h1`
  margin-bottom: 25px;
  text-align: center;
  font-size: 2rem; // 32px
  line-height: 2.5rem; // 40px
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};

  ${media.tablet`
    font-size: 2.5rem; // 40px
    line-height: 3rem; // 48px
    margin-bottom: 45px;
  `}

  ${media.desktopVeryLarge`
    margin-bottom: 65px;
  `}
`

export const RelatedStoriesContainer = styled.div`
  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;

  ${media.tablet`
    width: 80%;
    margin: auto;
  `}
`

// CSS Hack for hiding the horizontal scrollbar
// See: https://vigu-madurai.medium.com/solved-hide-scrollbar-but-still-scroll-54955525d238
export const HiddenScrollWrapper = styled.div`
  overflow-y: hidden;
  margin-bottom: -30px;
`

export const RelatedStoriesWrapper = styled.div`
  display: inline-flex;
  margin-left: 30px;
  margin-right: 30px;
  padding-bottom: 30px; // CSS Hack for hiding the horizontal scrollbar

  ${media.tablet`
    display:flex;
    flex-direction: row;
    margin-left: 0;
    margin-right: 0;
  `}
`
export const CtaButtonWrapper = styled.div`
  margin-top: 50px;
  text-align: center;
`

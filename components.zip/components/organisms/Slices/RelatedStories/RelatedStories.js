import React from 'react'
import { string, array } from 'prop-types'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Container, HiddenScrollWrapper, RelatedStoriesContainer, RelatedStoriesWrapper, Title, StyledCard, CtaButtonWrapper } from './RelatedStories.style'
import Button from '@axacom-client/components/atoms/Button/Button'
import { listIsEmpty } from '@axacom-client/services/list-service'
export default function RelatedStories({ anchorPoint, stories, storiesLink }) {
  const { domain, i18n } = useGlobalContext()

  return (
    <Slice slugifiedAnchor={anchorPoint} className="p-0" fluid data-testid="RelatedStories">
      <Container>
        <ResponsiveContainer veryLargeDesktop>
          <Title data-testid="RelatedStoriesMainTitle">{i18n.t('relatedStories.title')}</Title>
          <RelatedStoriesContainer>
            <HiddenScrollWrapper>
              <RelatedStoriesWrapper>
                {stories &&
                  stories.map((item, index) => {
                    const title = item?.stories?.cover?.[0]?.title
                    const image = item?.stories?.cover?.[0]?.image?.views?.desktop?.url || item?.stories?.cover?.[0]?.image?.main?.url
                    const readTime = item?.stories?.readTime
                    const href = domain + item.stories.url

                    return <StyledCard key={index} isRelatedStories title={title} image={image} readTime={readTime} href={href} />
                  })}
              </RelatedStoriesWrapper>
            </HiddenScrollWrapper>
          </RelatedStoriesContainer>
          <CtaButtonWrapper>
            {!listIsEmpty(storiesLink) && storiesLink && (
              <Button href={storiesLink[0]?.link?.url} type="link" iconRight="IconArrowRight" size="large" color="red">
                {storiesLink[0]?.linkLabel}
              </Button>
            )}
          </CtaButtonWrapper>
        </ResponsiveContainer>
      </Container>
    </Slice>
  )
}

RelatedStories.propTypes = {
  anchorPoint: string,
  stories: array,
  storiesLink: array,
}

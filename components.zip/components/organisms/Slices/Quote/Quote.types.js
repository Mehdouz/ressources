import { Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  quote: Slice(
    {
      text: Text('Text', 'Write here the text here'),
      name: Text('Name', 'Write here the name here'),
      role: Text('Role', 'Write here the role here'),
    },
    {},
    'Quote',
    'React Component',
    'format_quote'
  ),
}

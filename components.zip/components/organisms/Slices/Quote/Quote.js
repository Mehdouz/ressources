import React, { useRef } from 'react'
import { Top, ReadingContainer, IconWrapper, Line, Text, Author, Bottom } from '@axacom-client/components/organisms/Slices/Quote/Quote.style'
import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'
import { mediaVariables } from '@axacom-client/base/style/media'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { motion, useInView } from 'framer-motion/dist/framer-motion'
import { Slice } from '../../SimpleSlice/SimpleSlice'

const variants = {
  visible: {
    transition: { ease: 'easeInOut', staggerChildren: 0.1 },
  },
}

const svgVariants = {
  hidden: { scale: 0 },
  visible: { scale: 1 },
}

const textVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

const topLineVariants = {
  hidden: { width: 0 },
  visible: (isMobile) => {
    return { width: isMobile ? '90%' : '60%', transition: { delay: 0.3 } }
  },
}

const bottomLineVariants = {
  hidden: { width: 0 },
  visible: (isMobile) => {
    return { width: isMobile ? '75%' : '45%', transition: { delay: 0.3 } }
  },
}

export default function Quote({ text, name, role }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { margin: '-30%', once: true })

  const isMobile = useBetterMediaQueries({ query: `(max-width: ${mediaVariables.phoneMax}px)` }, false)

  return (
    <Slice data-testid="Quote">
      <motion.div ref={ref} initial="hidden" animate={isInView ? 'visible' : 'hidden'} exit="hidden" variants={variants}>
        <ResponsiveContainer mobile tablet>
          <ReadingContainer>
            <Top>
              <Line custom={isMobile} variants={topLineVariants} />
              <IconWrapper variants={svgVariants}>
                <Icon name="IconQuote" color={colors.grey300} width={46} height={33} />
              </IconWrapper>
            </Top>
            <Text variants={textVariants}>{text}</Text>
            <Author variants={textVariants}>{name}</Author>
            <Author variants={textVariants}>{role}</Author>
            <Bottom custom={isMobile} variants={bottomLineVariants} />
          </ReadingContainer>
        </ResponsiveContainer>
      </motion.div>
    </Slice>
  )
}

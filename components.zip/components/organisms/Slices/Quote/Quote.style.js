import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import { motion } from 'framer-motion/dist/framer-motion'
import { Typo37 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'

export const ReadingContainer = styled(CenteredReadingContainer)`
  text-align: center;
  margin: 0 auto;
  max-width: 500px;
`

export const Top = styled.div`
  position: relative;
  display: flex;
  justify-content: center;
`

export const IconWrapper = styled(motion.div)`
  background: white;
  padding: 0 20px;
  display: block;
  position: relative;
  z-index: 10;
  transform-origin: center;
`

export const Line = styled(motion.div)`
  width: 60%;
  height: 2px;
  background-color: ${colors.grey300};
  display: block;
  position: absolute;
  left: 50%;
  top: 20px;
  transform: translateX(-50%);
`

export const Text = styled(motion.p)`
  ${Typo37}
  text-align: center;
  margin-top: 30px;
  margin-bottom: 25px;
`

export const Author = styled(motion.p)`
  font-size: 14px;
  font-weight: ${font.weight.bold};
  line-height: 18px;
  text-align: center;
`

export const Bottom = styled(motion.div)`
  width: 45%;
  height: 2px;
  background-color: ${colors.grey300};
  display: block;
  margin: 30px auto 0;
`

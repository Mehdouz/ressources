import styled from 'styled-components'
import Text from '@axacom-client/components/molecules/Text/Text'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Typo18, Typo24, Typo28 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Container } from 'reactstrap'

const CaptionText = styled(Text)`
  ${Typo28}
  ${media.phone`
    ${Typo24}
    font-weight: ${font.weight.semiBold};
    line-height: 1.39rem;
    margin-top: ${getSpacing(2)};
  `}

  ${media.tablet`
    margin-top: ${getSpacing(2)};
  `}

  ${media.desktop`
    margin-top: 0;
    padding-top: ${getSpacing(4)};
  `}
`

const CreditText = styled.div`
  ${Typo18}
  margin-top: ${getSpacing(2)};
  text-align: left;
  color: ${colors.creditColor};
`

const CustomLink = styled(Button)`
  ${Typo28}
  color: ${colors.black};
  text-transform: none;
`

const CustomContainer = styled(Container)`
  ${media.phone`
    padding: 0;
  `}

  ${media.tablet`
    padding: 0;
  `}

  ${media.desktop`
    padding-right: 15px;
    padding-left: 15px;
  `}
`

const Line = styled.div`
  box-sizing: border-box;
  height: 0;
  width: 100%;
  border-top: 1px solid ${colors.gray};
`

export { CreditText, CaptionText, Line, CustomLink, CustomContainer }

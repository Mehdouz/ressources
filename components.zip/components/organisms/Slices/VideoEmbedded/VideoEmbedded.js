import React from 'react'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import SingleMedia from '@axacom-client/components/molecules/SingleMedia/SingleMedia'

export default function VideoEmbedded(props) {
  // eslint-disable-next-line react/prop-types
  const item = props[0] || props
  const { videoUrl, slugifiedAnchor } = item
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="VideoEmbedded">
      {videoUrl && <SingleMedia {...item} />}
    </Slice>
  )
}

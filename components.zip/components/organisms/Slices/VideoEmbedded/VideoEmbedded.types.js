import { Group, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  'video-embedded': Group(
    {
      anchorPoint: simpleSlice.anchorId,
      videoUrl: StructuredText('"Label video url', 'Fill-in the link of your embedded video'),
      caption: Text('Caption text', 'Fill-in your caption here'),
      credit: Text('Credit', 'Fill-in the credit here'),
    },
    'Large video',
    false,
    'Large video',
    'React Component',
    'ondemand_video'
  ),
}

import { Slice, Link, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  pressReleaseBlock: Slice(
    {
      title: Text('Title', 'Write the title here'),
      surtitle: Text('Surtitle', 'Write the surtitle here'),
      pressRelease: Link('Press Release link', 'document', ['press-release']),
      buttonText: Text('CTA label', 'Write the button label here'),
      buttonLink: Link('CTA Link'),
    },
    {},
    'Press-release Block',
    'React component'
  ),
}

import styled from 'styled-components'

import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Typo33, Typo25, Typo9, Typo12 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import Button from '@axacom-client/components/atoms/Button/Button'

export const StyledSlice = styled(Slice)`
  padding: 32px;
  display: flex;
  justify-content: center;

  ${media.tablet`
    padding: 50px 65px;
  `};

  ${media.desktop`
    padding: 50px 85px;
  `};

  ${media.desktopVeryLarge`
    padding: 60px 0;
  `};
`

export const Title = styled.h2`
  ${Typo33}
  margin-bottom: 32px;

  ${media.tablet`
    text-align: center;
  `};

  ${media.desktopVeryLarge`
    font-size: 40px;
    line-height: 48px;
  `};
`
export const PressReleaseCard = styled.div`
  background-color: ${colors.white};
  box-shadow: 2px 0px 48px rgba(1, 45, 50, 0.03), 2px 0px 36px rgba(1, 45, 50, 0.05);
  padding: 25px;
  margin-bottom: 32px;
  max-width: 990px;
`

export const PressReleaseSurtitle = styled.p`
  ${Typo25};
  text-transform: uppercase;
  color: ${colors.grey600};
  margin-bottom: 16px;
`
export const PressReleaseTitle = styled.h3`
  ${Typo9};
  margin-bottom: 16px;

  ${media.desktop`
    ${Typo12};
  `};
`

export const BottomCtaBlock = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
`

export const BottomCta = styled(Button)`
  margin: 0 auto;
`

import React from 'react'
import { object, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { StyledSlice, Title, PressReleaseSurtitle, PressReleaseCard, PressReleaseTitle, BottomCtaBlock, BottomCta } from './PressReleaseBlock.style.js'
import Button from '@axacom-client/components/atoms/Button/Button'

const PressReleaseBlock = ({ title, surtitle, pressRelease, buttonText, buttonLink }) => {
  const { i18n } = useGlobalContext()

  return (
    <StyledSlice>
      <Title data-testid="PressReleaseBlock_Title">{title}</Title>
      <PressReleaseCard>
        <PressReleaseSurtitle data-testid="PressReleaseBlock_PressRelease_Surtitle">{surtitle ? surtitle : i18n.t('pressRelease')}</PressReleaseSurtitle>
        <PressReleaseTitle data-testid="PressReleaseBlock_PressRelease_Title">{pressRelease?.title}</PressReleaseTitle>
        <Button data-test-id="PressReleaseBlock_PressRelease_Link" href={pressRelease.url} color="red" type="link" iconRight="IconArrowRight">
          {i18n.t('pressReleaseBlock.seemore')}
        </Button>
      </PressReleaseCard>
      <BottomCtaBlock>
        <BottomCta data-test-id="PressReleaseBlock_Link" href={buttonLink?.url} color="red">
          {buttonText}
        </BottomCta>
      </BottomCtaBlock>
    </StyledSlice>
  )
}

PressReleaseBlock.propTypes = {
  title: string,
  surtitle: string,
  pressRelease: object,
  buttonText: string,
  buttonLink: object,
}

export default PressReleaseBlock

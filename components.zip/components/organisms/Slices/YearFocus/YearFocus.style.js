import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Typo4, Typo10 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'

const strokeHeight = 6

export const Content = styled(motion.div)`
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 24px;
  padding-bottom: 0;
  margin-right: auto;
  margin-left: auto;

  ${media.phone`
    width: 100%;
  `}

  ${media.tablet`
    flex-direction: row;
  `}
`

export const Background = styled(motion.div)`
  background-color: ${(props) => props.$color};
  position: absolute;
  top: -20px;
  left: 0;
  content: ' ';
  width: 90%;
  height: 70%;
  will-change: transform;

  ${media.tablet`
    top: 0px;
    width: 40%
  `}
`

export const Stroke = styled(motion.div)`
  background-color: ${(props) => props.$color};
  transform-origin: 100%;
  will-change: transform;
  position: absolute;
  bottom: 0;
  right: 0;
  content: ' ';
  width: 30%;
  height: ${strokeHeight}px;
`

export const TextWrapper = styled(motion.div)`
  background: ${colors.bodyBg};
  display: flex;
  flex-direction: column;
  box-shadow: 0px 4px 10px rgb(0 0 0 / 20%);
  padding: 24px 24px;

  z-index: 0;

  ${media.tablet`
    flex: 0 0 50%;
    padding: 36px 36px;

  `}

  ${media.desktop`
  padding: 48px 48px;
  justify-content: center;

  `}

  ${media.desktopLarge`

  `}
`

export const Text = styled(motion.p)`
  ${Typo10}
  display: flex;
`

export const Title = styled(motion.h4)`
  ${Typo4}
  color: ${colors.grey500};
  margin-bottom: 16px;

  ${media.tablet`
    font-size: 36px;
  `}

  ${media.desktop`
    margin-bottom: 32px;
    font-size: 48px;
  `}
`

export const ImageWrapper = styled(motion.div)`
  display: flex;
  align-items: center;

  ${media.tablet`
    flex: 0 0 50%;
    padding: 24px 0;
  `}
`

export const Image = styled(motion.img)`
  width: 100%;
  position: relative;
  overflow: hidden;
`

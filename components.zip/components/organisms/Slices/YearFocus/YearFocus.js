import React, { useRef } from 'react'
import { Content, TextWrapper, Text, Title, Image, ImageWrapper, Background, Stroke } from '@axacom-client/components/organisms/Slices/YearFocus/YearFocus.style'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { useTimeline } from '@axacom-client/components/pages/timeline-v2/timeline-v2.page'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { useInView } from 'framer-motion/dist/framer-motion'

const variants = {
  visible: {
    transition: { ease: 'easeInOut', staggerChildren: 0.1 },
  },
}

const textBlockVariants = {
  hidden: { opacity: 0, x: 30 },
  visible: { opacity: 1, x: 0, transition: { delay: 0.5, staggerChildren: 0.3 } },
}

const imageVariants = {
  hidden: { opacity: 0, y: 30, x: 30 },
  visible: { opacity: 1, y: 0, x: 0, transition: { delay: 0.3 } },
}

const backgroundVariants = {
  hidden: { opacity: 0, y: 30, x: 30 },
  visible: { opacity: 1, y: 0, x: 0, transition: { delay: 0.8 } },
}

const textVariants = {
  hidden: { opacity: 0, x: 20 },
  visible: { opacity: 1, x: 0 },
}

const strokeVariants = {
  hidden: { width: 0 },
  visible: { width: '30%', transition: { delay: 0.7 } },
}

export default function YearFocus({ text, image, title, periodStep }) {
  const { colors } = useTimeline()

  const contentRef = useRef()
  const isInView = useInView(contentRef, { margin: '-100px', once: true })

  return (
    <Slice data-testid="YearFocus">
      <Container>
        <Content ref={contentRef} initial="hidden" animate={isInView ? 'visible' : 'hidden'} exit="hidden" variants={variants}>
          <Background $color={colors[periodStep]} variants={backgroundVariants} />
          <ImageWrapper>
            <Image data-testid="YearFocus_Image" src={image?.main?.url} alt={image?.alt} variants={imageVariants} />
          </ImageWrapper>
          <TextWrapper variants={textBlockVariants}>
            <Title data-testid="YearFocus_Title" variants={textVariants}>
              {title}
            </Title>
            <Text data-testid="YearFocus_Text" variants={textVariants}>
              {text}
            </Text>
          </TextWrapper>
          <Stroke $color={colors[periodStep]} variants={strokeVariants} />
        </Content>
      </Container>
    </Slice>
  )
}

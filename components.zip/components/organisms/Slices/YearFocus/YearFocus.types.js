import { Image, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  yearFocus: Slice(
    {
      title: Text('Title (Mandatory)'),
      text: Text('Text (Mandatory)', 'Max 257 characters'),
      image: Image('Image (320 x 240px) (Mandatory)', { width: 320, height: 240 }),
    },
    {},
    'Year Focus',
    'React component'
  ),
}

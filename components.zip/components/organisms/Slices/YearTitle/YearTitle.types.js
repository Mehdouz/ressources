import { Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  yearTitle: Slice(
    {
      title: Text('Year title', 'Write your title here'),
    },
    {},
    'Year Title',
    'React component'
  ),
}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Typo37 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'

export const Year = styled(motion.p)`
  ${Typo37};
`

export const Stroke = styled(motion.div)`
  position: relative;
  display: block;
  top: 6px;
  left: -45px;
  height: 6px;
  border-radius: 3px;
  width: 125px;
  background: ${(props) => props.$color};

  ${media.tablet`
      top: 14px;
  `}
`

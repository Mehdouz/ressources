import React, { useRef } from 'react'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Year, Stroke } from './YearTitle.style'
import { useTimeline } from '@axacom-client/components/pages/timeline-v2/timeline-v2.page'
import { Slice } from '../../SimpleSlice/SimpleSlice'
import { useInView } from 'framer-motion/dist/framer-motion'

const variants = {
  visible: {
    transition: { staggerChildren: 0.1 },
  },
}

const yearVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0 },
}

const strokeVariants = {
  hidden: { width: 0 },
  visible: { width: 125 },
}

export default function YearTitle({ title, periodStep }) {
  const { colors } = useTimeline()

  const ref = useRef()
  const isInView = useInView(ref, { margin: '-100px', once: true })

  return (
    <Slice dataTestid="YearTitle">
      <Container ref={ref} initial="hidden" animate={isInView ? 'visible' : 'hidden'} variants={variants}>
        <Year dataTestid="YearTitle__Title" variants={yearVariants}>
          {title}
        </Year>
        <Stroke $color={colors[periodStep]} variants={strokeVariants} />
      </Container>
    </Slice>
  )
}

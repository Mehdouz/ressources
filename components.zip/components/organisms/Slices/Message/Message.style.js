import styled from 'styled-components'

import media from '../../../../base/style/media'
import { getSpacing } from '../../../../base/style/spacing'
import { Typo18, Typo36 } from '../../../../base/style/typoStyle/typoStyle'

import Button from '@axacom-client/components/atoms/Button/Button'

const MessageContent = styled.div`
  text-align: center;
`

const ShortMessageContent = styled.div`
  text-align: left;
  margin-top: 16px;
`

const MessageImage = styled.div`
  margin-top: ${getSpacing(2)};
  margin-bottom: ${getSpacing(4)};

  ${media.tablet`
    margin-top: ${getSpacing(0)};
  `};
`

const Title = styled.div`
  ${Typo36}
  margin-bottom: ${getSpacing(2)};
`

const Content = styled.div`
  ${Typo18}
  margin-bottom: ${getSpacing(6)};
`
const Cta = styled(Button)`
  margin-bottom: ${getSpacing(4)};
  ${media.tablet`
    margin-top: ${getSpacing(2)};
  `};
`

export { MessageImage, MessageContent, Title, Content, Cta, ShortMessageContent }

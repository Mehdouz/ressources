import React from 'react'
import { array, object, oneOfType, string } from 'prop-types'
import { Col, Row } from 'reactstrap'
import Image from '@axacom-client/components/atoms/Image/Image'
import { Desktop, LargeDesktop, MobilesDevices } from '@axacom-client/components/utils/Responsive'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Content, Cta, MessageContent, MessageImage, ShortMessageContent, Title } from './Message.style'
import ResponsiveContainer, { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

const Message = ({ image, title, content, cta, dataTestid }) => (
  <Slice dataTestid={dataTestid || 'Message'}>
    <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
      <Row>
        {image && (
          <Col xs={{ size: 8, offset: 2 }} md={{ size: 4, offset: 4 }}>
            <MessageContent>
              <MessageImage>
                {image.views ? (
                  <>
                    {image.views.small && (
                      <MobilesDevices>
                        <Image ratio="1:1" src={image.views.small.url} alt="" />
                      </MobilesDevices>
                    )}
                    {image.views.medium && (
                      <Desktop>
                        <Image ratio="1:1" src={image.views.medium.url} alt="" />
                      </Desktop>
                    )}
                    {image.views.large && (
                      <LargeDesktop>
                        <Image ratio="1:1" src={image.views.large.url} alt="" />
                      </LargeDesktop>
                    )}
                  </>
                ) : (
                  <>{image.main && <Image ratio="1:1" src={image.main.url} alt="" />}</>
                )}
              </MessageImage>
            </MessageContent>
          </Col>
        )}
        <Col md={{ size: 8, offset: 2 }}>
          <MessageContent>
            <Title>{title}</Title>
            <Content>{content}</Content>
            {cta && cta.content && <Cta {...cta}>{cta.content}</Cta>}
          </MessageContent>
        </Col>
      </Row>
    </ResponsiveContainer>
  </Slice>
)

export const ShortMessage = ({ title, content }) => {
  return (
    <Container>
      <ShortMessageContent>
        <Title>{title}</Title>
        <Content>{content}</Content>
      </ShortMessageContent>
    </Container>
  )
}

Message.propTypes = {
  title: oneOfType([array, object, string]),
  content: oneOfType([array, object, string]),
  image: object,
  cta: object,
  dataTestid: string,
}

export default Message

import { Group, Link, StructuredText, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  iframeFullWidth: Group(
    {
      anchorPoint: StructuredText('Anchor ID (same as the anchors block)', 'my-anchor-id'),
      link: Link('iframe link', 'web'),
      frameId: Text('symex-iframe-id', 'symex-iframe-id'),
    },
    'Iframe Symex',
    false,
    'Iframe Symex',
    'React Component',
    'short_text'
  ),
}

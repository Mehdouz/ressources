import React, { useEffect, useRef, useState } from 'react'
import { string } from 'prop-types'
import styled from 'styled-components'
import gsap, { TweenLite } from 'gsap/dist/gsap'
import ScrollToPlugin from 'gsap/dist/ScrollToPlugin'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { getWindow, windowAddEventListener, windowRemoveEventListener } from '@axacom-client/services/window-service'

gsap.registerPlugin(ScrollToPlugin)

const IframeWrapper = styled.div`
  padding-top: 100%;
  position: relative;
  height: 100%;
  overflow: hidden;
`

const IframeInner = styled.iframe`
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  z-index: 0;
`

const OFFSET_Y = -450

export default function IframeFullWidth(props) {
  // eslint-disable-next-line react/prop-types
  const { slugifiedAnchor, frameId, link } = props[0] || props
  const [height, setHeight] = useState(400)
  const frame = useRef(null)

  function onIframeMessage(e) {
    if (e.data.sender === 'SymexGlobal') {
      // Note: for the third iFrame, when the user click on "Proceed", Symex update his page and increase the iframe height.
      //  so in order to keep up the user, we animate a scroll down to the new content.
      if (frameId === 'symex-finance2' && e.data.message === 'Proceed') onProceed()
      if (frameId === e.data.iframeId && e.data.height && height !== e.data.height) {
        // This check if hardcoded because by default, return by defaut 100px.
        // As we don't them to force 100px (we have no iframe with a lesser height than 100px)
        if (e.data.height > 100) setHeight(e.data.height)
      }
    }
  }

  function onProceed() {
    setTimeout(() => TweenLite.to(getWindow(), 0.2, { scrollTo: { y: frame.current, offsetY: OFFSET_Y, autoKill: false } }), 10)
  }

  useEffect(() => {
    windowAddEventListener('message', onIframeMessage)
    return () => {
      windowRemoveEventListener('message', onIframeMessage)
    }
  }, [])

  return (
    <Slice className="p-0" slugifiedAnchor={slugifiedAnchor} dataTestid="IframeSymex">
      <div ref={frame} className="iframe-full-width" style={{ height: `${height}px` }}>
        <IframeWrapper>
          <IframeInner src={link.url} key="iframeChildren" scrolling="no" frameBorder="0" height="100%" width="100%" />
        </IframeWrapper>
      </div>
    </Slice>
  )
}

IframeFullWidth.propTypes = {
  slugifiedAnchor: string,
  frameId: string,
  link: string,
}

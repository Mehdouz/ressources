import React from 'react'
import {
  SpotlightContainer,
  SpotlightArticleBlock,
  SpotlightArticleTitle,
  SpotlightArticleImage,
  SpotlightArticleImageContainer,
  SpotlightArticleDescription,
  SpotlightArticleLink,
  SideBlock,
  EventBlock,
  EventSurtitle,
  EventDate,
  EventLink,
  EventTitle,
  ArticlesBlock,
  ArticleItem,
  ArticleItemTitle,
  ArticlesSurtitle,
} from './SpotlightNews.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { getDate } from '@axacom-client/services/date-service'

export default function SpotlightNews({ mainArticle, image, title, subtitle, eventLink, items }) {
  return (
    <Slice data-testid="SpotlightNews">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        <SpotlightContainer>
          <SpotlightArticle mainArticle={mainArticle} image={image} title={title} subtitle={subtitle} />
          <SideBlock>
            {eventLink && <Event eventLink={eventLink} />}
            <ArticlesList articles={items} />
          </SideBlock>
        </SpotlightContainer>
      </ResponsiveContainer>
    </Slice>
  )
}

function SpotlightArticle({ mainArticle, image, title, subtitle }) {
  const spotlightTitle = title ? title : mainArticle.body[0].value.title
  const spotlightSubtitle = subtitle ? subtitle : mainArticle.body[0].value.subtitle

  return (
    <SpotlightArticleBlock>
      <SpotlightArticleLink href={mainArticle?.url}>
        <SpotlightArticleImageContainer>
          <SpotlightArticleImage src={image?.main?.url ? image?.main?.url : mainArticle.body[0].value.banner?.views?.medium?.url} />
        </SpotlightArticleImageContainer>
        <SpotlightArticleTitle>{spotlightTitle}</SpotlightArticleTitle>
        <SpotlightArticleDescription>{spotlightSubtitle}</SpotlightArticleDescription>
      </SpotlightArticleLink>
    </SpotlightArticleBlock>
  )
}

function Event({ eventLink }) {
  const { i18n, currentLocale } = useGlobalContext()
  const date = currentLocale === 'en' ? getDate().usDate(eventLink.date) : getDate().frDate(eventLink.date)

  return (
    <>
      <EventSurtitle>{i18n.t('spotlightNews.event')}</EventSurtitle>
      <EventBlock>
        <EventDate>{date}</EventDate>
        <EventLink href={eventLink.url}>
          <EventTitle>{eventLink.title}</EventTitle>
        </EventLink>
      </EventBlock>
    </>
  )
}

function ArticlesList({ articles }) {
  return (
    <ArticlesBlock>
      <ArticlesSurtitle>Articles</ArticlesSurtitle>
      <div>
        {articles &&
          articles.map(({ article }, index) => {
            return (
              <ArticleItem key={index}>
                <ArticleItemTitle href={article?.url}>{article?.body[0]?.value?.title}</ArticleItemTitle>
              </ArticleItem>
            )
          })}
      </div>
    </ArticlesBlock>
  )
}

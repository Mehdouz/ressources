import styled from 'styled-components'
import { font, colors } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { Typo33, Typo25, Typo9 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const SpotlightContainer = styled.div`
  display: flex;
  flex-direction: column;
  ${media.desktop`
    flex-direction: row;
    justify-content: space-between;
  `};
`

export const SpotlightArticleBlock = styled.div`
  margin-bottom: 65px;

  ${media.tablet`
    margin-bottom: 40px;
  `}

  ${media.desktop`
    width: 55%;
  `};
`

export const SideBlock = styled.div`
  ${media.desktop`
    width: 40%;
  `};
`

export const SpotlightArticleImage = styled.img`
  object-fit: cover;
  height: 100%;
  width: 100%;
  transition: transform 0.2s ease-in-out;
`

export const SpotlightArticleImageContainer = styled.div`
  aspect-ratio: 31/28;
  overflow: hidden;

  ${media.desktopLarge`
    aspect-ratio: 3/2;
  `};

  ${media.desktopVeryLarge`
    aspect-ratio: 2/1;
  `};
`

export const SpotlightArticleTitle = styled.h2`
  ${Typo33}
  margin-top: 25px;
`

export const SpotlightArticleLink = styled(SmartLink)`
  color: ${colors.black};

  &:hover {
    color: ${colors.black};

    h2 {
      color: #757575;
    }

    img {
      transform: scale(1.05);
    }
  }
`

export const SpotlightArticleDescription = styled.p`
  font-size: 1.25rem; // 20px
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  line-height: 1.75rem; // 28px
  margin-top: 25px;
`

export const EventBlock = styled.div`
  margin-bottom: 65px;
  padding: 25px;
  background: ${colors.grey200};

  ${media.tablet`
    margin-bottom: 40px;
    `}

  ${media.desktop`
    margin-bottom: 50px;
  `}
`

export const EventTitle = styled.h2`
  ${Typo9}
`

export const EventLink = styled(SmartLink)`
  color: ${colors.black};
`

export const EventDate = styled.p`
  ${Typo25}
  margin-bottom: 15px;

  ${media.tablet`
    margin-bottom: 8px;
  `}
`

export const EventSurtitle = styled.p`
  ${Typo25}
  text-transform: uppercase;
  margin-bottom: 15px;
`

export const ArticlesBlock = styled.div``

export const ArticleItem = styled.div`
  padding-top: 15px;
  padding-bottom: 15px;
  border-bottom: 1px solid ${colors.grey300};

  &:first-child {
    padding-top: 0;
  }

  &:last-child {
    border: none;
  }

  ${media.desktop`
    padding-top: 20px;
    padding-bottom: 20px;
  `}
`
export const ArticleItemTitle = styled(SmartLink)`
  ${Typo9}
  color: ${colors.black}
`

export const ArticlesSurtitle = styled.p`
  ${Typo25}
  text-transform: uppercase;
  margin-bottom: 25px;
`

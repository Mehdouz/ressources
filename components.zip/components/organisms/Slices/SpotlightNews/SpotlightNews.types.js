import { Image, Link, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  spotlightNews: Slice(
    {
      mainArticle: Link('Article link', 'document', ['article-v2']),
      image: Image('Image'),
      title: Text('Title'),
      subtitle: Text('Subtitle'),
      eventLink: Link('Event Link', 'document', ['event']),
    },
    {
      article: Link('Article link', 'document', ['article-v2']),
    },
    'Spotlight News',
    'React component'
  ),
}

import React from 'react'
import { Slice, SliceSubtitle, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

const TitleWithSubtitle = ({ title, subtitle, slugifiedAnchor }) => {
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} data-testid="TitleWithSubtitle">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        {title ? (
          <SliceTitle data-testid="TitleWithSubtitle__title" $textAlign="center">
            {title}
          </SliceTitle>
        ) : null}
        {subtitle ? (
          <SliceSubtitle className="mb-0" data-testid="TitleWithSubtitle__subtitle" $textAlign="center">
            {subtitle}
          </SliceSubtitle>
        ) : null}
      </ResponsiveContainer>
    </Slice>
  )
}

export default TitleWithSubtitle

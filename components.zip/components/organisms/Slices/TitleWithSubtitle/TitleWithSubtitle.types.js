import simpleSlice from '../../SimpleSlice/SimpleSlice.types'

export default {
  titleWithSubtitle: {
    type: 'Slice',
    fieldset: 'Title with subtitle',
    description: 'React component',
    icon: 'power_input',
    'non-repeat': {
      anchorId: simpleSlice.anchorId,
      title: {
        type: 'Text',
        config: {
          label: 'Title',
          placeholder: '',
        },
      },
      subtitle: {
        type: 'StructuredText',
        config: {
          label: 'Subtitle',
          placeholder: '',
        },
      },
    },
  },
}

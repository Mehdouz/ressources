import React, { useEffect, useState } from 'react'
import { arrayOf, object, string } from 'prop-types'
import { Slice, SliceSubtitle, SliceTitle } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { getEvents } from '@axacom-client/repositories/events'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import log from '@axacom-client/logger'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import Button from '@axacom-client/components/atoms/Button/Button'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'
import SingleEvent from './SingleEvent'

export default function Calendar({ calendarLink, calendarLinkName, items = [], subtitle, subtitleNoEvent, title, slugifiedAnchor }) {
  const { currentLocale } = useGlobalContext()
  const [events, setEvents] = useState([])

  useEffect(() => {
    getEvents(
      items.filter((item) => !!Object.keys(item).length).map((item) => ({ audience: { id: item?.audience?.id || '' } })),
      currentLocale
    )
      .then(setEvents)
      .catch((err) => log.error('[Calendar] getEvents error', { err }))
  }, [items, currentLocale])

  // take no-subtitle sentence if no events
  const formatSubtitle = events.length ? subtitle : subtitleNoEvent
  return (
    <Slice className="eventsCalendar" data-testid="Calendar" slugifiedAnchor={slugifiedAnchor}>
      <Container>
        {title ? <SliceTitle $textAlign="center">{title}</SliceTitle> : null}
        {formatSubtitle && formatSubtitle.length > 0 ? <SliceSubtitle $textAlign="center">{formatSubtitle}</SliceSubtitle> : null}
        <CenteredReadingContainer>
          {!!events.length &&
            // eslint-disable-next-line camelcase
            events?.map(({ city, country, eventTimeEnd, eventTimeStart, iCal, title, url_en, url_fr }, index) => {
              const eventProps = {
                city,
                country,
                eventTimeEnd,
                eventTimeStart,
                iCal,
                title,
                href: currentLocale === 'en' ? url_en : url_fr,
              }
              return <SingleEvent key={'wrap' + index} {...eventProps} />
            })}
        </CenteredReadingContainer>
        {calendarLink ? (
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <Button type="ghost" href={calendarLink.url} color="red">
              {calendarLinkName}
            </Button>
          </div>
        ) : null}
      </Container>
    </Slice>
  )
}

Calendar.propTypes = {
  calendarLink: object,
  calendarLinkName: string,
  items: arrayOf(object),
  subtitle: string,
  subtitleNoEvent: string,
  title: string,
  anchorId: string,
  slugifiedAnchor: string,
}

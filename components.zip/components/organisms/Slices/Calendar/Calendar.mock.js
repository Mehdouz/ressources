export const CalendarMock = {
  title: 'titre',
  subtitle: 'sous titre',
  subtitleNoEvents: 'subtitle no events',
  calendarLink: 'calendar link',
  calendarLinkName: 'calendar link name',
  currentLocale: 'en',
}

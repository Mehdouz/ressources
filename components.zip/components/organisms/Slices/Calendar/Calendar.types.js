import { Link, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  calendar: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'Title...'),
      subtitle: Text('Subtitle', 'Subtitle calendar...'),
      subtitleNoEvent: Text('Subtitle no events', 'Subtitle no events ...'),
      calendarLink: Link('Calendar link '),
      calendarLinkName: Text('Calendar link name', 'Choose the name of the calendar link'),
    },
    {
      audience: Link('Event type link', 'document', ['audience']),
    },
    'Calendar',
    'React component',
    'perm_contact_calendar'
  ),
}

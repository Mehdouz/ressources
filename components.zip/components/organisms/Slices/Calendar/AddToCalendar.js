import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { string } from 'prop-types'
import React from 'react'
import styled from 'styled-components'
import { lighten } from 'polished'
import { Typo14 } from '@axacom-client/base/style/typoStyle/typoStyle'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

export default function AddToCalendar({ href, iconName, color, children, ...rest }) {
  return (
    <Link href={href} {...rest} color={color || colors.brandRed}>
      <Icon name={iconName} color={color} width={20} height={20} style={{ marginRight: '8px' }} />
      {children}
    </Link>
  )
}

AddToCalendar.propTypes = {
  href: string,
  iconName: string,
  children: string,
  color: string,
}

export const Link = styled(SmartLink)`
  ${Typo14}
  text-decoration: none;
  text-transform: uppercase;
  font-weight: 700;
  color: ${(props) => props.color};
  padding: 24px 32px;

  &:hover,
  &:focus {
    color: ${lighten(0.25, '#233878')};
  }
`

export const Label = styled.span`
  ${Typo14}
  color: ${colors.brandRed};
  margin-left: 16px;
`

import React from 'react'
import { formatSentenceDate, formatSentenceHour } from '@axacom-client/services/date-service'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

import { EventDate, EventWrapper, EventContent, EventLinkTitle, PrimaryText, SecondText } from '@axacom-client/components/organisms/Slices/Calendar/Calendar.style'
import AddToCalendar from './AddToCalendar'

export default function SingleEvent({ city, country, eventTimeEnd, eventTimeStart, iCal, title, href }) {
  const { currentLocale } = useGlobalContext()
  const formattedSentenceHour = formatSentenceHour(eventTimeStart, eventTimeEnd, currentLocale)

  const labelCalendar = currentLocale === 'en' ? 'Add to calendar' : 'Ajouter au calendrier'
  return (
    <EventWrapper data-testid="CalendarEvent">
      <EventDate>
        {(eventTimeStart || eventTimeEnd) && <PrimaryText>{formatSentenceDate(eventTimeStart, eventTimeEnd, currentLocale)}</PrimaryText>}
        <SecondText>
          {formattedSentenceHour}
          {formattedSentenceHour && city && country && '  |  '}
          {(city || '') + (city && country ? ', ' : '') + (country || '')}
        </SecondText>
      </EventDate>
      <EventContent>
        <EventLinkTitle href={href}>{title}</EventLinkTitle>
        <AddToCalendar aria-label={labelCalendar} href={iCal} download={title.replace(/\.|\s/g, '-')} iconName="IconCalendar" color="#4773b9">
          {labelCalendar}
        </AddToCalendar>
      </EventContent>
    </EventWrapper>
  )
}

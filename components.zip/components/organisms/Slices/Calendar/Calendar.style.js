import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Typo18, Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import Text from '@axacom-client/components/molecules/Text/Text'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Label, SecondaryText } from '@axacom-client/base/style/typography'
import { lighten } from 'polished'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

export const CalendarSection = styled.section`
  background-color: ${colors.white};
  padding: ${getSpacing(6)} 0;
`
export const CalendarTitle = styled.h2`
  ${Typo43};
  margin: 0 0 ${getSpacing(4)};
  text-align: center;
`

export const CalendarSubtitle = styled(Text)`
  ${Typo18};
  text-align: center;
`

export const EventDate = styled.div`
  background-color: ${colors.actionBtnBlueHover};
  padding: 32px;
  display: flex;
  justify-content: center;
  flex-direction: column;
  min-height: 135px;

  ${media.desktop`
    min-width: 220px;
    max-width: 220px;
    min-height: 220px;
    text-align: center;
  `}
`

export const EventContent = styled.div`
  background-color: ${colors.grayLightest};
  padding: 32px 0 0;
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  min-height: 190px;
  ${media.desktop`
    width: 100%;
    min-height: 220px;
  `}
`

export const EventWrapper = styled.div`
  margin-bottom: 32px;
  ${media.desktop`
    display: flex;
  `}
`

export const PrimaryText = styled(Label)`
  color: ${colors.white};
  text-transform: uppercase;
  margin-bottom: 16px;
`
export const SecondText = styled(SecondaryText)`
  color: ${colors.white};
`

export const EventLinkTitle = styled(SmartLink)`
  display: block;
  padding: 0 32px 0;
  color: ${colors.textColor};
  text-align: left;
  font-size: 1.56rem;
  font-family: 'Source Sans Pro', sans-serif;
  font-weight: 700;
  line-height: 1.94rem;
  &:hover,
  &:focus {
    color: ${lighten(0.25, colors.textColor)};
  }
`

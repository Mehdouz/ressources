import React from 'react'
import { array, object, oneOfType, string } from 'prop-types'
import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import Image from '@axacom-client/components/atoms/Image/Image'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import Button from '@axacom-client/components/atoms/Button/Button'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Typo18, Typo28 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { MinTablet, Mobile } from '@axacom-client/components/utils/Responsive'
import Text from '@axacom-client/components/molecules/Text/Text'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

const Title = styled(Text)`
  ${Typo28};
  margin-bottom: ${getSpacing(1)};
  text-align: left;
`

const Description = styled(Text)`
  ${Typo18};
  font-weight: normal;
  margin-bottom: ${getSpacing(2)};
`

const ImageWrapperLeft = styled.div`
  ${media.phone`margin-bottom: ${getSpacing(2)};`}
  ${media.desktop`margin-bottom: 0;`}
`

const TextWrapperRight = styled.div`
  margin-left: ${getSpacing(5)};
  ${media.phone`margin-left: 0;`}
`

const Img = styled(Image)`
  margin-bottom: 0;
  ${media.phone`margin-bottom: ${getSpacing(2)};`}
  width: 165px;
  height: 165px;
`

const TextWithThumbnail = ({ title, text, image, link, linkName, slugifiedAnchor }) => {
  const imageWrapperLeft = (
    <>{image && <Img ratio="1:1" src={image.views.thumbnail.url} alt={image.views.thumbnail.alt} dataTestid="TextWithThumbnail_Image" style={{ maxHeight: '165px', padding: '0' }} />}</>
  )
  return (
    <Slice slugifiedAnchor={slugifiedAnchor} dataTestid="TextWithThumbnail">
      <Container>
        <Mobile>{imageWrapperLeft}</Mobile>
        <div className="d-flex">
          <MinTablet>
            <ImageWrapperLeft>{imageWrapperLeft}</ImageWrapperLeft>
          </MinTablet>
          <TextWrapperRight className="flex-shrink-1 align-self-center">
            {title && (
              <Title as="h2" data-testid="TextWithThumbnail_Title">
                {title}
              </Title>
            )}
            {text && <Description data-testid="TextWithThumbnail_Text">{text}</Description>}
            {link && (
              <Button type="link" url={link.url} target={link.target && link.target === 'web' ? '_blank' : '_self'} dataTestId="TextWithThumbnail_Link" color="red" iconRight="IconArrowRight">
                {linkName}
              </Button>
            )}
          </TextWrapperRight>
        </div>
      </Container>
    </Slice>
  )
}

export default TextWithThumbnail

TextWithThumbnail.propTypes = {
  title: oneOfType([string, object, array]),
  text: string,
  image: object,
  link: object,
  linkName: string,
  anchorId: string,
  slugifiedAnchor: string,
}

TextWithThumbnail.defaultProps = {}

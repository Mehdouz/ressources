import { Image, Link, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  textWithThumbnail: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'Title...'),
      text: Text('Text', 'Text...'),
      image: Image('Image', { width: 600 }, [{ name: 'thumbnail', width: 165, height: 165 }]),
      link: Link(),
      linkName: Text('Link name', 'Choose the name of the link'),
    },
    {},
    'Text With Thumbnail',
    'React component',
    'chrome_reader_mode'
  ),
}

import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Typo14, Typo18, Typo28, Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import Text from '@axacom-client/components/molecules/Text/Text'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Row } from 'reactstrap'
import { CategoryTitle } from '@axacom-client/base/style/typography'
import Button from '@axacom-client/components/atoms/Button/Button'

export const Header = styled.div`
  ${Typo14}
  display: flex;
  text-transform: uppercase;
  margin-top: ${getSpacing(2)};
`

export const HightlightedArticle = styled(Row)`
  margin-bottom: ${getSpacing(5)};
`

export const Subtitle = styled.div`
  margin-bottom: ${getSpacing(4)};
`

export const SubtitleRichText = styled(Text)`
  ${Typo18};
  text-align: left;
  margin-bottom: ${getSpacing(1)};
`

export const ItemTitle = styled(Text)`
  ${Typo28};
  text-align: left;
  margin-bottom: ${getSpacing(2)};
`

export const ReadArticleLink = styled(Button)`
  ${Typo14};
  color: ${colors.brandRed};
  text-align: left;
  text-transform: uppercase;
  padding: 0;
`

export const ReadTimeText = styled(CategoryTitle)`
  color: ${colors.gray};
  margin-left: 5px;
`

export const Title = styled.h2`
  ${Typo43}
  text-align: left;
  ${media.phone`
    margin-bottom: ${getSpacing(2)};
  `}

  ${media.tablet`
    margin-bottom: ${getSpacing(3)};
  `}

  ${media.desktop`
    margin-bottom: ${getSpacing(4)};
  `}
`

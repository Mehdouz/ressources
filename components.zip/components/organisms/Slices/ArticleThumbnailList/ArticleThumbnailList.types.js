import { Link, Select, Slice, Text } from '../../../../../tools/prismic/backup-types/generic-type'
import simpleSlice from '../../../organisms/SimpleSlice/SimpleSlice.types'

export default {
  articleThumbnailList: Slice(
    {
      anchorId: simpleSlice.anchorId,
      title: Text('Title', 'A general title...'),
      highlightedArticle: Link('Highlighted news', 'document', ['article-v2']),
      typeArticle: Select(['News', 'Press-News', 'Insights'], 'Type'),
    },
    {},
    'Article Thumbnail list',
    'React component',
    'list'
  ),
}

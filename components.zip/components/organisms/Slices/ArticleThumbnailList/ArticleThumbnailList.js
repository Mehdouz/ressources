import React from 'react'
import { Col } from 'reactstrap'
import { array, bool, object, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { i18n } from '@i18n-axa'
import Image from '@axacom-client/components/atoms/Image/Image'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Header, HightlightedArticle, SubtitleRichText, Subtitle, ItemTitle, ReadArticleLink, Title } from '@axacom-client/components/organisms/Slices/ArticleThumbnailList/ArticleThumbnailList.style'
import { getTheme } from '@axacom-client/repositories/documents'
import { getRelatedArticles } from '@axacom-client/repositories/articles'
import { getArticleMeta, getBodyAsString, isPopulated } from '@axacom-client/services/document-service'
import { getInnerWidth } from '@axacom-client/services/window-service'
import log from '@axacom-client/logger'
import ArticleList from './ArticleList/ArticleList'
import { timeToSentence, wordsReadTime } from '@axacom-client/services/string-service'
import MetaInfos from '@axacom-client/components/molecules/Card/MetaInfos'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export default function ArticleThumbnailList({ articles = [], dataTestid, highlightedArticle = {}, multiple = false, title, slugifiedAnchor, linkTopicPage }) {
  const { i18n, currentLocale } = useGlobalContext()

  const themeUrl = linkTopicPage?.url || highlightedArticle?.theme?.linkTopicPage?.url || highlightedArticle?.theme?.url

  return (
    <Slice className="articleThumbnail_simpleSlice" dataTestid={dataTestid || 'articleThumbnail_simpleSlice'} slugifiedAnchor={slugifiedAnchor}>
      <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
        <div className="px-4">
          <Title data-testid="articleThumbnail_title">{title}</Title>
          {highlightedArticle && (
            <HightlightedArticle>
              <Col lg={7} md={12} sm={12} xs={12}>
                <Image image={getArticleMeta('cover', highlightedArticle)} ratio="16:9" animation="scale" dataTestid="articleThumbnail_Image" />
              </Col>
              <Col lg={5} md={12} sm={12} xs={12}>
                <Header>
                  <SmartLink className="mb-3" data-testid="articleThumbnail_ItemSurtitle" href={themeUrl}>
                    {getArticleMeta('title', highlightedArticle.theme)}
                  </SmartLink>
                </Header>
                <ItemTitle data-testid="articleThumbnail_ItemTitle">{getArticleMeta('shortTitle', highlightedArticle, { shortToLongTitle: true, language: currentLocale })}</ItemTitle>
                <Subtitle data-testid="articleThumbnail_ItemSubtitle">
                  <SubtitleRichText>{getArticleMeta('subtitle', highlightedArticle)}</SubtitleRichText>
                  <MetaInfos contentType={highlightedArticle.contentType} readingTime={getArticleMeta('readTimeShort', highlightedArticle)}></MetaInfos>
                </Subtitle>
                <ReadArticleLink iconRight="IconArrowRight" color="red" type="link" size="large" url={highlightedArticle.url} dataTestId="articleThumbnail_ReadArticleLink">
                  {i18n.t('readArticle')}
                </ReadArticleLink>
              </Col>
            </HightlightedArticle>
          )}
          <ArticleList items={articles} visible={getNbItemsToShow(getInnerWidth(), multiple)} />
        </div>
      </ResponsiveContainer>
    </Slice>
  )
}

ArticleThumbnailList.getInitialProps = async ({ req, document }) => {
  log.debug('[ArticleThumbnailList] getInitialProps')
  const locale = (req || i18n)?.language

  const { highlightedArticle } = document
  if (highlightedArticle?.body) {
    const wordTime = wordsReadTime(getBodyAsString(highlightedArticle))?.wordTime
    highlightedArticle.readTime = timeToSentence(wordTime, locale, false)
    highlightedArticle.readTimeShort = timeToSentence(wordTime, locale, true)
  }
  // get the third level when the topic of the highlighted article is not populated
  if (!isPopulated(highlightedArticle?.theme) || !isPopulated(highlightedArticle?.theme?.highlightedArticle)) {
    try {
      log.debug(`[ArticleThumbnailList] getInitialProps getting theme=${highlightedArticle?.theme?.id}`)
      highlightedArticle.theme = await getTheme(highlightedArticle?.theme?.id, locale)
    } catch (e) {
      log.error('[ArticleThumbnailList] load theme error: ', e)
    }
  }

  const articles = document.articles || []
  try {
    const { typeArticle, query } = document
    const where = { ...query, ...(typeArticle ? { typeArticle } : {}) }
    log.info('[ArticleThumbnailList] getInitialProps getting articles', where)
    articles.push(...((await getRelatedArticles(where, 100, locale, { id: highlightedArticle?.id })) || []))
  } catch (e) {
    log.error('[ArticleThumbnailList] getRelatedArticles error: ', e)
  }

  log.debug('[ArticleThumbnailList] getInitialProps highlightedArticle')
  document.highlightedArticle = highlightedArticle || articles[0]

  log.debug('[ArticleThumbnailList] getInitialProps articles')
  document.articles = highlightedArticle ? articles : articles.slice(1, 12)
  return document
}

ArticleThumbnailList.propTypes = {
  linkTopicPage: object,
  articles: array,
  dataTestid: string,
  highlightedArticle: object,
  multiple: bool,
  title: string,
  anchorId: string,
  slugifiedAnchor: string,
}

// *** PRIVATE / VISIBLE FOR TESTING ***

export function getNbItemsToShow(width, multiple = false) {
  // if mobile
  if (width <= 767) {
    return multiple ? 3 : 6
    // if tablet
  } else if (width >= 768 && width <= 991) {
    return multiple ? 4 : 8
  } else {
    // if desktop
    return multiple ? 6 : 15
  }
}

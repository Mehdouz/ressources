import React, { useRef } from 'react'
import { StyledSlice, MotionReferrer, BackgroundImage, Container, TopBanner, SectionTitle, Title, Subtitle, Cta } from './FullBanner.style'
import { media } from '@axacom-client/base/style/variables'
import { useScroll, useTransform, circOut } from 'framer-motion/dist/framer-motion'

export default function FullBanner({ title, bannerTitle, bannerSubtitle, bannerButtonName, bannerButtonReference, bannerImage, children }) {
  const contentRef = useRef(null)

  // Calculate the scrollProgression while on cover & transform it to make parallax effect
  let { scrollYProgress } = useScroll({
    target: contentRef,
    offset: ['-115px start', 'end start'],
  })
  let y = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  let opacity = useTransform(scrollYProgress, [0, 1], [0.5, 0.1], { ease: circOut })

  return (
    <StyledSlice data-testid="FullBanner" $hasImage={bannerImage?.main}>
      <MotionReferrer ref={contentRef} />
      <Container>
        <SectionTitle data-testid="FullBanner__SectionTitle">{title}</SectionTitle>
        <TopBanner>
          <Title data-testid="FullBanner__Title">{bannerTitle}</Title>
          <Subtitle data-testid="FullBanner__SubTitle">{bannerSubtitle}</Subtitle>
          {bannerButtonName && bannerButtonReference?.url && (
            <Cta dataTestId="FullBanner__Link" iconRight="IconArrowRight" color="blue" href={bannerButtonReference.url}>
              {bannerButtonName}
            </Cta>
          )}
          {children}
        </TopBanner>
      </Container>
      <picture>
        <source media={`(max-width: ${media.phoneMax}px)`} srcSet={bannerImage?.views?.small.url} />
        <source media={`(min-width: ${media.desktopMax}px)`} srcSet={bannerImage?.views?.medium.url} />
        <BackgroundImage data-testid="FullBanner_Image" style={{ y, opacity }} src={bannerImage?.main.url} alt={bannerImage?.main?.alt} />
      </picture>
    </StyledSlice>
  )
}

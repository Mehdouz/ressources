import styled, { css } from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo27, Typo25, Typo26 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const FullWithContainer = styled.div`
  position: relative;
  border-bottom: 1px solid ${colors.gray};
  z-index: 50;
`

export const SurHeaderContainer = styled.div`
  display: flex;
  justify-content: space-between;
  position: relative;
  padding: 12px 25px;
  background-color: #fff;
`

export const Stock = styled.a`
  display: flex;
  flex-direction: row;
  align-items: center;
`

export const Title = styled.h2`
  position: relative;
  padding-right: 8px;
  margin-right: 8px;
  margin-bottom: 0;
  color: ${colors.grayDarker};
  ${Typo27};

  &:after {
    content: '';
    position: absolute;
    right: 0;
    top: 3px;
    margin-left: 8px;
    display: block;
    width: 1px;
    height: 12px;
    background-color: ${colors.gray};

    ${media.desktop`
      top: 6px;
      margin-left: 15px;
    `};
  }

  ${media.desktop`
    ${Typo26};
    padding-right: 15px;
    margin-right: 15px;
  `};

  ${media.desktopVeryLarge`
    font-size: 1rem;
    line-height: 1.5rem;
  `};
`

export const Price = styled.p`
  ${({ $language }) => css`
    color: ${colors.grayDarker};
    margin-right: 6px;
    ${Typo27};

    ${media.desktop`
      ${Typo25}
      font-weight: ${font.weight.semiBold};
    `};

    ${$language === 'en' &&
    css`
      &::before {
        content: '€';
      }
    `}

    ${$language === 'fr' &&
    css`
      &::after {
        content: ' €';
      }
    `}
  `}
`

export const ToolTip = styled(motion.div)`
  position: absolute;
  top: 45px;
  background: #fff;
  padding: 10px;
  left: 35px;
  border: 1px solid #ccc;
  color: ${colors.grayDarker};
  ${Typo27};

  &:before {
    content: '';
    display: block;
    position: absolute;
    left: 50%;
    bottom: 100%;
    margin-left: -5px;
    width: 0;
    height: 0;
    border: 7px solid transparent;
    border-bottom-color: #ccc;
  }

  &:after {
    content: '';
    display: block;
    position: absolute;
    left: calc(50% + 1px);
    margin-left: -5px;
    bottom: 100%;
    width: 0;
    height: 0;
    border: 6px solid transparent;
    border-bottom-color: white;
  }
`

export const VariationCours = styled.p`
  color: ${colors.creditColor};
  ${Typo27}
`
export const Link = styled(SmartLink)`
  text-transform: uppercase;
  margin-left: 8px;
  ${Typo27};
`

export const WorldWideLink = styled.div``

import React, { useState } from 'react'
import { AnimatePresence } from 'framer-motion/dist/framer-motion'
import { object } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { FullWithContainer, SurHeaderContainer, Stock, WorldWideLink, ToolTip, Title, Price, VariationCours, Link } from '@axacom-client/components/organisms/SurHeader/SurHeader.style'
import { getDateAndTimeWithTimezone } from '@axacom-client/services/date-service'

const STOCK_URL = {
  en: '/en/page/axa-share-performances#anchor=market-data&tab=share-performance',
  fr: '/fr/investisseurs/cours-action-axa#anchor=donnees-marche&tab=performance-action',
}

export default function SurHeader({ stockPrices }) {
  const { close: lastPrice, date, var_pct: variationPrix } = stockPrices
  const {
    i18n,
    i18n: { language },
    domain,
  } = useGlobalContext()

  const [tooltipOpen, setTooltipOpen] = useState(false)

  const formatedDate = language === 'en' ? getDateAndTimeWithTimezone().usDate(date) : getDateAndTimeWithTimezone().frDate(date)
  const stockUrl = `${domain}${STOCK_URL[language]}`
  const worldMapUrl = language === 'fr' ? `/${language}/a-propos-d-axa/axa-dans-le-monde` : `/${language}/about-us/axa-world-map`

  function handleMouseEnter() {
    setTooltipOpen(true)
  }

  function handleMouseLeave() {
    setTooltipOpen(false)
  }

  return (
    <FullWithContainer>
      <SurHeaderContainer>
        <Stock href={stockUrl} onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          <Title data-testid="SurHeader__Title">AXA</Title>
          <Price data-testid="SurHeader__Price" $language={language}>
            {lastPrice}
          </Price>
          <VariationCours data-testid="SurHeader__VariationCours">( {variationPrix}%)</VariationCours>
          <AnimatePresence>
            {tooltipOpen && (
              <ToolTip initial={{ opacity: 0 }} animate={{ y: '-5px', opacity: 1 }} exit={{ y: '5px', opacity: 0 }} transition={{ duration: 0.3 }}>
                {formatedDate}
              </ToolTip>
            )}
          </AnimatePresence>
        </Stock>
        <WorldWideLink>
          <Icon name="IconGlobe" color={colors.brandRed} width={16} height={16} />
          <Link href={worldMapUrl} data-testid="SurHeader__WorldWideLink">
            {i18n.t('axaWorldwide')}
          </Link>
        </WorldWideLink>
      </SurHeaderContainer>
    </FullWithContainer>
  )
}

SurHeader.propTypes = {
  stockPrices: object,
}

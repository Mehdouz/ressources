import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Typo10, Typo12 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export const TimelineHeaderContainer = styled(motion.div)`
  position: fixed;
  display: block;
  background-color: ${colors.white};
  top: 0;
  left: 0;
  width: 100%;
  z-index: 50;
  border-bottom: 1px solid ${colors.grey300};
`

export const Content = styled(Container)`
  display: flex;
  height: 60px;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
`

export const Title = styled(motion.h2)`
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 0;
  ${Typo12}
  ${media.desktopVeryLarge`
    margin-left:0;
    text-align: center;
    padding-left: 20px;
    padding-right: 150px; // illusion of center
  `}
`

export const Year = styled(motion.p)`
  ${Typo12}
`

export const SummaryWrapper = styled(motion.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 60;
  background-color: white;
  bottom: 0;
  overflow-y: auto;
`
export const Behind = styled(motion.div)`
  background-color: ${colors.grey900};
  opacity: 0.5;
  position: fixed;
  top: 70px;
  left: 0;
  right: 0;
  width: 100%;
  height: calc(100vh - 70px);
  z-index: -1;
`

export const Toggle = styled(motion.div)`
  position: relative;
  cursor: pointer;
  width: 20px;
  height: 36px;
  transform-origin: center;

  &:before {
    content: '';
    border: solid ${colors.grey400};
    border-width: 0 2px 2px 0;
    padding: 6px;
    transform: rotate(45deg);
    position: absolute;
    top: 8px;
    left: 0px;

    ${media.tablet`
      display: inline-block;
    `}
  }
`

export const Close = styled(motion.div)`
  position: relative;
  cursor: pointer;
  width: 35px;
  height: 35px;
  will-change: transform;
  transition: transform 0.2s;

  &:hover {
    transform: scale(1.2);
  }

  ${media.tablet`
    display: inline-block;
  `}
`

export const SummaryTitle = styled.div`
  height: 65px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-right: 10px;

  & p {
    ${Typo10}
    line-height: 20px;
  }
`

import React, { useEffect, useState } from 'react'
import { AnimatePresence } from 'framer-motion/dist/framer-motion'
import { TimelineHeaderContainer, Content, Title, Year, SummaryWrapper, Behind, Toggle, Close, SummaryTitle } from './TimelineHeader.style'
import { colors as colorsVariables } from '@axacom-client/base/style/variables'
import Progressbar from '@axacom-client/components/molecules/Progressbar/Progressbar'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'
import { mediaQueries } from '@axacom-client/base/style/media'
import { useTimeline } from '@axacom-client/components/pages/timeline-v2/timeline-v2.page'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { PeriodContentList } from '../TimelineSummary/TimelineSummary'
import useScrollBlock from '@axacom-client/hooks/useScrollBlock'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

const variants = {
  visible: {
    y: 0,
    transition: { ease: 'easeInOut', when: 'beforeChildren' },
  },
  hidden: {
    y: '-100%',
  },
  exit: {
    y: '-100%',
    transition: { ease: 'easeInOut' },
  },
}

const containerVariants = {
  visible: {
    transition: { staggerChildren: 0.05 },
  },
}

const contentVariants = {
  hidden: { opacity: 0, y: -20 },
  visible: { opacity: 1, y: 0 },
}

const toggleVariants = {
  hidden: { opacity: 0, y: -20 },
  visible: { opacity: 1, y: 0 },
  hover: { scale: 1.2 },
}

export default function TimelineHeader({ title }) {
  const isDesktop = useBetterMediaQueries({ query: mediaQueries.desktop }, true)

  const [displaySummary, setDisplaySummary] = useState(false)
  const { y, step, periods, colors } = useTimeline()
  const [showHeader, setShowHeader] = useState(false)

  const [blockScroll, allowScroll] = useScrollBlock()

  const handleMenu = () => {
    setDisplaySummary(!displaySummary)
    if (displaySummary) allowScroll()
    else blockScroll()
  }

  useEffect(() => {
    return y.onChange((latest) => {
      if (step.get() >= 0 && latest > 0 && latest < 1) {
        setShowHeader(true)
      } else {
        setShowHeader(false)
      }
    })
  }, [y])

  const currentIndex = step.get() >= 0 ? step.get() : 0
  const year = periods[currentIndex].period
  const currentTitle = periods[currentIndex].title

  return (
    <AnimatePresence exitBeforeEnter>
      {showHeader ? (
        <React.Fragment key={year + title}>
          <TimelineHeaderContainer animate="visible" exit="exit" initial="hidden" whileHover="hover" variants={variants}>
            <Content variants={containerVariants}>
              <Year variants={contentVariants}>{year}</Year>
              {isDesktop && (
                <Title data-testid="Stickyheader_Title" variants={contentVariants}>
                  {currentTitle}
                </Title>
              )}
              <Toggle onClick={handleMenu} variants={toggleVariants} />
            </Content>
            <Progressbar size={5} progress={y} color={colors[step.get()]} />
          </TimelineHeaderContainer>
        </React.Fragment>
      ) : null}
      {showHeader && displaySummary ? (
        <SummaryWrapper key="summary" animate="visible" exit="exit" initial="hidden" whileHover="hover" variants={variants}>
          <Container>
            <SummaryTitle>
              <p>{title}</p>
              <Close onClick={handleMenu}>
                <Icon name="IconCross" width={35} height={35} color={colorsVariables.grayDark} />
              </Close>
            </SummaryTitle>
          </Container>
          <PeriodContentList onClick={handleMenu} />
          <Behind onClick={handleMenu} initial={{ opacity: 0 }} animate={{ opacity: 0.5, transition: { delay: 0.2 } }} exit={{ opacity: 0, transition: { duration: 0 } }} />
        </SummaryWrapper>
      ) : null}
    </AnimatePresence>
  )
}

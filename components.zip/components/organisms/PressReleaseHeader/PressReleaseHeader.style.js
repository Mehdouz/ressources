import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import Button from '@axacom-client/components/atoms/Button/Button'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo17, Typo18, Typo40, Typo50 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'

export const StyledSlice = styled(Slice)`
  overflow: visible;
  min-height: 460px;
`

export const Cta = styled(Button)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 16px;
  letter-spacing: 1px;
  margin-bottom: 40px;
`

export const Title = styled.h1`
  ${Typo40}
  text-align: left;
`

export const PannelWrapper = styled.div`
  ${media.desktop`
    position: absolute;
    height: 100vh;
    left: 650px;
    top: 0;
  `}

  ${media.desktopLarge`
    left: 790px;
  `}
`

export const PressReleasePanel = styled.div`
  display: flex;
  width: 100%;
  flex-direction: column;
  gap: 15px;
  margin-top: 50px;
  ${Typo17}
  text-transform: uppercase;

  & button {
    height: 50px;
  }

  ${media.desktop`
    width: 150px;
    position: sticky;
    top: 20px;
    margin-top: 0px;
  `}
`

export const ShareBlock = styled.div`
  display: flex;
  flex-direction: column;
  position: relative;
  z-index: 20;
`

export const ShareContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 15px;
  position: absolute;
  top: 65px;
  width: 100%;
  z-index: 10;
`

export const ShareButton = styled(Button)`
  position: relative;
  z-index: 20;
`

export const Contact = styled(Button)`
  display: none;

  ${media.desktop`
    display: inline-flex;
    justify-content: space-between;
  `}
`

export const DownloadButton = styled(Button)`
  border: 0;
`

export const NewsletterButton = styled(Button)`
  white-space: nowrap;
`

export const ShareLink = styled(Button)`
  width: 100%;
  height: 50px;
  border-bottom: 0;
  background: ${colors.axaBlue500};
  color: ${colors.brandBlue};

  & span {
    display: flex;
    flex-direction: row;
    align-items: center;
    padding: 0;
    margin: 0;
    height: 100%;
    width: 100%;
    justify-content: space-between;
  }

  & svg path {
    transition: fill 0.3s ease;
  }

  &:hover {
    & div {
      background: ${colors.axaBlue400};

      & svg path {
        fill: ${colors.white};
      }
    }
  }
`

export const SocialText = styled.p`
  padding: 0 20px;
  text-transform: uppercase;
  ${Typo17}
  font-weight: ${font.weight.bold};
  width: 100%;

  ${media.desktop`
    width: 100px;
  `}
`

export const IconContainer = styled.div`
  background: ${colors.axaBlue300};
  position: absolute;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  width: 50px;
  transition: background 0.3s ease;
`

export const DateBlock = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-transform: uppercase;
  ${Typo17}
  padding-top: 50px;

  ${media.tablet`
    gap: 8px;
    flex-direction: row;
    padding-top: 30px;
    margin-bottom: -30px;
  `}

  ${media.desktop`
    margin-bottom: -10px;
  `}
`

export const Time = styled.p`
  ${Typo17}
  color: ${colors.gray};

  ${media.tablet`
    padding-left: 9px;
    position: relative;

    &:before {
      content: '|';
      position: absolute;
      left: 0;
    }
  `}
`

export const PressReleaseMeta = styled.div`
  font-weight: ${font.weight.bold};
  padding-bottom: 15px;
  border-bottom: 1px solid ${colors.grayLight};

  ${media.tablet`
    border: 0;
  `}

  ${media.desktop`
    border-bottom: 1px solid ${colors.grayLight};
  `}
`

export const PressReleaseType = styled.p`
  font-weight: ${font.weight.bold};
`

export const PressReleaseSize = styled.p`
  ${Typo17}
  font-weight: ${font.weight.bold};
  color: ${colors.gray};
`

export const ModalTitle = styled.h2`
  ${Typo50}
  margin-bottom: 20px;
`

export const ModalSubtitle = styled.p`
  ${Typo18}
  margin-bottom: 20px;
`

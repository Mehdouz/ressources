import React, { useState } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import {
  StyledSlice,
  Cta,
  DateBlock,
  Time,
  PannelWrapper,
  Title,
  PressReleasePanel,
  ShareBlock,
  ShareContainer,
  IconContainer,
  SocialText,
  ShareLink,
  DownloadButton,
  NewsletterButton,
  ShareButton,
  Contact,
  PressReleaseType,
  PressReleaseSize,
  PressReleaseMeta,
  ModalTitle,
  ModalSubtitle,
} from '@axacom-client/components/organisms/PressReleaseHeader/PressReleaseHeader.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { dateTime, dateTimeZone, getDateTimeZoneName } from '@axacom-client/services/date-service'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'
import svg from '@axacom-client/base/svg'
import { colors } from '@axacom-client/base/style/variables'
import { useShare } from '@axacom-client/hooks/useShare'
import { AnimatePresence, motion } from 'framer-motion/dist/framer-motion'
import { bytesToSize } from '@axacom-client/services/string-service'
import { useMediaQuery } from 'react-responsive'
import { mediaQueries } from '@axacom-client/base/style/media'
import NewsletterForm from '@axacom-client/components/molecules/Form/NewsletterForm'
import Modal from '@axacom-client/components/molecules/Modal/Modal'

const variants = {
  visible: {
    transition: { ease: [0.25, 1, 0.5, 1], staggerChildren: 0.03 },
  },
}

const variantsLinks = {
  visible: {
    y: 0,
    transition: { duration: 0.3, ease: [0.25, 1, 0.5, 1] },
  },
  hidden: (index) => {
    return { y: -65 * (index + 1) }
  },
  exit: (index) => {
    return { y: -65 * (index + 1), transition: { ease: 'easeOutQuart' } }
  },
}

export default function PressReleaseHeader({ title, document, date }) {
  const [modal, setModal] = useState(false)
  const toggle = () => setModal(!modal)
  const { i18n, currentLocale, bookmarks } = useGlobalContext()
  const hourFormat = currentLocale === 'fr' ? 'H:mm' : 'h:mm A'
  const formatedDate = date ? dateTime(date, 'LL', currentLocale) : null
  const formatedTime = date ? `${dateTimeZone(date, hourFormat, currentLocale)} ${getDateTimeZoneName(date)}` : null

  return (
    <StyledSlice data-testid="PressReleaseHeader">
      <ResponsiveContainer mobile>
        <CenteredReadingContainer>
          <Cta type="link" color="red" iconLeft="IconArrowLeft" href={bookmarks?.repositoryPresseRelease?.url} data-testid="PressReleaseHeader___Breadcrumb">
            {i18n.t('pressrelease.back.button')}
          </Cta>
        </CenteredReadingContainer>
      </ResponsiveContainer>
      <ResponsiveContainer mobile>
        <CenteredReadingContainer>
          {title && <Title data-testid="PressReleaseHeader__Title">{title}</Title>}
          <PannelWrapper>
            <Panel title={title} document={document} date={date} toggle={toggle} />
          </PannelWrapper>
          <DateBlock>
            {formatedDate && <p data-testid="PressReleaseHeader__Date">{formatedDate}</p>}
            {formatedTime && (
              <Time data-testid="PressReleaseHeader__Time">
                {i18n.t('pressrelease.published.at')} {formatedTime}
              </Time>
            )}
          </DateBlock>
        </CenteredReadingContainer>
      </ResponsiveContainer>
      <Modal isOpen={modal} toggle={toggle} modalTitle="Modal Newsletter">
        <ModalTitle>{i18n.t('newsletterSubscription.title')}</ModalTitle>
        <ModalSubtitle>{i18n.t('newsletterSubscription.subtitle')}</ModalSubtitle>
        <NewsletterForm
          isVisible={modal}
          textContent={i18n.t('newsletterSubscription.policy')}
          checkboxGDPR={i18n.t('newsletterSubscription.checkboxGDPR')}
          defaultValue={{ newsletterChoice: ['pressRelease'] }}
        />
      </Modal>
    </StyledSlice>
  )
}

function Panel({ title, document, toggle }) {
  const [isSharingVisible, setIsSharingVisible] = useState(false)
  const { i18n, currentLocale } = useGlobalContext()
  const isMobile = useMediaQuery({ query: mediaQueries.phone })

  return (
    <PressReleasePanel onMouseLeave={isMobile ? null : () => setIsSharingVisible(false)}>
      <ShareBlock onClick={isMobile ? () => setIsSharingVisible(!isSharingVisible) : null} onMouseEnter={isMobile ? null : () => setIsSharingVisible(true)}>
        <ShareButton data-testid="PressReleaseHeader__ShareButton" color="blue">
          {i18n.t('pressrelease.share')}
        </ShareButton>
        <AnimatePresence>
          {isSharingVisible && (
            <motion.div animate="visible" exit="exit" initial="hidden" variants={variants}>
              <Share title={title} />
            </motion.div>
          )}
        </AnimatePresence>
      </ShareBlock>
      <NewsletterButton data-testid="PressReleaseHeader__NewsletterButton" onClick={toggle} type="ghost" color="blue">
        {i18n.t('pressrelease.newsletter.button')}
      </NewsletterButton>
      {document?.url ? (
        <>
          <DownloadButton data-testid="PressReleaseHeader__DownloadButton" color="red" href={document.url}>
            {i18n.t('pressrelease.download.button')}
          </DownloadButton>
          <PressReleaseMeta>
            <PressReleaseType data-testid="PressReleaseHeader__Type">{i18n.t('pressrelease')}</PressReleaseType>
            <PressReleaseSize>PDF {bytesToSize(document.file.size, currentLocale)}</PressReleaseSize>
          </PressReleaseMeta>
        </>
      ) : null}
      <Contact data-testid="PressReleaseHeader__ContactButton" type="link" color="red" target="_self" iconRight="IconArrowDown" href="#contacts">
        {i18n.t('pressrelease.contacts')}
      </Contact>
    </PressReleasePanel>
  )
}

function Share({ title }) {
  const socials = ['facebook', 'twitter', 'linkedin']
  const icons = { facebook: svg.IconSocialFacebook, twitter: svg.IconSocialTwitter, linkedin: svg.IconSocialLinkedin }

  const { onShare } = useShare({ title })

  return (
    <ShareContainer>
      {socials.map((social, index) => {
        const Icon = icons[social]
        return (
          <ShareLink
            key={index}
            data-key={social}
            type="primary"
            color="blue"
            data-test-id="SocialShare_Link"
            className={'network-allowed'}
            data-analytics={`{"block_name":"share_button::${social}", "event_type":"A"}`}
            onClick={() => onShare(social)}
            custom={index}
            variants={variantsLinks}
          >
            <SocialText>{social}</SocialText>
            <IconContainer>
              <Icon color={colors.brandBlue} width={20} height={20} />
            </IconContainer>
          </ShareLink>
        )
      })}
    </ShareContainer>
  )
}

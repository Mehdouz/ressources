import { useTimeline } from '@axacom-client/components/pages/timeline-v2/timeline-v2.page'
import React, { useRef } from 'react'
import { StyledResponsiveContainer, PeriodContent, PeriodList, PeriodMainTitle, PeriodLink, Period, PeriodTitle, Foreground, Stroke } from './TimelineSummary.style'
import { Slice } from '../SimpleSlice/SimpleSlice'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { slugify } from '@axacom-client/services/string-service'
import { useInView } from 'framer-motion/dist/framer-motion'

export { PeriodList }
export default function TimelineSummary({ title }) {
  return (
    <Slice id="TimelineSummary" className="p-0" data-testid="TimelineSummary">
      <PeriodMainTitle>
        <Container>{title}</Container>
      </PeriodMainTitle>
      <PeriodContentList />
    </Slice>
  )
}

export const PeriodContentList = ({ ...rest }) => {
  const { periods } = useTimeline()
  return (
    <PeriodList>
      {periods.length > 0 &&
        periods.map((item, index) => {
          const id = slugify(periods[index]?.title).toLowerCase()

          return <PeriodContentLink showArrows key={index} index={index} data-testid="TimelineSummary__Item" href={`#${id}`} {...rest} {...item}></PeriodContentLink>
        })}
    </PeriodList>
  )
}

const foregroundVariants = {
  hidden: { scaleX: 1 },
  visible: { scaleX: 0, transition: { duration: 0.4, ease: [0.33, 1, 0.68, 1] } },
}

const textContainerVariants = {
  hover: {
    transition: { staggerChildren: 0.05 },
  },
}

const textVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0, transition: { delay: -0.05 } },
  hover: { x: 20 },
}

const strokeVariants = {
  hidden: { scaleX: 0 },
  visible: { scaleX: 1, transition: { delay: 0.1 } },
  hover: { scaleX: 1.5 },
}

const PeriodContentLink = ({ href, onClick, index, period, title, showArrows = false, ...rest }) => {
  const { colors, hovers } = useTimeline()

  const linkRef = useRef(null)
  const isInView = useInView(linkRef, { margin: '-100px', once: true })

  return (
    <li ref={linkRef} data-testid="TimelineSummary__Item" {...rest}>
      <PeriodLink
        data-testid="TimelineSummary__Item__Link"
        $color={hovers[index % colors.length]}
        href={href}
        onClick={onClick}
        initial="hidden"
        animate={isInView ? 'visible' : 'hidden'}
        exit="exit"
        whileHover="hover"
      >
        <Foreground $color={hovers[index % colors.length]} variants={foregroundVariants} />
        <StyledResponsiveContainer>
          <PeriodContent $color={colors[index % colors.length]} $showArrows={showArrows} variants={textContainerVariants}>
            <Period data-testid="TimelineSummary__Item__Period" variants={textVariants}>
              {period}
            </Period>
            <PeriodTitle data-testid="TimelineSummary__Item__Title" variants={textVariants}>
              {title}
            </PeriodTitle>
          </PeriodContent>
        </StyledResponsiveContainer>
        <Stroke $color={colors[index % colors.length]} variants={strokeVariants} />
      </PeriodLink>
    </li>
  )
}

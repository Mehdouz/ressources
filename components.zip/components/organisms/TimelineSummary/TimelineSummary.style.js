import styled, { css } from 'styled-components'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'

import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Typo10 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'

export const StyledResponsiveContainer = styled(Container)`
  height: 100%;
`

export const PeriodContent = styled(motion.div)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-height: 115px;
  position: relative;

  ${({ $showArrows }) =>
    $showArrows
      ? css`
          &:before {
            content: '';
            border: solid ${colors.gray};
            border-width: 0 2px 2px 0;
            display: none;
            padding: 6px;
            transform: rotate(-45deg);
            -webkit-transform: rotate(-45deg);
            position: absolute;
            right: 25px;

            ${media.tablet`
              display: inline-block;
            `}
          }
        `
      : null}
`

export const Stroke = styled(motion.div)`
  position: absolute;
  display: block;
  bottom: -1px;
  left: -4px;
  height: 6px;
  border-radius: 3px;
  width: 20%;
  background: ${(props) => props.$color};
  transform-origin: left;
`

export const PeriodList = styled.ul`
  background-color: white;
  list-style: none;
  padding: 0;
  margin: 0;

  & li {
    border-bottom: 1px solid ${colors.gray};

    &:first-child {
      border-top: 1px solid ${colors.gray};
    }
  }
`
export const PeriodMainTitle = styled.div`
  ${Typo10}
  height: 65px;
  display: flex;
  align-items: center;
`

export const Period = styled(motion.p)`
  font-size: 28px;
  line-height: 28px;
  font-weight: ${font.weight.bold};
  font-family: ${font.fontFamilyHeading};
  will-change: transform;
`

export const PeriodLink = styled(SmartLink)`
  width: 100%;
  height: 100%;
  display: block;
  color: ${colors.black};
  transition: background-color 0.2s;
  position: relative;
  &:hover,
  &:focus,
  &:active {
    color: ${colors.black};
    background-color: ${(props) => `${props.$color}`};
  }
`

export const PeriodTitle = styled(motion.p)`
  font-size: 20px;
  line-height: 24px;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  will-change: transform;

  ${media.tablet`
    font-size: 18px;
  `}
`

export const Foreground = styled(motion.div)`
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: ${({ $color }) => $color};
  transform-origin: right;
  z-index: 100;
`

export const Background = styled(motion.div)`
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  background-color: ${colors.white};
  transform-origin: right;
  z-index: 110;
`

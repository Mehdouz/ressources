import React, { useState } from 'react'
import { string, object } from 'prop-types'
import styled from 'styled-components'

import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Button from '../../atoms/Button/Button'
import Modal from '../../molecules/Modal/Modal'
import { PageTitle, StandardText } from '../../../base/style/typography'
import NewsletterForm from '../../molecules/Form/NewsletterForm'
import { getSpacing } from '../../../base/style/spacing'

const Title = styled(PageTitle)`
  margin-bottom: ${getSpacing(3)};
  padding-right: 50px;
`

const Subtitle = styled(StandardText)`
  margin-bottom: ${getSpacing(3)};
`

const ModalNewsletter = ({ buttonLabel, buttonType, buttonColor = 'red', width = 'auto', textContent, checkboxGDPR, defaultValue }) => {
  const [modal, setModal] = useState(false)
  const toggle = () => setModal(!modal)

  const { i18n } = useGlobalContext()

  return (
    <>
      <Button ariaExpanded={modal} type={buttonType} color={buttonColor} onClick={toggle} width={width} size="large">
        {buttonLabel}
      </Button>
      <Modal isOpen={modal} toggle={toggle} modalTitle="Modal Newsletter">
        <Title as="h1">{i18n.t('newsletterSubscription.title')}</Title>
        <Subtitle>{i18n.t('newsletterSubscription.subtitle')}</Subtitle>
        <NewsletterForm isVisible={modal} textContent={textContent} checkboxGDPR={checkboxGDPR} defaultValue={defaultValue} />
      </Modal>
    </>
  )
}

export default ModalNewsletter

ModalNewsletter.propTypes = {
  buttonLabel: string,
  buttonType: string,
  buttonColor: string,
  width: string,
  textContent: string,
  checkboxGDPR: string,
  defaultValue: object,
}

ModalNewsletter.defaultProps = {
  buttonLabel: 'popup',
}

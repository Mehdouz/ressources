import React from 'react'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { Container, HiddenScrollWrapper, RelatedArticlesContainer, RelatedArticlesWrapper, RelatedArticle, ArticleTitle, ReadArticleLink } from './RelatedArticles.style'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

export default function RelatedArticles({ anchorPoint, articles }) {
  const { domain, i18n } = useGlobalContext()

  return (
    <Slice slugifiedAnchor={anchorPoint} className="p-0" fluid data-testid="RelatedArticles">
      <Container>
        <ResponsiveContainer veryLargeDesktop>
          <RelatedArticlesContainer>
            <HiddenScrollWrapper>
              <RelatedArticlesWrapper>
                {articles &&
                  articles.map((item, index) => {
                    const title = item?.cover?.title
                    const image = item?.cover?.banner?.views?.medium?.url || item?.cover?.banner?.main?.url
                    const href = domain + item?.url

                    return (
                      <RelatedArticle key={index}>
                        <img src={image} alt={title} />
                        <ArticleTitle>{title}</ArticleTitle>
                        <ReadArticleLink iconRight="IconArrowRight" color="red" type="link" size="large" href={href} dataTestId="RelatedArticles__readMore">
                          {i18n.t('relatedArticle.readMore')}
                        </ReadArticleLink>
                      </RelatedArticle>
                    )
                  })}
              </RelatedArticlesWrapper>
            </HiddenScrollWrapper>
          </RelatedArticlesContainer>
        </ResponsiveContainer>
      </Container>
    </Slice>
  )
}

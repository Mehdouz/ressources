import React from 'react'
import { Title, Description, Persons, PersonBlock, Person, PersonInfos, PersonImage, PersonName, PersonRole } from '@axacom-client/components/organisms/OrganizationList/OrganizationList.style'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export default function OrganizationList({ title, description, persons }) {
  return (
    <Slice data-testid="PersonsList">
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        {title && <Title>{title}</Title>}
        {description && <Description>{description}</Description>}
        <Persons>
          {persons?.length > 0 &&
            persons.map(({ avatar, firstname, lastname, shortRole, shortDescription1, shortDescription2, url, slug, deactivateProfile }, index) => (
              <PersonBlock key={index}>
                <Person href={deactivateProfile === 'Yes' ? null : url}>
                  {avatar?.main?.url && <PersonImage src={avatar?.main?.url} alt={slug} />}
                  <PersonInfos>
                    {firstname && lastname && <PersonName>{`${firstname} ${lastname}`}</PersonName>}
                    {shortRole && <PersonRole>{shortRole}</PersonRole>}
                    {shortDescription1 && <PersonRole>{shortDescription1}</PersonRole>}
                    {shortDescription2 && <PersonRole>{shortDescription2}</PersonRole>}
                  </PersonInfos>
                </Person>
              </PersonBlock>
            ))}
        </Persons>
      </ResponsiveContainer>
    </Slice>
  )
}

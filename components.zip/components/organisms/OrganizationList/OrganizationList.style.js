import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo17, Typo40 } from '@axacom-client/base/style/typoStyle/typoStyle'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

export const Title = styled.h2`
  ${Typo40}
  text-align: center;
  margin-bottom: 30px;
`

export const Description = styled.p`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  font-size: 18px;
  line-height: 24px;
  text-align: center;

  ${media.tablet`
    font-size: 20px;
    line-height: 28px;
  `}

  ${media.desktopLarge`
    font-size: 24px;
    line-height: 34px;
  `}
`

export const Persons = styled.div`
  margin-top: 40px;

  ${media.tablet`
    display: flex;
    flex-wrap: wrap;
    gap: 90px 0;
    margin-top: 50px;
  `}

  ${media.desktop`
    margin-top: 80px;
  `}
`

export const PersonBlock = styled.div`
  ${media.tablet`
    width: 50%;
    justify-content: center;
    display: flex;
  `}

  ${media.desktop`
    width: 33%;
  `}
`

export const Person = styled(SmartLink)`
  display: flex;
  flex-direction: row;
  border-bottom: 1px solid ${colors.grayLighter};
  padding: 30px 0;
  align-items: start;

  ${media.tablet`
    flex-direction: column;
    border-bottom: none;
    align-items: center;
    padding: 0 30px;
  `}
`

export const PersonInfos = styled.div`
  display: flex;
  flex-direction: column;

  ${media.tablet`
    align-items: center;
  `}
`

export const PersonImage = styled.img`
  border-radius: 50%;
  display: block;
  width: 15%;
  margin-right: 25px;

  ${media.tablet`
    margin-right: 0px;
    margin-bottom: 30px;
    max-width: 100px;
    width: auto;
  `}
`

export const PersonName = styled.h3`
  ${Typo17}
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  margin-bottom: 0.5rem;

  ${media.tablet`
    margin-bottom: 0;
    font-size: 13px;
    text-align: center;
  `}
`

export const PersonRole = styled.p`
  ${Typo17}
  text-transform: uppercase;
  color: ${colors.textColor};
  text-align: left;

  ${media.tablet`
    font-size: 13px;
    text-align: center;
  `}
`

import React from 'react'
import { AnimatePresence, motion } from 'framer-motion/dist/framer-motion'
import { array, number } from 'prop-types'
import { InfosContainer, InfosTitle, InfosSurtitle, InfosButton } from '@axacom-client/components/organisms/SpotlightHome/SpotlightHome.style'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

const itemVariants = {
  show: { opacity: 1, x: 0 },
  hidden: { opacity: 0, x: 20 },
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
    },
  },
}
export function Infos({ items, selected }) {
  const { i18n } = useGlobalContext()

  return (
    <InfosContainer>
      <AnimatePresence>
        {items.map(
          ({ surtitle, title, link }, i) =>
            selected === i && (
              <motion.div key={`${title}-${i}`} initial="hidden" animate="show" variants={container}>
                <InfosSurtitle data-testid="surtitle" variants={itemVariants}>
                  {surtitle}
                </InfosSurtitle>
                <InfosTitle data-testid="title" variants={itemVariants}>
                  {title}
                </InfosTitle>
                <motion.div variants={itemVariants}>
                  <InfosButton data-testid="button" url={link.url} color="red">
                    {i18n.t('suggested.read')}
                  </InfosButton>
                </motion.div>
              </motion.div>
            )
        )}
      </AnimatePresence>
    </InfosContainer>
  )
}

Infos.propTypes = {
  items: array,
  selected: number,
}

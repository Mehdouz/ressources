export default [
  (document) => {
    return document.spotlightHome.every((card) => card.surtitle !== undefined && card.title !== undefined && card.link !== undefined)
  },
]

import styled from 'styled-components'

import { motion } from 'framer-motion/dist/framer-motion'
import Button from '@axacom-client/components/atoms/Button/Button'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'

export const LiveNotificationsContainer = styled.div`
  position: absolute;
  background: ${colors.brandRed};
  z-index: 10;
  margin: 30px;
  color: white;
  right: 0;
  ${media.phone`
    left: 0;
  `}
  ${media.tablet`
    width: 300px;
  `}
  ${media.desktopVeryLarge`
    border: 1px solid purple;
    margin-right: calc(((100vw - 1920px) / 2) + 30px);
  `}
`

export const LiveIcon = styled.div`
  background: white;
  color: ${colors.brandRed};
  border-radius: 15px;
  padding: 5px 15px;
  display: flex;
  align-items: center;
  gap: 6px;
  margin-left: 15px;
  margin-right: 15px;
  font-weight: 600;
  font-size: 0.9rem;
`
export const LiveDate = styled.div`
  flex: 1 2;
  font-size: 0.9rem;
  text-transform: uppercase;
`
export const LiveTag = styled.div`
  display: flex;
  align-items: center;
  height: 56px;
  cursor: pointer;
`

export const ToggleLive = styled(motion.a)`
  padding: 19px;
`

export const LiveListContainer = styled(motion.ul)`
  margin-bottom: 0;
  list-style: none;
  padding: 0;
  overflow: hidden;
`

export const LiveInnerItem = styled.div`
  padding: 15px;
`

export const LiveItem = styled(motion.li)`
  display: block;
  padding: 0;
  ${({ $isMultiple }) =>
    $isMultiple
      ? `
  position: relative;
  &:after {
    content: '';
    position: absolute;
    border-top: 1px solid ${colors.des_redLight};
    top: 0;
    left: 15px;
    right: 15px;
  }
  `
      : ''}
`

export const LiveItemTitle = styled.p`
  font-weight: 600;
  line-height: 1.5rem;
  margin-bottom: 15px;
`

export const LiveButton = styled(Button)`
  border-bottom-color: ${colors.gray};
  &:after {
    background-color: ${colors.gray};
  }
  color: ${colors.grayDarker};
  &:hover,
  &:active,
  &:focus {
    color: ${colors.grayDarker};
  }
`

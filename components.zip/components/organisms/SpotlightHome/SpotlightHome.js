import React, { useState } from 'react'
import { array, string } from 'prop-types'
import { useMediaQuery } from 'react-responsive'
import { SpotlightHomeContainer, SliderContainer, SliderContentContainer } from '@axacom-client/components/organisms/SpotlightHome/SpotlightHome.style'
import { mediaVariables } from '@axacom-client/base/style/media'
import { DotCardList } from './DotCardList'
import { Infos } from './Infos'
import { SlideBackground } from './SlideBackground'
import { LiveNotifications } from './LiveNotifications'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

function SpotlightHome({ items, liveDate, liveNotifications }) {
  const isOnlyTablet = useMediaQuery({ minWidth: mediaVariables.tabletMin, maxWidth: mediaVariables.tabletMax })
  const currentItems = items.slice(0, isOnlyTablet ? 3 : 5) // 3 elements only for tablet
  const showLiveNotif = liveDate && liveNotifications.length >= 1

  return (
    <SpotlightHomeContainer data-testid="SpotlightHome">
      {/* notifications */}
      {showLiveNotif ? <LiveNotifications date={liveDate} items={liveNotifications}></LiveNotifications> : null}
      {/* Background images */}
      <DotCardSlider items={currentItems}></DotCardSlider>
    </SpotlightHomeContainer>
  )
}

SpotlightHome.propTypes = {
  items: array,
  liveDate: string,
  liveNotifications: array,
}

export default SpotlightHome

function DotCardSlider({ items }) {
  const [selected, setSelected] = useState(0)
  const handleSelect = (index) => setSelected(index)

  return (
    <>
      <SliderContainer>
        {items.map((item, i) => (
          <SlideBackground key={i} isSelected={i === selected} image={item.image} />
        ))}
      </SliderContainer>
      <SliderContentContainer>
        <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
          {/* contents like title, surtitle, link */}
          <Infos items={items} selected={selected} />
          {/* Dot/pause items */}
          <DotCardList items={items} selected={selected} onSelect={handleSelect}></DotCardList>
        </ResponsiveContainer>
      </SliderContentContainer>
    </>
  )
}

DotCardSlider.propTypes = {
  items: array,
}

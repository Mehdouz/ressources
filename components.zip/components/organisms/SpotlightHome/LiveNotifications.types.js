import { Group, Link, Text, DatePicker } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $liveNotificationDate: DatePicker('Live notification date'),
  $liveNotifications: Group(
    {
      title: Text('Title', 'Enter the title'),
      linkName: Text('Link name', 'eg: Watch the live'),
      link: Link('Link'),
    },
    'Live notifications (Only 2 elements will be shown)',
    true
  ),
}

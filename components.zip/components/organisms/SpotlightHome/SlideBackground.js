import React from 'react'
import { bool, object } from 'prop-types'
import { useMediaQuery } from 'react-responsive'
import { ImageWrapper, ImageContent } from '@axacom-client/components/organisms/SpotlightHome/SpotlightHome.style'
import { mediaVariables } from '@axacom-client/base/style/media'
import useFirstMountState from '@axacom-client/hooks/useFirstMountState'

const variants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
}

export const SlideBackground = ({ isSelected, image }) => {
  const isMobile = useMediaQuery({ maxWidth: mediaVariables.phoneMax })
  const isTablet = useMediaQuery({ minWidth: mediaVariables.tabletMin, maxWidth: mediaVariables.tabletMax })
  const isFirst = useFirstMountState()

  let src = image.main.url
  if (image?.views?.tablet?.url && isTablet) src = image.views.tablet.url
  else if (image?.views?.mobile?.url && isMobile) src = image.views.mobile.url

  return (
    <ImageWrapper initial={isFirst ? false : 'hidden'} animate={isSelected ? 'visible' : 'hidden'} variants={variants}>
      <ImageContent $src={src}></ImageContent>
    </ImageWrapper>
  )
}

SlideBackground.propTypes = {
  isSelected: bool,
  image: object,
}

import React, { useState, useEffect } from 'react'
import { array, bool, func, string } from 'prop-types'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { LiveNotificationsContainer, LiveTag, LiveIcon, LiveDate, ToggleLive, LiveItem, LiveButton, LiveItemTitle, LiveListContainer, LiveInnerItem } from './LiveNotifications.style'
import { colors } from '@axacom-client/base/style/variables'
import { AnimatePresence } from 'framer-motion/dist/framer-motion'
import useFirstMountState from '@axacom-client/hooks/useFirstMountState'
import { useMediaQuery } from 'react-responsive'
import { mediaQueries } from '@axacom-client/base/style/media'

export function LiveNotifications({ date, items }) {
  const isDesktop = useMediaQuery({ query: mediaQueries.desktop })
  const [isOpen, setIsOpen] = useState(false)
  const isMultiple = items?.length >= 1
  const currentItems = items.slice(0, 2)

  useEffect(() => {
    setIsOpen(isDesktop)
  }, [isDesktop])

  const handleClick = () => setIsOpen(!isOpen)

  return (
    <LiveNotificationsContainer>
      <LiveHeader isOpen={isOpen} date={date} onToggleClick={handleClick}></LiveHeader>
      <LiveList items={currentItems} isOpen={isOpen} isMultiple={isMultiple} />
    </LiveNotificationsContainer>
  )
}

LiveNotifications.propTypes = {
  date: string,
  items: array,
}

const itemVariants = {
  on: { height: 'auto', opacity: 1 },
  off: { height: 0, opacity: 0 },
}

const LiveList = ({ items, isMultiple, isOpen }) => {
  const isFirst = useFirstMountState()

  return (
    <LiveListContainer data-testid="LiveNotificationsList">
      <AnimatePresence>
        {isOpen &&
          items.map(({ title, link, linkName }) => (
            <LiveItem initial={isFirst ? false : 'off'} animate="on" exit="off" variants={itemVariants} $isMultiple={isMultiple} key={title} data-testid="LiveNotificationsList__item">
              <LiveInnerItem>
                <LiveItemTitle>{title}</LiveItemTitle>
                <LiveButton url={link?.url} color="white">
                  {linkName}
                </LiveButton>
              </LiveInnerItem>
            </LiveItem>
          ))}
      </AnimatePresence>
    </LiveListContainer>
  )
}

LiveList.propTypes = {
  items: array,
  isMultiple: bool,
  isOpen: bool,
  isFirst: bool,
}

const variants = {
  on: { rotate: -180 },
  off: { rotate: 0 },
}

function LiveHeader({ isOpen, date, onToggleClick }) {
  return (
    <div data-testid="LiveNotificationsHeader">
      <LiveTag onClick={onToggleClick}>
        <LiveIcon>
          <Icon name="IconBroadcast" color={colors.brandRed} width={10} height={10}></Icon>
          <span>LIVE</span>
        </LiveIcon>
        <LiveDate data-testid="LiveNotificationsHeader__date">{date}</LiveDate>
        <ToggleLive initial={false} animate={isOpen ? 'on' : 'off'} variants={variants}>
          <Icon name="IconDown" color="white" width={15} height={15}></Icon>
        </ToggleLive>
      </LiveTag>
    </div>
  )
}

LiveHeader.propTypes = {
  isOpen: bool,
  date: string,
  onToggleClick: func,
}

import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import { Typo30, Typo25 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Button from '@axacom-client/components/atoms/Button/Button'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Container as InnerResponsiveContainer } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'

export const SpotlightHomeContainer = styled.div`
  position: relative;
  height: 750px;

  ${media.tablet`
    height: 800px;
  `}

  ${media.desktopVeryLarge`
    height: 900px;
  `}
`

export const SliderContainer = styled.div`
  background: ${colors.grayDarker};
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  overflow: hidden;
`

export const DotCardsContainer = styled.div`
  display: flex;
  justify-content: center;
  gap: 24px;

  ${media.phone`
    position: absolute;
    bottom: 60px;
    left: 0;
    right: 0;
  `}

  ${media.desktop`
    padding-bottom: 120px;
    bottom: 0;
  `}

  ${media.desktopVeryLarge`
    padding-bottom: 150px;
  `}
`

export const ImageContent = styled.div`
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  min-height: 750px;
  ${({ $src }) => `background-image: url(${$src});`}
  ${media.tablet`min-height: 100%;`}
`

export const ImageWrapper = styled(motion.div)`
  will-change: opacity;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  &:before {
    content: '';
    display: block;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 1;
    background: linear-gradient(
      180deg,
      rgba(255, 255, 255, 0.7) 0%,
      rgba(253, 253, 253, 0.7) 4.57%,
      rgba(246, 246, 246, 0.7) 9.14%,
      rgba(234, 234, 234, 0.7) 13.7%,
      rgba(217, 217, 217, 0.7) 18.27%,
      rgba(196, 196, 196, 0.7) 22.84%,
      rgba(170, 170, 170, 0.7) 27.41%,
      rgba(142, 142, 142, 0.7) 31.98%,
      rgba(113, 113, 113, 0.7) 36.54%,
      rgba(85, 85, 85, 0.7) 41.11%,
      rgba(59, 59, 59, 0.7) 45.68%,
      rgba(38, 38, 38, 0.7) 50.25%,
      rgba(21, 21, 21, 0.7) 54.81%,
      rgba(9, 9, 9, 0.7) 59.38%,
      rgba(2, 2, 2, 0.7) 63.95%,
      rgba(0, 0, 0, 0.7) 68.52%
    );
    mix-blend-mode: multiply;
  }
`

export const Surtitle = styled(motion.h3)`
  ${Typo25}
  font-weight: bold;
  letter-spacing: 0.03rem;
  text-transform: uppercase;
`

export const SliderContentContainer = styled.div`
  height: 100%;

  ${InnerResponsiveContainer} {
    height: 100%;
    display: flex;
    flex-direction: column;

    ${media.desktop`
      justify-content: space-between;
  `}
  }
`

// <Infos />
export const InfosContainer = styled.div`
  margin: 0 30px;
  color: white;
  position: relative;
  padding-top: 150px;

  ${media.tablet`
    padding-top: 80px;
    margin-left: 0;
    margin-right: 0;
    min-height: 450px;
    display: flex;
    align-items: center;
  `}

  ${media.desktop`
    min-height: 500px;
    padding-top: 80px;
    padding-bottom: 80px;
  `}

  ${media.desktopVeryLarge`
    min-height: 610px;
  `}
`

export const InfosTitle = styled(motion.h2)`
  display: block;
  will-change: opacity, transition;
  margin-bottom: 40px;
  ${Typo30}
  max-height: 340px;
  overflow: hidden;

  ${media.desktop`
    max-width: 530px;
    max-height: calc(calc(0.9rem + 3.5vw) * 6); // its basically the current dynamic line-height * 6
  `}

  ${media.desktopLarge`
    max-width: 720px;
  `}

  ${media.desktopVeryLarge`
    max-width: 1240px;
  `}
`

export const InfosSurtitle = styled(Surtitle)`
  display: block;
  will-change: opacity, transition;
  margin-bottom: 10px;
`

export const InfosButton = styled(Button)`
  will-change: opacity;
  transition: opacity 0.2s ease-in;
`

export const DotProgression = styled(motion.div)`
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 3px;
  background: ${colors.brandRed};
  will-change: transform;
  ${media.tablet`
    bottom: inherit;
    top: 0;
    height: 4px;
  `}
`

export const PlayWrapper = styled.div`
  height: 50px;
  width: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  ${({ $isSelected }) => `opacity: ${$isSelected ? `1` : `0`};`}
  ${media.tablet`
    margin-left: 5px;
    justify-content: left;
    width: 30px;
  `}
`

// The play icon is not properly centered so we put a ml to center it
export const StyledIcon = styled(Icon)`
  margin-left: 6px;
  ${media.tablet`margin: 0;`}
`

export const DotInfos = styled.div`
  opacity: 0.6;
  ${({ $isSelected }) => `${$isSelected ? `opacity: 1;` : ''}`}
  transition: opacity 0.2s;
  will-change: color;
  position: relative;
  margin-top: 5px;
  ${media.tablet`margin-top: 0;`}
`

export const DotSurtitle = styled(Surtitle)`
  margin-bottom: 15px;
  display: none;
  ${media.tablet`display: block;`}
`

export const DotTitle = styled.h4`
  letter-spacing: 0.01rem;
  line-height: 1.5rem;
  display: none;
  ${media.tablet`display: block;`}
}`

// Dots
export const DotContainer = styled.div`
  color: white;
  position: relative;
  cursor: pointer;
  ${media.tablet`flex: 1 1 0%;`}
  ${media.desktop`
    &:hover {
      opacity: 1;
      ${PlayWrapper} {
        opacity: 1;
      }
      ${DotInfos} {
        opacity: 1;
      }
    }
  `}
`

export const DotIndictor = styled.div`
  width: 100%;
  height: 3px;
  &:after {
    content: '';
    display: block;
    width: 100%;
    height: 3px;
    background: gray;
    will-change: height;
    transition: height 0.2s;
  }
  will-change: opacity, height;
  transition: opacity 0.2s ease-in, height 0.2s;
  ${media.tablet`
    height: 4px;
    &:after {
      ${({ $isSelected }) => `height: ${$isSelected ? `4px;` : `2px;`};`}
    }
    margin-bottom: 15px;
  `}
`

import { Group, Link, Text, Image } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $spotlightHome: Group(
    {
      image: Image(
        'Image',
        {
          width: 1920,
        },
        [
          {
            name: 'tablet',
            width: 1512,
            height: 850,
          },
          {
            name: 'mobile',
            width: 767,
            height: 700,
          },
        ]
      ),
      surtitle: Text('Surtitle (mandatory)', 'Enter the surtitle'),
      title: Text('Title (mandatory)', 'Enter the title'),
      link: Link('Link (mandatory)'),
    },
    'Spotlight Home (3 to 5 elements max)', // label
    true, // repeat
    'The Spotlight Home', // fieldset
    'The description' // description
  ),
}

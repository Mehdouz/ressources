import React, { useEffect, useState } from 'react'
import { useAnimation } from 'framer-motion/dist/framer-motion'

import { DotContainer, DotIndictor, DotProgression, PlayWrapper, StyledIcon, DotSurtitle, DotTitle, DotInfos } from '@axacom-client/components/organisms/SpotlightHome/SpotlightHome.style'
import useCountDown from '@axacom-client/hooks/useCountDown'
import useFirstMountState from '@axacom-client/hooks/useFirstMountState'
import { mediaQueries } from '@axacom-client/base/style/media'
import { useMediaQuery } from 'react-responsive'
import { number, func, string, bool } from 'prop-types'

const SLIDE_DURATION = 7
const INITIAL_COUNT_DOWN = SLIDE_DURATION * 1000 // ms
const INTERVAL = 100

const variants = {
  initial: { scaleX: 0, transformOrigin: '0%' },
  visible: { scaleX: 1, transition: { duration: SLIDE_DURATION }, transitionEnd: { transformOrigin: '100%' } },
  hidden: { scaleX: 0, transition: { duration: 0.1 }, transitionEnd: { transformOrigin: '0%' } },
}

export default function DotCard({ index, title, surtitle, selected, onSelect, isLastDot }) {
  const [isPaused, setIsPaused] = useState(true)
  const controls = useAnimation()
  const isFirst = useFirstMountState()
  const [timeLeft, { start, pause, resume, reset }] = useCountDown(INITIAL_COUNT_DOWN, INTERVAL)
  const isSelected = index === selected

  const handleClick = () => {
    // change pause state only when selected
    if (isSelected) setIsPaused(!isPaused)
    else onSelect(index)
  }

  // when selected AND paused
  useEffect(() => {
    if (!isFirst && isSelected) {
      if (isPaused) {
        controls.stop()
        pause()
      } else {
        controls.start({ ...variants.visible, transition: { duration: timeLeft / 1000 } })
        resume()
      }
    }
  }, [isPaused])

  // when a slide change
  useEffect(() => {
    if (isSelected) {
      setIsPaused(false)
      controls.start('visible')
      start()
    } else {
      setIsPaused(true)
      controls.start('hidden')
      reset()
    }
  }, [selected])

  // when timer reach 0
  useEffect(() => {
    if (isSelected && !isFirst && timeLeft === 0) onSelect(isLastDot ? 0 : index + 1)
  }, [timeLeft])

  return (
    <DotContainer data-testid="SpotlightHome__item" onMouseUp={handleClick}>
      <IconToggler isSelected={isSelected} isPaused={isPaused}></IconToggler>
      <DotInfos href="/" $isSelected={isSelected}>
        <DotIndictor $isSelected={isSelected} />
        <DotProgression initial="initial" animate={controls} variants={variants} />
        <DotSurtitle>{surtitle}</DotSurtitle>
        <DotTitle>{title}</DotTitle>
      </DotInfos>
    </DotContainer>
  )
}

DotCard.propTypes = {
  index: number,
  title: string,
  surtitle: string,
  selected: number,
  onSelect: func,
  isLastDot: bool,
}

const IconToggler = ({ isSelected, isPaused }) => {
  const isMobile = useMediaQuery({ query: mediaQueries.phone })
  const size = isMobile ? 20 : 15

  return (
    <PlayWrapper $isSelected={isSelected}>
      <StyledIcon name={isPaused ? 'IconPlay' : 'IconPause'} color="white" width={size} height={size}></StyledIcon>
    </PlayWrapper>
  )
}

IconToggler.propTypes = {
  isSelected: bool,
  isPaused: bool,
}

import React from 'react'
import { DotCardsContainer } from '@axacom-client/components/organisms/SpotlightHome/SpotlightHome.style'
import { array, number, func } from 'prop-types'

import dynamic from 'next/dynamic'

const DotCard = dynamic(() => import('./DotCard'), { ssr: false })

export function DotCardList({ items, onSelect, selected }) {
  return (
    <DotCardsContainer data-testid="SpotlightHome__timer">
      {items.map((item, index) => (
        <DotCard key={index} index={index} selected={selected} onSelect={onSelect} isLastDot={items.length - 1 === index} {...item}></DotCard>
      ))}
    </DotCardsContainer>
  )
}

DotCardList.propTypes = {
  items: array,
  selected: number,
  onSelect: func,
}

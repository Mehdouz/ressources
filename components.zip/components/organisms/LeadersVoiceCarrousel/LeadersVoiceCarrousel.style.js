import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo12, Typo9, Typo26 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Button from '@axacom-client/components/atoms/Button/Button'
import Text from '@axacom-client/components/molecules/Text/Text'

export const LeadersVoiceCarrouselContainer = styled.div`
  padding: 65px 0;
  background: ${colors.stories.teal.backgroundDark};
  color: ${colors.white};
  position: relative;

  ${media.tablet`
    padding: 0;
  `}
`

export const Introduction = styled.div`
  margin-bottom: 65px;
  padding: 0 32px;

  ${media.tablet`
    margin: 0;
    padding: 100px 100px 0;
  `}

  ${media.desktop`
    width: 280px;
    padding: 0;
    margin-right: 60px;
    margin-left: 100px;
    align-self: center;
    margin-bottom: 0;
  `}

  ${media.desktopLarge`
    width: 315px;
    margin-right: 100px;
  `}

  ${media.desktopVeryLarge`
    width: 450px;
    margin: 0 185px;
  `}
`

export const ArrowBloc = styled.div`
  display: flex;
  justify-content: center;
  gap: 8px;
`

export const RightArrow = styled.div`
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 1px solid #fff;
  opacity: ${({ isDisabled }) => (isDisabled ? '0.5' : '1')};
`

export const LeftArrow = styled.div`
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 1px solid #fff;
  opacity: ${({ isDisabled }) => (isDisabled ? '0.5' : '1')};
`

export const Carrousel = styled(motion.div)`
  display: flex;
  margin-bottom: 50px;
  cursor: ${({ $isDragging }) => ($isDragging ? 'grabbing' : 'grab')};

  ${media.tablet`
    display: inline-flex;
    padding: 90px 0;
    margin-bottom: 0;
  `}

  ${media.desktop`
    margin: 0;
  `}
`

export const CarrouselContainer = styled.div`
  ${media.tablet`
    display: flex;
    flex-direction: row;
    overflow-x: scroll;
    -ms-overflow-style: none;
    scrollbar-width: none;
    &::-webkit-scrollbar {
      display: none;
    }
  `}
`

export const MainTitle = styled.h2`
  ${Typo12}

  ${media.tablet`
    font-size: 2.5rem;
    line-height: 3rem;
  `}

  ${media.desktop`
    font-size: 2rem;
    line-height: 2.5rem;
  `}

  ${media.desktopVeryLarge`
    font-size: 3rem;
    line-height: 3.5rem;
  `}
`

export const MainText = styled.p`
  ${Typo9};
  font-weight: ${font.weight.regular};

  ${media.desktopVeryLarge`
    font-size: 1.5rem;
  `}
`

export const MainButton = styled(Button)`
  color: ${colors.white};
  margin-top: 40px;
  width: 100%;
  border-width: 1px;

  &:hover {
    color: ${colors.stories.teal.backgroundDark};
  }

  ${media.tablet`
    width: auto;
  `}
`

export const Card = styled.a`
  width: 100%;
  color: ${colors.white};
  flex-shrink: 0;
  padding: 0 32px;
  display: inline-block;
  transition: background-color 0.2s;
  ${({ $isClickable }) =>
    $isClickable
      ? `
    cursor: pointer;
    pointer-events: all;`
      : `
    pointer-events: none;
    user-drag: none;`}

  ${media.tablet`
    width: ${({ hasMultipleLeaders }) => (hasMultipleLeaders ? '435px' : '290px')};
    margin-right: 25px;
    padding: 0;

    &:nth-child(1){
      margin-left: 100px;
    }
  `}

  ${media.desktop`
    margin-right: 25px;

    &:nth-child(2){
      margin-left: 0;
    }
  `}
`

export const CardIntro = styled.div`
  min-height: 90px;
  margin-bottom: 25px;
`

export const LeadersName = styled.p`
  margin-bottom: 8px;
  color: ${colors.white};
  ${Typo9};
  font-weight: ${font.weight.bold};

  ${media.desktopVeryLarge`
    line-height: 1.75rem;
  `}
`

export const LeadersRole = styled(Text)`
  ${Typo26}
  color: #80A3A7;
`

export const ArticleTitle = styled.p`
  color: ${colors.white};
  ${Typo9}

  ${media.desktopVeryLarge`
    font-size: 1.5rem;
    line-height: 1.75rem;
  `}
`

export const RoleImage = styled.img`
  width: 100%;
  margin-bottom: 25px;

  ${media.tablet`
    width: auto;
  `};
`

export const OverlayGrab = styled(motion.div)`
  display: flex;
  opacity: ${({ inView }) => (inView ? '1' : '0')};
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.7);
  top: 0;
  left: 0;
  position: absolute;
  z-index: 200;
  transition: opacity 0.3s ease;
`

export const TitleOverlay = styled.p`
  color: ${colors.white};
  font-size: 23px;
  font-weight: 600;
`

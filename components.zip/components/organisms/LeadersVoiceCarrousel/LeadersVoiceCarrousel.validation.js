import { isFieldFulfilled } from '../../utils/FieldValidation'

export default [
  (document) => {
    return document.leadersVoiceLeader.length >= 4
  },
  (document) => {
    return document.leadersVoiceTitle !== undefined
  },
  (document) => {
    return document.leadersVoiceText !== undefined
  },
  (document) => {
    const mandatoryFields = ['leaderName', 'leaderRoleRichText', 'articleTitle', 'articleLink']

    return document.leadersVoiceLeader.every((leader) => mandatoryFields.every((field) => isFieldFulfilled(leader[field])))
  },
]

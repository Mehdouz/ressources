import React, { useState, useRef, useEffect } from 'react'
import { array, string, object, number, func, bool } from 'prop-types'
import { AnimatePresence } from 'framer-motion/dist/framer-motion'
import { useCookies } from 'react-cookie'
import { useInView } from 'react-intersection-observer'

import { mediaQueries } from '@axacom-client/base/style/media'
import { colors, media } from '@axacom-client/base/style/variables'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'
import useLinkTarget from '@axacom-client/hooks/useLinkTarget'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { getTimeInMs } from '@axacom-client/services/date-service'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

import {
  LeadersVoiceCarrouselContainer,
  Introduction,
  Carrousel,
  CarrouselContainer,
  MainTitle,
  MainText,
  MainButton,
  CardIntro,
  ArrowBloc,
  LeftArrow,
  RightArrow,
  Card,
  RoleImage,
  LeadersName,
  LeadersRole,
  ArticleTitle,
  OverlayGrab,
  TitleOverlay,
} from './LeadersVoiceCarrousel.style'

function LeadersVoiceCarrousel({ leadersVoiceTitle, leadersVoiceText, leadersVoiceLink, leadersVoiceLinkName, leadersVoiceLeader }) {
  const [translateValue, setTranslateValue] = useState(0)
  const [isDraggable, setIsDraggable] = useState(true)
  const [isDragging, setIsDragging] = useState(false)
  const [cookies, setCookie] = useCookies([])
  const [hideOverlay, setHideOverlay] = useState(true)

  const leaders = leadersVoiceLeader.slice(0, 8)
  const carrouselRef = useRef(null)
  const { ref, inView } = useInView({ rootMargin: '0px', threshold: 0.7 })

  const isDesktop = useBetterMediaQueries({ query: mediaQueries.desktop }, false)
  const isTabletOrDesktop = useBetterMediaQueries({ query: mediaQueries.tablet }, true)

  useEffect(() => {
    setHideOverlay(() => cookies.hideOverlay)
  }, [])

  function overlayHandleClick() {
    const expires = new Date()
    expires.setTime(expires.getTime() + getTimeInMs().withDays(183))
    setCookie('hideOverlay', 'ok')
    setHideOverlay(true)
  }

  function toggleClick() {
    setIsDraggable(!isDraggable)
  }

  function toggleCursor() {
    setIsDragging(!isDragging)
  }

  return (
    <LeadersVoiceCarrouselContainer data-testid="LeadersVoiceCarrousel__Container" ref={ref}>
      <AnimatePresence>{!hideOverlay && isTabletOrDesktop && <Overlay exit={{ opacity: 0 }} transition={{ duration: 0.3 }} onClick={overlayHandleClick} inView={inView} />}</AnimatePresence>
      {!isDesktop && <IntroductionBloc leadersVoiceTitle={leadersVoiceTitle} leadersVoiceText={leadersVoiceText} leadersVoiceLink={leadersVoiceLink} leadersVoiceLinkName={leadersVoiceLinkName} />}
      <CarrouselContainer ref={carrouselRef}>
        {isTabletOrDesktop ? (
          <Carrousel drag="x" dragConstraints={carrouselRef} onDragStart={toggleClick} onDragEnd={toggleClick} onMouseDown={toggleCursor} onMouseUp={toggleCursor} $isDragging={isDragging}>
            {isDesktop && (
              <IntroductionBloc leadersVoiceTitle={leadersVoiceTitle} leadersVoiceText={leadersVoiceText} leadersVoiceLink={leadersVoiceLink} leadersVoiceLinkName={leadersVoiceLinkName} />
            )}
            {leaders && leaders.map((leader, index) => <LeadersCard key={index} isClickable={isDraggable} {...leader} />)}
          </Carrousel>
        ) : (
          <Carrousel animate={{ x: `${translateValue}%` }} transition={{ type: 'spring', duration: 0.6 }}>
            {leaders && leaders.map((leader, index) => <LeadersCard key={index} isClickable={isDraggable} {...leader} />)}
          </Carrousel>
        )}
      </CarrouselContainer>
      {!isTabletOrDesktop && <MobileNavigation leaders={leaders} translateValue={translateValue} setTranslateValue={setTranslateValue} />}
    </LeadersVoiceCarrouselContainer>
  )
}

function Overlay(props) {
  const { i18n } = useGlobalContext()

  return (
    <OverlayGrab {...props}>
      <TitleOverlay>{i18n.t('overlayLeadersCarrousel')}</TitleOverlay>
      <img src="/base/images/grab.gif" alt="grab" />
      <Icon name="IconArrows" color={colors.white} width={80} height={50} />
    </OverlayGrab>
  )
}

function MobileNavigation({ leaders, translateValue, setTranslateValue }) {
  const [currentIndex, setCurrentIndex] = useState(1)

  function handlePrev() {
    if (currentIndex > 1) {
      setCurrentIndex(currentIndex - 1)
      setTranslateValue(translateValue + 100)
    }
  }

  function handleNext() {
    if (currentIndex < leaders.length) {
      setCurrentIndex(currentIndex + 1)
      setTranslateValue(translateValue - 100)
    }
  }

  return (
    <ArrowBloc>
      <LeftArrow isDisabled={currentIndex === 1} onClick={handlePrev} data-testid="LeadersVoiceCarrousel__LeftArrow">
        <Icon name="IconLeftArrow" width={6} height={8} color={colors.white} />
      </LeftArrow>
      <RightArrow isDisabled={currentIndex === leaders.length} onClick={handleNext} data-testid="LeadersVoiceCarrousel__RightArrow">
        <Icon name="IconRightArrow" width={6} height={8} color={colors.white} />
      </RightArrow>
    </ArrowBloc>
  )
}

function IntroductionBloc({ className, leadersVoiceTitle, leadersVoiceText, leadersVoiceLink, leadersVoiceLinkName }) {
  return (
    <Introduction className={className}>
      <MainTitle data-testid="LeadersVoiceCarrousel__Title">{leadersVoiceTitle}</MainTitle>
      <MainText data-testid="LeadersVoiceCarrousel__IntroText">{leadersVoiceText}</MainText>
      <MainButton data-testid="LeadersVoiceCarrousel__Button" href={leadersVoiceLink?.url} color="white" type="ghost">
        {leadersVoiceLinkName}
      </MainButton>
    </Introduction>
  )
}

function LeadersCard({ leaderName: name, leaderRoleRichText: role, articleTitle: title, multipleLeaders, articleLink, doubleImage, singleImage, isClickable }) {
  const image = multipleLeaders === 'Yes' ? doubleImage : singleImage
  const hasMultipleLeaders = multipleLeaders === 'Yes' ? true : false
  const target = useLinkTarget(articleLink.url)

  return (
    <Card href={articleLink?.url} target={target} hasMultipleLeaders={hasMultipleLeaders} $isClickable={isClickable} draggable={false}>
      <CardIntro>
        <LeadersName data-testid="LeadersVoiceCarrousel__Leader_Name">{name}</LeadersName>
        <LeadersRole data-testid="LeadersVoiceCarrousel__Leader_Role">{role}</LeadersRole>
      </CardIntro>
      <picture>
        <source media={`(max-width: ${media.phoneMax}px)`} srcSet={image.views.mobile.url} />
        <source media={`(max-width: ${media.desktopMax}px)`} srcSet={image.views.desktop.url} />
        <source media={`(min-width: ${media.desktopXLMin}px)`} srcSet={image.main.url} />

        <RoleImage data-testid="LeadersVoiceCarrousel__Leader_Image" src={image.main.url} alt={image?.main?.alt} draggable={false} />
      </picture>
      <ArticleTitle data-testid="LeadersVoiceCarrousel__Article_Title">{title}</ArticleTitle>
    </Card>
  )
}

IntroductionBloc.propTypes = {
  className: string,
  leadersVoiceTitle: string,
  leadersVoiceText: string,
  leadersVoiceLink: object,
  leadersVoiceLinkName: string,
}

LeadersCard.propTypes = {
  leaderName: string,
  leaderRole: string,
  leaderRoleRichText: array,
  articleTitle: string,
  multipleLeaders: string,
  articleLink: object,
  doubleImage: object,
  singleImage: object,
  isClickable: bool,
}

MobileNavigation.propTypes = {
  leaders: array,
  translateValue: number,
  setTranslateValue: func,
}

LeadersVoiceCarrousel.propTypes = {
  leadersVoiceTitle: string,
  leadersVoiceText: string,
  leadersVoiceLink: object,
  leadersVoiceLinkName: string,
  leadersVoiceLeader: array,
}

export default LeadersVoiceCarrousel

import { Group, Link, Text, Image, Select, StructuredText } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $leadersVoiceTitle: Text('Title (Mandatory)'),
  $leadersVoiceText: Text('Text (Mandatory)'),
  $leadersVoiceLinkName: Text('Link Name'),
  $leadersVoiceLink: Link('Link'),
  $leadersVoiceLeader: Group(
    {
      multipleLeaders: Select(['No', 'Yes'], 'Multiple Leaders', 'Yes or no', 'No'),
      singleImage: Image('Single Leader Image (290x360px)', { width: 290, height: 360 }, [
        {
          name: 'desktop',
          width: 280,
          height: 335,
        },
        {
          name: 'mobile',
          width: 310,
          height: 380,
        },
      ]),
      doubleImage: Image('Double Leader Image (435x360px)', { width: 435, height: 360 }, [
        {
          name: 'desktop',
          width: 435,
          height: 335,
        },
        {
          name: 'mobile',
          width: 310,
          height: 380,
        },
      ]),
      leaderName: Text("Leader's Name (Mandatory)"),
      leaderRoleRichText: StructuredText("Leader's Role (Mandatory)", 'Add the role', { multi: 'paragraph' }),
      articleTitle: Text('Article Title (Mandatory)'),
      articleLink: Link('Article Link (Mandatory)'),
    },
    'Leaders',
    true
  ),
}

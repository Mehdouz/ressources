import React from 'react'
import styled from 'styled-components'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

import { Typo17 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { font } from '@axacom-client/base/style/variables'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

const Wrapper = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  margin-bottom: 50px;

  ${media.desktopLarge`
    margin-bottom: 80px;
  `}
`

const Title = styled.h2`
  ${Typo17}
  text-transform: uppercase;
  margin-right: 10px;
  margin-bottom: 0px;

  ${media.desktop`
    font-size: 13px;
    letter-spacing: 0.008rem;
  `}
`

const Theme = styled(SmartLink)`
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.1em;
  line-height: 1.5rem;

  ${media.tablet`
    position: relative;
    margin-right: 25px;
  `}
`

export default function ArticleTheme({ theme }) {
  const { domain, i18n } = useGlobalContext()
  const href = theme?.linkTopicPage?.url ? theme?.linkTopicPage?.url : domain + theme?.url

  return (
    <Slice className="p-0" fluid data-testid="ArticleTheme">
      <ResponsiveContainer mobile>
        <CenteredReadingContainer>
          <Wrapper>
            <Title>{i18n.t('articleTags.tag')}</Title>
            <Theme href={href}>{theme?.metaContent?.[0]?.title}</Theme>
          </Wrapper>
        </CenteredReadingContainer>
      </ResponsiveContainer>
    </Slice>
  )
}

import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import Button from '@axacom-client/components/atoms/Button/Button'

export const ItemContainer = styled.div`
  width: 100%;
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
  max-width: 540px;

  ${media.tablet`
    max-width: 620px;
 `}
  ${media.desktopLarge`
    max-width: 750px;
  `}
`

export const Breadcrumb = styled.div`
  display: flex;
  flex-direction: column;

  ${media.tablet`
    flex-direction: row;
    margin-bottom: 40px;
  `}
`

export const Backlink = styled(Button)`
  display: flex;
  flex-direction: row;
  font-family: ${font.fontFamilyBase};
  font-weight: 700;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.1em;
  line-height: 30px;
  vertical-align: middle;
  transition: color 0.3s linear;
  justify-content: left;
`

export const Topic = styled.div`
  display: block;
  font-family: ${font.fontFamilyBase};
  font-weight: 400;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 30px;
  color: ${colors.grayDark};

  ${media.tablet`
    &:before {
        margin: 0 10px;
        content: ' | ';
      }
  `}
`

export const InfoContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin: 40px 15px;

  ${media.tablet`
    display: block;
    flex-direction: none;
    margin-bottom: ${({ $hasSlices }) => ($hasSlices ? '0px' : '75px')}
  `}

  ${media.desktop`
    margin-bottom: ${({ $hasSlices }) => ($hasSlices ? '0px' : '100px')}
  `}

  ${media.desktopLarge`
    margin-bottom: ${({ $hasSlices }) => ($hasSlices ? '0px' : '150px')}
  `}
`

export const CoverContainer = styled.div`
  vertical-align: middle;
  box-shadow: 4px 4px 0px #eee;
  margin-right: auto;
  margin-left: auto;
  display: block;
  width: 200px;
  max-width: none;
  margin-top: 40px;
  order: 1;

  ${media.tablet`
    margin-top: 0;
    float: left;
  `}
`

export const Title = styled.h1`
  text-align: left;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 28px;
  line-height: 31px;
  letter-spacing: 0.015em;
  margin-top: 40px;
  margin-bottom: 0px;
  display: block;
  text-align: center;
  order: 0;

  ${media.tablet`
    font-size: 36px;
    line-height: 40px;
    text-align: left;
    margin-left: 260px;
    width: inherit;
    margin-top: 0;
  `}

  ${media.desktopLarge`
    font-size: 48px;
    line-height: 50px;
  `}
`

export const ButtonContainer = styled.div`
  text-align: left;
  display: flex;
  flex-direction: column;
  min-height: 80px;
  order: 3;

  ${media.tablet`
    all: unset;
    display: flex;
    margin-left: 260px;
    min-height: 80px;
    flex-direction: row;
  `}
`

export const DownloadButton = styled(Button)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  font-size: 14px;
  margin-top: 30px;
  letter-spacing: 1px;
  height: 66%;
  display: block;
  border-bottom: none;

  :after {
    background: #ec4d33;
  }

  ${media.tablet`
    height: 50px;
    flex: 0 0 auto;
    padding: 0 30px;
    margin-right: 20px;
  `}
`

export const LinkButton = styled(Button)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  font-size: 14px;
  /* line-height: 16px; */
  margin-top: 30px;
  letter-spacing: 1px;
  height: 66%;
  border: 3px solid #f07662;
  color: #f07662;
  background-color: transparent;
  padding: 0 30px;
  display: block;

  :after {
    background: #f07662;
    content: '';
    position: absolute;
    z-index: -1;
    transition: width 0.3s, opacity 0.3s;
    width: 0;
    height: 530px;
    top: 50%;
    left: 50%;
    opacity: 0;
    transform: translate3d(-50%, -50%, 0) rotate(45deg);
    backface-visibility: hidden;
  }

  ${media.tablet`
    height: 50px;
    flex: 0 0 auto;
    padding: 0 30px;
    margin-right: 20px;
  `}
`

export const DownloadButtonLabel = styled.span`
  display: block;
`

export const LinkButtonLabel = styled.span`
  display: block;
`

export const MetadataContainer = styled.div`
  text-align: left;
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  margin-left: auto;
  margin-right: auto;
  width: 200px;
  order: 2;

  ${media.tablet`
    margin-left: 260px;
    width: inherit;
    margin-right: auto;
  `}
`

export const MetadataTypeSize = styled.span`
  color: #757575;
  font-family: ${font.fontFamilyBase};
  font-weight: 400;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;

  ${media.tablet`
    font-size: 12px;
  `}
`

export const MetadataTitle = styled.span`
  text-transform: uppercase;
  font-family: ${font.fontFamilyBase};
  font-weight: 400;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;

  ${media.tablet`
    font-size: 13px;
  `}
`

export const MetadataDate = styled.span`
  font-family: ${font.fontFamilyBase};
  font-weight: 400;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;

  ${media.tablet`
    font-size: 13px;
  `}
`

export const Clear = styled.div`
  clear: both;
`

import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { bytesToSize } from '@axacom-client/services/string-service'
import {
  ItemContainer,
  Breadcrumb,
  Backlink,
  Topic,
  InfoContainer,
  CoverContainer,
  Title,
  ButtonContainer,
  DownloadButton,
  LinkButton,
  LinkButtonLabel,
  DownloadButtonLabel,
  MetadataTypeSize,
  MetadataTitle,
  MetadataContainer,
  MetadataDate,
  Clear,
} from './PublicationBody.style'
import { getDateWithMonthAsStringComma } from '@axacom-client/services/date-service'

const PublicationBody = ({ title, cover, document, documentTitle, topic, date, webLink, nameLink, $hasSlices }) => {
  const { i18n, currentLocale, bookmarks } = useGlobalContext()

  return (
    <ItemContainer data-testid="PublicationBody__Container">
      {document && (
        <InfoContainer $hasSlices={$hasSlices}>
          <Breadcrumb data-testid="PublicationBody__Breadcrumb">
            <Backlink
              url={bookmarks?.repositoryPublication?.url}
              type="link"
              color="red"
              iconLeft="IconArrowLeft"
              data-testid="PublicationBody__ButtonFile"
              data-analytics='{"block_name":"publications::view_all"}'
            >{`${i18n.t('publication.viewAllPublications') ? i18n.t('publication.viewAllPublications') : 'View all publications'}`}</Backlink>
            <Topic>{topic?.title}</Topic>
          </Breadcrumb>
          {cover && <CoverContainer data-testid="PublicationBody__CoverContainer">{cover?.main?.url && <img data-testid="PublicationBody__Cover" src={cover.main.url} alt={title} />}</CoverContainer>}
          {title && <Title data-testid="PublicationBody__Title">{title}</Title>}
          <ButtonContainer>
            {document.target === 'file' && (
              <DownloadButton
                href={document.url}
                ariaLabel={
                  document.target === 'file'
                    ? `${i18n.t('investorPublications.download') ? i18n.t('investorPublications.download') : 'Download PDF'}, ${title}`
                    : `${i18n.t('publication.more') ? i18n.t('publication.more') : 'View more'}}, ${title}`
                }
                color="red"
                data-testid="PublicationBody__ButtonLink"
              >
                <DownloadButtonLabel data-testid="PublicationBody__ButtonFileContentLabel">
                  {i18n.t('investorPublications.download') ? i18n.t('investorPublications.download') : 'Download PDF'}
                </DownloadButtonLabel>
              </DownloadButton>
            )}
            {webLink?.url && nameLink && (
              <LinkButton
                href={webLink?.url}
                color="red"
                type="ghost"
                target="_blank"
                data-testid="PublicationBody__ButtonLink"
                data-analytics='{"block_name":"AXACOM-Publication_accessible_version", "event_type":"Click_on_the_accessible_version", "label":"{{ title }}"}'
              >
                <LinkButtonLabel data-testid="PublicationBody__LinkButtonLabel">{nameLink}</LinkButtonLabel>
              </LinkButton>
            )}
          </ButtonContainer>
          <MetadataContainer>
            <MetadataTitle data-testid="PublicationBody__DocumentTitle">{documentTitle}</MetadataTitle>
            <MetadataTypeSize data-testid="PublicationBody__TypeSize">PDF {bytesToSize(document.file.size, currentLocale)}</MetadataTypeSize>
            <MetadataDate data-testid="PublicationBody__Date">{getDateWithMonthAsStringComma(date, currentLocale)}</MetadataDate>
          </MetadataContainer>
          <Clear />
        </InfoContainer>
      )}
    </ItemContainer>
  )
}

export default PublicationBody

import { Button } from '../../atoms/Button/Button.types'
import { Select, Text } from '../../../../tools/prismic/backup-types/generic-type'

export const bgColor = ['white', 'gray', 'blue']

export default {
  anchorId: Text('Anchor ID', 'my-anchor-id'),
  bgColor: Select(bgColor, 'Select a background color (default: white)', undefined, 'white'),
  title: Text('Slice title'),
  subtitle: {
    type: 'StructuredText',
    config: {
      label: 'Subtitle',
      placeholder: 'Select a subtitle',
    },
  },
  ...Button('Slice button'),
}

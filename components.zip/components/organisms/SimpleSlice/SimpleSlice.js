import React from 'react'
import { bool, node, string } from 'prop-types'
import slugify from 'slugify'
import styled from 'styled-components'
import Text from '@axacom-client/components/molecules/Text/Text'
import { Typo18, Typo36 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'

export function Slice({ slugifiedAnchor, bgColor, dataTestid, overflow = false, children, ...rest }) {
  return (
    <Wrapper id={slugifiedAnchor && slugify(slugifiedAnchor)} bgColor={bgColor} $overflow={overflow} data-testid={dataTestid || 'SimpleSlice'} {...rest}>
      <Body>{children}</Body>
    </Wrapper>
  )
}

Slice.propTypes = {
  className: string,
  slugifiedAnchor: string,
  bgColor: string,
  dataTestid: string,
  noPaddings: bool,
  overflow: bool,
  children: node,
}

export const SliceSubtitle = styled(Text)`
  ${Typo18};
  width: 100%;
  ${({ $textAlign }) => ($textAlign ? `text-align: ${$textAlign};` : '')}
  white-space: pre-wrap;

  padding: 0 24px;
  margin-bottom: 32px;

  ${media.tablet`
    margin-bottom: 48px;
  `}

  ${media.desktopVeryLarge`
    margin-bottom: 64px;
  `}
`

export const SliceTitle = styled.h2`
  ${Typo36}
  ${({ $textAlign }) => ($textAlign ? `text-align: ${$textAlign};` : '')}

  width: 100%;
  padding: 0 24px;
  margin-bottom: 32px;
`

const backgroundHexadecimal = (bg) => {
  switch (bg) {
    case 'gray':
      return colors.wildSand
    case 'blue':
      return colors.brandBlue
    case 'white':
      return colors.white
    default:
      return colors.bodyBg
  }
}

const Wrapper = styled.div`
  text-align: center;
  padding-top: 32px;
  padding-bottom: 32px;
  background-color: ${(props) => backgroundHexadecimal(props.bgColor)};
  color: ${(props) => (props.bgColor === 'blue' ? colors.white : colors.textColor)};
  overflow: ${(props) => (props.$overflow ? 'visible' : 'hidden')};
  ${media.tablet`
    padding-top: 48px;
    padding-bottom: 48px;
  `}

  ${media.desktopVeryLarge`
    padding-top: 64px;
    padding-bottom: 64px;
  `}
`

const Body = styled.div`
  text-align: left;
`

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Typo43 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: ${colors.grey100};

  ${media.tablet`
    max-width: 100vw;
    margin: 50px auto;
    height: 20vh;
  `}
`

export const StyledErrorText = styled.p`
  margin: 0 auto;
  color: ${colors.errorRed};
  text-align: center;
  ${Typo43}
`

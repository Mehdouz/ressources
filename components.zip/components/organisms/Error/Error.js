import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Container, StyledErrorText } from '@axacom-client/components/organisms/Error/Error.style'
import { any, string } from 'prop-types'
import { ErrorBoundary } from 'react-error-boundary'

export function RequirementsErrorMessage() {
  const { currentLocale } = useGlobalContext()
  const isFrench = currentLocale === 'fr' ? true : false

  const errorMessage = {
    fr: 'Erreur, veuillez vérifier que tous les champs obligatoires sont bien remplis',
    en: 'Something went wrong. Please check that all mandatory fields have been filled in',
  }

  return (
    <Container>
      <img className="p-5" src="/base/images/space_invader_yellow.png" alt="error" />
      <StyledErrorText>{isFrench ? errorMessage.fr : errorMessage.en}</StyledErrorText>
    </Container>
  )
}

export function ErrorMessage({ message }) {
  const { env } = useGlobalContext()
  if (env === 'production') return ''
  return (
    <Container>
      <pre className="m-0">{message}</pre>
    </Container>
  )
}

ErrorMessage.propTypes = {
  message: string,
}

export function ErrorSliceBoundary({ sliceType, children, ...rest }) {
  const message = `Error when rendering the slice: "${sliceType}". Check the console for more info`
  return (
    <ErrorBoundary {...rest} fallback={<ErrorMessage message={message} />}>
      {children}
    </ErrorBoundary>
  )
}

ErrorSliceBoundary.propTypes = {
  sliceType: string,
  children: any,
}

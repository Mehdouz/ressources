import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo12, Typo7 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const StickyHeaderContainer = styled(motion.div)`
  position: fixed;
  display: block;
  background-color: ${colors.white};
  top: 0;
  left: 0;
  width: 100%;
  z-index: 50;
`

export const Content = styled.div`
  display: flex;
  align-items: center;
  flex-direction: row;
  padding: 20px 80px 20px 40px;

  ${media.tablet`
    padding: 10px 80px 10px 20px;
  `}
`

export const LeftContent = styled.div`
  display: flex;
  align-items: center;
  flex-direction: row;
  width: 100%;
`

export const Share = styled.div`
  display: flex;
  align-items: center;
  position: absolute;
  right: 0;
  top: 0;
  flex-direction: column;
  z-index: 100;
`

export const LogoWrapper = styled.div`
  width: 48px;
  height: 48px;
  display: block;
`

export const Title = styled.h2`
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 0;
  ${Typo7}
  font-weight: ${font.weight.regular};
  text-align: center;

  ${media.tablet`
    font-size: 18px;
    line-height: 20px;
    margin-left: 20px;
    padding: 0 30px;
  `}

  ${media.desktop`
    ${Typo12}
  `}

  ${media.desktopLarge`
    padding: 0 10%;

  `}

  ${media.desktopVeryLarge`
    margin-left:0;
    text-align: center;
  `}
`

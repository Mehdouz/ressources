import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo12, Typo25, Typo27, Typo31, Typo32 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'
import media from '@axacom-client/base/style/media'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export const HeaderWrapper = styled.div`
  width: 100%;
  margin: 0;
  display: flex;
  flex-direction: column;
  position: relative;
  z-index: 20;
`

export const HeaderContainer = styled.div`
  padding: 20px 25px;
  display: flex;
  flex-direction: row;
  position: relative;
  background-color: ${colors.white};
  z-index: 30;
`

export const MenuContainer = styled(motion.div)`
  width: 100%;
  height: auto;
  display: flex;
  flex-direction: ${({ isRightMenu }) => (isRightMenu ? 'column' : 'row')};
  padding-top: ${({ isRightMenu }) => (isRightMenu ? '40px' : '0')};
  position: absolute;
  background-color: ${({ $backgroundColor }) => $backgroundColor};
  transition: background-color 10s;
  will-change: background-color;
  color: ${colors.white};
  overflow: hidden;
  top: 80px;
  z-index: 20;
`

export const Underline = styled(motion.div)`
  width: 100%;
  height: 3px;
  left: 0;
  bottom: -34px;
  background: ${colors.sienna400};
  position: absolute;
`

export const RightSubmenuContainer = styled(motion.div)`
  display: flex;
  height: auto;
  height: 100%;
  position: relative;
`

export const RightContainer = styled(motion.div)`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: auto;
  position: relative;
`

export const BottomContainer = styled(motion.div)`
  display: flex;
  width: 100%;
  flex-direction: column;
  position: relative;
  padding: 25px;
  gap: 25px;
  height: auto;
  background-color: ${({ $backgroundColor }) => $backgroundColor};
  z-index: 30;

  ${media.tablet`
    flex-direction: row;
    justify-content: center;
    align-items: center;
  `}

  ${media.desktop`
    justify-content: center;
  `}
`

export const BottomButton = styled(SmartLink)`
  padding: 10px 35px;
  border: 1px solid #fff;
  color: ${colors.white};
  text-transform: uppercase;
  position: relative;
  display: flex;
  gap: 8px;
  align-items: center;
  z-index: 10;
  transition: background 0.3s;
  will-change: background;

  ${Typo27};

  &:focus {
    color: ${colors.white};
  }

  &:hover {
    color: ${({ $hoverColor }) => $hoverColor};
    background: ${colors.white};

    & svg {
      fill: ${({ $hoverColor }) => $hoverColor};
    }
  }

  ${media.phone`
    justify-content: center;
  `}
`

export const RightMenuButton = styled.div`
  display: flex;
  flex-direction: row;
  width: 100%;
  position: relative;
  height: 30px;
`

export const LeftSubmenuContainer = styled.div`
  width: 34%;
  padding: 40px 50px;
`

export const RightSubmenuBackground = styled.div`
  width: 100%;
  position: absolute;
  height: 100%;
  top: 0;
  left: 0;
  z-index: 0;
  display: block;
  background-color: ${({ $backgroundColor }) => $backgroundColor};
  transition: background-color 10s;
  will-change: background-color;
`

export const ThirdLevelBackground = styled(motion.div)`
  width: 100%;
  position: absolute;
  height: 100%;
  top: 0;
  left: 0;
  z-index: 0;
  display: block;
  background-color: ${({ $backgroundColor }) => $backgroundColor};
  transition: background-color 10s;
  will-change: background-color;
`

export const LogoLink = styled.a``

export const MainMenuContainer = styled.ul`
  list-style-type: none;
  display: flex;
  flex-direction: row;
  width: 100%;
  align-items: center;
  padding: 0;
  margin-left: 35px;
  margin-bottom: 0;
  line-height: 18px;

  &:after {
    content: '';
    flex-grow: 1;
    order: 0;
  }
`

export const MainMenuItemButton = styled.button`
  text-transform: none !important;
  text-decoration: none !important;
  background: transparent;
  border: 0;
  display: block;
  padding: 0;

  color: ${({ $isSelected }) => ($isSelected ? colors.sienna400 : colors.AXABlue)};
  ${({ $isRightMenu }) =>
    $isRightMenu
      ? `
        font-size: 14px;
        font-weight: ${font.weight.regular};
        `
      : `
        font-size: 16px;
        font-weight: ${font.weight.semiBold};
  `}
  cursor: pointer;

  &:hover,
  &:focus {
    outline: 0;
  }
`

export const MainMenuItemLink = styled(SmartLink)`
  background: transparent;
  border: 0;
  display: block;

  color: ${({ $isSelected }) => ($isSelected ? colors.sienna400 : colors.AXABlue)};
  ${({ $isRightMenu }) =>
    $isRightMenu
      ? `
        font-size: 14px;
        font-weight: ${font.weight.regular};
        `
      : `
        font-size: 16px;
        font-weight: ${font.weight.semiBold};
  `}
  cursor: pointer;

  &:hover {
    color: ${colors.AXABlue};
    outline: 0;
  }

  &:focus {
    color: ${colors.sienna400};
    outline: 0;
  }
`

export const MainMenuItem = styled.li`
  position: relative;
  order: ${({ $isRightMenu }) => ($isRightMenu ? '1' : '0')};
  margin-right: 30px;

  ${({ $isRightMenu }) =>
    $isRightMenu
      ? `
        order: 1;
        border-right: 1px;
        &:after {
            content: '';
            height: 12px;
            position: absolute;
            width: 1px;
            right: -16px;
            top: 5px;
            background: #E5E5E5;
        }
        &:last-child {
          margin-right: 40px;
          &:after {
            content: '';
            height: 24px;
            position: absolute;
            width: 1px;
            right: -20px;
            top: -1px;
            background: #CCCCCC;
        }
      }

        `
      : `
        order:0;
  `}

  ${media.desktopLarge`
    margin-right: 50px;

    ${({ $isRightMenu }) =>
      $isRightMenu &&
      `
        &:after {
            right: -26px;
            top: 5px;
        }
        &:last-child {
          margin-right: 50px;
          &:after {
            right: -27px;
        }
      }
  `}
  `}
`

export const SubMenuContainer = styled(motion.div)`
  position: relative;
  display: block;
  z-index: 20;

  ${({ menuLevel }) => {
    if (menuLevel === 2)
      return `
        width: 45%;
      `
    if (menuLevel === 3)
      return `
        width: 55%;
      `
  }}
`

export const SubMenuList = styled(motion.ul)`
  list-style: none;
  margin: 0;
  padding: 0;
  position: relative;
  z-index: 20;
  display: block;
  flex: 2;
`

export const HighLightContainer = styled(motion.div)`
  position: relative;
  height: auto;
  z-index: 20;
`

export const HighLightInner = styled(motion.div)`
  padding: ${({ $isRightMenu }) => ($isRightMenu ? '24px 0px 30px 0px' : '40px 80px')};
  max-width: ${({ $isRightMenu }) => ($isRightMenu ? 'none' : '850px')};
`

export const HighLightTitle = styled(motion.h3)`
  text-transform: uppercase;
  ${Typo27};
`

export const HighLightTitleLine = styled(motion.div)`
  width: 100%;
  height: 1px;
  background: ${colors.white};
  display: block;
  position: relative;
  margin-top: 8px;
  margin-bottom: 25px;
  opacity: 0.2;
`

export const HighLightItemBlock = styled(SmartLink)`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  width: 100%;

  &:not(:last-child) {
    margin-bottom: 30px;
  }

  ${({ $isRightMenu }) =>
    $isRightMenu &&
    `
      width: calc(50% - 45px);
    `}

  ${media.tablet`
    ${({ $isRightMenu }) =>
      $isRightMenu &&
      `
        &:not(:last-child) {
          margin-bottom: 0px;
        }

        &:last-child {
          margin-left: 5px;
        }
    `}
  `}
`

export const HighLightItemImage = styled(motion.img)`
  width: 180px;
  object-fit: scale-down;
`

export const HighLightItemContent = styled.div`
  margin-left: 25px;
`

export const HighLightItemSurtitle = styled(motion.p)`
  margin-bottom: 10px;
  text-transform: uppercase;
  color: #ffffff;
  opacity: 0.5;
  ${Typo25};
`

export const HighLightItemTitle = styled(motion.h4)`
  ${Typo32};
  color: ${colors.white};
`

export const HighLightItemLink = styled(SmartLink)`
  color: ${colors.white};
  text-decoration: underline;
  display: block;
  ${Typo25};

  &:hover,
  &:focus {
    color: ${colors.white};
  }
`

export const SearchContainer = styled.div`
  display: flex;
  width: 30px;
  justify-content: space-between;
`

export const SearchInput = styled(motion.input)`
  ${Typo32}
  position: absolute;
  padding-left: 10px;
  width: 50%;
  height: 41px;
  color: ${colors.grey600};
  border: 1px solid ${colors.grayLight};
  font-weight: ${font.weight.regular};
  top: 22px;
  right: 77px;
  z-index: 40;

  &::-webkit-search-cancel-button {
    display: none;
  }

  &::placeholder {
    color: ${colors.grey400};
  }
`

export const SearchButton = styled.button`
  position: absolute;
  right: 25px;
  cursor: pointer;
  top: 22px;
  order: 1;
  padding: 8px;
  margin-left: -10px;
  background-color: ${({ $searchIsOpen }) => ($searchIsOpen ? colors.AXABlue : colors.white)};
  line-height: 18px;
  border: 0;
  outline: 0;

  &:hover,
  &:focus {
    & svg {
      transform: scale(1.15);
      transition: transform 200ms ease-out;
      will-change: transform;
    }
    outline: ${({ $searchIsOpen }) => ($searchIsOpen ? 1 : 0)};
  }
`

export const StyledResponsiveContainer = styled(Container)`
  height: 100%;
`

export const RightTitle = styled(motion.h1)`
  margin: 0;
  padding-bottom: 12px;
  ${Typo12};
`

export const SecondLevelContainer = styled.div`
  flex: 2 1 0%;
`

export const SecondLevelWrapper = styled(motion.div)`
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  gap: 16px;
  padding: 20px 25px 25px;

  ${media.tablet`
    flex-direction: row;
  `}

  ${media.desktop`
    padding: 12px 0 18px;
  `}
`

export const SecondLevelButton = styled(SmartLink)`
  padding: 16px;
  color: ${colors.white};
  position: relative;
  display: flex;
  flex-direction: row;
  width: 100%;
  gap: 2px;
  align-items: center;
  border-radius: 8px;
  background-color: ${colors.tosca300};
  justify-content: space-between;
  cursor: pointer;
  transition: background 0.3s;
  will-change: background;
  z-index: 10;

  font-size: 1.1rem;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  line-height: 1.75rem;
  text-align: center;

  &:focus {
    color: ${colors.white};
  }

  &:hover {
    color: ${colors.white};
    background: ${colors.tosca400};

    & svg {
      fill: ${({ $hoverColor }) => $hoverColor};
    }
  }

  & span {
    font-weight: ${font.weight.semiBold};
    font-family: ${font.fontFamilyBase};
    font-size: 16px;
    line-height: 24px;
    text-decoration: underline;
  }

  ${media.tablet`
    flex-direction: row;
    width: calc(50% - 9px);
  `}

  ${media.desktop`
    text-align: left;
    padding: 8px 20px;
    gap: 8px;
    font-size: 1rem;
    width: calc(33% - 8px);
  `}
`

export const HighLightItemsContainer = styled.div`
  ${({ $isRightMenu }) =>
    $isRightMenu &&
    `
      display: flex;
      flex-direction: row;
      gap: 45px;
  `}
`
export const LabelCta = styled(motion.p)`
  text-align: center;
  z-index: 1;
`

export const BlockTwoAndThreeWrapper = styled(motion.div)`
  padding: 0 30px;
  margin-bottom: 20px;
  flex: 2 1 0%;

  ${media.tablet`
    padding: 16px 30px 32px;
    margin: 0;
  `}

  ${media.desktop`
    padding: 24px 0px;
  `}
`

export const BlockTwoAndThree = styled(motion.div)`
  padding: 15px 0;

  ${media.tablet`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    padding: 18px 0;

    &:first-child {
      padding-top: 0;
    }

    &:last-child {
      padding-bottom: 0;
    }
  `}
`

export const Level2 = styled(motion.h2)`
  font-family: ${font.fontFamilyBase};
  font-style: normal;
  font-weight: ${font.weight.bold};
  font-size: 20px;
  line-height: 28px;
  color: ${colors.white};

  & a {
    color: ${colors.white};
  }

  ${media.desktop`
    font-family: ${font.fontFamilyHeading};
  `}
`

export const BlockSublevelThree = styled(motion.ul)`
  list-style: none;
  margin: 0;
  padding: 0;
  position: relative;
  z-index: 20;
  display: block;
  flex: 2;

  ${media.tablet`
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    padding-left: 8px;
    margin: 0;
  `}
`

export const Level3 = styled(motion.li)`
  ${Typo31};
  width: 100%;
  padding: 8px 15px;

  & a {
    color: ${colors.white};

    &:hover {
      font-weight: ${font.weight.bold};
      color: ${colors.white};
    }
  }

  ${media.tablet`
    font-family: ${font.fontFamilyBase};
    font-weight: ${font.weight.regular};
    font-size: 16px;
    line-height: 24px;
    display: flex;
    align-items: center;
    color: ${colors.white};
    padding: 3px 0;
    width: 50%;
  `}
`

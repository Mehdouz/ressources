import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Typo31 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

export const SubMenuLink = styled(SmartLink)`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: ${colors.white};
  background: ${({ $isActive, $activeColor }) => ($isActive ? $activeColor : '')} !important;
  padding: 8px 25px;
  ${Typo31};
  cursor: pointer;
  gap: 15px;

  &:hover {
    color: ${colors.white};
    background: ${({ $hoverColor }) => $hoverColor};
    transition: background 0.5s;
    will-change: background;
  }

  &:focus,
  &:active {
    color: ${colors.white};
    background: ${({ $activeColor }) => $activeColor};
  }

  ${media.desktop`
    &:hover {
      outline: 0;
    }

    &:focus,
    &:active {
      outline: 0;
    }
  `}
`

export const SubMenuButton = styled.button`
  text-transform: none !important;
  text-decoration: none !important;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: ${colors.white};
  background: ${({ $isActive, $activeColor }) => ($isActive ? $activeColor : '')} !important;
  padding: 8px 25px;
  ${Typo31};
  cursor: pointer;
  gap: 15px;
  background: transparent;
  border: 0;
  text-align: left;

  & svg {
    min-width: 15px;
  }

  &:hover {
    color: ${colors.white};
    background: ${({ $hoverColor }) => $hoverColor};
    transition: background 0.5s;
    will-change: background;
  }

  &:focus,
  &:active {
    color: ${colors.white};
    background: ${({ $activeColor }) => $activeColor};
  }
  ${media.tablet`
    padding: 8px 25px;
  `}

  ${media.desktop`
    &:hover {
      outline: 0;
    }

    &:focus,
    &:active {
      outline: 0;
    }
  `}
`

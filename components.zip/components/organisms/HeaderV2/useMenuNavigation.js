import React from 'react'
import { colors } from '../../../base/style/variables'

const MAX_LEVEL_DEEPNESS = 3

const menuColors = {
  leftMenu: {
    background: [colors.teal200, colors.teal400, colors.teal500],
    active: [colors.teal300, colors.teal500, 'rgba(250,250,250, 0.1)'],
    hover: ['rgba(17, 27, 29, 0.2)', 'rgba(17, 27, 29, 0.2)', 'rgba(250,250,250, 0.1)'],
    cta: [colors.teal300],
  },
  rightMenu: {
    background: [colors.tosca200, colors.tosca300, colors.tosca500],
    active: [colors.tosca300, colors.tosca500, 'rgba(250,250,250, 0.1)'],
    hover: ['rgba(17, 27, 29, 0.2)', 'rgba(17, 27, 29, 0.2)', 'rgba(250,250,250, 0.1)'],
    cta: [colors.tosca400],
    secondLevelHover: [colors.tosca500],
  },
}

export default function useMenuNavigation() {
  const [stateMenu, setStateMenu] = React.useState([])
  const [direction, setDirection] = React.useState(0)
  const [isSelected, setIsSelected] = React.useState(null)
  const [searchIsOpen, setSearchIsOpen] = React.useState(false)

  function clamp(nb, min = 0, max = 1) {
    return Math.min(Math.max(nb, min), max)
  }

  // reset the entire menu
  function resetMenu() {
    setDirection(0)
    setStateMenu([])
  }

  function goToNextLevel(indexToAdd) {
    const newState = [...stateMenu]
    newState.push(indexToAdd)
    setDirection(1)
    setStateMenu(newState)
  }

  // change the current menu
  function changeCurrentMenu(indexToChange) {
    const newState = [...stateMenu]
    if (newState.length >= 1) {
      newState[newState.length - 1] = indexToChange
    } else {
      if (newState.length === 0) {
        newState.push(indexToChange)
      }
    }
    setStateMenu(newState)
  }

  // lift up only one level above the current one
  function backMenu() {
    const newState = [...stateMenu]
    newState.splice(-1, 1)
    setDirection(-1)
    setStateMenu(newState)
  }

  // go to a specific menu level (from anywhere)
  function goToMenu(stateToApply) {
    const newState = validateTree(stateToApply)
    if (newState) {
      if (stateMenu.length > newState.length) {
        setDirection(-1)
      } else if (stateMenu.length < newState.length) {
        setDirection(1)
      }
      setStateMenu(newState)
    }
  }

  function hasMenuLevel(menuLevel) {
    return typeof stateMenu[clamp(menuLevel - 1, 0, 2)] === 'number'
  }

  function getColor({ deepness = 0, isRightMenu = false, type = 'background' }) {
    const menuType = isRightMenu ? 'rightMenu' : 'leftMenu'
    if (typeof deepness === 'number') return menuColors[menuType][type][deepness]
    return menuColors[menuType][type][clamp(0, stateMenu.length - 1, MAX_LEVEL_DEEPNESS)]
  }

  return {
    stateMenu,
    goToNextLevel,
    resetMenu,
    changeCurrentMenu,
    backMenu,
    goToMenu,
    hasMenuLevel,
    getColor,
    direction,
    setDirection,
    isSelected,
    setIsSelected,
    searchIsOpen,
    setSearchIsOpen,
  }
}

function validateTree(state) {
  return state
}

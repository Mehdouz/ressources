import React from 'react'
import { motion } from 'framer-motion/dist/framer-motion'
import {
  HighLightContainer,
  HighLightInner,
  HighLightItemsContainer,
  HighLightTitle,
  HighLightTitleLine,
  HighLightItemBlock,
  HighLightItemImage,
  HighLightItemContent,
  HighLightItemSurtitle,
  HighLightItemTitle,
  HighLightItemLink,
} from '@axacom-client/components/organisms/HeaderV2/HeaderV2.style'

const hightlightsContainerVariants = {
  visible: (isRightMenu) => {
    return isRightMenu ? { transition: { staggerChildren: 0.05 } } : { transition: { staggerChildren: 0.05, when: 'afterChildren' } }
  },
  exit: {
    transition: { ease: 'easeOut' },
  },
}

const highlightsVariants = {
  visible: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.3 },
  },
  hidden: { x: '10px', opacity: 0 },
  exit: { x: '10px', opacity: 0, transition: { duration: 0 } },
}

const highlightsSurtitleVariant = {
  visible: {
    x: 0,
    opacity: 0.5,
    transition: { duration: 0.3 },
  },
  hidden: { x: '10px', opacity: 0 },
  exit: { x: '10px', opacity: 0, transition: { duration: 0 } },
}

const titlelineVariants = {
  visible: {
    width: '100%',
    transition: { duration: 0.3 },
  },
  hidden: { width: 0 },
  exit: {
    width: 0,
    transition: { duration: 0 },
  },
}

export default function Highlights({ highlights, isRightMenu, ...rest }) {
  const { globalTitle, items } = highlights

  return (
    <HighLightContainer data-testid="Header__HighLight__Container" custom={isRightMenu} variants={hightlightsContainerVariants} {...rest}>
      <HighLightInner $isRightMenu={isRightMenu}>
        <HighLightTitle data-testid="Header__HighLight__Title" variants={highlightsVariants}>
          {globalTitle}
        </HighLightTitle>
        <HighLightTitleLine variants={titlelineVariants} />
        <HighLightItemsContainer $isRightMenu={isRightMenu}>
          {items &&
            items.map((item, index) => {
              const { image, link, linkLabel, surtitle, title } = item
              return (
                <HighLightItemBlock key={index} data-testid="Header__HighLight__Item__Block" href={link?.href} $isRightMenu={isRightMenu}>
                  <HighLightItemImage data-testid="Header__HighLight__Item__Image" src={image.main.url} variants={highlightsVariants} />
                  <HighLightItemContent>
                    <HighLightItemSurtitle data-testid="Header__HighLight__Item__Surtitle" variants={highlightsSurtitleVariant}>
                      {surtitle}
                    </HighLightItemSurtitle>
                    <HighLightItemTitle data-testid="Header__HighLight__Item__Title" variants={highlightsVariants}>
                      {title}
                    </HighLightItemTitle>
                    <HighLightItemLink data-testid="Header__HighLight__Item__Link" href={link?.href} Component={motion.a} variants={highlightsVariants}>
                      {linkLabel}
                    </HighLightItemLink>
                  </HighLightItemContent>
                </HighLightItemBlock>
              )
            })}
        </HighLightItemsContainer>
      </HighLightInner>
    </HighLightContainer>
  )
}

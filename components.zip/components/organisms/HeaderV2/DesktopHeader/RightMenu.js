import React from 'react'
import { MenuContainer, StyledResponsiveContainer, RightTitle, BottomContainer, BottomButton } from '@axacom-client/components/organisms/HeaderV2/HeaderV2.style'
import Highlights from './Highlights'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { motion } from 'framer-motion/dist/framer-motion'
import { useHeaderContext } from '../HeaderV2'
import SecondLevel from '../SecondLevel'
import SubMenuRight from '../SubMenuRight'

const bottomVariants = {
  visible: {
    transition: { staggerChildren: 0.05, delayChildren: 0.2 },
  },
}

const bottomButtonsVariants = {
  visible: {
    x: 0,
    opacity: 1,
  },
  hidden: {
    x: 15,
    opacity: 0,
  },
}

const titleVariants = {
  visible: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.2 },
  },
  hidden: {
    x: 20,
    opacity: 0,
  },
  exit: {
    opacity: 0,
    transition: { duration: 0 },
  },
}

export default function RightMenu({ menu, ...rest }) {
  const { stateMenu, getColor } = useHeaderContext()
  const cta = menu?.cta
  const hasCtas = (cta?.contact1?.href && cta?.contact1?.title) || (cta?.contact2?.href && cta?.contact2?.title)

  return (
    <MenuContainer isRightMenu $backgroundColor={getColor({ deepness: 0, isRightMenu: true })} {...rest}>
      <StyledResponsiveContainer>
        <RightTitle key={`${stateMenu[0]}-introduction`} data-testid="Header__Introduction__Title" variants={titleVariants}>
          {menu?.title}
        </RightTitle>
        {menu?.secondLevel && <SecondLevel items={menu?.secondLevel} />}
        {menu?.menus && <SubMenuRight $isDesktop menuData={menu?.menus} />}
        {menu?.highlights?.items?.length > 0 && <Highlights isRightMenu highlights={menu?.highlights} />}
      </StyledResponsiveContainer>
      {hasCtas && (
        <BottomContainer data-testid="Header__Cta__Container" $backgroundColor={getColor({ isRightMenu: true, type: 'cta' })} variants={bottomVariants}>
          {cta.contact1?.href && cta.contact1?.title ? (
            <BottomButton data-testid="Header__Cta__Button" href={cta.contact1.href} $hoverColor={getColor({ type: 'cta', isRightMenu: true })} Component={motion.a} variants={bottomButtonsVariants}>
              {cta.contact1Title}
              {cta.contact1Icon === 'newsletter' ? <Icon name="IconNewsletter" color="#FFF" width={13} height={13} /> : <Icon name="IconChat" color="#FFF" width={13} height={13} />}
            </BottomButton>
          ) : null}
          {cta.contact2?.href && cta.contact2?.title ? (
            <BottomButton data-testid="Header__Cta__Button" href={cta.contact2.href} $hoverColor={getColor({ type: 'cta', isRightMenu: true })} Component={motion.a} variants={bottomButtonsVariants}>
              {cta.contact2Title}
              {cta.contact2Icon === 'newsletter' ? <Icon name="IconNewsletter" color="#FFF" width={13} height={13} /> : <Icon name="IconChat" color="#FFF" width={13} height={13} />}
            </BottomButton>
          ) : null}
        </BottomContainer>
      )}
    </MenuContainer>
  )
}

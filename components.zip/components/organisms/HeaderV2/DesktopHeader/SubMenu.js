import React, { useState } from 'react'
import { motion } from 'framer-motion/dist/framer-motion'
import styled from 'styled-components'
import { useHeaderContext } from '../HeaderV2'
import { SubMenuList } from '../HeaderV2.style'
import { SubMenuLink, SubMenuButton } from '../SubMenuLink'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

const StyledSubMenuList = styled(SubMenuList)`
  ${({ menuLevel }) => {
    if (menuLevel === 2)
      return `
        padding: 28px 30px;
        height: 100%;
      `
    if (menuLevel === 3)
      return `
        padding: 28px 30px;
        height: 100%;
      `
  }}
`

function SubMenu({ menuData, childrenVariants, menuLevel, ...rest }) {
  const [isActive, setIsActive] = useState(null)
  const { stateMenu, goToMenu, getColor } = useHeaderContext()
  const hoverColor = getColor({ deepness: menuLevel - 1, type: 'hover' })
  const activeColor = getColor({ deepness: menuLevel - 1, type: 'active' })

  function handleItemClick(index) {
    if (menuLevel === 1) {
      if (stateMenu[1] === index) {
        goToMenu([stateMenu[0]])
      } else {
        goToMenu([stateMenu[0], index])
      }
    }
    if (menuLevel === 2) {
      if (stateMenu[2] === index) {
        goToMenu([stateMenu[0], stateMenu[1]])
      } else {
        goToMenu([stateMenu[0], stateMenu[1], index])
      }
    }

    toggleActive(index)
  }

  function toggleActive(index) {
    setIsActive(() => (isActive === index ? null : index))
  }

  return (
    <StyledSubMenuList menuLevel={menuLevel} {...rest}>
      {menuData &&
        menuData.map(({ title, link, menus }, index) => {
          const hasMenus = menus && menus.length > 0
          let linkAttrs = {}
          if (hasMenus) linkAttrs.onClick = () => handleItemClick(index)
          else linkAttrs.href = link.href

          return (
            <motion.li key={title + index} data-testid="Header_Submenu_Item" variants={childrenVariants}>
              {hasMenus ? (
                <SubMenuButton {...linkAttrs} data-testid="Header_Submenu_Link" $hoverColor={hoverColor} $activeColor={activeColor} $isActive={isActive === index}>
                  {title} <Icon name="IconArrowRight" color="white" width={15} height={15} />
                </SubMenuButton>
              ) : (
                <SubMenuLink {...linkAttrs} data-testid="Header_Submenu_Link" $hoverColor={hoverColor} $activeColor={activeColor} $isActive={isActive === index}>
                  {title}{' '}
                </SubMenuLink>
              )}
            </motion.li>
          )
        })}
    </StyledSubMenuList>
  )
}

export default SubMenu

import React, { useRef } from 'react'
import useOnClickOutside from '@axacom-client/hooks/useOnClickOutside'
import LeftMenu from './LeftMenu'
import RightMenu from './RightMenu'
import { HeaderWrapper } from '@axacom-client/components/organisms/HeaderV2/HeaderV2.style'
import TopHeader from './TopHeader'
import { AnimatePresence } from 'framer-motion/dist/framer-motion'
import { useHeaderContext } from '../HeaderV2'

const variants = {
  visible: {
    height: 'auto',
    transition: { ease: 'easeOut', duration: 0.4, staggerChildren: 0.1 },
  },
  hidden: {
    height: 0,
  },
  exit: (stateMenu) => {
    return typeof stateMenu[0] === 'number' ? { height: 0, transition: { duration: 0 } } : { height: 0, transition: { duration: 0.2 } }
  },
}

export default function DesktopHeader({ leftMenu, rightMenu }) {
  const { stateMenu, resetMenu, setIsSelected } = useHeaderContext()
  const headerRef = useRef()

  useOnClickOutside(headerRef, () => {
    resetMenu()
    setIsSelected(null)
  })

  const menus = [...leftMenu, ...rightMenu.map((m) => ({ ...m, isRightMenu: true }))]
  const isRightMenu = menus?.[stateMenu?.[0]]?.isRightMenu

  return (
    <HeaderWrapper ref={headerRef}>
      <TopHeader menus={menus} />
      <AnimatePresence custom={stateMenu}>
        {stateMenu.length !== 0 &&
          (isRightMenu ? (
            <RightMenu key={`${stateMenu[0]}-mainMenu`} menu={menus?.[stateMenu?.[0]]} custom={stateMenu} animate="visible" exit="exit" initial="hidden" variants={variants} />
          ) : (
            <LeftMenu key={`${stateMenu[0]}-mainMenu`} menu={menus?.[stateMenu?.[0]]} custom={stateMenu} animate="visible" exit="exit" initial="hidden" variants={variants} />
          ))}
      </AnimatePresence>
    </HeaderWrapper>
  )
}

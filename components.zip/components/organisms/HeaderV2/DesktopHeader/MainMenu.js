import React from 'react'
import { AnimateSharedLayout } from 'framer-motion/dist/framer-motion'

import { MainMenuContainer, MainMenuItem, MainMenuItemButton, MainMenuItemLink, Underline } from '@axacom-client/components/organisms/HeaderV2/HeaderV2.style'
import { useHeaderContext } from '../HeaderV2'

export default function MainMenu({ menus }) {
  const { stateMenu, goToMenu, resetMenu, isSelected, setIsSelected } = useHeaderContext()

  function handleItemClick(index) {
    if (stateMenu[0] === index) {
      setIsSelected(null)
      resetMenu()
    } else {
      setIsSelected(index)
      goToMenu([index])
    }
  }

  function handleItemEnter(index) {
    setIsSelected(index)
  }

  function handelItemLeave() {
    if (stateMenu[0] === undefined) setIsSelected(null)
    setIsSelected(stateMenu[0])
  }

  return (
    <AnimateSharedLayout>
      <MainMenuContainer data-testid="Header_MainMenu_Container" layout onMouseLeave={handelItemLeave}>
        {menus &&
          menus.map((item, index) => {
            return (
              item.title && (
                <MainMenuItem key={index} data-testid="Header_MainMenu_Item" $isRightMenu={item.isRightMenu}>
                  {item.dropdown === 'Yes' ? (
                    <MainMenuItemButton
                      data-testid="Header_MainMenu_Item_Link"
                      $isSelected={stateMenu[0] === index}
                      onMouseEnter={() => handleItemEnter(index)}
                      onFocus={() => handleItemEnter(index)}
                      onBlur={() => handelItemLeave(index)}
                      onClick={() => handleItemClick(index)}
                      $isRightMenu={item.isRightMenu}
                    >
                      {item.title}
                    </MainMenuItemButton>
                  ) : (
                    item.title && (
                      <MainMenuItemLink
                        data-testid="Header_MainMenu_Item_Link"
                        $isSelected={stateMenu[0] === index}
                        href={item?.link?.href}
                        onMouseEnter={() => handleItemEnter(index)}
                        onFocus={() => handleItemEnter(index)}
                        onBlur={() => handelItemLeave(index)}
                        onClick={() => resetMenu()}
                        $isRightMenu={item.isRightMenu}
                      >
                        {item.title}
                      </MainMenuItemLink>
                    )
                  )}

                  {index === isSelected && !item.isRightMenu ? <Underline layoutId="underline" /> : null}
                  {index === isSelected && item.isRightMenu ? <Underline layoutId="underlineRight" /> : null}
                </MainMenuItem>
              )
            )
          })}
      </MainMenuContainer>
    </AnimateSharedLayout>
  )
}

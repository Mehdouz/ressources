import React, { useState } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { useHeaderContext } from '../HeaderV2'
import { SearchContainer, SearchInput, SearchButton } from '@axacom-client/components/organisms/HeaderV2/HeaderV2.style'
import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { AnimatePresence } from 'framer-motion/dist/framer-motion'

const searchVariants = {
  visible: {
    width: '50%',
    transition: { ease: 'easeOut', duration: 0.15 },
  },
  hidden: {
    width: 0,
  },
}

export default function Search() {
  const { bookmarks, i18n } = useGlobalContext()
  const { searchIsOpen, setSearchIsOpen } = useHeaderContext()
  const [isHovered, setIsHovered] = useState(false)

  function handleKeyPress(e) {
    if (e.key === 'Enter' && e.target.value) {
      // eslint-disable-next-line no-undef
      document.location.href = `${bookmarks.search.url}?q=${e.target.value}`
    }
  }

  return (
    <SearchContainer data-testid="Header_Search_Container">
      <SearchButton
        data-testid="Header_Search_Button"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onFocus={() => setIsHovered(true)}
        onBlur={() => setIsHovered(false)}
        $searchIsOpen={searchIsOpen}
        onClick={() => setSearchIsOpen(!searchIsOpen)}
      >
        {searchIsOpen ? (
          <Icon name="IconCross" color={colors.white} width={25} height={25} dataTestid="CloseIcon" />
        ) : (
          <Icon name="IconGlass" color={isHovered ? colors.sienna400 : colors.AXABlue} width={25} height={25} dataTestid="SearchIcon" />
        )}
      </SearchButton>
      <AnimatePresence>
        {searchIsOpen && (
          <SearchInput
            data-testid="Header_Search_Input"
            type="search"
            tabIndex="0"
            placeholder={i18n.t('search.input')}
            onKeyPress={(e) => handleKeyPress(e)}
            initial="hidden"
            animate="visible"
            variants={searchVariants}
          />
        )}
      </AnimatePresence>
    </SearchContainer>
  )
}

import React from 'react'
import { array } from 'prop-types'
import { HeaderContainer, LogoLink } from '@axacom-client/components/organisms/HeaderV2/HeaderV2.style'
import MainMenu from './MainMenu'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { useHeaderContext } from '../HeaderV2'
import { IconAxaSolid } from '@axacom-client/base/svg/logo'
import Search from '@axacom-client/components/organisms/HeaderV2/DesktopHeader/Search'

export default function TopHeader({ menus }) {
  const { currentLocale } = useGlobalContext()
  const { searchIsOpen } = useHeaderContext()

  return (
    <HeaderContainer>
      <LogoLink data-testid="Header_Logo_Link" href={'/' + currentLocale}>
        <IconAxaSolid width={45} height={45} />
      </LogoLink>
      {!searchIsOpen && <MainMenu menus={menus} />}
      <Search />
    </HeaderContainer>
  )
}

TopHeader.propTypes = {
  menus: array,
}

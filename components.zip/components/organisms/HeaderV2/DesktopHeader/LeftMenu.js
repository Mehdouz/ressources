import React from 'react'
import {
  MenuContainer,
  LeftSubmenuContainer,
  RightSubmenuContainer,
  RightSubmenuBackground,
  ThirdLevelBackground,
  SubMenuContainer,
  RightContainer,
  BottomContainer,
  BottomButton,
} from '@axacom-client/components/organisms/HeaderV2/HeaderV2.style'
import SubMenu from './SubMenu'
import Introduction from '../Introduction'
import Highlights from './Highlights'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { motion } from 'framer-motion/dist/framer-motion'
import { useHeaderContext } from '../HeaderV2'

export default function LeftMenu({ menu, ...rest }) {
  const { stateMenu, getColor } = useHeaderContext()

  return (
    <MenuContainer $backgroundColor={getColor({ deepness: 0 })} {...rest}>
      <LeftSubMenu title={menu?.title} description={menu?.description} href={menu?.link.href} label={menu?.linkLabel} menuData={menu?.menus} />
      <RightSubmenu menuData={menu?.menus?.[stateMenu[1]]?.menus} cta={menu?.cta} highlights={menu?.highlights} />
    </MenuContainer>
  )
}

function LeftSubMenu({ title, description, label, href, menuData }) {
  const { stateMenu } = useHeaderContext()

  return (
    <LeftSubmenuContainer>
      <Introduction key={`${stateMenu[0]}-introduction`} title={title} description={description} href={href} label={label} />
      <SubMenu key={`${stateMenu[0]}-submenuLeft`} menuLevel={1} menuData={menuData} childrenVariants={subMenuVariants} />
    </LeftSubmenuContainer>
  )
}

const containersVariants = {
  visible: {
    transition: { ease: 'easeIn', staggerChildren: 0.05 },
  },
  exit: {
    transition: { duration: 0, ease: 'easeOut' },
  },
}

const thirdlevelBackgroundVariants = {
  visible: {
    width: '100%',
    transition: { ease: 'easeIn', duration: 0.2 },
  },
  hidden: { width: 0 },
}

const subMenuVariants = {
  visible: {
    y: 0,
    opacity: 1,
  },
  hidden: {
    y: 10,
    opacity: 0,
  },
  exit: {
    x: 10,
    opacity: 0,
    transition: { duration: 0 },
  },
}

const bottomVariants = {
  visible: {
    transition: { staggerChildren: 0.05 },
  },
}

const bottomButtonsVariants = {
  visible: {
    x: 0,
    opacity: 1,
  },
  hidden: {
    x: 15,
    opacity: 0,
  },
}

function RightSubmenu({ highlights, menuData, cta }) {
  const { stateMenu, hasMenuLevel, getColor } = useHeaderContext()
  const hasCtas = (cta?.contact1?.href && cta?.contact1?.title) || (cta?.contact2?.href && cta?.contact2?.title)
  const hasHighlights = highlights?.items.length > 0

  return (
    <RightContainer>
      <RightSubmenuContainer>
        {hasHighlights || hasMenuLevel(2) || hasMenuLevel(3) ? <RightSubmenuBackground key={`${stateMenu[0]}-rightSubmenuBackground`} $backgroundColor={getColor({ deepness: 1 })} /> : null}
        {!hasMenuLevel(2) && hasHighlights ? <Highlights key={`${stateMenu[0]}-highlights`} highlights={highlights} /> : null}
        {hasMenuLevel(2) && (
          <SubMenuContainer key={`${stateMenu[0]}-${stateMenu[1]}-two-submenuContainer`} data-testid="Header_Submenu_Container" menuLevel={2} variants={containersVariants}>
            <SubMenu key={`${stateMenu[0]}-${stateMenu[1]}-two-submenu`} data-testid="Header_Submenu" menuData={menuData} menuLevel={2} childrenVariants={subMenuVariants} />
          </SubMenuContainer>
        )}
        {hasMenuLevel(3) && (
          <SubMenuContainer key={`${stateMenu.join('-')}-three-submenuContainer`} data-testid="Header_Submenu_Container" menuLevel={3} variants={containersVariants}>
            <ThirdLevelBackground $backgroundColor={getColor({ deepness: 2 })} variants={thirdlevelBackgroundVariants} />
            <SubMenu key={`${stateMenu.join('-')}-three-submenu`} data-testid="Header_Submenu" menuData={menuData?.[stateMenu[2]]?.menus} menuLevel={3} childrenVariants={subMenuVariants} />
          </SubMenuContainer>
        )}
      </RightSubmenuContainer>
      {hasCtas && (
        <BottomContainer data-testid="Header_Cta_Container" $backgroundColor={getColor({ type: 'cta' })} variants={bottomVariants}>
          {cta.contact1?.href && cta.contact1?.title ? (
            <BottomButton data-testid="Header_Cta_Button" href={cta.contact1.href} $hoverColor={getColor({ type: 'cta' })} Component={motion.a} variants={bottomButtonsVariants}>
              {cta.contact1Title}
              {cta.contact1Icon === 'newsletter' ? <Icon name="IconNewsletter" color="#FFF" width={13} height={13} /> : <Icon name="IconChat" color="#FFF" width={13} height={13} />}
            </BottomButton>
          ) : null}
          {cta.contact2?.href && cta.contact2?.title ? (
            <BottomButton data-testid="Header_Cta_Button" href={cta.contact2.href} $hoverColor={getColor({ type: 'cta' })} Component={motion.a} variants={bottomButtonsVariants}>
              {cta.contact2Title}
              {cta.contact2Icon === 'newsletter' ? <Icon name="IconNewsletter" color="#FFF" width={13} height={13} /> : <Icon name="IconChat" color="#FFF" width={13} height={13} />}
            </BottomButton>
          ) : null}
        </BottomContainer>
      )}
    </RightContainer>
  )
}

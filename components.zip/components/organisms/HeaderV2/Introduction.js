import React from 'react'
import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo12, Typo27, Typo32 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'
import media from '@axacom-client/base/style/media'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

const introVariants = {
  visible: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.2 },
  },
  hidden: (custom) => {
    return {
      x: custom?.direction > 0 ? 20 : -20,
      opacity: 0,
    }
  },
  exit: {
    opacity: 0,
    transition: { duration: 0 },
  },
}

const Container = styled(motion.div)`
  padding: 0 25px;
  ${media.tablet`
    justify-content: center;
  `}
  position: relative;
`

const Title = styled(motion.h1)`
  margin-bottom: 10px;
  ${Typo12};
`

const Description = styled(motion.p)`
  margin-bottom: 15px;
  ${Typo27};
  font-weight: ${font.weight.regular};
`

const Cta = styled(SmartLink)`
  color: ${colors.white};
  display: block;
  margin-bottom: 40px;
  ${Typo32};
  text-decoration: underline;

  &:hover,
  &:focus {
    color: ${colors.white};
  }
`

export default function Introduction({ title, description, href, label, custom, ...rest }) {
  return (
    <Container custom={custom} {...rest}>
      {title && (
        <Title data-testid="Header_Introduction_Title" custom={custom} variants={introVariants}>
          {title}
        </Title>
      )}
      {description && (
        <Description data-testid="Header_Introduction_Description" custom={custom} variants={introVariants}>
          {description}
        </Description>
      )}
      {label && href && (
        <Cta data-testid="Header_Introduction_Cta" href={href} alt={label} Component={motion.a} custom={custom} variants={introVariants}>
          {label}
        </Cta>
      )}
    </Container>
  )
}

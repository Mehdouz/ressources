import React from 'react'
import { Level2, Level3, BlockTwoAndThreeWrapper, BlockTwoAndThree, BlockSublevelThree } from './HeaderV2.style'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

const variants = {
  visible: { transition: { staggerChildren: 0.04 } },
}

const variantsMobile = {
  visible: { transition: { staggerChildren: 0.05, delayChildren: 0.15 } },
}

const subMenuVariants = {
  visible: {
    y: 0,
    opacity: 1,
  },
  hidden: {
    y: 10,
    opacity: 0,
  },
  exit: {
    x: 10,
    opacity: 0,
    transition: { duration: 0 },
  },
}

const subMenuVariantsMobile = {
  visible: { x: 0, opacity: 1 },
  hidden: { x: 20, opacity: 0 },
  exit: { x: 20, opacity: 0 },
}

export default function SubMenuRight({ menuData, $isDesktop }) {
  return (
    <BlockTwoAndThreeWrapper data-testid="Header__SubmenuRight">
      {menuData.map((level2, index) => {
        return (
          <BlockTwoAndThree key={level2?.title + index + index} variants={$isDesktop ? variants : variantsMobile}>
            <Level2 key={level2?.title + index} data-testid="Header__SubmenuRight__Level2" variants={$isDesktop ? subMenuVariants : subMenuVariantsMobile}>
              {level2?.title}
            </Level2>
            <BlockSublevelThree>
              {level2?.menus.map((level3, indexItem) => (
                <Level3 key={level3?.title + indexItem} data-testid="Header__SubmenuRight__Level3" variants={$isDesktop ? subMenuVariants : subMenuVariantsMobile}>
                  <SmartLink href={level3?.link?.href} data-testid="Header__SubmenuRight__Level3__Link">
                    {level3?.title}
                  </SmartLink>
                </Level3>
              ))}
            </BlockSublevelThree>
          </BlockTwoAndThree>
        )
      })}
    </BlockTwoAndThreeWrapper>
  )
}

import React, { useState } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { SearchContainer, SearchInput, SearchButton } from './MobileHeader.style'
import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

export default function Search() {
  const { bookmarks, i18n } = useGlobalContext()
  const [inputText, setInputText] = useState('')

  const searchUrl = bookmarks.search.url

  function handleKeyPress(e) {
    if (e.key === 'Enter' && e.target.value) {
      // eslint-disable-next-line no-undef
      document.location.href = `${searchUrl}?q=${e.target.value}`
    }
  }

  function handleClick() {
    if (inputText.length > 0) {
      // eslint-disable-next-line no-undef
      document.location.href = `${searchUrl}?q=${inputText}`
    }
  }

  return (
    <SearchContainer data-testid="Header_Search_Container">
      <SearchInput data-testid="Header_Search_Input" type="search" tabIndex="0" placeholder={i18n.t('search.input')} onChange={(e) => setInputText(e.target.value)} onKeyPress={handleKeyPress} />
      <SearchButton data-testid="Header_Search_Button" onClick={handleClick}>
        <Icon name="IconGlass" color={colors.white} width={20} height={20} dataTestid="SearchIcon" />
      </SearchButton>
    </SearchContainer>
  )
}

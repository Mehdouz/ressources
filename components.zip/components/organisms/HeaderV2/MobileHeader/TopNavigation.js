import React from 'react'
import { TopNav, MenuBurgerIcon, BurgerButton } from './MobileHeader.style'
import { IconAxaSolid } from '@axacom-client/base/svg/logo'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

export default function TopNavigation({ onBurgerClick, showCross }) {
  const { currentLocale } = useGlobalContext()

  return (
    <TopNav>
      <SmartLink data-testid="Header_Logo_Link" href={'/' + currentLocale}>
        <IconAxaSolid width={48} height={48}></IconAxaSolid>
      </SmartLink>
      <BurgerButton aria-label="Toggle navigation" type="button" onClick={onBurgerClick}>
        <MenuBurgerIcon showCross={showCross} />
      </BurgerButton>
    </TopNav>
  )
}

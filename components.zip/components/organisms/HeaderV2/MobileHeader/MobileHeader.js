import React, { useEffect } from 'react'
import { AnimatePresence } from 'framer-motion/dist/framer-motion'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Background, NavigationView, NavigationInnerView } from './MobileHeader.style'
import useScrollBlock from '../../../../hooks/useScrollBlock'
import { BottomContainer, BottomButton } from '../HeaderV2.style'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { useHeaderContext } from '../HeaderV2'
import Introduction from '../Introduction'
import SubMenuMobileLeft from './SubMenuMobileLeft'
import SubMenuRight from '../SubMenuRight'
import TopNavigation from './TopNavigation'
import MainMenu from './MainMenu'
import BackButton from './BackButton'
import SecondLevel from '../SecondLevel'

const getTitleFromState = (stateMenu, menus) => {
  if (stateMenu.length === 2) {
    return menus[stateMenu[0]].menus[stateMenu[1]].title
  } else if (stateMenu.length === 3) {
    return menus[stateMenu[0]].menus[stateMenu[1]].menus[stateMenu[2]].title
  }
}

const navListVariants = {
  visible: { y: '0%', x: '0%', transition: { type: 'tween', duration: 0.2, staggerChildren: 0.05 } },
  hidden: ({ direction }) => {
    if (direction === -1) {
      return { x: '-100%', transition: { type: 'tween', duration: 0.2 } }
    } else {
      return { y: '-100%', transition: { type: 'tween', duration: 0.2 } }
    }
  },
  exit: ({ state, isOpen }) => {
    if (!isOpen && state.length === 0) {
      return { y: '-100%', transition: { type: 'tween', duration: 0.2 } }
    } else {
      return { x: '-100%', transition: { type: 'tween', duration: 0.2 } }
    }
  },
}

const navigationViewVariants = {
  visible: { x: 0, transition: { type: 'tween', duration: 0.2 } },
  hidden: ({ direction }) => {
    return {
      x: direction > 0 ? '100%' : '-100%',
      transition: { type: 'tween', duration: 0.2 },
    }
  },
  exit: ({ direction, isOpen, state }) => {
    // when the user close the entire menu, slide it up
    if (!isOpen && state.length === 0) {
      return { y: '-100%', transition: { type: 'tween', duration: 0.2 } }
    }
    return {
      transition: { type: 'tween', duration: 0.2 },
      x: direction > 0 ? '-100%' : '100%',
    }
  },
}

const navigationInnerViewVariants = {
  visible: { x: 0, transition: { type: 'tween', duration: 0.2, staggerChildren: 0.05 } },
}
const BgMenuVariants = {
  visible: { x: 0, transition: { type: 'tween', duration: 0.2 } },
  hidden: ({ direction }) => {
    return {
      x: direction > 0 ? '100%' : '-100%',
      transition: { type: 'tween', duration: 0.2 },
    }
  },
  exit: ({ direction }) => {
    return {
      x: direction > 0 ? '-100%' : '100%',
      transition: { type: 'tween', duration: 0.2 },
    }
  },
}

export default function MobileHeader({ leftMenu, rightMenu }) {
  const { stateMenu, resetMenu, backMenu, direction, getColor } = useHeaderContext()
  const [blockScroll, allowScroll] = useScrollBlock()
  const { i18n } = useGlobalContext()
  const [isOpen, setIsOpen] = React.useState(false)

  const handleBurgerClick = () => {
    setIsOpen((open) => !open)
    resetMenu()
  }

  const handleBackClick = () => backMenu()

  const menus = [...leftMenu, ...rightMenu.map((m) => ({ ...m, isRightMenu: true }))]

  if (isOpen) blockScroll()
  else allowScroll()

  useEffect(() => {
    return () => {
      allowScroll()
    }
  }, [])

  const getCurrentMenu = () => {
    if (stateMenu.length === 1) {
      return menus[stateMenu[0]].menus
    } else if (stateMenu.length === 2) {
      return menus[stateMenu[0]].menus[stateMenu[1]].menus
    } else if (stateMenu.length === 3) {
      return menus[stateMenu[0]].menus[stateMenu[1]].menus[stateMenu[2]].menus
    }
  }

  const custom = { direction, state: stateMenu, isOpen }
  const isRightMenu = menus?.[stateMenu?.[0]]?.isRightMenu

  return (
    <>
      <TopNavigation onBurgerClick={handleBurgerClick} showCross={isOpen} />
      <AnimatePresence custom={custom}>
        {isOpen ? (
          stateMenu.length === 0 ? (
            <MainMenu data-testid="MobileHeader__MainMenu" key="mainmenu" menus={menus} initial="hidden" animate="visible" exit="exit" variants={navListVariants} custom={custom} />
          ) : (
            <NavigationView
              data-testid="MobileHeader__NavigationView"
              key={`${stateMenu.join('-')}-container`}
              $backgroundColor={getColor({ isRightMenu: menus?.[stateMenu?.[0]].isRightMenu })}
              initial="hidden"
              animate="visible"
              exit="exit"
              custom={custom}
              variants={navigationViewVariants}
            >
              <NavigationInnerView key={`${stateMenu.join('-')}-innerView`} variants={navigationInnerViewVariants} custom={custom}>
                <Background key={`${stateMenu.join('-')}-bg`} $backgroundColor={getColor({ isRightMenu: menus?.[stateMenu?.[0]].isRightMenu })} variants={BgMenuVariants} custom={custom} />
                <BackButton data-testid="MobileHeader__NavigationView__BackButton" key={`${stateMenu.join('-')}-back`} onClick={handleBackClick} custom={custom}>
                  {getTitleFromState(stateMenu, menus) || i18n.t('header.back')}
                </BackButton>
                <Introduction
                  key="intro"
                  data-testid="MobileHeader__NavigationView__Introduction"
                  title={menus[stateMenu[0]].title}
                  description={menus[stateMenu[0]].description}
                  label={menus[stateMenu[0]].linkLabel}
                  href={menus[stateMenu[0]].link?.href}
                  custom={custom}
                />
                {isRightMenu && menus[stateMenu[0]]?.secondLevel && <SecondLevel items={menus[stateMenu[0]]?.secondLevel} $isMobile />}
                {isRightMenu
                  ? menus[stateMenu[0]]?.menus && (
                      <SubMenuRight data-testid="MobileHeader__NavigationView__SubMenuLinks" key={`${stateMenu.join('-')}-submenuRight`} menuData={menus[stateMenu[0]]?.menus} $isMobile />
                    )
                  : getCurrentMenu() && (
                      <SubMenuMobileLeft
                        data-testid="MobileHeader__NavigationView__SubMenuLinks"
                        key={`${stateMenu.join('-')}-submenu`}
                        menuLevel={stateMenu.length}
                        menuData={getCurrentMenu()}
                        custom={custom}
                      />
                    )}
                {menus?.[stateMenu?.[0]]?.cta ? (
                  <CTAList
                    data-testid="MobileHeader__CTA"
                    cta={menus[stateMenu[0]].cta}
                    bgColor={getColor({ isRightMenu: isRightMenu, type: 'cta' })}
                    hoverColor={getColor({ isRightMenu: isRightMenu, type: 'cta' })}
                  ></CTAList>
                ) : null}
              </NavigationInnerView>
            </NavigationView>
          )
        ) : null}
      </AnimatePresence>
    </>
  )
}

const CTAList = ({ cta, bgColor, hoverColor, ...rest }) => {
  return (
    <BottomContainer data-testid="Header_Cta_Container" $backgroundColor={bgColor} {...rest}>
      {cta.contact1 && (
        <BottomButton href={cta.contact1.href} $hoverColor={hoverColor} data-testid="Header_Cta_Button">
          {cta.contact1Title}
          <Icon name="IconNewsletter" color="#FFF" width={13} height={13} />
        </BottomButton>
      )}
      {cta?.contact2 && cta?.contact2?.href && (
        <BottomButton href={cta.contact2.href} $hoverColor={hoverColor} data-testid="Header_Cta_Button">
          {cta.contact2Title}
          <Icon name="IconChat" color="#FFF" width={13} height={13} />
        </BottomButton>
      )}
    </BottomContainer>
  )
}

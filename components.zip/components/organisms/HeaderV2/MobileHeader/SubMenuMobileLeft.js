import React from 'react'
import { object, array, number } from 'prop-types'
import { motion } from 'framer-motion/dist/framer-motion'
import { useHeaderContext } from '../HeaderV2'
import { SubMenuList } from '../HeaderV2.style'
import { SubMenuLink, SubMenuButton } from '../SubMenuLink'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

const variants = {
  visible: {
    transition: { ease: 'easeOut', duration: 0.4, staggerChildren: 0.05 },
  },
}

const childrenVariants = {
  visible: { x: 0, opacity: 1 },
  hidden: ({ direction }) => {
    return { x: direction > 0 ? 20 : -20, opacity: 0 }
  },
  exit: { x: -20, opacity: 0 },
}

function SubMenu({ menuData, menuLevel, custom, ...rest }) {
  const { stateMenu, goToMenu } = useHeaderContext()

  function handleItemClick(index) {
    if (stateMenu[menuLevel] === index) {
      goToMenu([...stateMenu])
    } else {
      goToMenu([...stateMenu, index])
    }
  }

  return (
    <SubMenuList menuLevel={menuLevel} {...rest} variants={variants}>
      {menuData &&
        menuData.map(({ title, link, menus }, index) => {
          const hasMenus = menus && menus.length > 0
          let linkAttrs = {}
          if (hasMenus) linkAttrs.onClick = () => handleItemClick(index)
          else linkAttrs.href = link.href

          return (
            <motion.li key={title + index} variants={childrenVariants} custom={custom}>
              {hasMenus ? (
                <SubMenuButton {...linkAttrs}>
                  {title}
                  <Icon name="IconArrowRight" color="white" width={15} height={15} />
                </SubMenuButton>
              ) : (
                <SubMenuLink {...linkAttrs}>{title}</SubMenuLink>
              )}
            </motion.li>
          )
        })}
    </SubMenuList>
  )
}

export default SubMenu

SubMenu.propTypes = {
  menuData: array,
  childrenVariants: object,
  menuLevel: number,
  custom: object,
}

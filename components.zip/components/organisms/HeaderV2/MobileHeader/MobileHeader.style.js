import styled from 'styled-components'
import { Typo25, Typo26, Typo32 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'
import { colors, font } from '@axacom-client/base/style/variables'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'

export const TopNav = styled.div`
  height: 72px;
  background-color: white;
  padding: 0 25px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
  z-index: 30;
  box-shadow: inset 0px -1px 0px #f0f0f0;
`

export const MenuBurgerIcon = styled.span`
  display: block;
  position: relative;
  height: 2px;
  width: 16px;
  background: ${({ showCross }) => (showCross ? 'transparent' : colors.AXABlue)};
  transition: all 0.2s;
  :before,
  :after {
    content: '';
    display: block;
    position: absolute;
    left: 0;
    z-index: 0;
    width: 16px;
    height: 2px;
    transition: all 0.2s;
    background: ${colors.AXABlue};
    transform-origin: ${({ showCross }) => (showCross ? '50% 50%' : '0 0')};
  }
  :before {
    top: ${({ showCross }) => (showCross ? 0 : '-6px')};
    transform: ${({ showCross }) => (showCross ? 'rotate3d(0, 0, 1, 45deg)' : 'rotate3d(0, 0, 0, 0)')};
  }
  :after {
    top: ${({ showCross }) => (showCross ? 0 : '6px')};
    transform: ${({ showCross }) => (showCross ? 'rotate3d(0, 0, 1, -45deg)' : 'rotate3d(0, 0, 0, 0)')};
  }
`

export const BurgerButton = styled.button`
  border: 0;
  width: 32px;
  height: 32px;
  padding: 8px;
  background-color: transparent;
`

export const BackButtonLink = styled(motion.button)`
  position: relative;
  ${Typo25}
  font-weight: bold;
  padding: 20px 20px 20px 25px;
  color: white;
  margin-top: 10px;
  display: flex;
  gap: 15px;
  align-items: center;
  outline: none;
  border: 0;
  background: transparent;

  &:focus,
  &:hover,
  &:active {
    color: white;
  }
`

export const BackLabel = styled(motion.div)`
  text-transform: uppercase;
`

export const NavigationGroup = styled(motion.nav)`
  ${Typo26};
  padding: 0;
  margin: 0;
  list-style: none;
  display: ${({ $isOpen }) => ($isOpen ? 'block' : 'none')};
  position: fixed;
  top: 115px;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 21;
`

export const MainMenuView = styled(motion.nav)`
  list-style: none;
  background-color: white;
  position: fixed;
  top: 115px;
  left: 0;
  right: 0;
  bottom: 0;
  overflow: auto;
  z-index: 22;
`

export const NavigationView = styled(motion.div)`
  color: white;
  background-color: ${({ $backgroundColor }) => $backgroundColor ?? 'white'};
  transition: background-color 1s;
  position: fixed;
  top: 115px;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 22;
  overflow: auto;
`

export const NavigationInnerView = styled(motion.div)`
  display: flex;
  flex-direction: column;
  position: relative;
  height: 100%;
`

export const Background = styled(motion.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  background-color: ${({ $backgroundColor }) => $backgroundColor ?? 'white'};
`

export const NavigationWrapper = styled(motion.div)`
  position: relative;
  height: 100vh;
`

export const NavigationContainer = styled(motion.div)`
  padding: 20px;
  position: sticky;
  top: 0;
  width: 100%;
  color: white;
  background-color: white;
`

export const NavItemContainer = styled(motion.li)`
  box-shadow: inset 0px 1px 0px #f0f0f0;
  &:last-child {
    box-shadow: inset 0px 1px 0px #f0f0f0, inset 0px -1px 0px #f0f0f0;
  }
  ${({ $isRightMenu }) => ($isRightMenu ? `background-color: #FAFAFA;` : '')}
`

export const NavItemLink = styled(SmartLink)`
  padding: 19px 25px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: ${colors.AXABlue};
  font-weight: 600;
  &:hover,
  &:focus {
    color: inherit;
  }
`

export const NavItemButton = styled.button`
  text-transform: none !important;
  text-decoration: none !important;
  padding: 19px 25px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: ${colors.AXABlue};
  font-weight: 600;
  background: transparent;
  border: 0;
  width: 100%;

  &:hover,
  &:focus {
    color: inherit;
  }
`

export const SearchContainer = styled.div`
  box-shadow: inset 0px 1px 0px #f0f0f0, inset 0px -1px 0px #f0f0f0;
  display: flex;
  padding: 40px 25px;
  justify-content: space-between;
  background: #fafafa;
`

export const SearchInput = styled(motion.input)`
  ${Typo32}
  padding-left: 10px;
  width: 100%;
  height: 41px;
  color: ${colors.grey600};
  border: 1px solid ${colors.grayLight};
  font-weight: ${font.weight.regular};

  &::-webkit-search-cancel-button {
    display: none;
  }

  &::placeholder {
    color: ${colors.grey400};
  }
`

export const SearchButton = styled.button`
  cursor: pointer;
  position: relative;
  padding: 7px 10px;
  background-color: ${colors.AXABlue};
  margin-left: 15px;
  border: 0;
`

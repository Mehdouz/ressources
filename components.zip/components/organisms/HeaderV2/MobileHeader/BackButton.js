import React from 'react'
import { node } from 'prop-types'

import { BackLabel, BackButtonLink } from './MobileHeader.style'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

const defaultBackVariants = {
  visible: { opacity: 1, x: 0, transition: { type: 'tween', duration: 0.2 } },
  exit: { opacity: 0, x: -20 },

  hidden: (custom) => {
    return {
      x: custom?.direction > 0 ? 20 : -20,
      opacity: 0,
    }
  },
}

export default function BackButton({ children, ...rest }) {
  return (
    <BackButtonLink initial="hidden" animate="visible" exit="exit" variants={defaultBackVariants} {...rest}>
      <Icon name="IconArrowLeft" color="white" width={15} height={15} />
      <BackLabel>{children}</BackLabel>
    </BackButtonLink>
  )
}

BackButton.propTypes = {
  children: node.isRequired,
}

import React from 'react'

import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

import { NavItemContainer, MainMenuView, NavItemButton, NavItemLink } from './MobileHeader.style'
import { useHeaderContext } from '../HeaderV2'
import Search from '@axacom-client/components/organisms/HeaderV2/MobileHeader/Search'

const navItemVariants = {
  visible: { opacity: 1, y: 0, x: 0, transition: { duration: 0.2 } },
  hidden: (custom) => {
    return custom?.direction < 0 ? { x: -20, opacity: 0 } : {}
  },
}
export default function MainMenu({ menus, custom, ...rest }) {
  const { goToMenu } = useHeaderContext()
  const handleClick = (index) => () => goToMenu(index)

  return (
    <MainMenuView custom={custom} {...rest}>
      {menus.map(({ link, title, isRightMenu, dropdown, ...m }, i) => {
        const hasDropdown = dropdown === 'Yes'
        let linkAttrs = {}
        if (hasDropdown) linkAttrs.onClick = handleClick([i])
        else linkAttrs.href = link.href

        return (
          title && (
            <NavItemContainer key={`left-${m.title}-${i}`} $isRightMenu={isRightMenu} variants={navItemVariants} custom={custom}>
              {hasDropdown ? (
                <NavItemButton {...linkAttrs}>
                  {title} <Icon className="mr-1" name="IconArrowRight" color={colors.AXABlue} width={15} height={15} />
                </NavItemButton>
              ) : (
                <NavItemLink {...linkAttrs}>{title}</NavItemLink>
              )}
            </NavItemContainer>
          )
        )
      })}
      <Search />
    </MainMenuView>
  )
}

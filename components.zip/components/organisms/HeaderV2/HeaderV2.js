import React, { createContext, useContext } from 'react'
import { object } from 'prop-types'
import DesktopHeader from './DesktopHeader/DesktopHeader'
import MobileHeader from './MobileHeader/MobileHeader'
import useMenuNavigation from './useMenuNavigation'
import { mediaVariables } from '@axacom-client/base/style/media'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'

const HeaderContext = createContext({})
export const useHeaderContext = () => useContext(HeaderContext)

function HeaderV2({ menu }) {
  const navActions = useMenuNavigation()
  const { leftMenu, rightMenu } = menu
  const isMaxTablet = useBetterMediaQueries({ query: `(max-width: ${mediaVariables.tabletMax}px)` }, false)

  return (
    <HeaderContext.Provider value={navActions}>
      {isMaxTablet ? <MobileHeader leftMenu={leftMenu} rightMenu={rightMenu} /> : <DesktopHeader leftMenu={leftMenu} rightMenu={rightMenu} />}
    </HeaderContext.Provider>
  )
}

HeaderV2.propTypes = {
  menu: object,
}

export default HeaderV2

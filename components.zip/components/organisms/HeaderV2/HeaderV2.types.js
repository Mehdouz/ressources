import { Link, Slices, Slice, Select, Text, Image } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  labelName: Text('Document title', 'Add a primary menu title', true),
  leftMenu: LeftMenuSlices(),
  rightMenu: RightMenuSlices(),
}

function LeftMenuSlices() {
  return Slices({
    menu: Slice(
      {
        dropdown: Select(['Yes', 'No'], 'Display the dropdown menu?', 'Choose your option', 'Yes'),
        title_en: Text('🇬🇧 Title [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title [fr]', 'Write the title here'),
        description_en: Text('🇬🇧 Description (Mandatory, 70 characters max) [en]', 'Write the description here'),
        description_fr: Text('🇫🇷 Description (Mandatory, 70 characters max) [fr]', 'Write the description here'),
        linkLabel_en: Text('🇬🇧 Link label [en]', 'Write the link label here'),
        linkLabel_fr: Text('🇫🇷 Link label [fr]', 'Write the link label here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link'),
      },
      {},
      'Menu'
    ),
    submenu: Slice(
      {},
      {
        level: Select(['Level 2', 'Level 3', 'Level 4'], 'Menu level', 'Choose the level', 'Level 2'),
        title_en: Text('🇬🇧 Title [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title [fr]', 'Write the title here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link [fr]'),
      },
      'Menu > Submenu'
    ),
    'menu-highlights': Slice(
      {
        globalTitle_en: Text('🇬🇧 Global Title [en]', 'Write the global title here'),
        globalTitle_fr: Text('🇫🇷 Global Title [fr]', 'Write the global title here'),
      },
      {
        image: Image('Image', { width: 180, height: 110 }, []),
        surtitle_en: Text('🇬🇧 Surtitle [en]', 'Write the surtitle here'),
        surtitle_fr: Text('🇫🇷 Surtitle [fr]', 'Write the surtitle here'),
        title_en: Text('🇬🇧 Title (70 characters max) [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title (70 characters max) [fr]', 'Write the title here'),
        linkLabel_en: Text('🇬🇧 Link label [en]', 'Write the link label here'),
        linkLabel_fr: Text('🇫🇷 Link label [fr]', 'Write the link label here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link [fr]'),
      },
      'Menu > Highlights'
    ),
    'menu-cta': Slice(
      {
        contact1_en: Link('🇬🇧 Link #1'),
        contact1_fr: Link('🇫🇷 Link #1'),
        contact1Title_en: Text('🇬🇧 Link #1 title [en]'),
        contact1Title_fr: Text('🇫🇷 Link #1 title [fr]'),
        contact1Icon: Select(['contact', 'newsletter'], 'Icone link #1', undefined, 'Contact'),

        contact2_en: Link('🇬🇧 Link #2'),
        contact2_fr: Link('🇫🇷 Link #2'),
        contact2Title_en: Text('🇬🇧 Link #2 title [en]'),
        contact2Title_fr: Text('🇫🇷 Link #2 title [fr]'),
        contact2Icon: Select(['contact', 'newsletter'], 'Icone link #2', undefined, 'Contact'),
      },
      {},
      'Menu > CTA'
    ),
  })
}

function RightMenuSlices() {
  return Slices({
    menu: Slice(
      {
        dropdown: Select(['Yes', 'No'], 'Display the dropdown menu?', 'Choose your option', 'Yes'),
        title_en: Text('🇬🇧 Title [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title [fr]', 'Write the title here'),
        description_en: Text('🇬🇧 Description (Mandatory, 70 characters max) [en]', 'Write the description here'),
        description_fr: Text('🇫🇷 Description (Mandatory, 70 characters max) [fr]', 'Write the description here'),
        linkLabel_en: Text('🇬🇧 Link label [en]', 'Write the link label here'),
        linkLabel_fr: Text('🇫🇷 Link label [fr]', 'Write the link label here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link'),
      },
      {},
      'Menu'
    ),
    submenu: Slice(
      {},
      {
        level: Select(['Level 2', 'Level 3', 'Level 4'], 'Menu level', 'Choose the level', 'Level 2'),
        title_en: Text('🇬🇧 Title [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title [fr]', 'Write the title here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link [fr]'),
      },
      'Menu > Submenu'
    ),
    'extended-menu': Slice(
      {
        dropdown: Select(['Yes', 'No'], 'Display the dropdown menu?', 'Choose your option', 'Yes'),
        title_en: Text('🇬🇧 Title [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title [fr]', 'Write the title here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link'),
      },
      {},
      'Extended Menu'
    ),
    'extended-menu-secondLevel': Slice(
      {},
      {
        title_en: Text('🇬🇧 Title [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title [fr]', 'Write the title here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link [fr]'),
      },
      'Ext > Level 2 only'
    ),
    'extended-menu-levelTwoAndThree': Slice(
      {},
      {
        level: Select(['Level 2', 'Level 3'], 'Menu level', 'Choose the level', 'Level 2'),
        title_en: Text('🇬🇧 Title [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title [fr]', 'Write the title here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link [fr]'),
      },
      'Ext > Level 2 + 3'
    ),
    'menu-highlights': Slice(
      {
        globalTitle_en: Text('🇬🇧 Global Title [en]', 'Write the global title here'),
        globalTitle_fr: Text('🇫🇷 Global Title [fr]', 'Write the global title here'),
      },
      {
        image: Image('Image', { width: 180, height: 110 }, []),
        surtitle_en: Text('🇬🇧 Surtitle [en]', 'Write the surtitle here'),
        surtitle_fr: Text('🇫🇷 Surtitle [fr]', 'Write the surtitle here'),
        title_en: Text('🇬🇧 Title (70 characters max) [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title (70 characters max) [fr]', 'Write the title here'),
        linkLabel_en: Text('🇬🇧 Link label [en]', 'Write the link label here'),
        linkLabel_fr: Text('🇫🇷 Link label [fr]', 'Write the link label here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link [fr]'),
      },
      'Menu > Highlights'
    ),
    'extended-menu-highlights': Slice(
      {
        globalTitle_en: Text('🇬🇧 Global Title [en]', 'Write the global title here'),
        globalTitle_fr: Text('🇫🇷 Global Title [fr]', 'Write the global title here'),
      },
      {
        image: Image('Image', { width: 180, height: 130 }, []),
        surtitle_en: Text('🇬🇧 Surtitle [en]', 'Write the surtitle here'),
        surtitle_fr: Text('🇫🇷 Surtitle [fr]', 'Write the surtitle here'),
        title_en: Text('🇬🇧 Title (70 characters max) [en]', 'Write the title here'),
        title_fr: Text('🇫🇷 Title (70 characters max) [fr]', 'Write the title here'),
        linkLabel_en: Text('🇬🇧 Link label [en]', 'Write the link label here'),
        linkLabel_fr: Text('🇫🇷 Link label [fr]', 'Write the link label here'),
        link_en: Link('🇬🇧 Link [en]'),
        link_fr: Link('🇫🇷 Link [fr]'),
      },
      'Ext. Highlight'
    ),
    'menu-cta': Slice(
      {
        contact1_en: Link('🇬🇧 Link #1'),
        contact1_fr: Link('🇫🇷 Link #1'),
        contact1Title_en: Text('🇬🇧 Link #1 title [en]'),
        contact1Title_fr: Text('🇫🇷 Link #1 title [fr]'),
        contact1Icon: Select(['contact', 'newsletter'], 'Icone link #1', undefined, 'Contact'),

        contact2_en: Link('🇬🇧 Link #2'),
        contact2_fr: Link('🇫🇷 Link #2'),
        contact2Title_en: Text('🇬🇧 Link #2 title [en]'),
        contact2Title_fr: Text('🇫🇷 Link #2 title [fr]'),
        contact2Icon: Select(['contact', 'newsletter'], 'Icone link #2', undefined, 'Contact'),
      },
      {},
      'Menu > CTA'
    ),
    'extended-menu-cta': Slice(
      {
        contact1_en: Link('🇬🇧 Link #1'),
        contact1_fr: Link('🇫🇷 Link #1'),
        contact1Title_en: Text('🇬🇧 Link #1 title [en]'),
        contact1Title_fr: Text('🇫🇷 Link #1 title [fr]'),
        contact1Icon: Select(['contact', 'newsletter'], 'Icone link #1', undefined, 'Contact'),

        contact2_en: Link('🇬🇧 Link #2'),
        contact2_fr: Link('🇫🇷 Link #2'),
        contact2Title_en: Text('🇬🇧 Link #2 title [en]'),
        contact2Title_fr: Text('🇫🇷 Link #2 title [fr]'),
        contact2Icon: Select(['contact', 'newsletter'], 'Icone link #2', undefined, 'Contact'),
      },
      {},
      'Ext. CTA'
    ),
  })
}

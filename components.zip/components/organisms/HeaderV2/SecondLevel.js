import React from 'react'
import { SecondLevelWrapper, SecondLevelContainer, SecondLevelButton } from '@axacom-client/components/organisms/HeaderV2/HeaderV2.style'
import { useHeaderContext } from './HeaderV2'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

const variants = {
  visible: { transition: { staggerChildren: 0.05 } },
}

const variantsMobile = {
  visible: { transition: { staggerChildren: 0.1 } },
}

const buttonsVariants = {
  visible: {
    x: 0,
    opacity: 1,
  },
  hidden: {
    x: 15,
    opacity: 0,
  },
  exit: {
    opacity: 0,
    transition: { duration: 0 },
  },
}

export default function SecondLevel({ items, $isMobile }) {
  const { getColor } = useHeaderContext()

  return (
    <SecondLevelContainer>
      <SecondLevelWrapper data-testid="Header__SecondLevel" variants={$isMobile ? variantsMobile : variants}>
        {items.map(
          (item, index) =>
            item?.title &&
            item?.link?.href && (
              <SecondLevelButton
                key={index}
                data-testid="Header__SecondLevel__Button"
                href={item?.link?.href}
                $hoverColor={getColor({ type: 'secondLevelHover', isRightMenu: true })}
                variants={buttonsVariants}
              >
                {item?.title}
                <Icon name="IconArrowRight" color="#FFF" width={16} height={16} />
              </SecondLevelButton>
            )
        )}
      </SecondLevelWrapper>
    </SecondLevelContainer>
  )
}

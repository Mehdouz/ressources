const footer = {
  legals: [
    {
      link: {
        title: 'Legal link 1',
        url: 'https://www.google.fr',
      },
    },
  ],
  primaryTitle: 'ACCÈS RAPIDE',
  primaryMenu: [
    {
      title: 'Nous contacter',
      link: {
        url: '#',
      },
    },

    {
      title: 'S’abonner aux alertes e-mails',
      link: {
        url: '#',
      },
    },
    {
      title: 'Informations reglementées',
      link: {
        url: '#',
      },
    },
  ],
  secondaryTitle: 'AXA & VOUS',
  secondaryMenu: [
    {
      title: 'Politique de traceurs / cookies',
      link: {
        url: '#',
      },
    },
    {
      title: 'Gestionnaire de traceurs / cookies',
      link: {
        url: '#',
      },
    },
    {
      title: 'Politique de protection des données à caractère personnel',
      link: {
        url: '#',
      },
    },
  ],
  socialTitle: 'NOUS SUIVRE',
  socialMenu: [
    {
      name: 'Facebook',
      link: {
        url: '#',
      },
    },
    {
      name: 'Linkedin',
      link: {
        url: '#',
      },
    },
    {
      name: 'Youtube',
      link: {
        url: '#',
      },
    },
    {
      name: 'Instagram',
      link: {
        url: '#',
      },
    },
    {
      name: 'Twitter',
      link: {
        url: '#',
      },
    },
  ],
}

export default footer

const socialNetwork = ['Facebook', 'Linkedin', 'Youtube', 'Instagram', 'Twitter']

export default {
  $primaryTitle: {
    type: 'Text',
    config: {
      label: 'Primary menu title',
      placeholder: 'Add a primary menu title',
      useAsTitle: true,
    },
  },
  $primaryMenu: {
    type: 'Group',
    fieldset: 'Primary Menu',
    config: {
      fields: {
        title: {
          type: 'Text',
          config: {
            label: 'Link label',
            placeholder: 'Add a label',
          },
        },
        link: {
          type: 'Link',
          config: {
            label: 'Link target',
            placeholder: 'Add a link',
          },
        },
      },
    },
  },
  $secondaryTitle: {
    type: 'Text',
    config: {
      label: 'Secondary menu title',
      placeholder: 'Add a secondary menu title',
    },
  },
  $secondaryMenu: {
    type: 'Group',
    fieldset: 'Secondary Menu',
    config: {
      fields: {
        title: {
          type: 'Text',
          config: {
            label: 'Link label',
            placeholder: 'Add a label',
          },
        },
        link: {
          type: 'Link',
          config: {
            label: 'Link target',
            placeholder: 'Add a link',
          },
        },
      },
    },
  },
  $thirdTitle: {
    type: 'Text',
    config: {
      label: 'Third menu title',
      placeholder: 'Add a Third menu title',
    },
  },
  $thirdMenu: {
    type: 'Group',
    fieldset: 'Third Menu',
    config: {
      fields: {
        title: {
          type: 'Text',
          config: {
            label: 'Link label',
            placeholder: 'Add a label',
          },
        },
        link: {
          type: 'Link',
          config: {
            label: 'Link target',
            placeholder: 'Add a link',
          },
        },
      },
    },
  },
  $socialTitle: {
    type: 'Text',
    config: {
      label: 'Social menu title',
      placeholder: 'Add a social menu title',
    },
  },
  $socialMenu: {
    type: 'Group',
    fieldset: 'Social Menu',
    config: {
      fields: {
        name: {
          type: 'Select',
          fieldset: 'Social network name',
          config: {
            label: 'Select the Social network name',
            options: socialNetwork,
          },
        },
        link: {
          type: 'Link',
          config: {
            label: 'Link target',
            placeholder: 'Add a link',
          },
        },
      },
    },
  },
  $legals: {
    type: 'Group',
    fieldset: 'Legals',
    config: {
      repeat: false,
      fields: {
        title: {
          type: 'Text',
          config: {
            label: 'Legals label',
            placeholder: 'Add a label',
          },
        },
        link: {
          type: 'Link',
          config: {
            label: 'Legals target link',
            placeholder: 'Add a link',
          },
        },
      },
    },
  },
}

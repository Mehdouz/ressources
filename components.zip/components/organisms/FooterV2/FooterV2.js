import React, { useState } from 'react'
import { array, string } from 'prop-types'
import { darken } from 'polished'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { FullWithContainer, LangLink, LangWrapper, Legals, Link, NavTitle, Slash, SocialCol, SocialNav, SubNavRow, NavList, List, SubNavWrapper, FooterWrapper, FooterLists } from './FooterV2.style'
import { colors } from '@axacom-client/base/style/variables'
import { MinDesktop } from '@axacom-client/components/utils/Responsive'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { getWindowProp } from '@axacom-client/services/window-service'

export default function Footer({ primaryTitle, primaryMenu, secondaryTitle, secondaryMenu, thirdTitle, thirdMenu, socialTitle, socialMenu, legals }) {
  const { urls, locales, currentLocale, i18n } = useGlobalContext()
  const [isHovered, setHovered] = useState(false)

  return (
    <FullWithContainer>
      <FooterWrapper>
        <FooterLists>
          <List>
            {primaryTitle && <NavTitle data-testid="FooterNav_Title">{primaryTitle}</NavTitle>}
            <NavList>
              {primaryMenu.map((primary, index) => (
                <li key={index}>{primary.link?.url && <Link url={primary.link.url}>{primary.title}</Link>}</li>
              ))}
            </NavList>
          </List>
          <List>
            {secondaryTitle && <NavTitle data-testid="FooterNav_Title">{secondaryTitle}</NavTitle>}
            <NavList>
              {secondaryMenu.map((secondary, index) =>
                secondary.link?.url.includes('/cookies') ? (
                  <li key={index}>
                    <Link texttransform="none" onClick={() => getWindowProp('OneTrust').ToggleInfoDisplay()}>
                      {secondary.title}
                    </Link>
                  </li>
                ) : (
                  <li key={index}>{secondary.link?.url && <Link url={secondary.link.url}>{secondary.title}</Link>}</li>
                )
              )}
            </NavList>
          </List>
          <List>
            {thirdTitle && <NavTitle data-testid="FooterNav_Title">{thirdTitle}</NavTitle>}
            <NavList>
              {thirdMenu.map((third, index) => (
                <li key={index}>{third.link?.url && <Link url={third.link.url}>{third.title}</Link>}</li>
              ))}
            </NavList>
          </List>
          <SocialCol>
            <MinDesktop>
              <NavTitle data-testid="FooterNav_Title">{socialTitle}</NavTitle>
            </MinDesktop>
            <SocialNav>
              {socialMenu.map((social, index) => (
                <li key={index}>
                  {social.link && social.link.url && (
                    <Link url={social.link.url} onMouseEnter={() => setHovered(social.name)} onMouseLeave={() => setHovered(false)}>
                      <Icon name={`Icon${social.name}`} color={isHovered === social.name ? darken(0.2, colors.AXABlue) : colors.AXABlue} width={24} height={24} />
                    </Link>
                  )}
                </li>
              ))}
            </SocialNav>
          </SocialCol>
        </FooterLists>
      </FooterWrapper>
      <SubNavRow>
        <SubNavWrapper>
          <LangWrapper>
            {locales.map((locale, index) => (
              <React.Fragment key={index}>
                {locale === currentLocale ? (
                  <LangLink active={true} as={'p'} data-testid="LangLink_CurrentLocale">
                    {locale === 'en' ? 'English' : 'Français'}
                  </LangLink>
                ) : (
                  <LangLink url={urls['url_' + locale]} data-testid="LangLink_Other">
                    {locale === 'en' ? 'English' : 'Français'}
                  </LangLink>
                )}
                {index !== locales.length - 1 && <Slash>/</Slash>}
              </React.Fragment>
            ))}
          </LangWrapper>
          <Legals>
            {legals[0].link && legals[0].link.url && <Link url={legals[0].link.url}>{legals[0].title || legals[0].link.title}</Link>} {i18n.t('footer.copyright')} {new Date().getFullYear()}{' '}
            {i18n.t('footer.AllRight')}
          </Legals>
        </SubNavWrapper>
      </SubNavRow>
    </FullWithContainer>
  )
}

Footer.propTypes = {
  primaryTitle: string,
  primaryMenu: array,
  secondaryTitle: string,
  secondaryMenu: array,
  socialTitle: string,
  socialMenu: array,
  legals: array,
}

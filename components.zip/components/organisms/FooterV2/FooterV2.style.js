import React from 'react'
import { any, string } from 'prop-types'
import styled from 'styled-components'

import media from '../../../base/style/media'
import { Typo13, Typo16, Typo18, Typo20Bold } from '../../../base/style/typoStyle/typoStyle'
import { colors } from '../../../base/style/variables'
import { getSpacing } from '../../../base/style/spacing'

import Button from '../../atoms/Button/Button'

const LinkFromButton = ({ className, children, ...otherProps }) => (
  <Button type="link" className={className} {...otherProps}>
    {children}
  </Button>
)

LinkFromButton.propTypes = { className: string, children: any.isRequired }

export const FullWithContainer = styled.footer`
  position: relative;
  border-top: 1px solid ${colors.gray};
`

export const FooterWrapper = styled.div`
  display: flex;
  flex-direction: column;

  ${media.desktop`
    flex-direction: row;
    padding: 40px 25px 30px;
  `}

  ${media.desktopLarge`
    justify-content: start;
    padding: 40px 25px 30px;

  `}
`

export const FooterLists = styled.div`
  display: flex;
  flex-direction: column;
  order: 2;
  padding-bottom: 25px;

  ${media.tablet`
    order: 1;
    flex-direction: row;
    flex-wrap: wrap;
    padding-bottom: 0px;
  `}

  ${media.desktop`
    justify-content: start;
    flex-wrap: nowrap;
    padding: 0;
    width: 100%;
    gap: 50px;
  `}

  ${media.desktopLarge`
    width: 100%;
    gap: 30px;
    justify-content: flex-start
  `}
`

export const NavList = styled.ul`
  list-style: none;
  padding: 0;
  margin-top: 30px;

  & li {
    margin: 0 0 ${getSpacing(2)};
  }

  ${media.desktop`
    margin-bottom: 0;
  `}
`

export const NavRow = styled.div`
  flex-direction: column-reverse;

  ${media.phone`
    padding-bottom: ${getSpacing(2)};
    border-bottom: 1px solid ${colors.gray};
  `}

  ${media.tablet`
    flex-direction: column;
  `}

  ${media.desktop`
    flex-direction: row;
  `}
`

export const Link = styled(LinkFromButton)`
  ${Typo18}
  text-transform: none;
  color: ${colors.AXABlue};
  height: auto;
  display: flex;
  text-align: left;
  justify-content: flex-start;
  align-items: center;
  letter-spacing: 0;
  padding: 0;

  &:hover,
  &:focus {
    text-decoration: underline;
    color: ${colors.AXABlue};
  }
`

export const SocialNav = styled.ul`
  display: flex;
  justify-content: space-between;
  margin: ${getSpacing(2)} 0;
  list-style: none;
  padding-left: 0;

  ${media.tablet`
    justify-content: center;
    gap: 60px;
  `}

  ${media.desktop`
    justify-content: space-between;
    gap: inherit;
  `}

  ${Link} {
    padding: ${getSpacing(1)};
    margin: 0;
  }
`

export const DefaultNav = styled.ul`
  margin-top: ${getSpacing(2)};

  ${media.tablet`
    margin-top: ${getSpacing(4)};
    margin-bottom: ${getSpacing(1)};
  `}

  ${media.desktop`
    margin-bottom: ${getSpacing(4)};
  `}
`

export const NavTitle = styled.p`
  ${Typo20Bold}
  text-transform: uppercase;
  color: ${colors.AXABlue};
`

export const List = styled.div`
  margin-top: 40px;
  padding: 0 30px;
  order: 2;

  ${media.tablet`
    width: 33%;
    margin-bottom: 30px;
  `}

  ${media.desktop`
    margin-top: 0px;
    margin-bottom: 0px;
    padding: 0;
    width: 300px;
  `}

  ${media.desktopLarge`
    padding-right: 70px;
    width: 320px;
  `}

  ${media.desktopVeryLarge`
    margin-top: 0px;
    padding-right: 100px;
    width: 350px;
  `}
`

export const SocialCol = styled.div`
  order: 1;
  padding: 0 20px;
  border-bottom: 1px solid ${colors.gray};
  width: 100%;

  ${NavTitle} {
    margin-left: ${getSpacing(1)};
  }

  ${media.desktop`
    order: 2;
    width: 250px;
    padding: 0;
    margin-top: 0px;
    border: 0;
  `}

  ${media.desktopLarge`
    margin-left: auto;
  `}
`

export const SubNavWrapper = styled.div`
  width: 100%;

  ${media.tablet`
    display: flex;
    align-items: center;
    justify-content: space-between;
  `}

  ${media.desktopLarge`
    padding: ${getSpacing(1)} 25px;
  `}
`

export const SubNavRow = styled.div`
  padding: 0 25px 30px;
  border-top: 1px solid ${colors.gray};
  display: flex;
  flex-direction: column;

  ${media.tablet`
    flex-direction: row;
    justify-content: space-between;
    padding-top: ${getSpacing(1)};
    padding-bottom: ${getSpacing(1)};
    align-items: center;
  `}

  ${media.desktopLarge`
    padding: 0;
  `}
`

export const LangWrapper = styled.div`
  display: flex;

  ${media.phone`
    margin-top: ${getSpacing(4)};
    margin-bottom: ${getSpacing(2)};
  `}
`

export const LangLink = styled(LinkFromButton)`
  ${Typo16}
  font-weight: ${({ active }) => (active ? 'bold' : 'normal')};
  color: ${colors.AXABlue};
  height: auto;
  text-decoration: none;
  padding: 0;
  text-transform: uppercase;
  display: inline-flex;
  align-items: center;

  &:hover,
  &:focus {
    text-decoration: ${({ active }) => (active ? 'none' : 'underline')};
    color: ${colors.AXABlue};
  }
`

export const Slash = styled.span`
  color: ${colors.AXABlue};
  margin: 0 4px;
`

export const Legals = styled.div`
  ${Typo13}

  ${Link} {
    ${Typo13}
    color: ${colors.textColor};
    display: inline;
  }

  ${media.tablet`
    text-align: right;
  `}
`

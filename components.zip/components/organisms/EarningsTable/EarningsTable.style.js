import styled, { css } from 'styled-components'
import media from '@axacom-client/base/style/media'
import { font, colors } from '@axacom-client/base/style/variables'
import { Typo15, Typo32, Typo9 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'

export const YearButton = styled.button`
  cursor: pointer;
  color: ${colors.grey500};
  background-color: transparent;
  border: 0;
  font-size: 18px;
  font-family: ${font.fontFamilyBase};
  padding: 25px 15px;
  position: relative;

  ${({ $isActive }) =>
    $isActive &&
    css`
      color: ${colors.brandRed};
    `}

  &:hover {
    color: ${colors.brandRed};
  }

  &:focus {
    outline-style: none;
    box-shadow: none;
    border-color: transparent;
  }
`

export const DateFilterWrapper = styled.div`
  padding: 0 15px;
  border-top: 1px solid ${colors.grayLighter};
  border-bottom: 1px solid ${colors.grayLighter};
  white-space: nowrap;
  overflow-x: auto;
  width: 100%;
  position: relative;
`

export const DateFilter = styled.div`
  position: relative;

  &:before {
    content: '';
    position: absolute;
    top: 0;
    height: 100%;
    width: 40px;
    z-index: 1;
    pointer-events: none;
    right: 0;
    background: linear-gradient(to right, rgba(255, 255, 255, 0), white);
  }

  &:after {
    content: '';
    position: absolute;
    top: 0;
    height: 100%;
    width: 40px;
    z-index: 1;
    pointer-events: none;
    left: 0;
    background: linear-gradient(to left, rgba(255, 255, 255, 0), white);
  }
`

export const TableContainer = styled.div`
  overflow-x: auto;
  width: 100%;
  transform: rotateX(180deg);
  margin-top: 30px;

  ::-webkit-scrollbar {
    padding-bottom: 10px;
    height: 8px;
  }

  ::-webkit-scrollbar-track {
    background: #b2b2b2;
  }

  ::-webkit-scrollbar-thumb {
    background: ${colors.brandBlue};
  }

  ::-webkit-scrollbar-thumb:hover {
    background: #3a5e95;
  }
`

export const Table = styled.table`
  transform: rotateX(180deg);
`

export const TableHeaderRow = styled.th`
  color: ${colors.brandBlue};
  padding-top: 43px;
  padding-bottom: 43px;
  white-space: normal;
  vertical-align: top;
  text-align: center;
  ${Typo32};
  font-weight: ${font.weight.regular};
  border-bottom: 2px solid #dee2e6;

  &:first-child {
    padding-left: 20px;
    text-align: left;
  }

  & span {
    color: ${colors.grayDark};
    display: block;
  }

  ${media.desktopLarge`
    ${Typo9};
    font-weight: ${font.weight.regular};
  `}
`

export const TableRow = styled.tr`
  background-color: ${({ $hasBackground }) => ($hasBackground ? colors.grayLighter : 'transparent')};
`

export const TableCell = styled.td`
  text-align: left;
  min-width: 200px;
  padding-top: 28px;
  padding-bottom: 28px;
  text-align: center;
  border-top: 1px solid #dee2e6;
  ${Typo32};
  font-weight: ${font.weight.regular};

  &:first-child {
    text-align: left;
    padding-left: 20px;
  }

  ${media.desktopVeryLarge`
    min-width: 240px;
  `}
`

export const TableCellLink = styled.a`
  display: flex;
  flex-direction: column;
  align-items: center;
  ${Typo15};
  letter-spacing: 0.08em;
  color: ${colors.textColor};
  text-transform: uppercase;

  & span {
    margin-top: 8px;
  }
`

export const Underline = styled(motion.div)`
  position: absolute;
  bottom: 0px;
  height: 2px;
  left: 0;
  width: 100%;
  background-color: ${colors.brandRed};
`

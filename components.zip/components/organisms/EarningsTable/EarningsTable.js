import React, { useState, useEffect } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { colors } from '@axacom-client/base/style/variables'
import { DateFilter, DateFilterWrapper, YearButton, TableContainer, Table, TableHeaderRow, TableCell, TableCellLink, TableRow, Underline } from './EarningsTable.style'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { motion, AnimatePresence } from 'framer-motion/dist/framer-motion'
import { getWindow, getLocation } from '@axacom-client/services/window-service'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

const rows = [
  'pressRelease',
  'presentationAnalysts',
  'appendices',
  'presentationAnalystsPotcast',
  'presentationAnalystsQAPotcast',
  'presentationAnalystsWebcast',
  'presentationAnalystsTranscript',
  'annualReport',
  'activityReport',
  'financialSupplement2PDF',
  'financialSupplement2EXCEL',
  'financialSupplementPDF',
  'financialSupplementEXCEL',
  'USFinancialSupplement',
  'EmbededValueReport',
  'SolvencyFinancial',
  'ExecutiveSummaryTranslations',
  'QuantitativeReporting',
  'pressPresentation',
  'pressPresentationWebcast',
  'pressPresentationPodcast',
  'pressPresentationQAPodcast',
  'pressPresentationTranscript',
  'ActivityAndCorporateReport',
  'henriInterview',
  'henriInterviewTranscript',
]

const headerRows = ['earnings.table.thead.doc', 'earnings.table.thead.annualResults', 'earnings.table.thead.9Mactivity', 'earnings.table.thead.halfYearResults', 'earnings.table.thead.1Qactivity']

const variants = {
  visible: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.2 },
  },
  hidden: {
    x: -30,
    opacity: 0,
  },
  exit: {
    opacity: 0,
    x: 30,
    transition: { duration: 0.2 },
  },
}

export default function EarningsTable({ tableResults }) {
  const { i18n } = useGlobalContext()
  const [currentTableIndex, setCurrentTableIndex] = useState(0)
  const [isSelected, setIsSelected] = useState(null)
  const currentTable = tableResults[currentTableIndex]
  const window = getWindow()

  useEffect(() => {
    const urlYear = getLocation('hash').split('=')[1]
    const yearIndex = tableResults.findIndex((table) => table.year === urlYear)
    if (yearIndex !== -1) {
      setCurrentTableIndex(yearIndex)
    }
  }, [])

  function handleClick(index) {
    window.location.href = `${window.location.origin}${window.location.pathname}#year=${tableResults[index].year}`
    setCurrentTableIndex(index)
  }

  return (
    <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
      <DateFilter>
        <DateFilterWrapper>
          {tableResults.map((table, index) => {
            return (
              <YearButton
                key={index}
                onMouseEnter={() => setIsSelected(index)}
                onMouseLeave={() => setIsSelected(currentTableIndex)}
                onClick={() => handleClick(index)}
                $isActive={currentTableIndex === index}
              >
                {table.year}
                {isSelected === index ? <Underline layoutId="underline" /> : null}
              </YearButton>
            )
          })}
        </DateFilterWrapper>
      </DateFilter>
      <AnimatePresence exitBeforeEnter>
        <motion.div key={currentTableIndex} animate="visible" initial="hidden" exit="exit" variants={variants}>
          <TableContainer>
            <Table>
              <thead>
                <tr>
                  {headerRows.map((headerTitle, index, rows) => {
                    const currentColumn = `t${rows.length - index}`

                    return (
                      <TableHeaderRow key={index}>
                        {i18n.t(headerTitle)}
                        {index !== 0 && currentTable?.[currentColumn]?.editionDate && <span>({currentTable?.[currentColumn]?.editionDate})</span>}
                      </TableHeaderRow>
                    )
                  })}
                </tr>
              </thead>
              <tbody>
                {rows.map((item, index) => {
                  const rowReference = `${item}Reference`
                  const rowTitle = () => {
                    if (item === 'ActivityAndCorporateReport')
                      return <p>{currentTable.year < '2016' ? i18n.t('earnings.table.row.ActivityAndCorporateReport') : i18n.t('earnings.table.row.ActivityAndCorporateReport_new')}</p>
                    if (item === 'henriInterview') return <p>{`${i18n.t('earnings.table.row.CEOInterview')} ${currentTable.CEOname || i18n.t('earnings.table.row.defaultCEO')}`}</p>
                    if (item === 'henriInterviewTranscript') return <p>{`${i18n.t('earnings.table.row.CEOInterviewTranscript')} ${currentTable.CEOname || i18n.t('earnings.table.row.defaultCEO')}`}</p>
                    else return <p>{i18n.t(`earnings.table.row.${item}`)}</p>
                  }
                  return (
                    <TableRow key={index} $hasBackground={index % 2 === 0}>
                      <TableCell>{rowTitle()}</TableCell>
                      <TableCell>
                        {currentTable?.t4?.[rowReference] ? (
                          <TableCellLink href={currentTable?.t4[rowReference]?.url} target="_blank">
                            <Icon name={getIconProperties(currentTable.t4[rowReference]?.url)?.name} color={getIconProperties(currentTable?.t4[rowReference]?.url)?.color} width={25} height={25} />
                            <span>{currentTable?.t4[item]}</span>
                          </TableCellLink>
                        ) : (
                          '---'
                        )}
                      </TableCell>
                      <TableCell>
                        {currentTable?.t3?.[rowReference] ? (
                          <TableCellLink href={currentTable?.t3[rowReference]?.url} target="_blank">
                            <Icon name={getIconProperties(currentTable?.t3[rowReference]?.url)?.name} color={getIconProperties(currentTable?.t3[rowReference]?.url)?.color} width={25} height={25} />
                            <span>{currentTable?.t3[item]}</span>
                          </TableCellLink>
                        ) : (
                          '---'
                        )}
                      </TableCell>
                      <TableCell>
                        {currentTable?.t2?.[rowReference] ? (
                          <TableCellLink href={currentTable?.t2[rowReference]?.url} target="_blank">
                            <Icon name={getIconProperties(currentTable?.t2[rowReference]?.url)?.name} color={getIconProperties(currentTable?.t2[rowReference]?.url)?.color} width={25} height={25} />
                            <span>{currentTable?.t2[item]}</span>
                          </TableCellLink>
                        ) : (
                          '---'
                        )}
                      </TableCell>
                      <TableCell>
                        {currentTable?.t1?.[rowReference] ? (
                          <TableCellLink href={currentTable?.t1[rowReference]?.url} target="_blank">
                            <Icon name={getIconProperties(currentTable?.t1[rowReference]?.url)?.name} color={getIconProperties(currentTable?.t1[rowReference]?.url)?.color} width={25} height={25} />
                            <span>{currentTable?.t1[item]}</span>
                          </TableCellLink>
                        ) : (
                          '---'
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </tbody>
            </Table>
          </TableContainer>
        </motion.div>
      </AnimatePresence>
    </ResponsiveContainer>
  )
}

function getIconProperties(url) {
  if (url.includes('.xls') || url.includes('.xlxs')) return { name: 'IconExcel', color: colors.excelColor }
  if (url.includes('.ppt')) return { name: 'IconPowerpoint', color: colors.powerpointColor }
  if (url.includes('.pdf')) return { name: 'IconPdf', color: colors.acrobatColor }
  if (url.includes('.mp3')) return { name: 'IconMp3', color: colors.podcastColor }
  if (url.includes('youtu')) return { name: 'IconYoutube', color: colors.youtubeColor }
  if (url.includes('content.axa') || url.includes('webstyle') || url.includes('media.axa') || url.includes('webcast')) return { name: 'IconWebcast', color: colors.webcastColor }
}

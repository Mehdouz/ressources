import React, { useRef } from 'react'
import { media, colors } from '@axacom-client/base/style/variables'
import {
  MotionReferrer,
  BackgroundImage,
  ArticleCover,
  ArticleHeaderInner,
  Title,
  Subtitle,
  AuthorBlock,
  AuthorImage,
  AuthorInfos,
  AuthorName,
  AuthorRole,
  Date,
  ArticleHeaderTopic,
  ArticleInfos,
  ArticleReadTime,
  Share,
} from './ArticleHeader.style'
import { useScroll, useTransform, circOut } from 'framer-motion/dist/framer-motion'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'
import { mediaQueries } from '@axacom-client/base/style/media'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'
import { dateTime } from '@axacom-client/services/date-service'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import SocialShare from '@axacom-client/components/molecules/SocialShare/SocialShare'

export function ArticleHeader({ cover, author, date, theme, readTime, typeArticle }) {
  const { domain, currentLocale } = useGlobalContext()
  const { banner, title, subtitle } = cover
  const contentRef = useRef(null)

  // Calculate the scrollProgression while on cover & transform it to make parallax effect
  let { scrollYProgress } = useScroll({
    target: contentRef,
    offset: ['-115px start', 'end start'],
  })
  let y = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  let opacity = useTransform(scrollYProgress, [0, 1], [1.1, 0], { ease: circOut })

  const formatedDate = date ? dateTime(date, 'LL', currentLocale) : null
  const authorData = author?.[0]?.referenceAuthor ? author?.[0]?.referenceAuthor : author?.[0]
  const hasAuthor = author?.[0]?.referenceAuthor || author?.[0]?.fullName

  const topicHref = theme?.linkTopicPage?.url ? theme?.linkTopicPage?.url : domain + theme?.url

  return (
    <>
      <MotionReferrer ref={contentRef} />
      <ArticleCover>
        <picture>
          <source media={`(max-width: ${media.phoneMax}px)`} srcSet={banner?.views?.small.url} />
          <source media={`(max-width: ${media.desktopMax}px)`} srcSet={banner?.views?.medium.url} />
          <BackgroundImage data-testid="FullBanner_Image" style={{ y, opacity }} src={banner?.main.url} alt={banner?.main?.alt} />
        </picture>
      </ArticleCover>

      <ResponsiveContainer tablet desktop largeDesktop veryLargeDesktop>
        <ArticleHeaderInner $hasAuthor={hasAuthor}>
          <Share>
            <SocialShare title={title} theme="blue" />
          </Share>
          {hasAuthor && <Author isLinkedPerson={!!author?.[0]?.referenceAuthor} {...authorData} />}
          {formatedDate && <Date>{formatedDate}</Date>}
          {title && <Title>{title}</Title>}
          {subtitle && <Subtitle>{subtitle}</Subtitle>}
          {
            <ArticleInfos>
              {theme && typeArticle == 'Insights' && <ArticleHeaderTopic href={topicHref}>{theme?.metaContent?.[0]?.title}</ArticleHeaderTopic>}
              <ArticleReadTime>
                <Icon name="IconAlarm" color={colors.textColor} width={15} height={15} />
                {readTime}
              </ArticleReadTime>
            </ArticleInfos>
          }
        </ArticleHeaderInner>
      </ResponsiveContainer>
    </>
  )
}

function Author({ fullName, role, avatar, isLinkedPerson, shortRole, firstname, lastname }) {
  const isNotMobile = useBetterMediaQueries({ query: mediaQueries.tablet }, true)

  return (
    <AuthorBlock>
      {avatar?.main?.url && isNotMobile && <AuthorImage src={avatar.main.url} alt={fullName} />}
      <AuthorInfos>
        {<AuthorName>{isLinkedPerson ? `${firstname} ${lastname}` : fullName}</AuthorName>}
        {<AuthorRole>{isLinkedPerson ? shortRole : role}</AuthorRole>}
      </AuthorInfos>
    </AuthorBlock>
  )
}

import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo33 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const BackgroundImage = styled(motion.img)`
  position: absolute;
  top: -10%;
  left: 0;
  z-index: 0;
  height: 110%;
  width: 100%;
  object-fit: cover;
  opacity: 0.7;

  ${media.desktopLarge`
    width: 100%;
  `}
`

export const MotionReferrer = styled.div`
  position: absolute;
  top: 0;
  bottom: 0;
  height: 100%;
  width: 100%;
`

export const ArticleCover = styled.div`
  position: relative;
  width: 100%;
  height: 400px;
  background: #000;
  overflow: hidden;

  ${media.tablet`
    height: 480px;
  `}

  ${media.desktop`
    height: 650px;
  `}
`

export const ArticleHeaderContainer = styled.div`
  transform: translateY(-100px);
  position: relative;
`

export const ArticleHeaderInner = styled.div`
  background: ${colors.white};
  padding: 40px 32px 10px;
  position: relative;

  ${media.tablet`
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: -120px;
    padding: ${({ $hasAuthor }) => ($hasAuthor ? '0px' : '50px')} 90px 20px;
  `}

  ${media.desktop`
    margin-top: -150px;
  `}
`

export const Title = styled.h1`
  margin-top: 30px;
  ${Typo33}
  line-height: 36px;
  letter-spacing: 0px;

  ${media.tablet`
    text-align: center;
    font-size: 58px;
    line-height: 60px;
  `}

  ${media.desktopLarge`
    font-size: 72px;
    line-height: 74px;
  `}
`

export const Subtitle = styled.h2`
  margin-top: 30px;
  font-weight: ${font.weight.regular};
  font-size: 18px;
  line-height: 24px;

  ${media.tablet`
    text-align: center;
    font-size: 20px;
    line-height: 28px;
  `}

  ${media.desktopLarge`
    width: 80%;
    font-size: 24px;
    line-height: 34px;
  `}
`

export const AuthorBlock = styled.div`
  ${media.tablet`
    display: flex;
    align-items: center;
    flex-direction: column;
    margin-top: -48px;
    position: relative;
    margin-bottom: 15px;
  `}
`

export const AuthorImage = styled.img`
  display: inline-block;
  vertical-align: middle;
  width: 96px;
  margin-bottom: 20px;
  border-radius: 50%;
`

export const AuthorInfos = styled.p`
  font-size: 13px;
  letter-spacing: 0.1em;
  line-height: 1.5rem;
  text-transform: uppercase;
`

export const AuthorRole = styled.span``
export const AuthorName = styled.a`
  margin-right: 15px;
  font-weight: ${font.weight.bold};
  position: relative;

  &:after {
    content: '';
    display: block;
    height: 10px;
    position: absolute;
    top: 4px;
    right: -7px;
    width: 1px;
    background-color: #ccc;
  }
`

export const Date = styled.p`
  font-size: 13px;
  letter-spacing: 0.1em;
  line-height: 1.5rem;
  text-transform: uppercase;
  margin-top: 10px;
`

export const ArticleInfos = styled.div`
  font-size: 13px;
  letter-spacing: 0.1em;
  line-height: 1.5rem;
  text-transform: uppercase;
  margin-top: 30px;

  ${media.tablet`
    display: flex;
    flex-direction: row;
  `}
`

export const ArticleHeaderTopic = styled.a`
  font-weight: ${font.weight.bold};

  ${media.tablet`
    position: relative;
    margin-right: 25px;

    &:after {
      content: '';
      display: block;
      height: 10px;
      position: absolute;
      top: 7px;
      right: -12px;
      width: 1px;
      background-color: #ccc;
    }
  `}
`

export const ArticleReadTime = styled.p`
  display: flex;
  align-items: center;
  gap: 5px;
`

export const Share = styled.div`
  display: flex;
  align-items: center;
  position: absolute;
  right: 0;
  top: -68px;
  flex-direction: row-reverse;
  z-index: 100;

  & div {
    display: flex;
    flex-direction: row-reverse;
  }

  ${media.tablet`
    top: 0;
    flex-direction: column;

    & div {
      flex-direction: column;
    }
  `}
`

import React from 'react'
import { StyledSlice, TopBanner, SectionTitle, Title, Subtitle } from './LightBanner.style'
import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

export default function LightBanner({ title, bannerTitle, bannerSubtitle }) {
  return (
    <StyledSlice>
      <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
        {title && <SectionTitle>{title}</SectionTitle>}
        <TopBanner>
          {bannerTitle && <Title>{bannerTitle}</Title>}
          {bannerSubtitle && <Subtitle>{bannerSubtitle}</Subtitle>}
        </TopBanner>
      </ResponsiveContainer>
    </StyledSlice>
  )
}

import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Slice } from '../SimpleSlice/SimpleSlice'
import { font, colors } from '@axacom-client/base/style/variables'
import { Typo15, Typo10, Typo40 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const StyledSlice = styled(Slice)`
  ${media.desktop`
    padding-bottom: 0px;
  `}
`

export const TopBanner = styled.div`
  display: flex;
  flex-direction: column;

  ${media.desktop`
    flex-direction: row;
  `}
`

export const SectionTitle = styled.h2`
  ${Typo15}
  text-transform: uppercase;
  text-align: center;
  color: ${colors.grayDark};
  letter-spacing: 0.08em;
  margin-top: 20px;

  ${media.desktop`
    text-align: left;
  `}
`

export const Title = styled.h1`
  ${Typo40}
  text-align: center;
  margin-top: 20px;

  ${media.desktop`
    text-align: left;
    width: 50%;
    padding-right: 50px;
    margin-top: 10px;
  `}
`

export const Subtitle = styled.p`
  text-align: center;
  ${Typo10}
  color: ${colors.grayDark};
  font-weight: ${font.weight.regular};
  margin-top: 10px;

  ${media.desktop`
    text-align: left;
    width: 50%;
  `}
`

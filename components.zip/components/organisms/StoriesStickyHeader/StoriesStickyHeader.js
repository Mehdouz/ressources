import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { AnimatePresence, useScroll } from 'framer-motion/dist/framer-motion'
import { StickyHeaderContainer, Content, LogoWrapper, Title, BackToStories, Share, LeftContent } from './StoriesStickyHeader.style'
import Logo from '@axacom-client/components/atoms/Logo/Logo'
import Progressbar from '@axacom-client/components/molecules/Progressbar/Progressbar'
import SocialShare from '@axacom-client/components/molecules/SocialShare/SocialShare'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { BackToTop } from '@axacom-client/components/molecules/BackToTop/BackToTop'
import { useEffect } from 'react'
import { getWindow } from '@axacom-client/services/window-service'
import { useState } from 'react'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'
import { mediaQueries } from '@axacom-client/base/style/media'

const variants = {
  visible: {
    y: 0,
    transition: { ease: 'easeInOut', staggerChildren: 0.1 },
  },
  hidden: {
    y: '-100%',
  },
  exit: {
    y: '-100%',
    transition: { ease: 'easeInOut', staggerChildren: 0.1 },
  },
}

export default function StoriesStickyHeader({ title }) {
  const [isHeaderVisible, setIsHeaderVisible] = useState(false)
  const { scrollY } = useScroll()

  useEffect(() => {
    return scrollY.onChange((latest) => {
      if (latest >= getWindow().innerHeight) {
        setIsHeaderVisible(true)
      } else {
        setIsHeaderVisible(false)
      }
    })
  }, [scrollY])

  return <AnimatePresence>{isHeaderVisible && <Header title={title} />}</AnimatePresence>
}

function Header({ title }) {
  const { i18n, currentLocale } = useGlobalContext()
  const { scrollYProgress } = useScroll()
  const isDesktop = useBetterMediaQueries({ query: mediaQueries.desktop }, true)

  return (
    <>
      <StickyHeaderContainer animate="visible" exit="exit" initial="hidden" variants={variants}>
        <Content>
          <LeftContent>
            <LogoWrapper>
              <SmartLink data-testid="Stickyheader_Logo_Link" href={'/' + currentLocale}>
                <Logo />
              </SmartLink>
            </LogoWrapper>

            <BackToStories data-testid="Stickyheader_BackToTop" href={`/${currentLocale}/stories`} type="link" iconLeft="IconLeftArrowNew" size="small" color="red">
              {i18n.t('stickyHeader.backToStories')}
            </BackToStories>

            {isDesktop && <Title data-testid="Stickyheader_Title">{title}</Title>}
          </LeftContent>

          <Share>
            <SocialShare title={title} />
          </Share>
        </Content>
        <Progressbar progress={scrollYProgress} />
      </StickyHeaderContainer>
      <BackToTop />
    </>
  )
}

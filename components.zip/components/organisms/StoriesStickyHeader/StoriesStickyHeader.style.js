import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import Button from '@axacom-client/components/atoms/Button/Button'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Typo12 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const StickyHeaderContainer = styled(motion.div)`
  position: fixed;
  display: block;
  background-color: ${colors.white};
  top: 0;
  left: 0;
  width: 100%;
  z-index: 50;
`

export const BackToStories = styled(Button)`
  margin-left: 35px;
  white-space: nowrap;

  & svg {
    height: 10px;
    margin-right: 10px;
  }

  ${media.tablet`
    margin-left: 50px;
  `}
`

export const Content = styled.div`
  display: flex;
  align-items: center;
  flex-direction: row;
  padding: 10px 80px 10px 20px;
`

export const LeftContent = styled.div`
  display: flex;
  align-items: center;
  flex-direction: row;
  width: 100%;
`

export const Share = styled.div`
  display: flex;
  align-items: center;
  position: absolute;
  right: 0;
  top: 0;
  flex-direction: column;
  z-index: 100;
`

export const LogoWrapper = styled.a`
  width: 48px;
  height: 48px;
  display: block;
`

export const Title = styled.h2`
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-left: 50px;
  margin-bottom: 0;
  ${Typo12}
  ${media.desktopVeryLarge`
    margin-left:0;
    text-align: center;
    padding-left: 20px;
    padding-right: 150px; // illusion of center
  `}
`

import { mandatoryFieldRule } from '../../utils/FieldValidation'

export default [
  mandatoryFieldRule({ mandatoryFields: ['latestPressReleasesTitle', 'latestPressReleasesLinkName', 'latestPressReleasesLink', 'nextEventsTitle', 'nextEventsLinkName', 'nextEventsLink'] }),
]

import styled from 'styled-components'

import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'

import Button from '@axacom-client/components/atoms/Button/Button'

export const CategoryTitle = styled.h2`
  margin: 0;
  margin-bottom: 8px;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 24px;
  line-height: 32px;

  ${media.tablet`
    font-size: 40px;
    line-height: 48px;
  `}

  ${media.desktopLarge`
    font-size: 32px;
    line-height: 40px;
  `}

  ${media.desktopVeryLarge`
    font-size: 39px;
  `}
`

export const LatestPrAndNextEventsContainer = styled.div`
  padding: 64px 0;

  ${media.desktopLarge`
    display: flex;
    gap: 1.5rem;
  `}
`

export const PressReleasesContainer = styled.div`
  margin-bottom: 48px;

  ${media.desktopLarge`
    flex: 1 1 50%;
  margin-bottom: 0;
  `}
`

export const SubCategoryLink = styled(Button)`
  margin-bottom: 8px;

  ${media.desktopLarge`
    margin-bottom: 24px;
  `}

  ${media.desktopVeryLarge`
    margin-bottom: 32px;
  `}
`

export const PressReleaseItemContainer = styled.a`
  display: block;
  color: ${colors.grayDarker};
  border-bottom: 1px solid ${colors.grayLighter};

  &:last-of-type {
    border-bottom: none;
  }

  &:hover {
    color: inherit;
  }
`

export const PressReleaseItemInnerContainer = styled.div`
  transition: transform 300ms ease-in, opacity 200ms linear;
  padding: 24px 16px;

  &:focus,
  &:hover {
    transform: translateX(10px);
  }

  ${media.tablet`
    display: flex;
    padding-left: 0;
  `}
`

export const PressReleaseItemDate = styled.div`
  margin-bottom: 8px;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  font-size: 14px;
  line-height: 18px;
  letter-spacing: 1px;
  text-transform: uppercase;
  color: ${colors.grayDarker};

  ${media.tablet`
    flex: 0 0 130px;
    padding: 0.3rem 1rem 1.5rem 0;
  `}

  ${media.desktopVeryLarge`
    font-size: 15px;
  `}
`

export const PressReleaseItemTitle = styled.h3`
  margin: 0;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 24px;
  line-height: 32px;

  ${media.desktopVeryLarge`
    font-size: 32px;
    line-height: 41.6px;
  `}
`

export const EventsContainer = styled.div`
  ${media.desktopLarge`
    flex: 1 1 50%;
  `}
`

export const EventItemContainer = styled.a`
  display: block;
  color: ${colors.grayDarker};
  margin: 24px 0;
  padding: 24px;
  background: ${colors.grayLightest};

  &:first-of-type {
    margin-top: 0;
  }

  &:hover {
    color: ${colors.grayDark};
  }
`

export const EventItemSurtextContainer = styled.div`
  margin-bottom: 8px;
`

export const EventItemDate = styled.span`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  font-size: 14px;
  line-height: 18px;
  letter-spacing: 1px;
  color: ${colors.grayDarker};
`

export const EventItemTitle = styled.h3`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  font-size: 24px;
  line-height: 32px;

  ${media.desktopVeryLarge`
    font-size: 32px;
  `}
`

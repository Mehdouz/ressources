import React from 'react'
import { string, array, object } from 'prop-types'

import ResponsiveContainer from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer'

import {
  CategoryTitle,
  SubCategoryLink,
  LatestPrAndNextEventsContainer,
  PressReleasesContainer,
  PressReleaseItemContainer,
  PressReleaseItemInnerContainer,
  PressReleaseItemDate,
  PressReleaseItemTitle,
  EventsContainer,
  EventItemContainer,
  EventItemSurtextContainer,
  EventItemDate,
  EventItemTitle,
} from './LatestPrAndNextEvents.style'

function LatestPrAndNextEvents({
  latestPressReleasesTitle,
  latestPressReleasesLinkName,
  latestPressReleasesLink,
  nextEventsTitle,
  nextEventsLinkName,
  nextEventsLink,
  latestPressReleases,
  nextEvents,
}) {
  return (
    <ResponsiveContainer mobile tablet desktop largeDesktop veryLargeDesktop>
      <LatestPrAndNextEventsContainer data-testid="LatestPrAndNextEvents__Container">
        <PressReleasesContainer data-testid="LatestPrAndNextEvents__PressReleasesContainer">
          <CategoryTitle data-testid="LatestPrAndNextEvents__PressReleasesTitle">{latestPressReleasesTitle}</CategoryTitle>
          <SubCategoryLink color="red" type="link" iconRight="IconArrowRight" href={latestPressReleasesLink?.url} data-testid="LatestPrAndNextEvents__PressReleasesLink">
            {latestPressReleasesLinkName}
          </SubCategoryLink>
          {latestPressReleases?.map((item, index) => (
            <PressReleaseItemContainer key={`press-release-item-${index}-${item.title}`} href={item.url} data-testid="LatestPrAndNextEvents__PressReleaseItemContainer">
              <PressReleaseItemInnerContainer data-testid="LatestPrAndNextEvents__PressReleaseItemInnerContainer">
                <PressReleaseItemDate data-testid="LatestPrAndNextEvents__PressReleaseItemDate">{item.date}</PressReleaseItemDate>
                <PressReleaseItemTitle data-testid="LatestPrAndNextEvents__PressReleaseItemTitle">{item.title}</PressReleaseItemTitle>
              </PressReleaseItemInnerContainer>
            </PressReleaseItemContainer>
          ))}
        </PressReleasesContainer>
        {!!nextEvents?.length && (
          <EventsContainer data-testid="LatestPrAndNextEvents__EventsContainer">
            <CategoryTitle data-testid="LatestPrAndNextEvents__EventsTitle">{nextEventsTitle}</CategoryTitle>
            <SubCategoryLink color="red" type="link" iconRight="IconArrowRight" href={nextEventsLink?.url} data-testid="LatestPrAndNextEvents__EventsLink">
              {nextEventsLinkName}
            </SubCategoryLink>
            {nextEvents?.map((item, index) => (
              <EventItemContainer key={`event-item-${index}-${item.title}`} href={item.url} data-testid="LatestPrAndNextEvents__EventItemContainer">
                <EventItemSurtextContainer data-testid="LatestPrAndNextEvents__EventItemSurtextContainer">
                  <EventItemDate data-testid="LatestPrAndNextEvents__EventItemDate">{item.date}</EventItemDate>
                </EventItemSurtextContainer>
                <EventItemTitle data-testid="LatestPrAndNextEvents__EventItemTitle">{item.title}</EventItemTitle>
              </EventItemContainer>
            ))}
          </EventsContainer>
        )}
      </LatestPrAndNextEventsContainer>
    </ResponsiveContainer>
  )
}

LatestPrAndNextEvents.propTypes = {
  latestPressReleasesTitle: string,
  latestPressReleasesLinkName: string,
  latestPressReleasesLink: object,
  nextEventsTitle: string,
  nextEventsLinkName: string,
  nextEventsLink: object,
  latestPressReleases: array,
  nextEvents: array,
}

export default LatestPrAndNextEvents

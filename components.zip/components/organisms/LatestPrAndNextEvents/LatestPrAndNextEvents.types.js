import { Link, Text } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $latestPressReleasesTitle: Text('Latest Press Releases Title (Mandatory)', 'Write your title here'),
  $latestPressReleasesLinkName: Text('Latest Press Releases Link Name (Mandatory)', 'Write your text here'),
  $latestPressReleasesLink: Link('Latest Press Releases Link (Mandatory)', null, null, true, 'Link (web/document/media)'),
  $nextEventsTitle: Text('Next Events Title (Mandatory)', 'Write your title here'),
  $nextEventsLinkName: Text('Next Events Link Name (Mandatory)', 'Write your text here'),
  $nextEventsLink: Link('Next Events Link (Mandatory)', null, null, true, 'Link (web/document/media)'),
}

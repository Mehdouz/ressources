import { Group, Image, Link, Text } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $commitmentCarouselSurtitle: Text('Commitment Carousel Surtitle', 'Write your title here'),
  $commitmentCarouselTitle: Text('Commitment Carousel Title', 'Write your title here'),
  $commitmentCarouselCards: Group(
    {
      image: Image('Image (800x800px) (Mandatory)', { width: 800, height: 800 }),
      surtitle: Text('Card Surtitle (Mandatory)', 'Write your title here'),
      title: Text('Card Title (Mandatory)', 'Write your title here'),
      link: Link('Card Link (Mandatory)', null, null, true, 'Link (web/document/media)'),
    },
    'Commitment Carousel Cards (2 items minimum)',
    true
  ),
}

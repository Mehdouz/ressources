export const DEVICE_DEFAULT = 'default'
export const DEVICE_MOBILE = 'mobile'
export const DEVICE_DESKTOP = 'desktop'
export const RESIZE_ACTION = 'resize'
export const PAGINATION_ACTION = 'pagination'

export const PAGE_SIZES = {
  [DEVICE_DEFAULT]: 3,
  [DEVICE_MOBILE]: 1,
  [DEVICE_DESKTOP]: 4,
}

export function getDevice({ isMobile, isVeryLargeDesktop }) {
  if (isMobile) {
    return DEVICE_MOBILE
  } else if (isVeryLargeDesktop) {
    return DEVICE_DESKTOP
  } else {
    return DEVICE_DEFAULT
  }
}

export function calculatePages(cards, pageSize) {
  return cards.reduce((allPages, currentCard, currentIndex) => {
    if (currentIndex % pageSize === 0) {
      allPages.push([currentCard])
    } else {
      allPages[allPages.length - 1].push(currentCard)
    }

    return allPages
  }, [])
}

export function getInitialState({ cards }) {
  return getNewState({
    device: DEVICE_DEFAULT,
    cards: cards.map((card) => ({
      imageUrl: card?.image?.main?.url,
      linkUrl: card?.link?.url,
      surtitle: card?.surtitle,
      title: card?.title,
    })),
  })
}

export function getNewState({ device, cards }) {
  const pageSize = PAGE_SIZES[device] || PAGE_SIZES[DEVICE_DEFAULT]

  return {
    page: 1,
    pageSize,
    cards,
    pages: calculatePages(cards, pageSize),
    hasPaginationComponent: cards.length > pageSize,
    device,
    translateValue: 0,
  }
}

export function reducer(state, action) {
  switch (action.type) {
    case RESIZE_ACTION:
      return getNewState({ device: action.payload, cards: state.cards })
    case PAGINATION_ACTION:
      return {
        ...state,
        page: action.payload,
        translateValue: -(action.payload - 1) * 100,
      }
    default:
      return state
  }
}

export function resizeAction({ device }) {
  return {
    type: RESIZE_ACTION,
    payload: device,
  }
}

export function paginationAction({ pageNumber }) {
  return {
    type: PAGINATION_ACTION,
    payload: pageNumber,
  }
}

import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'

import { colors, font } from '@axacom-client/base/style/variables'
import { Typo12 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { multilineEllipsis } from '@axacom-client/base/style/utils'
import media from '@axacom-client/base/style/media'

export const CommitmentCarrouselContainer = styled.div`
  padding-top: 50px;
  padding-bottom: 32px;
`

export const Surtitle = styled.h3`
  text-align: center;
  text-transform: uppercase;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 18px;
  letter-spacing: 1px;
  margin: 0 auto;
  padding: 1rem 0;
`

export const Title = styled.h2`
  ${Typo12}

  text-align: center;
  margin: 0 32px 40px 32px;

  ${media.tablet`
    margin: 0 100px 40px 100px;
  `}

  ${media.desktop`
    font-size: 32px;
    line-height: 40px;
  `}

  ${media.desktopVeryLarge`
    width: 1200px;
    margin: 0 auto 40px auto;
    font-size: 48px;
    line-height: 48px;
  `}
`

export const CardsContainer = styled.div`
  display: inline-flex;
  overflow: hidden;
  margin-bottom: 15px;
`

export const CardsPageContainer = styled(motion.div)`
  display: flex;
  flex: 0 0 100vw;
  justify-content: center;

  ${media.tablet`
    gap: 1rem;
  `}

  ${media.desktop`
    gap: 1.5rem;
  `}
`

export const Card = styled.a`
  position: relative;

  // Flex-basis : (containerMaxWidth - maxGaps * flexGap) / maxCards
  ${media.tablet`
    flex-basis: calc((100% - 2rem) / 3);
  `}

  ${media.desktop`
    flex-basis: calc((100% - 3rem) / 3);
  `}

  ${media.desktopVeryLarge`
    flex-basis: calc((1600px - 4.5rem) / 4);
  `}
`

export const CardImage = styled.img`
  // This filter enables better readability for texts on top
  filter: contrast(66%) brightness(0.9);
  // Minimum image size is 767px, to cover 100vw in mobile
  // before switching to tablet design at breakpoint 768px.
  //
  // The next line ensures even a smaller image works fine
  // except for the quality loss (this should not happen).
  width: 800px;
`

export const CardTextContainer = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  padding: 40px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  color: ${colors.white};

  ${media.tablet`
    padding: 24px;
  `}

  ${media.desktop`
    padding: 40px;
  `}
`

export const CardSurtitle = styled.h3`
  text-transform: uppercase;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 18px;
  letter-spacing: 1px;
  color: ${colors.white};
  ${multilineEllipsis({ maxLines: 2 })}

  ${media.desktopVeryLarge`
    font-size: 16px;
  `}
`

export const CardTitle = styled.h2`
  ${Typo12}

  ${multilineEllipsis({ maxLines: 3 })}

  margin-bottom: 1.5rem;

  ${media.phone`
    font-size: 32px;
    line-height: 40px;
  `}

  ${media.tablet`
    font-size: 18px;
    line-height: 24px;
    margin-bottom: 1rem;
  `}

  ${media.desktop`
    font-size: 32px;
    line-height: 40px;
    margin-bottom: 1.5rem;
  `}

  ${media.desktopVeryLarge`
    font-size: 39px;
  `}
`

export const CardLinkButtonContainer = styled.div``

export const CardLinkButton = styled.div`
  text-transform: uppercase;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 16px;
  letter-spacing: 1px;
  color: ${colors.white};

  &::after {
    content: '\u2192';
    margin-left: 0.5rem;
    font-family: ${font.fontFamilyBase};
    font-weight: ${font.weight.semiBold};
    font-size: 18px;
  }
`

import { mandatoryFieldRule } from '../../utils/FieldValidation'

export default [
  mandatoryFieldRule({ mandatoryFields: ['commitmentCarouselCards'] }),
  (document) => document.commitmentCarouselCards.length >= 2,
  (document) => document.commitmentCarouselCards.every((item) => item?.image && item?.surtitle && item?.title && item?.link?.url),
]

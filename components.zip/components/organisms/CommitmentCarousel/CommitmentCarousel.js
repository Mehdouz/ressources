import React, { useReducer, useCallback, useEffect } from 'react'
import { string, array } from 'prop-types'
import { useMediaQuery } from 'react-responsive'

import { mediaQueries } from '@axacom-client/base/style/media'
import useLinkTarget from '@axacom-client/hooks/useLinkTarget'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Pagination from '@axacom-client/components/molecules/Pagination/Pagination'

import { getDevice, reducer, getInitialState, resizeAction, paginationAction } from './CommitmentCarousel.utils'
import {
  CommitmentCarrouselContainer,
  Surtitle,
  Title,
  Card,
  CardImage,
  CardTextContainer,
  CardSurtitle,
  CardTitle,
  CardLinkButton,
  CardLinkButtonContainer,
  CardsContainer,
  CardsPageContainer,
} from './CommitmentCarousel.style'

function CommitmentCarousel({ surtitle, title, cards }) {
  const { i18n } = useGlobalContext()

  // Do NOT use useMediaQuery results before first rendering,
  // in order to prevent rehydration errors
  //
  // See: https://observablehq.com/@werehamster/avoiding-hydration-mismatch-when-using-react-hooks
  const isMobile = useMediaQuery({ query: mediaQueries.phone })
  const isVeryLargeDesktop = useMediaQuery({ query: mediaQueries.desktopVeryLarge })
  const device = getDevice({ isMobile, isVeryLargeDesktop })

  const [state, dispatch] = useReducer(reducer, { cards }, getInitialState)

  useEffect(() => {
    dispatch(resizeAction({ device }))
  }, [device])

  const onPageChange = useCallback(
    async (pageNumber) => {
      dispatch(paginationAction({ pageNumber }))
    },
    [dispatch]
  )

  return (
    <CommitmentCarrouselContainer data-testid="CommitmentCarrouselContainer">
      {surtitle && <Surtitle data-testid="CommitmentCarrouselSurtitle">{surtitle}</Surtitle>}
      {title && <Title data-testid="CommitmentCarrouselTitle">{title}</Title>}
      <CardsContainer data-testid="CommitmentCarrouselCardsContainer">
        {state.pages.map((page, index) => (
          <CardsPageContainer key={`page-${index}`} animate={{ x: `${state.translateValue}vw` }} transition={{ type: 'spring', duration: 0.6 }} data-testid="CommitmentCarrouselCardsPageContainer">
            {page.map((card, index) => (
              <Card key={`card-${index}`} href={card.linkUrl} target={useLinkTarget(card.linkUrl)} data-testid="CommitmentCarrouselCard">
                <CardImage src={card.imageUrl} data-testid="CommitmentCarrouselCardImage" />
                <CardTextContainer data-testid="CommitmentCarrouselCardTextContainer">
                  <CardSurtitle data-testid="CommitmentCarrouselCardSurtitle">{card?.surtitle}</CardSurtitle>
                  <CardTitle data-testid="CommitmentCarrouselCardTitle">{card?.title}</CardTitle>
                  <CardLinkButtonContainer data-testid="CommitmentCarrouselCardLinkButtonContainer">
                    <CardLinkButton data-testid="CommitmentCarrouselCardLinkButton">{i18n?.t('home-v2.commitmentCarousel.readMore')}</CardLinkButton>
                  </CardLinkButtonContainer>
                </CardTextContainer>
              </Card>
            ))}
          </CardsPageContainer>
        ))}
      </CardsContainer>
      {state.hasPaginationComponent && <Pagination currentPage={state.page} totalPages={state.pages.length} onPageChange={onPageChange} />}
    </CommitmentCarrouselContainer>
  )
}

CommitmentCarousel.propTypes = {
  surtitle: string,
  title: string,
  cards: array,
}

export default CommitmentCarousel

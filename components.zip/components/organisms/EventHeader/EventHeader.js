import React, { useState } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import {
  Container,
  Cta,
  DateBlock,
  Day,
  Adress,
  MonthYear,
  StartDateBlock,
  HeaderInfos,
  Title,
  TitleBlock,
  DownloadButton,
  StartingDate,
  Description,
  Panel,
  PanelWrapper,
} from '@axacom-client/components/organisms/EventHeader/EventHeader.style'
import { dateTime, dateTimeZone, getDateTimeZoneName, isDayPassed } from '@axacom-client/services/date-service'
import { useMediaQuery } from 'react-responsive'
import { mediaQueries } from '@axacom-client/base/style/media'
import icalService from '@axacom-server/services/ical-service'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'
import LegacyShare from './LegacyShare'

export default function EventHeader({ title, description, eventTimeStart = '', eventTimeEnd = '', streetAddress, streetAddress2, zipcode, city, country, eventLink, $hasSlices }) {
  const { i18n, currentLocale, bookmarks } = useGlobalContext()
  const [isSharingVisible, setIsSharingVisible] = useState(false)
  const isMobile = useMediaQuery({ query: mediaQueries.phone })
  const isDesktop = useMediaQuery({ query: mediaQueries.desktop })

  // Starting day formating
  const startingDateDay = eventTimeStart ? dateTime(eventTimeStart, 'D', currentLocale) : null
  const startingDateMonthYear = eventTimeStart ? dateTime(eventTimeStart, 'MMMM YYYY', currentLocale) : null

  const { formatedStartingTime, formatedEndingDate, isAvaibleSoon, startingFrom } = formatDate(eventTimeStart, eventTimeEnd)

  const formatedAdress = `${streetAddress ? streetAddress : ''} ${streetAddress2 ? streetAddress2 : ''} ${zipcode ? zipcode : ''} ${city ? city : ''} | ${country ? country : ''}`

  // Event Download Url
  const eventDownloadUrl = icalService.get({ title, city, eventTimeStart, eventTimeEnd, description, eventLink }, i18n.language)

  return (
    <Container data-testid="EventHeader">
      <Cta type="link" color="red" iconLeft="IconArrowLeft" href={bookmarks?.repositoryEvent?.url} data-testid="EventHeader___Breadcrumb">
        {i18n.t('event.viewCalendar')}
      </Cta>
      <CenteredReadingContainer>
        <HeaderInfos>
          {isMobile && eventTimeStart ? (
            <>
              {title && <Title data-testid="EventHeader__Title">{title}</Title>}
              <StartDateBlock>
                <Day>{startingDateDay}</Day>
                <MonthYear>{startingDateMonthYear}</MonthYear>
              </StartDateBlock>
              {formatedStartingTime && (
                <DateBlock>
                  {startingFrom ? (
                    <StartingDate data-testid="EventHeader__StartingDate">{formatedStartingTime}</StartingDate>
                  ) : (
                    <>
                      <StartingDate data-testid="EventHeader__StartingDate">
                        {i18n.t('event.startingTime')}
                        {formatedStartingTime}
                      </StartingDate>
                      {formatedEndingDate && !isAvaibleSoon && (
                        <p data-testid="EventHeader__EndingDate">
                          {i18n.t('event.endingTime')}
                          {formatedEndingDate}
                        </p>
                      )}
                    </>
                  )}
                  {(streetAddress || streetAddress2) && <Adress data-testid="EventHeader__Adress">{formatedAdress}</Adress>}
                </DateBlock>
              )}
            </>
          ) : (
            <>
              <StartDateBlock>
                <Day>{startingDateDay}</Day>
                <MonthYear>{startingDateMonthYear}</MonthYear>
              </StartDateBlock>
              <TitleBlock>
                {title && <Title data-testid="EventHeader__Title">{title}</Title>}
                {formatedStartingTime && (
                  <DateBlock>
                    {startingFrom ? (
                      <StartingDate data-testid="EventHeader__StartingDate">{formatedStartingTime}</StartingDate>
                    ) : (
                      <>
                        <StartingDate data-testid="EventHeader__StartingDate">
                          {i18n.t('event.startingTime')}
                          {formatedStartingTime}
                        </StartingDate>
                        {formatedEndingDate && !isAvaibleSoon && (
                          <p data-testid="EventHeader__EndingDate">
                            {i18n.t('event.endingTime')}
                            {formatedEndingDate}
                          </p>
                        )}
                      </>
                    )}
                    {(streetAddress || streetAddress2) && <Adress data-testid="EventHeader__Adress">{formatedAdress}</Adress>}
                  </DateBlock>
                )}
              </TitleBlock>
            </>
          )}
        </HeaderInfos>
        <PanelWrapper>
          <Panel onMouseLeave={isDesktop ? () => setIsSharingVisible(false) : null}>
            <LegacyShare title={title} setVisible={setIsSharingVisible} isVisible={isSharingVisible} />
            {((eventTimeStart && !isDayPassed(eventTimeStart)) || (eventTimeEnd && !isDayPassed(eventTimeEnd))) && (
              <DownloadButton type="ghost" color="blue" href={eventDownloadUrl} download={title.replace(/\.| /gm, '-')} target="_self">
                {i18n.t('eventBlock.addToCalendar')}
              </DownloadButton>
            )}
          </Panel>
        </PanelWrapper>
        <Description $hasSlices={$hasSlices}>{description}</Description>
      </CenteredReadingContainer>
    </Container>
  )
}

export function getFormattedEndingDate(eventTimeStart, eventTimeEnd, currentLocale, hourFormat) {
  const startDate = (format) => dateTimeZone(eventTimeStart, format, currentLocale)
  const endDate = (format) => dateTimeZone(eventTimeEnd, format, currentLocale)

  if (!eventTimeEnd) {
    return null
  } else if (startDate('DD MMM YYYY') === endDate('DD MMM YYYY')) {
    return `${dateTimeZone(eventTimeEnd, hourFormat, currentLocale)} ${getDateTimeZoneName(eventTimeEnd)}`
  } else {
    return `${dateTime(eventTimeEnd, 'LL', currentLocale)} ${dateTimeZone(eventTimeEnd, hourFormat, currentLocale)} ${getDateTimeZoneName(eventTimeEnd)}`
  }
}

export const formatDate = (eventTimeStart, eventTimeEnd) => {
  const { i18n, currentLocale } = useGlobalContext()
  // Check if event has same timeStart and timeEnd, if so we render "start at"
  const startingFrom = eventTimeStart == eventTimeEnd

  // Check if event has same timeStart and timeEnd and hour is 1 or 2, if so we render "soon at"
  const isAvaibleSoon = !(eventTimeStart.indexOf('00:00:00+0000') === -1) && !(eventTimeEnd.indexOf('00:00:00+0000') === -1)

  // Ending day & starting time formating
  const hourFormat = currentLocale === 'fr' ? 'H:mm' : 'h:mm A'
  const formatedStartingTime = isAvaibleSoon ? i18n.t('event.soon') : `${dateTimeZone(eventTimeStart, hourFormat, currentLocale)} ${getDateTimeZoneName(eventTimeEnd)}`
  const formatedEndingDate = getFormattedEndingDate(eventTimeStart, eventTimeEnd, currentLocale, hourFormat)

  return { formatedStartingTime, formatedEndingDate, isAvaibleSoon, startingFrom }
}

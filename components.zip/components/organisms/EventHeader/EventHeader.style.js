import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import Button from '@axacom-client/components/atoms/Button/Button'
import { colors, font } from '@axacom-client/base/style/variables'
import { Typo2, Typo10, Typo17, Typo40 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { CenteredReadingContainer } from '@axacom-client/components/atoms/CenteredReadingContainer/CenteredReadingContainer'

export const Container = styled(CenteredReadingContainer)`
  padding-top: 32px;
  padding-left: 32px;
  padding-right: 32px;

  ${media.tablet`
    padding-top: 48px;
    padding-left: 0px;
    padding-right: 0px;
  `}

  ${media.desktopVeryLarge`
    padding-top: 64px;
  `}
`

export const Cta = styled(Button)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 16px;
  letter-spacing: 1px;
  margin-bottom: 40px;
`

export const Title = styled.h1`
  ${Typo40}
  text-align: center;
  margin: 0;

  ${media.tablet`
    text-align: left;
  `}
`

export const TitleBlock = styled.div`
  display: flex;
  flex-direction: column;
  margin-left: 2rem;
  flex: 1 1 0;
`

export const HeaderInfos = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;

  ${media.tablet`
    flex-direction: row;
    align-items: start;
    justify-content: start;
  `}
`

export const StartDateBlock = styled.div`
  ${Typo17}
  color: ${colors.white};
  background: ${colors.brandBlue};
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 25px;
  width: 200%;
  margin-top: 25px;

  ${media.tablet`
    width: 150px;
    height: 150px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 0;
  `}

  ${media.desktop`
    width: 160px;
    height: 160px;
  `}
`

export const Day = styled.p`
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 2rem; // 28px
  line-height: 2rem; // 32px

  ${media.tablet`
    width: auto;
    margin-top: 0;
    font-size: 3.625rem; //58px
    line-height: 3.75rem; //60px
  `}

  ${media.desktopLarge`
    font-size: 72px;
    line-height: 74px;
  `}
`

export const MonthYear = styled.p`
  ${Typo2}
  text-transform: uppercase;
  font-weight: ${font.weight.bold};
`

export const DateBlock = styled.div`
  ${Typo17}
  color: ${colors.textColor};
  margin-top: 25px;
  text-align: center;
  text-transform: uppercase;

  ${media.tablet`
    text-align:left;
  `}
`

export const StartingDate = styled.p`
  font-weight: ${font.weight.bold};
`

export const Adress = styled.p`
  white-space: break-spaces;
`

export const Description = styled.p`
  ${Typo10}
  margin-top: 35px;
  margin-bottom: ${({ $hasSlices }) => ($hasSlices ? '0px' : '35px')};

  ${media.tablet`
    margin-top: 75px;
    margin-bottom: ${({ $hasSlices }) => ($hasSlices ? '0px' : '85px')};
  `};
`

export const ShareBlock = styled.div`
  display: flex;
  flex-direction: column;
  position: relative;
  z-index: 20;

  ${media.tablet`
    flex: 1 1 0;
  `}
`

export const ShareContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 15px;
  position: absolute;
  top: 68px;
  width: 100%;
  z-index: 10;
`

export const PanelWrapper = styled.div`
  margin-top: 35px;
  width: 100%;

  ${media.tablet`
    position: relative;
  `}

  ${media.desktop`
    position: absolute;
    height: 500px;
    right: -170px;
    top: 0;
    width: 160px;
    margin-top: 0;
  `}

  ${media.desktopLarge`
    right: -200px;
    width: 190px;
  `}
`

export const Panel = styled.div`
  position: sticky;
  top: 10px;
  display: flex;
  flex-direction: column;

  ${media.tablet`
    flex-direction: row;
    gap: 20px;
  `}

  ${media.desktop`
    flex-direction: column;
    display: block;
    gap: 0;
  `}
`

export const DownloadButton = styled(Button)`
  width: 100%;
  font-weight: ${font.weight.bold};
  height: 50px;
  margin-bottom: 16px;

  ${media.tablet`
    flex: 1 1 0;
  `}
`

export const ShareButton = styled(Button)`
  position: relative;
  z-index: 20;
  margin-bottom: 18px;
  font-weight: ${font.weight.bold};
  height: 50px;
`

export const ShareLink = styled(Button)`
  width: 100%;
  height: 50px;
  border-bottom: 0;
  background: ${colors.axaBlue500};
  color: ${colors.brandBlue};

  & span {
    display: flex;
    flex-direction: row;
    align-items: center;
    padding: 0;
    margin: 0;
    height: 100%;
    width: 100%;
    justify-content: space-between;
  }

  & svg path {
    transition: fill 0.3s ease;
  }

  &:hover {
    & div {
      background: ${colors.axaBlue400};

      & svg path {
        fill: ${colors.white};
      }
    }
  }
`

export const SocialText = styled.p`
  padding: 0 20px;
  text-transform: uppercase;
  ${Typo17}
  font-weight: ${font.weight.bold};
  width: 100%;

  ${media.tablet`
    width: calc(100% - 50px);
  `}
`

export const IconContainer = styled.div`
  background: ${colors.axaBlue300};
  position: absolute;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  width: 50px;
  transition: background 0.3s ease;
`

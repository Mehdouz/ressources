import React from 'react'
import { ShareBlock, ShareContainer, ShareButton, ShareLink, SocialText, IconContainer } from '@axacom-client/components/organisms/EventHeader/EventHeader.style'
import svg from '@axacom-client/base/svg'
import { colors } from '@axacom-client/base/style/variables'
import { useShare } from '@axacom-client/hooks/useShare'
import { AnimatePresence, motion } from 'framer-motion/dist/framer-motion'
import { useMediaQuery } from 'react-responsive'
import { mediaQueries } from '@axacom-client/base/style/media'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

const variants = {
  visible: {
    transition: { ease: [0.25, 1, 0.5, 1], staggerChildren: 0.03 },
  },
}

const variantsLinks = {
  visible: {
    y: 0,
    transition: { duration: 0.3, ease: [0.25, 1, 0.5, 1] },
  },
  hidden: (index) => {
    return { y: -65 * (index + 1) }
  },
  exit: (index) => {
    return { y: -65 * (index + 1), transition: { ease: 'easeOutQuart' } }
  },
}

export default function LegacyShare({ title, isVisible, setVisible }) {
  const { i18n } = useGlobalContext()
  const isDesktop = useMediaQuery({ query: mediaQueries.desktop })

  return (
    <ShareBlock onClick={isDesktop ? null : () => setVisible(!isVisible)} onMouseEnter={isDesktop ? () => setVisible(true) : null}>
      <ShareButton data-testid="PressReleaseHeader__ShareButton" color="blue">
        {i18n.t('pressrelease.share')}
      </ShareButton>
      <AnimatePresence>
        {isVisible && (
          <motion.div animate="visible" exit="exit" initial="hidden" variants={variants}>
            <Share title={title} />
          </motion.div>
        )}
      </AnimatePresence>
    </ShareBlock>
  )
}

function Share({ title }) {
  const socials = ['facebook', 'twitter', 'linkedin']
  const icons = { facebook: svg.IconSocialFacebook, twitter: svg.IconSocialTwitter, linkedin: svg.IconSocialLinkedin }

  const { onShare } = useShare({ title })

  return (
    <ShareContainer>
      {socials.map((social, index) => {
        const Icon = icons[social]
        return (
          <ShareLink
            key={index}
            data-key={social}
            type="primary"
            color="blue"
            data-test-id="SocialShare_Link"
            className={'network-allowed'}
            data-analytics={`{"block_name":"share_button::${social}", "event_type":"A"}`}
            onClick={() => onShare(social)}
            custom={index}
            variants={variantsLinks}
          >
            <SocialText>{social}</SocialText>
            <IconContainer>
              <Icon color={colors.brandBlue} width={20} height={20} />
            </IconContainer>
          </ShareLink>
        )
      })}
    </ShareContainer>
  )
}

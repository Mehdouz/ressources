import React from 'react'
import styled from 'styled-components'
import { i18n } from '@i18n-axa'
import log from '@axacom-client/logger'
import media from '@axacom-client/base/style/media'
import Footer from '@axacom-client/components/organisms/FooterV2/FooterV2'
import HeaderV2 from '@axacom-client/components/organisms/HeaderV2/HeaderV2'
import SurHeader from '@axacom-client/components/organisms/SurHeader/SurHeader'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { getFooter, getHeaderV2 } from '@axacom-client/repositories/documents'
import { getStockPrices } from '@axacom-client/repositories/stock-prices'
import { sliceLeftMenu, sliceRightMenu, sliceHighlights } from '@axacom-client/services/header-service'

const LayoutWrapper = styled.div`
  overflow: hidden;

  ${media.desktop`
    overflow: visible;
  `};
`

export default function Layout({ header, footer, stockPrices, children }) {
  const { features } = useGlobalContext()

  return (
    <LayoutWrapper>
      <SurHeader stockPrices={stockPrices} />
      {header && <HeaderV2 menu={header} stockPrices={stockPrices} />}
      <a id="content" tabIndex="-1" />
      {children}
      {footer && <Footer {...footer} features={features} />}
    </LayoutWrapper>
  )
}

export async function getLayoutProps() {
  const language = i18n.language
  const [header, footer, stockPrices, pageProps] = await Promise.all([getHeaderV2(language), getFooter(language), getStockPrices()])

  log.debug('[Layout] got header/footer/stockPrices/pageProps data')
  header.leftMenu = await sliceLeftMenu()(header?.leftMenu, language)
  header.rightMenu = await sliceRightMenu()(header?.rightMenu, language)

  // Return only 3 highlights, slice otherwise
  header.leftMenu = sliceHighlights(header?.leftMenu, 3)
  header.rightMenu = sliceHighlights(header?.rightMenu, 2)

  return { ...pageProps, header, footer, stockPrices, namespacesRequired: ['common'] }
}

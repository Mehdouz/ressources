import React from 'react'
import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import { colors } from '@axacom-client/base/style/variables'
import { number, string } from 'prop-types'

const ProgressbarContainer = styled(motion.div)`
  transform-origin: 0%;
  background-color: ${({ $color }) => $color};
  display: block;
  height: ${({ $size }) => $size}px;
`

export default function Progressbar({ size = 3, progress = 0, color = colors.axaBlue100, ...rest }) {
  return <ProgressbarContainer data-testid="Progressbar" {...rest} style={{ scaleX: progress }} $size={size} $color={color} />
}

Progressbar.propTypes = {
  size: number,
  color: string,
}

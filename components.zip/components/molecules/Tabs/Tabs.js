import React, { useContext, createContext, useState, useEffect } from 'react'

import { func, node, number, oneOfType, string } from 'prop-types'

/**
 * #Example
 *
 *  const Example = () => {
 *    return (
 *      <>
 *        <Tabs activeTab={1}>
 *          <TabPanel tabId={1}>
 *            <h1>Bonjour premier</h1>
 *          </TabPanel>
 *          <TabPanel tabId={2}>
 *            <h1>Bonjour second</h1>
 *          </TabPanel>
 *        </Tabs>
 *      </>
 *    )
 *  }
 *
 * TODO: Add <TabList />, <Tab/> and <TabPanels /> similar to reach ui
 * source: https://reach.tech/tabs/
 *
 */
function Tabs({ activeTab = 0, ...rest }) {
  const [tab, setTab] = useState(activeTab)

  useEffect(() => {
    setTab(activeTab)
  }, [activeTab])

  return <TabsProvider tab={tab} setTab={setTab} {...rest} />
}

Tabs.propTypes = { activeTab: oneOfType([string, number]), children: node.isRequired }

export default Tabs

export const TabsContext = createContext()

// simple provider with only 2 values: { tab, setTab }
export function TabsProvider({ tab, setTab, ...rest }) {
  return <TabsContext.Provider value={{ tab, setTab }} {...rest} />
}

TabsProvider.propTypes = { tab: oneOfType([string, number]), setTab: func, children: node.isRequired }

// expose context as hooks
export const useTabs = () => useContext(TabsContext)

export function TabPanel({ tabId, children }) {
  const { tab } = useTabs()

  if (tab === tabId) return <>{children}</>
  return null
}

TabPanel.propTypes = { tabId: oneOfType([string, number]), children: node.isRequired }

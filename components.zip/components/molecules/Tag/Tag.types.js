export default {
  $title: {
    type: 'Text',
    config: {
      placeholder: `Tag's title`,
      label: 'Title',
    },
  },
}

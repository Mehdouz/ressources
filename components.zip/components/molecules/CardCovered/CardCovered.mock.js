export default {
  _meta: {
    text: 'StructuredText',
    cta_label: 'StructuredText',
    cta_link: 'Link.document',
    image: 'Image',
  },
  text: [
    {
      type: 'paragraph',
      text: 'Renforcer notre présence au cœur de l’assurance',
      spans: [],
    },
  ],
  cta_link: {
    id: 'WUouOBAAALIqqKj3',
    type: 'article-v2',
    target: 'document',
    isBroken: false,
    url: '/not-populated',
  },
  image: {
    main: {
      dimensions: {
        width: 1920,
        height: 1280,
      },
      alt: '',
      copyright: '',
      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/3c420ec4d68452004c5a6f6a3cc091b92fb6f890_emedic-2.jpg',
    },
    views: {
      small: {
        dimensions: {
          width: 768,
          height: 432,
        },
        alt: '',
        copyright: '',
        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/feec5d6757653fd6829d396f545b12248b00211a_emedic-2.jpg',
      },
      medium: {
        dimensions: {
          width: 970,
          height: 545,
        },
        alt: '',
        copyright: '',
        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/2dc38e4852f0d74377ab9d9961894175957dffb6_emedic-2.jpg',
      },
    },
  },
}

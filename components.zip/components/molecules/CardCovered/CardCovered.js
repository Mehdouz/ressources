import React, { useState } from 'react'
import { array, object, string } from 'prop-types'

import { useGlobalContext } from './../../../store/GlobalContext'

import Button from '../../atoms/Button/Button'
import Text from '../Text/Text'
import styled, { css } from 'styled-components'
import media from '../../../base/style/media'
import { colors } from '../../../base/style/variables'
import { fadeIn } from '../../../base/style/animation'
import { Typo28 } from '../../../base/style/typoStyle/typoStyle'

const hovered = css`
  &:before {
    background: linear-gradient(#fff, #fff);
    opacity: 0.88;
    transition: opacity 0.5s ease-out;
  }
`

const CardContainer = styled.div`
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  color: ${colors.white};
  display: block;
  width: 100%;
  position: relative;

  animation: ${fadeIn} 0.5s ease-in;

  &:before {
    content: '';
    display: block;
    padding-top: 80%;

    background: linear-gradient(${colors.textColor}, ${colors.textColor});
    opacity: 0.39;
  }

  ${(props) => (props.isHovered ? hovered : '')}
`

const CardWrapper = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;

  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: column;

  pointer-events: none;

  padding: 40px 30px;

  ${media.tablet`
     padding: 35px;
  `}
`
const CardCaption = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
`

const CardText = styled(Text)`
  ${Typo28}
  text-align: center;
  margin: 0;
  transition: color 0.5s ease-out;
  color: ${(props) => (props.isHovered ? colors.textColor : colors.white)};
`
const CardButton = styled(Button)`
  flex-shrink: 0;
`

const CardCovered = ({ text, image, ctaLabel, ctaLink, as, dataTestid }) => {
  const { i18n } = useGlobalContext()
  const [isHovered, setHovered] = useState(false)
  let attrs = {}
  if (as && as === 'a') {
    attrs = {
      as,
      href: ctaLink?.url || '/',
      target: ctaLink?.target === 'web' ? '_blank' : '_self',
    }
  }

  return (
    <CardContainer
      style={{ ...(image && { backgroundImage: `url(${image.main.url})` }) }}
      image={image}
      isHovered={isHovered}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      {...attrs}
      data-testid={dataTestid || 'CardCovered'}
    >
      <CardWrapper>
        <CardCaption>
          <CardText isHovered={isHovered} data-testid="CardContainerText">
            {text}
          </CardText>
        </CardCaption>
        <CardButton
          tabIndex="-1"
          type={isHovered ? 'primary' : 'ghost'}
          color={isHovered ? 'red' : 'white'}
          ariaLabel={!ctaLabel ? `${i18n.t('suggested.read')}, ${text}` : ''}
          size="medium"
          style={{ flexShrink: 0 }}
          data-testid="CardContainerButtonRead"
        >
          {ctaLabel || i18n.t('suggested.read')}
        </CardButton>
      </CardWrapper>
    </CardContainer>
  )
}

export default CardCovered

CardCovered.propTypes = {
  image: object,
  text: array,
  ctaLabel: string,
  ctaLink: object,
  as: string,
  dataTestid: string,
}

CardCovered.defaultProps = {}

import styled from 'styled-components'
import Button from '@axacom-client/components/atoms/Button/Button'
import media from '@axacom-client/base/style/media'
import { font, colors } from '@axacom-client/base/style/variables'
import { Typo12, Typo32 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const Container = styled.div`
  padding: 40px;
  background-color: ${colors.grey100};
  border: 1px solid ${colors.grey200};

  ${media.tablet`
    width: 100%;
  `}
`

export const SubscribeText = styled.div`
  ${media.tablet`
    width: 50%;
  `}

  ${media.desktop`
    width: 100%;
  `}
`

export const Content = styled.div`
  ${media.tablet`
    width: 80%;
    margin: 0 auto;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
  `}

  ${media.desktop`
    width: 100%;
    display: block;
  `}
`

export const Title = styled.div`
  ${Typo12};
  margin-bottom: 10px;
`

export const Cta = styled(Button)`
  ${media.tablet`
    width: 45%;
  `}
`

export const Text = styled.div`
  ${Typo32};
  font-weight: ${font.weight.regular};
  margin-bottom: 40px;

  ${media.tablet`
    margin-bottom: 0;
  `}

  ${media.desktop`
    margin-bottom: 40px;
  `}
`

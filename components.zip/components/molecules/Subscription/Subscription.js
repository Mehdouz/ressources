import React from 'react'
import { string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Container, Content, SubscribeText, Title, Text } from './Subscription.style'
import ModalNewsletter from '@axacom-client/components/organisms/ModalNewsletter/ModalNewsletter'

export default function Subscription({ title, text, ctaText, ...rest }) {
  const { i18n } = useGlobalContext()

  return (
    <Container data-testid="Subscription" {...rest}>
      <Content>
        <SubscribeText>
          <Title data-testid="Subscription__Title">{title}</Title>
          <Text>{text}</Text>
        </SubscribeText>
        <ModalNewsletter
          data-testid="Subscription__Cta"
          buttonType="primary"
          buttonColor="red"
          buttonLabel={ctaText}
          checkboxGDPR={i18n.t('newsletterSubscription.checkboxGDPR')}
          defaultValue={{ newsletterChoice: ['article'] }}
        />
      </Content>
    </Container>
  )
}

Subscription.propTypes = {
  title: string,
  text: string,
  ctaText: string,
}

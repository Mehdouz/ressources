import styled from 'styled-components'
import { font, colors } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Typo19 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const FilterContent = styled.div`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 16px;

  ${media.desktop`
    margin-bottom: 65px;
  `}

  ${media.desktop`
    ${({ $isSidebar }) =>
      $isSidebar &&
      `
        justify-content: left;
        gap: 10px;
      `}
  `}
`

export const Filter = styled(Button)`
  display: block;
  border: 1px solid #e5e5e5;
  color: ${({ $isActive }) => ($isActive ? 'white' : '#757575')};
  opacity: ${({ $isLoading }) => ($isLoading ? '0.5' : '1')};
  padding: 8px 16px;
  ${Typo19}
  letter-spacing: 0;
  font-weight: ${font.weight.semiBold};
  background-color: ${({ $isActive }) => ($isActive ? colors.AXABlue : 'white')};
  transition: border 0.3s ease-out;
  height: inherit;

  & span {
    text-transform: capitalize;
    padding: 0;
    margin: 0;
  }

  &:active,
  &:focus {
    outline: 0;
    color: ${({ $isActive }) => ($isActive ? 'white' : '#757575')};
    &:after {
      width: 0;
      color: white;
    }
  }

  &:after {
    background-color: ${colors.AXABlue};
  }

  &:hover {
    color: ${({ $isActive }) => ($isActive ? 'white' : '#757575')};
    border-color: ${colors.AXABlue};
    background-color: ${({ $isActive }) => ($isActive ? colors.AXABlue : 'white')};

    &:after {
      width: ${({ $isActive }) => ($isActive ? '125%' : '0')};
    }
  }

  ${media.desktopVeryLarge`
    ${({ $isSidebar }) =>
      $isSidebar &&
      `
        padding: 20px 45px;
      `}
  `}
`

import React from 'react'
import { array, bool, func } from 'prop-types'
import { Filter, FilterContent } from './FilterList.style'

export default function FilterList({ isLoading, filters, activeFilters, onFilterClick, isSidebar = false }) {
  function handleFilterClick({ id, title }) {
    const thisFilter = activeFilters.filter((filter) => filter.id === id)
    const otherFilters = activeFilters.filter((filter) => filter.id !== id)
    const isFilterActive = thisFilter.length > 0

    const newFilters = isFilterActive ? otherFilters : [{ id, title }, ...activeFilters]

    if (!isLoading) {
      onFilterClick(newFilters)
    }
  }

  return (
    <FilterContent $isSidebar={isSidebar}>
      {filters &&
        filters.map((item, index) => (
          <Filter
            key={index}
            $isActive={activeFilters.some((activeFilter) => item.id === activeFilter.id)}
            onClick={() => handleFilterClick({ id: item.id, title: item.title })}
            type="ghost"
            color="darkGrey"
            $isLoading={isLoading}
            $isSidebar={isSidebar}
          >
            {item.title}
          </Filter>
        ))}
    </FilterContent>
  )
}

FilterList.propTypes = {
  isLoading: bool,
  activeFilters: array,
  filters: array,
  onFilterClick: func,
  isSidebar: bool,
}

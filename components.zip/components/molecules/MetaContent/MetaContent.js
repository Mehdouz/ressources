import React from 'react'
import { object, string } from 'prop-types'
import Head from 'next/head'
import Script from 'next/script'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { getArticleMeta } from '@axacom-client/services/document-service'

export default function MetaContent({ pageProps, fbAppId }) {
  const { domain, env, i18n } = useGlobalContext()
  const { slug, metaContent: metaContentRaw, type, url, url_en, url_fr, seoDescription, tweet, sharingImage, sharingDescription } = pageProps

  const metaContent = metaContentRaw?.[0] ? metaContentRaw?.[0] : metaContentRaw

  const title = getArticleMeta('title', pageProps) || slug
  const description = metaContent?.seoDescription || seoDescription || metaContent?.summary?.[0]?.text || metaContent?.sharingDescription || sharingDescription || i18n.t('meta.social.description')
  const socialImage =
    metaContent?.socialImage?.split('?')[0] || (metaContent?.sharingImage || sharingImage)?.main?.url?.split('?')[0] || `${domain}/base/images/social-network/default_social_image.jpg`

  const isLocal = env === 'development'
  const isUatOrPreProd = ['uat.axa.com', 'preprod.axa.com'].some((host) => domain.includes(host))

  return (
    <>
      <Script
        dangerouslySetInnerHTML={{
          __html: `
          window.tc_vars = {
            _env_country: '',
            _env_work: '${env === 'production' ? 'production' : 'development'}',
            _env_language: '${i18n.language}',
            page_name: "${metaContent?.sectionReferrer ? `${metaContent?.sectionReferrer}::${title}` : title}",
            page_template: "${metaContent?.sectionReferrer || type}",
            title: "${title}",
            title_en: "${url_en}",
            title_fr: "${url_fr}",
          }`,
        }}
      />
      {isLocal ? (
        <>
          <Script
            src="https://cdn.cookielaw.org/scripttemplates/otSDKStub.js"
            data-document-language="true"
            type="text/javascript"
            charSet="UTF-8"
            data-domain-script="4b0fe946-c84f-4b04-920e-3b5dea970d86-test"
          />
          <Script type="text/javascript" dangerouslySetInnerHTML={{ __html: 'function OptanonWrapper() {}' }} />
        </>
      ) : (
        <>
          <Script type="text/javascript" src="https://cdn.tagcommander.com/2149/tc_AXAcom_5.js"></Script>
          <Script type="text/javascript" src={`https://cdn.tagcommander.com/2149${isUatOrPreProd ? '/uat' : ''}/tc_AXAcom_7.js`}></Script>
        </>
      )}
      <Head>
        <title>{title && `${title} | `}AXA</title>
        <meta name="description" content={description} />

        {/* Google site verification */}
        <meta name="google-site-verification" content="RHv0INirqvzMYljG16nGxHmIK2Y5-o3Un79IQ2hcyJQ" />
        <meta property="fb:app_id" content={fbAppId} />

        {/* Open Graph Metas */}
        <meta property="og:title" content={title} />
        <meta property="og:site_name" content="AXA.com" />
        <meta property="og:url" content={domain + url} />
        <meta property="og:type" content="website" />
        <meta property="og:description" content={description} />
        <meta property="og:image" content={socialImage} />
        <meta property="og:locale" content={i18n.language} />

        {/* Twitter Metas */}
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:site" content="@AXA" />
        <meta name="twitter:tweet" content={metaContent?.tweet || tweet} />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={socialImage} />
      </Head>
    </>
  )
}

MetaContent.propTypes = { pageProps: object, fbAppId: string }

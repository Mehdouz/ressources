import React from 'react'
import { node, string, object, bool } from 'prop-types'
import styled from 'styled-components'
import { CarouselProvider, Slider } from 'pure-react-carousel'
import media from '@axacom-client/base/style/media'
import ContentCarouselDots from './ContentCarouselDots'
import ContentCarouselArrows from './ContentCarouselArrows'
export { Slide } from 'pure-react-carousel'

const ContentSlider = styled((props) => <Slider {...props} />)`
  .carousel__slider-tray {
    padding: 0;
    list-style: none;
    transition: transform 0.2s;
  }
`

const Wrapper = styled.div`
  padding-bottom: 60px;
  .carousel {
    position: relative;
    ${media.tablet`
      & .carousel__slider {
        padding-left: 8%;
        padding-right: 8%;
      }
    `}
  }
`

export default function ContentCarousel({ showArrows = true, children, style, className, dataTestid, ...rest }) {
  const totalSlides = React.Children.toArray(children).length

  return (
    <Wrapper style={style} className={className} data-testid={'ContentCarousel' || dataTestid}>
      <CarouselProvider naturalSlideWidth={16} naturalSlideHeight={9} totalSlides={totalSlides} isIntrinsicHeight infinite {...rest}>
        <ContentSlider>{children}</ContentSlider>

        <ContentCarouselDots totalSlides={totalSlides} />
        {showArrows ? <ContentCarouselArrows /> : null}
      </CarouselProvider>
    </Wrapper>
  )
}

ContentCarousel.propTypes = {
  dataTestid: string,
  children: node.isRequired,
  className: string,
  style: object,
  showArrows: bool,
}

ContentCarousel.defaultProps = {
  showArrows: true,
}

import React from 'react'
import styled from 'styled-components'
import { Dot } from 'pure-react-carousel'
import { colors } from '@axacom-client/base/style/variables'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { number, string } from 'prop-types'

const Wrapper = styled.div`
  position: absolute;
  bottom: -${getSpacing(5)};
  left: 0;
  right: 0;
  display: flex;
  justify-content: center;
`

const CarouselDot = styled((props) => <Dot {...props} />)`
  padding: 8px;
  border: 0;
  background: transparent;
  &::after {
    content: '';
    border-radius: 50%;
    height: 10px;
    width: 10px;

    cursor: pointer;
    display: block;
    transition: background-color 0.2s;
    background-color: ${colors.des_redLight};
  }
  &.carousel__dot--selected::after {
    background-color: ${colors.brandRed};
  }
`

export default function CarouselDots({ totalSlides, ...rest }) {
  return (
    <Wrapper data-testid="ContentCarouselDots" {...rest}>
      {[...Array(totalSlides)].map((_, i) => (
        <CarouselDot data-testid="ContentCarouselDot" slide={i} key={i}></CarouselDot>
      ))}
    </Wrapper>
  )
}

CarouselDots.propTypes = {
  dataTestid: string,
  totalSlides: number.isRequired,
}

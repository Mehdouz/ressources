import React from 'react'
import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

import { ButtonBack, ButtonNext } from 'pure-react-carousel'
import { string } from 'prop-types'

const Wrapper = styled.div`
  display: flex;
  justify-content: center;
`

const CustomButtonBack = styled((props) => <ButtonBack {...props} />)`
  border: 0;
  padding: 0;
  transform: rotate(90deg);
  background-color: transparent;
  position: absolute;
  top: 50%;
  margin-top: -20px;
  left: calc(10% + 20px);
`

const CustomButtonNext = styled((props) => <ButtonNext {...props} />)`
  border: 0;
  padding: 0;
  transform: rotate(-90deg);
  background-color: transparent;
  position: absolute;
  top: 50%;
  margin-top: -20px;
  right: calc(10% + 20px);
`

const IconLeft = styled(Icon)`
  background-color: transparent;
`

const IconRight = styled(Icon)`
  background-color: transparent;
`

export default function CarouselArrows({ ...rest }) {
  return (
    <Wrapper data-testid="ContentCarouselArrows" {...rest}>
      <CustomButtonBack data-testid="ContentCarouselLeft">
        <IconLeft name="IconDown" color={colors.brandRed} width={40} height={40} />
      </CustomButtonBack>
      <CustomButtonNext data-testid="ContentCarouselRight">
        <IconRight name="IconDown" color={colors.brandRed} width={40} height={40} />
      </CustomButtonNext>
    </Wrapper>
  )
}

CarouselArrows.propTypes = {
  datatestId: string,
}

import { Group, Image, StructuredText, Text } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $name: Text('Team name', 'Select the name of the team', true),
  $contacts: Group(
    {
      label: StructuredText('Label'),
      phone_number: Text('Phone number'),
      phone_image: Image('Phone Image'),
      email: Text('Email'),
    },
    'Contacts',
    true
  ),
}

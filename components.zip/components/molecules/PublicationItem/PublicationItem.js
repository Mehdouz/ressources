import React from 'react'
import { object, string } from 'prop-types'

import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { bytesToSize } from '@axacom-client/services/string-service'

import {
  PublicationItemContainer,
  PublicationItemTitle,
  PublicationItemButton,
  PublicationItemDownloadButton,
  PublicationItemImage,
  PublicationItemDownloadButtonContent,
  PublicationItemDownloadButtonLabel,
  PublicationItemDownloadButtonTypeSize,
} from './PublicationItem.style'

const PublicationItem = ({ className, title, cover, document, url }) => {
  const { i18n, currentLocale } = useGlobalContext()
  return (
    <PublicationItemContainer className={className} data-testid="PublicationItem__Container">
      {cover && (
        <PublicationItemButton href={url} data-testid="PublicationItem__ButtonPage">
          <div data-testid="PublicationItem__ImageContainer">
            <PublicationItemImage data-testid="PublicationItem__Image" ratio="100:143" src={cover.main.url} alt={title} />
          </div>
          {title && <PublicationItemTitle data-testid="PublicationItem__Title">{title}</PublicationItemTitle>}
        </PublicationItemButton>
      )}

      {document && (
        <PublicationItemDownloadButton
          url={document.url}
          type="link"
          $isAnimated={false}
          ariaLabel={
            document.target === 'file'
              ? `${i18n.t('investorPublications.download') ? i18n.t('investorPublications.download') : 'Download PDF'}, ${title}`
              : `${i18n.t('publication.more') ? i18n.t('publication.more') : 'View more'}}, ${title}`
          }
          color="red"
          iconRight={document.target === 'file' ? 'IconDownload' : 'IconArrowRight'}
          data-testid="PublicationItem__ButtonFile"
        >
          {document.target === 'file' && (
            <>
              <PublicationItemDownloadButtonContent data-testid="PublicationItem__ButtonFileContent">
                <PublicationItemDownloadButtonLabel data-testid="PublicationItem__ButtonFileContentLabel">
                  {i18n.t('investorPublications.download') ? i18n.t('investorPublications.download') : 'Download PDF'}
                </PublicationItemDownloadButtonLabel>
                <PublicationItemDownloadButtonTypeSize data-testid="PublicationItem__ButtonFileContentSize">PDF {bytesToSize(document.file.size, currentLocale)}</PublicationItemDownloadButtonTypeSize>
              </PublicationItemDownloadButtonContent>
            </>
          )}

          {document.target !== 'file' && (
            <>
              <PublicationItemDownloadButtonContent data-testid="PublicationItem__ButtonNoFileContent">
                {i18n.t('publication.more') ? i18n.t('publication.more') : 'View more'}
              </PublicationItemDownloadButtonContent>
            </>
          )}
        </PublicationItemDownloadButton>
      )}
    </PublicationItemContainer>
  )
}

PublicationItem.propTypes = {
  className: string,
  title: string,
  cover: object,
  date: string,
  document: object,
  url: string,
}
export default PublicationItem

import styled from 'styled-components'
import { lighten } from 'polished'

import { colors, font } from '@axacom-client/base/style/variables'
import Button from '@axacom-client/components/atoms/Button/Button'
import Image from '@axacom-client/components/atoms/Image/Image'
import Text from '@axacom-client/components/molecules/Text/Text'

export const PublicationItemContainer = styled.div``

export const PublicationItemTitle = styled(Text)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  font-size: 20px;
  line-height: 28px;

  display: block;
  color: ${colors.grayDarker};
  margin: 24px 0;

  &:hover,
  &:focus {
    color: ${lighten(0.25, colors.grayDarker)};
  }
`

export const PublicationItemButton = styled.a`
  text-decoration: none;
`

export const PublicationItemDownloadButton = styled(Button)`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 14px;
  line-height: 16px;
  letter-spacing: 1px;

  display: flex;
  padding-left: 0;
  justify-content: start;
  align-items: start;
`

export const PublicationItemImage = styled(Image)`
  img {
    top: 0%;
    transform: translate(-50%);
  }
`

export const PublicationItemDownloadButtonContent = styled.div`
  text-align: left;

  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 12px;
  line-height: 16px;
  letter-spacing: 1px;
`

export const PublicationItemDownloadButtonLabel = styled.span`
  display: block;
`

export const PublicationItemDownloadButtonTypeSize = styled.span`
  color: #757575;
`

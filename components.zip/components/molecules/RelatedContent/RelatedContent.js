import React from 'react'
import { array, object, oneOfType, string } from 'prop-types'
import styled from 'styled-components'
import { Col, Row } from 'reactstrap'

import { useGlobalContext } from './../../../store/GlobalContext'

import Text from '../Text/Text'
import Button from '../../atoms/Button/Button'
import Image from '../../atoms/Image/Image'

import media from '../../../base/style/media'
import { colors } from '../../../base/style/variables'
import { Typo14, Typo24 } from '../../../base/style/typoStyle/typoStyle'

const RelatedContentSection = styled.section`
  border-bottom: 1px solid ${colors.grayLight};

  ${media.tablet`border-bottom: 1px solid #979797;`}
`

const RelatedContentTitle = styled(Text)`
  ${Typo14};
  text-transform: uppercase;
  margin: 0 0 15px;
`

const RelatedContentText = styled(Text)`
  ${Typo24};
  margin: 0 0 15px;
`
const RelatedContentLink = styled(Button)`
  margin: 0 0 15px;
  padding: 0;

  ${media.tablet`margin: 0 0 25px;`}
`
const ImageWrapper = styled.div`
  margin-right: -15px;

  ${media.tablet`margin-right: 0;`}
`

export default function RelatedContent({ title, image, text, ctaLabel, ctaLink }) {
  const { i18n } = useGlobalContext()
  return (
    <RelatedContentSection>
      <Row>
        <Col xs="12">
          <RelatedContentTitle as="h3" data-testid="RelatedContent_Title">
            {title || i18n.t('suggested.article.title')}
          </RelatedContentTitle>
        </Col>
        <Col xs="4">
          <ImageWrapper>
            <Image ratio="1:1" isBackground={true} src={image.main.url} style={{ margin: '5px 0 20px' }} />
          </ImageWrapper>
        </Col>
        <Col xs="8">
          {text && <RelatedContentText data-testid="RelatedContent_Text">{text}</RelatedContentText>}
          {ctaLink && (
            <RelatedContentLink color="red" type="link" iconRight="IconArrowRight" size="small" url={ctaLink.url} ariaLabel={!ctaLabel ? `${i18n.t('suggested.article.title')}, ${title}` : ''}>
              {ctaLabel || i18n.t('suggested.article.read')}
            </RelatedContentLink>
          )}
        </Col>
      </Row>
    </RelatedContentSection>
  )
}

RelatedContent.propTypes = {
  title: oneOfType([string, object, array]),
  image: object,
  text: oneOfType([string, object, array]),
  ctaLabel: string,
  ctaLink: object,
  className: string,
}

import React, { useState } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import {
  StyledSlice,
  Container,
  RestrictionSlice,
  ContentWrapper,
  TextWrapper,
  SubmitButton,
  UnauthorizedText,
  ErrorMessage,
  PostalCodeWrapper,
  CountryWrapper,
  InputWrapper,
  SelectWrapper,
  FormZipcodeWrapper,
  FormDisclaimerWrapper,
  YesNoButton,
} from './RestrictionForm.styles'
import { useForm } from 'react-hook-form'
import importedData from './restriction-countries.json'
import { TechnicalError } from '@axacom-client/domains/errors'
import log from '@axacom-client/logger'

export default function RestrictionForm(props) {
  const { i18n, currentLocale } = useGlobalContext()
  const {
    register,
    formState: { errors },
    handleSubmit,
  } = useForm()
  const { restrictionType, zipcodeContent, disclaimerContent, countries } = props.data
  const [step, setStep] = useState(restrictionType)

  const allowPage = () => {
    props.setIsAllowed(true)
  }

  const importedCountries = Object.entries(importedData.countries)
    .map((c) => [c[1].code, c[1][currentLocale]])
    .sort((a, b) => {
      if (a[1] < b[1]) return -1
      if (a[1] > b[1]) return 1
      return 0
    })

  const onSubmit = async (form) => {
    try {
      let isUnauthorized = null

      switch (step) {
        case 'zipcode':
          isUnauthorized = countries.find((country) => country.countryCode == form[i18n.t('restriction.placeholderCountry')])

          if (isUnauthorized) setStep('unauthorized')
          else disclaimerContent && setStep('disclaimer')
          break
        case 'disclaimer':
          isUnauthorized = form == i18n.t('restriction.no')

          if (isUnauthorized) setStep('unauthorized')
          else allowPage()
          break
      }
    } catch (e) {
      log.error('[Restriction] error : ', e)
      throw new TechnicalError()
    }
  }

  return (
    <StyledSlice data-testid="Restriction">
      <Container>
        {step == 'zipcode' && (
          <RestrictionSlice>
            <ContentWrapper>
              <TextWrapper>{zipcodeContent}</TextWrapper>
            </ContentWrapper>
            <FormZipcodeWrapper onSubmit={handleSubmit(onSubmit)}>
              <PostalCodeWrapper>
                <InputWrapper placeholder={i18n.t('restriction.placeholderPostalCode')} {...register(i18n.t('restriction.placeholderPostalCode'))} />
              </PostalCodeWrapper>
              <CountryWrapper>
                {errors[i18n.t('restriction.placeholderCountry')]?.type === 'required' && <ErrorMessage>{i18n.t('restriction.labelErrorCountry')}</ErrorMessage>}
                <SelectWrapper
                  defaultValue=""
                  {...register(i18n.t('restriction.placeholderCountry'), { required: true })}
                  aria-invalid={errors[i18n.t('restriction.placeholderCountry')] ? 'true' : 'false'}
                >
                  <option value="" disabled>
                    {i18n.t('restriction.placeholderCountry')}
                  </option>
                  {importedCountries &&
                    importedCountries.map(([key, value]) => (
                      <option key={key} value={key}>
                        {value}
                      </option>
                    ))}
                </SelectWrapper>
              </CountryWrapper>
              <SubmitButton type="ghost" color="grey" ariaLabel={i18n.t('restriction.validate')}>
                {i18n.t('restriction.validate')}
              </SubmitButton>
            </FormZipcodeWrapper>
          </RestrictionSlice>
        )}
        {step == 'disclaimer' && (
          <RestrictionSlice>
            <ContentWrapper>
              <TextWrapper>{disclaimerContent}</TextWrapper>
            </ContentWrapper>
            <FormDisclaimerWrapper>
              <YesNoButton type="ghost" color="grey" ariaLabel={i18n.t('restriction.yes')} onClick={() => onSubmit(i18n.t('restriction.yes'))}>
                {i18n.t('restriction.yes')}
              </YesNoButton>
              <YesNoButton type="ghost" color="grey" ariaLabel={i18n.t('restriction.no')} onClick={() => onSubmit(i18n.t('restriction.no'))}>
                {i18n.t('restriction.no')}
              </YesNoButton>
            </FormDisclaimerWrapper>
          </RestrictionSlice>
        )}
        {step == 'unauthorized' && (
          <RestrictionSlice>
            <ContentWrapper>
              <UnauthorizedText>{i18n.t('restriction.unauthorized')}</UnauthorizedText>
            </ContentWrapper>
            <SubmitButton url="/" type="ghost" color="grey" ariaLabel={i18n.t('backToHome')}>
              {i18n.t('backToHome')}
            </SubmitButton>
          </RestrictionSlice>
        )}
      </Container>
    </StyledSlice>
  )
}

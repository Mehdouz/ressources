import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { font, colors } from '@axacom-client/base/style/variables'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import Text from '../../Text/Text'

export const StyledSlice = styled(Slice)`
  background-color: #37588b;
  overflow: auto;
  padding-bottom: 30px;
  padding-top: 0.67em;
  padding-left: 15px;
  padding-right: 15px;

  ${media.desktop`
    padding-top: 0.67em;
  `}
`

export const Container = styled.div`
  margin: 0 auto;
  padding-right: 15px;
  padding-left: 15px;
  position: relative;
  color: ${colors.white};
  z-index: 10;

  ${media.tablet`
    max-width: 750px;
  `}

  ${media.desktop`
    max-width: 970px;
  `}

  ${media.desktopLarge`
    max-width: 1170px;
  `}

  ${media.desktopVeryLarge`
    max-width: 1440px;
  `}
`

export const RestrictionSlice = styled.div`
  display: block;
`

export const ContentWrapper = styled.div`
  margin-bottom: 30px;
`
export const TextWrapper = styled(Text)`
  font-size: 16px;
  line-height: 28px;

  ${media.desktop`
    font-size: 18px;
    line-height: 34px;
  `}
`

export const FormZipcodeWrapper = styled.form`
  margin-bottom: 30px;

  ${media.desktop`
    display: flex;
    justify-content: space-between;
    flex-flow: row wrap;
  `}
`

export const FormDisclaimerWrapper = styled.form`
  margin-bottom: 30px;

  ${media.desktop`
    display: flex;
    justify-content: space-between;
  `}
`

export const DisclaimerSlice = styled.div`
  display: block;
`

export const DisclaimerContentWrapper = styled.div`
  margin-bottom: 30px;
`

export const SubmitButton = styled(Button)`
  line-height: 46px;
  padding: 0 30px;
  justify-content: center;
  margin: auto;
  width: 100%;
  border: 3px solid #ccc;
  letter-spacing: 0.1em;
  font-weight: ${font.weight.bold};
  margin-bottom: 20px;
  display: block;

  ${media.tablet`
    width: 50%;
    margin-top: 2rem;
    height: 100%; 
  `}
`

export const YesNoButton = styled(Button)`
  line-height: 46px;
  padding: 0 30px;
  justify-content: center;
  margin: auto;
  width: 100%;
  border: 3px solid #ccc;
  letter-spacing: 0.1em;
  font-weight: ${font.weight.bold};
  margin-bottom: 20px;
  display: block;

  ${media.tablet`
    display: flex;
    width: 48%;
  `}
`

export const UnauthorizedText = styled(Text)`
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 36px;
  line-height: 38px;
  letter-spacing: 0.015em;
  margin-top: 40px;
`

export const ErrorMessage = styled.p`
  width: 100%;
  display: block;
  margin-bottom: 5px;
  margin-top: 10px;
  color: #f07662;
`

export const PostalCodeWrapper = styled.div`
  ${media.tablet`width: 48%;`}
`

export const CountryWrapper = styled.div`
  position: relative;
  display: block;
  margin-bottom: 10px;
  padding: 0;

  ${media.tablet`
    width: 48%;
  `}

  &::after {
    font-family: 'icomoon';
    font-weight: bold;
    font-size: 20px;
    text-transform: none;
    line-height: 1;
    content: '>';
    transform: rotate(90deg);
    color: #f07662;
    position: absolute;
    top: 15px;
    right: 20px;
    background-repeat: no-repeat;
    background-size: 100%;
    z-index: 2;
    pointer-events: none;
  }
`

export const InputWrapper = styled.input`
  display: inline-block;
  vertical-align: middle;
  padding: 0 15px;
  border: 1px solid #ccc;
  min-height: 50px;
  border-radius: 0;
  border: 1px solid #dadada;
  width: 100%;
  margin-bottom: 10px;
  margin-right: 10px;
  font-size: 18px;
  line-height: 1.5;
`

export const SelectWrapper = styled.select`
  min-height: 50px;
  width: 100%;
  margin: 0;
  background: white;
  border: 1px solid transparent;
  box-sizing: border-box;
  appearance: none;
  color: #999;
  padding: 0.6em 1.9em 0.5em 0.8em;
  font-size: 18px;
  line-height: 1.5;
`

import React, { useState } from 'react'
import { func, object } from 'prop-types'
import { Col, Row } from 'reactstrap'
import { Form as FormikForm, Formik } from 'formik'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import * as formFields from '@axacom-client/components/atoms/FormFields/FormFields'
import ErrorI18n from '@axacom-client/components/pages/errors/errors.i18n'
import { ErrorMessage } from '@axacom-client/components/atoms/FormFields/Fields.style'
import { getInitialValues } from '@axacom-client/services/form-service'
import { buildSchema } from '@axacom-client/services/validation-service'
import log from '@axacom-client/logger'

export default function Form({ fields, handleSubmit }) {
  const [isError, setError] = useState(false)
  const { currentLocale } = useGlobalContext()
  const initialValues = getInitialValues(fields)
  const formSchema = buildSchema(fields, currentLocale)

  const onSubmitForm = async (values, { setSubmitting }) => {
    try {
      await handleSubmit(values)
    } catch (e) {
      const error = e.data || e
      log.error('[Form] submit error: ', { error })
      setSubmitting(false)
      return setError((ErrorI18n[error.message] || ErrorI18n.somethingWrong).text[currentLocale])
    }
  }

  return (
    <Formik initialValues={initialValues} validationSchema={formSchema} validateOnBlur={true} validateOnChange={true} isValid={formSchema.isValidSync(initialValues)} onSubmit={onSubmitForm}>
      {({ handleChange, handleBlur, values, errors, touched }) => {
        return (
          <FormikForm>
            {Object.entries(fields).map(([field, props], index) => {
              const ComponentField = formFields[field]
              if (ComponentField) {
                return (
                  <Row key={index}>
                    <Col sm={{ size: 12 }}>
                      {/* TODO: remove value/onChange/onBlur/errors/touched. These value are already in the <Field /> render props */}
                      <ComponentField name={field} {...props} value={values[field]} onChange={handleChange} onBlur={handleBlur} errors={errors} touched={touched} />
                    </Col>
                  </Row>
                )
              } else {
                log.error(`[Oops] can't find ${field} FormField`)
              }
            })}
            {isError && (
              <Row>
                <Col>
                  <div style={{ textAlign: 'center', marginTop: '8px' }} className="error">
                    <ErrorMessage>{isError}</ErrorMessage>
                  </div>
                </Col>
              </Row>
            )}
          </FormikForm>
        )
      }}
    </Formik>
  )
}

Form.propTypes = {
  fields: object,
  errors: object,
  handleSubmit: func,
}

import React from 'react'
import { bool, func, object, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Form from '@axacom-client/components/molecules/Form/Form'
import { subscribeNewsletter } from '@axacom-client/repositories/newsletter'
import log from '@axacom-client/logger'
import { TechnicalError } from '@axacom-client/domains/errors'

const NewsletterForm = ({ handleSubmit, defaultValue = {}, textContent = '', checkboxGDPR = '', isVisible }) => {
  const { i18n, currentLocale } = useGlobalContext()

  const formFields = {
    email: {
      required: true,
      email: true,
    },
    newsletterChoice: {
      groupRequired: true,
      defaultValue: defaultValue.newsletterChoice,
    },
    textContent: { children: textContent || i18n.t('newsletter-form:policy') },
    agreement: {
      label: checkboxGDPR || i18n.t('newsletter-form:checkbox-gdpr'),
      required: true,
    },
    recaptcha: {
      required: true,
      isVisible,
    },
    submit: {
      label: i18n.t('newsletterSubscription.button'),
    },
  }

  if (!handleSubmit)
    handleSubmit = async (form) => {
      try {
        await subscribeNewsletter(currentLocale, form)
        log.info('[SubscribeNewsletter] successful ')

        formFields.submit.color = 'success'
        formFields.submit.label = i18n.t('form.contact.sent')
      } catch (e) {
        log.error('[SubscribeNewsletter] error : ', e)
        throw new TechnicalError()
      }
    }

  return <Form fields={formFields} handleSubmit={handleSubmit} />
}

export default NewsletterForm

NewsletterForm.propTypes = {
  handleSubmit: func,
  isVisible: bool,
  textContent: string,
  checkboxGDPR: string,
  defaultValue: object,
}

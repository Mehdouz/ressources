import React, { createRef, useEffect, useRef, useState } from 'react'
import { Container } from 'reactstrap'
import { arrayOf, object, string } from 'prop-types'
import { NavCustom, StickyWrapper } from '@axacom-client/components/molecules/StickySlice/StickySlice.style'
import ArticleThumbnailList from '@axacom-client/components/organisms/Slices/ArticleThumbnailList/ArticleThumbnailList'
import Menu from '@axacom-client/components/molecules/Menu/Menu'
import { getComponentProps } from '@axacom-client/services/component-service'
import { getArticleMeta } from '@axacom-client/services/document-service'
import { getDimensions, getScrollY } from '@axacom-client/services/window-service'
import log from '@axacom-client/logger'

export default function StickySlice({ menuItems, activateNewsletterButton }) {
  const [isSticky, setSticky] = useState(false)
  const [headerHeight, setHeaderHeight] = useState(50)
  const [selectedSectionIndex, setSelectedSection] = useState(0)

  const headerRef = useRef(null)
  const stickyBlock = useRef(null)
  const { current } = useRef(menuItems.map(() => createRef()))

  useEffect(() => {
    function handleScroll() {
      const headHeight = getDimensions(headerRef.current).height
      const scrollPosition = getScrollY() + headHeight
      const selected = menuItems.findIndex((_, index) => {
        const ele = current[index]
        if (ele) {
          const { offsetBottom, offsetTop } = getDimensions(ele.current)
          return scrollPosition > offsetTop && scrollPosition < offsetBottom
        }
      })

      setHeaderHeight(headHeight)
      setSelectedSection(selected)
      const { offsetTop, offsetBottom } = getDimensions(stickyBlock.current)
      const needSticky = scrollPosition > offsetTop && scrollPosition < offsetBottom
      setSticky(needSticky)
    }

    handleScroll()
    // eslint-disable-next-line no-undef
    window.addEventListener('scroll', handleScroll)
    // eslint-disable-next-line no-undef
    window.addEventListener('resize', handleScroll)

    return () => {
      // eslint-disable-next-line no-undef
      window.removeEventListener('scroll', handleScroll)
      // eslint-disable-next-line no-undef
      window.removeEventListener('resize', handleScroll)
    }
  }, [selectedSectionIndex])

  const menu = <Menu items={menuItems} selectedSection={selectedSectionIndex} activateNewsletterButton={activateNewsletterButton} />
  // TODO jdecoen ???
  // const menu = <Menu setScrollToContentCallback={index => scrollTo(sectionRefs.current[index])} items={menuItems} selectedSection={selectedSectionIndex} />

  return (
    <div ref={stickyBlock}>
      <StickyWrapper sticky={isSticky} ref={headerRef}>
        <Container>
          <NavCustom>{!!menuItems?.length && menu}</NavCustom>
        </Container>
      </StickyWrapper>
      <div style={{ marginTop: isSticky ? headerHeight + 20 : 0 }}>
        {menuItems.map((menuItem, index) => (
          <div key={index} id={menuItem.theme.slug} ref={current[index]}>
            <ArticleThumbnailList
              title={menuItem.themeText || getArticleMeta('title', menuItem.theme)}
              multiple={true}
              highlightedArticle={menuItem.theme.highlighted_article}
              linkTopicPage={menuItem.theme.linkTopicPage}
              articles={menuItem.articles}
              dataTestid="StickyThemeMenu"
            />
          </div>
        ))}
      </div>
    </div>
  )
}

StickySlice.getInitialProps = async ({ document: menuItems, ...context }) => {
  log.debug('[StickySlice] getInitialProps')
  const componentsProps = await Promise.all(
    menuItems.map((menuItem) =>
      getComponentProps('StickySlice', ArticleThumbnailList, context, {
        ...menuItem,
        query: { theme: menuItem.theme.id },
        highlightedArticle: menuItem.theme.highlighted_article,
        linkTopicPage: menuItem.theme.linkTopicPage,
        articles: menuItem.articles,
      })
    )
  )
  componentsProps.forEach(({ highlightedArticle, ...componentProps }, index) => {
    menuItems[index].theme.highlighted_article = highlightedArticle
    return (menuItems[index] = { ...menuItems[index], ...componentProps })
  })
  return menuItems
}

StickySlice.propTypes = { menuItems: arrayOf(object).isRequired, activateNewsletterButton: string }

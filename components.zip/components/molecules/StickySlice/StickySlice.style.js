import { Navbar } from 'reactstrap'
import styled from 'styled-components'
import { getSpacing } from '@axacom-client/base/style/spacing'

export const NavCustom = styled(Navbar)`
  display: block !important;
  z-index: 19 !important;
  padding: ${getSpacing(1)} 0 ${getSpacing(1)} 0 !important;
`

export const StickyWrapper = styled.div`
  background: #ffffff;
  transition: top 0.3s;
  -webkit-box-shadow: 0 20px 20px -20px rgba(0, 0, 0, 0.2);
  -moz-box-shadow: 0 20px 20px -20px rgba(0, 0, 0, 0.2);
  box-shadow: 0 20px 20px -20px rgba(0, 0, 0, 0.2);
  ${({ sticky }) => (sticky ? 'position: fixed;\ntop: 0;\nleft: 0;\nright: 0;\nz-index: 1;' : 'position: relative;')}
`

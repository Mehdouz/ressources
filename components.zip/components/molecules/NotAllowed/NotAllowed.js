import React from 'react'
import { func, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Button from '@axacom-client/components/atoms/Button/Button'
import { getDocument, getWindowProp } from '@axacom-client/services/window-service'
import { Content, Text, Title, Wrapper } from './NotAllowed.styles'

export default function NotAllowed({ cookie, category }) {
  const { i18n } = useGlobalContext()

  function openPreferencesCenter() {
    getWindowProp('OneTrust').ToggleInfoDisplay()
    setTimeout(() => {
      const socialToggle = getDocument().querySelector(`[data-optanongroupid=${category}] .ot-tgl`)
      socialToggle?.scrollIntoView()
      socialToggle?.firstChild?.click()
    }, 50)
  }

  return (
    <Wrapper data-testid="NotAllowed">
      <Content>
        <Title>
          {cookie} {i18n.t('cookieRestriction.warningTitle')}
        </Title>
        <Text>{i18n.t('cookieRestriction.warningSubtitle')}</Text>
        <Button color="red" size="small" onClick={() => openPreferencesCenter()}>
          {i18n.t('cookie.activate')}
        </Button>
      </Content>
    </Wrapper>
  )
}

NotAllowed.propTypes = { cookie: string.isRequired, category: string, onClick: func }

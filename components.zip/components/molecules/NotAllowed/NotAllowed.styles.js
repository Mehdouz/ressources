import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Typo16, Typo20Bold } from '@axacom-client/base/style/typoStyle/typoStyle'

export const Wrapper = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: block;
  z-index: 0;
  background: ${colors.textColor};
  color: ${colors.bodyBg};
  font-size: 16px;
  line-height: initial;
  margin: auto;
  text-align: center;
`

export const Content = styled.div`
  position: relative;
  top: 50%;
  transform: translateY(-50%);
  padding: 20px;
`

export const Title = styled.p`
  ${Typo20Bold}
`

export const Text = styled.p`
  margin-bottom: 20px;
  ${Typo16}
`

import { Nav, NavItem, NavLink } from 'reactstrap'
import styled from 'styled-components'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Typo14 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { lighten } from 'polished'
import { colors } from '../../../base/style/variables'

export const StickyBar = styled.div`
  display: flex;
  height: 100%;
  align-items: center;
  overflow: auto;
  white-space: nowrap;
  user-select: none;
  cursor: pointer;
  padding: 0 !important;
  scrollbar-width: none;

  ::-webkit-scrollbar {
    height: 0;
  }
`

export const RightButtonsWrapper = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
  flex: 1;
  margin-left: ${getSpacing(4)};
`

export const MenuItemStyle = styled(NavItem)`
  flex-wrap: nowrap;
  list-style: none;
  margin-left: ${getSpacing(4)};
  &:first-child {
    margin-left: 0;
  }
  cursor: pointer;
`

export const NavCustom = styled(Nav)`
  flex-wrap: nowrap !important;
  width: 100% !important;
`

export const MenuLink = styled(NavLink)`
  ${Typo14}
  text-decoration: none;
  text-transform: uppercase;
  display: flex;
  align-items: center;
  line-height: 2rem;
  height: 100%;
  color: ${colors.textColor};
  padding: ${getSpacing(1)} 0 ${getSpacing(1)} 0;
  width: min-content;

  a {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-user-drag: none;
  }

  &:hover,
  &:focus {
    color: ${lighten(0.25, colors.textColor)};
  }
`

export const Stroke = styled.div`
  display: block;
  position: absolute;
  z-index: 1;
  bottom: 0;
  left: 0;
  width: ${({ width }) => width}px;
  height: 3px;
  background: ${colors.brandRed};
  transform: translate3d(${(props) => props.left}px, 0, 0);
  visibility: ${(props) => (props.isVisible ? 'visible' : 'hidden')};
  transition: transform 0.2s ease, width 0.2s ease, visibility 0s ease ${(props) => (props.isVisible ? '0s' : '0.2s')};
`

import React, { createRef, useEffect, useRef, useState } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { MenuItemStyle, MenuLink, NavCustom, RightButtonsWrapper, StickyBar, Stroke } from '@axacom-client/components/molecules/Menu/Menu.style'
import ModalNewsletter from '@axacom-client/components/organisms/ModalNewsletter/ModalNewsletter'
import { arrayOf, func, number, object, string } from 'prop-types'

export default function StickyThemeMenu({ items, selectedSection, activateNewsletterButton }) {
  const { i18n, currentLocale } = useGlobalContext()

  const [strokeLeft, setStrokeLeft] = useState(0)
  const [strokeState, setStrokeState] = useState(false)
  const [strokeWidth, setStrokeWidth] = useState(0)
  const [previousSection, setPreviousSection] = useState(selectedSection)

  let currentTarget = {}
  const sectionRefs = useRef(items.map(() => createRef()))
  const scrollableStickyBar = useRef(null)

  useEffect(() => {
    // do actions if a topic is selected
    if (sectionRefs.current[selectedSection]) {
      // if topics menu items are offscreen (coordinate under 0) then we pick them up on screen by scrolling
      if (
        sectionRefs.current[selectedSection].current.getBoundingClientRect().right > scrollableStickyBar.current.getBoundingClientRect().width ||
        (sectionRefs.current[selectedSection].current.getBoundingClientRect().left < 0 && previousSection !== selectedSection)
      ) {
        // eslint-disable-next-line no-undef
        scrollableStickyBar.current.scrollLeft = sectionRefs.current[selectedSection].current.offsetLeft - screen.availWidth + (sectionRefs.current[selectedSection].current.offsetWidth + 50)
      } else if (sectionRefs.current[selectedSection].current.offsetLeft === 0 && previousSection !== selectedSection) {
        scrollableStickyBar.current.scrollLeft = -(sectionRefs.current[selectedSection].current.offsetWidth + 50)
      }
      animStroke(sectionRefs.current[selectedSection].current)
      setPreviousSection(selectedSection)
    }
  })

  const outMenu = () => {
    if (selectedSection) {
      setStrokeState(false)
      currentTarget = {}
    }
  }

  const animStroke = (event) => {
    currentTarget = event?.currentTarget || event
    if (strokeLeft === currentTarget.getBoundingClientRect().x && strokeState) return
    setStrokeState(true)
    // stroke is wrapped in scrollableBar so we need to adjust alignment to left
    setStrokeLeft(currentTarget.getBoundingClientRect().x - scrollableStickyBar.current.getBoundingClientRect().x)
    setStrokeWidth(currentTarget.getBoundingClientRect().width)
  }

  // TODO jdecoen ???
  // const handleSelectItem = (index, e) => {
  //   setScrollToContentCallback(index)
  // }

  return (
    <StickyBar ref={scrollableStickyBar} onScroll={() => setStrokeState(false)}>
      <NavCustom fill={true} justified={true}>
        {items.map((item, index) => {
          return (
            // <MenuItemStyle id={'content' + item.theme.slug} key={index} onClick={e => handleSelectItem(index, e)} onMouseOut={() => outMenu()} className="h-100">
            <MenuItemStyle id={'content' + item.theme.slug} key={index} onMouseOut={() => outMenu()} className="h-100">
              <MenuLink
                href={`#${item.theme.slug}`}
                innerRef={sectionRefs.current[index]}
                onFocus={(e) => animStroke(e)}
                onMouseEnter={(e) => animStroke(e)}
                data-testid={`MenuLink-${index}`}
                aria-label={currentLocale === 'en' ? `Display articles with the ${item.theme.slug} theme` : `Afficher les articles du thème ${item.theme.slug}`}
              >
                {item.themeText || item.theme?.metaContent?.[0]?.title}
              </MenuLink>
            </MenuItemStyle>
          )
        })}
        {activateNewsletterButton === 'Yes' && (
          <RightButtonsWrapper className="d-inline-flex">
            <ModalNewsletter buttonLabel={i18n.t('newsletterSubscription.news.button')} buttonColor="red" defaultValue={{ newsletterChoice: ['article'] }} />
          </RightButtonsWrapper>
        )}
      </NavCustom>
      <Stroke width={strokeWidth} left={strokeLeft} isVisible={strokeState} />
    </StickyBar>
  )
}

StickyThemeMenu.propTypes = {
  items: arrayOf(object).isRequired,
  setScrollToContentCallback: func,
  selectedSection: number,
  activateNewsletterButton: string,
}

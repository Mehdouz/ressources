import React, { useState } from 'react'
import { object, string } from 'prop-types'
import styled, { css } from 'styled-components'
import { colors } from '../../../base/style/variables'
import Text from '../../molecules/Text/Text'
import { Typo14, Typo16, Typo18, Typo20Bold, Typo24 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { font } from '@axacom-client/base/style/variables'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { fadeIn } from '@axacom-client/base/style/animation'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

const ContactItemTitle = styled(Text)`
  ${Typo24}
  display: block;
  color: ${colors.white};
`

const ContactDescription = styled.a`
  ${Typo20Bold}
  display: block;
  color: ${colors.white};
  margin-top: ${getSpacing(2)};
`

const ContactEmail = styled.a`
  ${Typo16}
  font-weight: ${font.weight.bold};
  display: block;
  color: ${colors.white};
  margin-top: ${getSpacing(2)};
  cursor: pointer;
`

const ContactItemSection = styled(Text)`
  ${Typo18}
  line-height: ${getSpacing(3)};
  display: block;
  color: ${colors.white};
`

const ContactItemButton = styled.div`
  text-decoration: none;
`

const ContactItemHovered = styled.div`
  position:relative;
  animation:moveUp 0.5s ease-out forwards;
  animation-iteration-count:1;
  -webkit-animation:moveUp 0.5s;
  -webkit-animation-iteration-count:1;
  }
  @keyframes moveUp
  { from {top:20px; opacity: 0;}
  to {top:0px; opacity: 1}
  }
  @-webkit-keyframes moveUp /* Safari and Chrome */
  {
  from {top:20px; opacity: 0;}
  to {top: 0px; opacity: 1;}
  }
`

const Footer = styled.div`
  left: ${getSpacing(2)};
  bottom: ${getSpacing(2)};
  position: absolute;
  padding-right: ${getSpacing(2)};
`

const Question = styled.div`
  ${Typo14}
  display: inline-flex;
  flex-direction: row;
  align-items: center;
  color: ${colors.white};
  text-transform: uppercase;
  font-weight: ${font.weight.regular};
  letter-spacing: 1px;
`

const CustomText = styled(Text)`
  margin-top: 0;
  margin-left: ${getSpacing(1)};
`
const hovered = css`
  &:before {
    background-color: ${colors.black};
    opacity: 0.8;
    transition: background-color 0.3s ease-in-out;
  }
`

const ContactContainer = styled.div`
  background-image: url(${(props) => props.$image});
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;
  color: ${colors.white};
  display: block;
  width: 100%;
  position: relative;
  border-radius: 0;
  border: none;
  margin-top: ${getSpacing(4)};
  height: 339px;
  animation: ${fadeIn} 0.5s ease-in;

  &:before {
    content: '';
    display: block;
    background: linear-gradient(180deg, rgba(0255, 255, 255, 0) 50%, rgba(0, 0, 0, 0.72) 100%);
    height: 100%;
    padding: 0;
    width: 100%;
  }

  ${(props) => (props.isHovered ? hovered : '')}
`

const ContactWrapper = styled.div`
  position: absolute;
  width: 100%;
  top: 0;
  left: 0;
  bottom: 0;
  padding: ${getSpacing(2)};
`

const ContactItem = ({ name, phone, section, email, contactImage, ...rest }) => {
  const [isHovered, setHovered] = useState(false)
  const { currentLocale } = useGlobalContext()

  const contactItemButton = (
    <ContactItemButton data-testid="ContactItemButtonPage">
      <Question>
        <Icon name="IconQuestionmark" color={colors.white} />
        <CustomText>{currentLocale === 'fr' ? 'Une question ?' : 'Any question?'}</CustomText>
      </Question>
      <Footer>
        {name && <ContactItemTitle data-testid="ContactItemTitle">{name}</ContactItemTitle>}
        {section && <ContactItemSection data-testid="ContactSectionTitle">{section}</ContactItemSection>}
      </Footer>
    </ContactItemButton>
  )

  const contactItemButtonHovered = (
    <ContactItemHovered data-testid="ContactItemButtonPage">
      {name && <ContactItemTitle data-testid="ContactName">{name}</ContactItemTitle>}
      {phone && (
        <ContactDescription href={`tel:${phone}`} data-testid="ContactPhone">
          {phone}
        </ContactDescription>
      )}
      {email && (
        <ContactEmail href={`mailto:${email}`} data-testid="ContactEmail">
          {email}
        </ContactEmail>
      )}
    </ContactItemHovered>
  )

  return (
    <ContactContainer {...rest} $image={contactImage?.main?.url} isHovered={isHovered} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)} data-testid="ContactContainer">
      {isHovered && <ContactWrapper>{contactItemButtonHovered}</ContactWrapper>}
      {!isHovered && <ContactWrapper>{contactItemButton}</ContactWrapper>}
    </ContactContainer>
  )
}

ContactItem.propTypes = {
  name: string,
  phone: string,
  section: string,
  email: string,
  contactImage: object,
}
export default ContactItem

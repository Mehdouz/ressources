import React from 'react'
import { array, arrayOf, node, object, oneOfType, string } from 'prop-types'
import { Elements, RichText } from 'prismic-reactjs'
import slugify from 'slugify'

import urlResolver from '@axacom-client/services/urlResolver'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import YoutubePlayer from '@axacom-client/components/molecules/YoutubePlayer/YoutubePlayer'
import { motion } from 'framer-motion/dist/framer-motion'

/**
 * Create link for document, file or web
 *
 * @returns {*} link
 * @VisibleForTesting
 */
export const htmlSerializer = function (type, element, content, children, key) {
  const { currentLocale } = useGlobalContext()
  let tagProps = { href: '/broken' }
  switch (type) {
    case Elements.hyperlink:
      if (!element?.data) {
        return (
          <a key={tagProps.href} {...tagProps}>
            {content}
          </a>
        )
      }
      switch (element.data.type) {
        case 'Link.document':
          tagProps.href = urlResolver(element.data.value?.document, currentLocale)
          break
        case 'Link.file':
          tagProps.href = element.data.value?.file?.url
          tagProps.target = '_blank'
          break
        case 'Link.web':
          tagProps.href = element.data.value?.url
          tagProps.target = '_blank'
          break
      }
      return (
        <a key={slugify(tagProps.href)} {...tagProps}>
          {content}
        </a>
      )
    case Elements.embed:
      return <YoutubePlayer html={element.oembed.html} key={key} />
    default:
      return null
  }
}

// TODO: Make <Text /> more generic.
// Every generic component and especially the <Text /> has to have the same Node element behavior. (Similar to "<></>" where you can render everything you want)
//  It can be text string array object or even undefined (undefined is typeof undefined === "undefined" while typeof null === "object")
// - <Text /> should simply render children as <tag>{children}</tag>
// - As we need to have a specific rendering for our richText (the switch case bellow) we should put it in a props as follow:
// <Text richText={dataComingFromContento} />
// And we should be able to have the following aswell:
// <Text>Nostrud tempor dolor cupidatat aliquip nulla esse enim eu do deserunt ut.</Text>
// <Text>[Component1, Component2]</Text> <-- This is possible by default with react.

export default function Text({ children, ...rest }) {
  switch (typeof children) {
    case 'string':
    case 'number':
      return <p {...rest}>{children}</p>
    case 'object':
      return (
        <div {...rest}>
          <RichText render={children.props?.render || (Array.isArray(children) ? children : Array.isArray(children.text) ? children.text : [children])} htmlSerializer={htmlSerializer} />
        </div>
      )
    default:
      return null
  }
}

export const MotionText = React.forwardRef(({ children, ...rest }, ref) => {
  switch (typeof children) {
    case 'string':
    case 'number':
      return (
        <motion.p {...rest} ref={ref}>
          {children}
        </motion.p>
      )
    case 'object':
      return (
        <motion.div {...rest} ref={ref}>
          <RichText render={children.props?.render || (Array.isArray(children) ? children : Array.isArray(children.text) ? children.text : [children])} htmlSerializer={htmlSerializer} />
        </motion.div>
      )
    default:
      return null
  }
})

MotionText.displayName = 'MotionText'

Text.propTypes = {
  children: oneOfType([arrayOf(node), node, object, array, string]).isRequired,
  className: string,
  dataTestId: string,
}

import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { Typo25 } from '@axacom-client/base/style/typoStyle/typoStyle'

export const ShareButtonWrapper = styled(motion.button)`
  display: block;
  border: 0;
  justify-content: center;
  align-items: center;
  height: 68px;
  width: 68px;
  cursor: pointer;
  outline: none;
  transform: background-color 0.2s;
  will-change: background-color;
  background-color: ${({ theme }) => (theme === 'white' ? colors.white : colors.brandBlue)};

  &:focus {
    background-color: ${({ theme }) => (theme === 'white' ? colors.axaBlue200 : colors.brandBlue)};
    outline: none;
  }

  &:hover {
    background-color: ${({ theme }) => (theme === 'white' ? colors.axaBlue200 : colors.brandBlue)};
  }
`

export const ShareTitle = styled.p`
  ${Typo25}
  font-weight: ${font.weight.semiBold};
  color: ${colors.AXABlue};
  text-transform: uppercase;
  white-space: nowrap;
  margin-right: 15px;
`

export const Button = styled(motion.button)`
  display: block;
  border: 0;
  justify-content: center;
  align-items: center;
  height: 68px;
  width: 68px;
  background-color: ${({ theme }) => (theme === 'white' ? colors.white : colors.axaBlue500)};
  ${({ theme }) => (theme === 'white' ? '' : 'border-right: 1px solid #FFF')};

  &:focus {
    background-color: ${({ theme }) => (theme === 'white' ? colors.axaBlue200 : colors.axaBlue500)};
    outline: none;
  }

  &:hover {
    background-color: ${({ theme }) => (theme === 'white' ? colors.axaBlue200 : colors.axaBlue500)};
    transition: background-color 200ms ease-out;
    will-change: background-color;
  }

  &.network-allowed {
    cursor: pointer;
  }

  &:not(.network-allowed) > svg path {
    fill: ${colors.creditColor};
  }

  @media (min-width: ${media.tabletMin}) {
    padding: 7px;
  }
`

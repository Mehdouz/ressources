import React, { useState } from 'react'
import { array, string } from 'prop-types'
import svg from '@axacom-client/base/svg'
import { Button, ShareButtonWrapper } from './SocialShare.style'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { colors } from '@axacom-client/base/style/variables'
import { AnimatePresence, motion } from 'framer-motion/dist/framer-motion'
import { useShare } from '@axacom-client/hooks/useShare'

const variants = {
  visible: {
    transition: { ease: 'easeInOut', staggerChildren: 0.05 },
  },
}

const variantsLinks = {
  visible: {
    y: 0,
    opacity: 1,
  },
  hidden: {
    opacity: 0,
  },
  exit: {
    opacity: 0,
  },
}

export default function SocialShare({ title, theme = 'white' }) {
  const [isSharingVisible, setIsSharingVisible] = useState(false)

  const socials = ['facebook', 'twitter', 'linkedin', 'mail']
  const icons = { share: svg.IconShare, facebook: svg.IconSocialFacebook, twitter: svg.IconSocialTwitter, linkedin: svg.IconSocialLinkedin, mail: svg.IconEmail }

  const { onShare } = useShare({ title })

  return (
    <>
      <ShareButtonWrapper key={title} data-test-id="SocialShare_ShareButton" onClick={() => setIsSharingVisible(!isSharingVisible)} theme={theme}>
        {isSharingVisible ? (
          <Icon name="IconCloseNew" color={theme === 'white' ? colors.AXABlue : colors.white} width={14} height={14} />
        ) : (
          <Icon name="IconShareNew" color={theme === 'white' ? colors.AXABlue : colors.white} width={18} height={20} />
        )}
      </ShareButtonWrapper>

      <AnimatePresence>
        {isSharingVisible && (
          <motion.div key={title} variants={variants}>
            {socials.map((social, index) => {
              const Icon = icons[social]
              return (
                <Button
                  key={index + title}
                  data-key={social}
                  data-test-id="SocialShare_Link"
                  className={'network-allowed'}
                  data-analytics={`{"block_name":"share_button::${social}", "event_type":"A"}`}
                  onClick={() => onShare(social)}
                  theme={theme}
                  variants={variantsLinks}
                >
                  <Icon color={theme === 'white' ? colors.AXABlue : colors.brandBlue} width={20} height={20} />
                </Button>
              )
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

SocialShare.propTypes = {
  social: array,
  url: string,
  content: string,
  title: string,
  tweet: string,
  via: string,
  hashtags: string,
}

import React from 'react'
import { fullname } from '@axacom-client/services/string-service'
import { AuthorImage, AuthorName, AuthorRole, AuthorWrapper } from './Author.styles'
import Button from '@axacom-client/components/atoms/Button/Button'
import { DescriptionWrapper } from '@axacom-client/components/molecules/Author/Author.styles'

export default function Author({ slugifiedAnchor = '', author, authorPicture, authorName, authorRole, dataTestId = 'Author' }) {
  return (
    <AuthorWrapper id={slugifiedAnchor} data-testid={dataTestId} className="align-content-end align-top">
      {(authorPicture || author?.avatar) && (
        <ButtonIfTarget href={author?.deactivateProfile === 'Yes' ? null : author?.url} dataTestId={dataTestId} className="text-right">
          <AuthorImage src={(author?.avatar || authorPicture)?.main?.url} dataTestid={`${dataTestId}-Image`} round={true} ratio="1:1" className="p-0 d-inline-flex" />
        </ButtonIfTarget>
      )}
      <DescriptionWrapper isButton={author?.url} hasImage={!authorPicture && !author?.avatar}>
        <ButtonIfTarget href={author?.deactivateProfile === 'Yes' ? null : author?.url} dataTestId={dataTestId} className="d-block">
          <AuthorName data-testid={`${dataTestId}-Name`}>{fullname(author) || authorName}</AuthorName>
        </ButtonIfTarget>
        <AuthorRole data-testid={`${dataTestId}-Role`}>{author?.role || authorRole}</AuthorRole>
      </DescriptionWrapper>
    </AuthorWrapper>
  )
}

// ********** PRIVATE **********

function ButtonIfTarget({ href, dataTestId, children, className, style }) {
  return href ? (
    <Button type="link" color="red" href={href} dataTestId={`${dataTestId}-Button`} className={className} {...{ style }}>
      {children}
    </Button>
  ) : (
    children
  )
}

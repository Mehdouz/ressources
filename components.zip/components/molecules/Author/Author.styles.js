import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Typo16 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Text from '@axacom-client/components/molecules/Text/Text'
import Image from '@axacom-client/components/atoms/Image/Image'
import { getSpacing } from '@axacom-client/base/style/spacing'
import media from '@axacom-client/base/style/media'
import Button from '@axacom-client/components/atoms/Button/Button'

export const AuthorWrapper = styled.div`
  text-align: right;
  margin: 0 0 16px;
  text-transform: uppercase;
  vertical-align: top;
  display: flex;
  flex-direction: row;

  ${media.phone`
    text-align: left;
  `}

  ${media.tablet`
    flex-direction: column;
    align-items: end;
  `}
`

export const AuthorImage = styled(Image)`
  ${media.phone`
    width: 85px;
    height: 85px;
    flex: 0 0 85px;
    margin-right: ${getSpacing(2)};
  `}

  ${media.desktop`
      margin-top: 0;
  `}

  width: 100px;
  height: 100px;
  margin-bottom: ${getSpacing(2)};
`

export const AuthorName = styled(Text)`
  text-align: right;
  ${Typo16}
  font-weight: bold;
  letter-spacing: 1px;
  color: ${colors.brandRed};
  ${media.phone`
    text-align: left;
  `}
`

export const AuthorRole = styled(Text)`
  text-align: right;
  ${Typo16}

  ${media.phone`
    text-align: left;
  `}
`

export const DescriptionWrapper = styled.div`
  ${(props) =>
    media.phone`
      p {
        ${props.hasImage ? ' margin-left: 0; margin-bottom: 0;' : ''};
      }
    `}
`

export const StyledButton = styled(Button)`
  align-items: flex-start;
`

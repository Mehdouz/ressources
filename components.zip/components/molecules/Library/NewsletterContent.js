import React from 'react'
import ModalNewsletter from '@axacom-client/components/organisms/ModalNewsletter/ModalNewsletter'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'

export default function NewsletterContent() {
  const { i18n } = useGlobalContext()

  const modalNewsletterProps = {
    buttonLabel: i18n.t('newsletter.subscription.repository.button'),
    width: '100%',
    textContent: i18n.t('newsletterSubscription.policy'),
    checkboxGDPR: i18n.t('newsletterSubscription.checkboxGDPR'),
    defaultValue: { newsletterChoice: ['article'] },
  }
  return (
    <Wrapper>
      <Title>{i18n.t('newsletter.subscription.repository.title')}</Title>
      <Description>{i18n.t('newsletter.subscription.repository.description')}</Description>
      <ModalNewsletter data-testid="SuggestedNewsletterModal" {...modalNewsletterProps} />
    </Wrapper>
  )
}

const Wrapper = styled.div`
  margin: 0 24px 32px 24px;
  padding-bottom: 24px;
  border-bottom: 1px solid ${colors.grey400};
`

const Title = styled.h3`
  font-family: 'Publico-Headline', serif;
  font-weight: 400;
  font-size: 18px;
  line-height: 20px;
  letter-spacing: 0.005em;
`

const Description = styled.p`
  font-family: 'Source Sans Pro', sans-serif;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  margin-bottom: 24px;
`

import React from 'react'
import styled from 'styled-components'
import moment from 'moment'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import { getDateTimeZoneName } from '@axacom-client/services/date-service'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { formatDate } from '@axacom-client/components/organisms/EventHeader/EventHeader'

export default function TopEventContent({ dateTimeStart, dateTimeEnd, isBeforeToday, location }) {
  return (
    <Top>
      <EventDate dateTimeStart={dateTimeStart} dateTimeEnd={dateTimeEnd}></EventDate>
      <EventInfos $showTopSeparator={!isBeforeToday}>
        {location ? <BottomLabel>{location}</BottomLabel> : null}
        <EventTime dateTimeStart={dateTimeStart} dateTimeEnd={dateTimeEnd} isBeforeToday={isBeforeToday} />
      </EventInfos>
    </Top>
  )
}

function EventTime({ dateTimeStart, dateTimeEnd, isBeforeToday }) {
  const { i18n, currentLocale } = useGlobalContext()
  let formatTime = currentLocale === 'fr' ? 'H:mm' : 'h:mm A'
  const startTime = moment(dateTimeStart).format(formatTime)
  const endTime = moment(dateTimeEnd).format(formatTime)

  const { formatedStartingTime, startingFrom } = formatDate(dateTimeStart, dateTimeEnd)

  if (isBeforeToday) {
    return (
      <BottomLabel>
        <PastEvent>{i18n.t('eventBlock.pastEvent')}</PastEvent>
      </BottomLabel>
    )
  }

  if (startingFrom) {
    let formatTime = startingFrom ? `${formatedStartingTime}` : `${i18n.t('startat')} ${startTime} ${getDateTimeZoneName(dateTimeStart)}`

    return <BottomLabel>{formatTime}</BottomLabel>
  }

  // is not the same day but has start and end time
  if (startTime && endTime) {
    return (
      <BottomLabel>
        {startTime} {i18n.t('to')} {endTime} ({getDateTimeZoneName(dateTimeEnd)})
      </BottomLabel>
    )
  }

  // has at least one time
  if (startTime || endTime) {
    return (
      <BottomLabel>
        {startTime || endTime} ({getDateTimeZoneName(dateTimeStart)})
      </BottomLabel>
    )
  }
  return null
}

function EventDate({ dateTimeStart, dateTimeEnd }) {
  // days
  const dayStart = moment(dateTimeStart).format('DD')
  const dayEnd = moment(dateTimeEnd).format('DD')

  // months
  const monthStart = moment(dateTimeStart).format('MMM')
  const monthEnd = moment(dateTimeEnd).format('MMM')

  // years
  const yearStart = moment(dateTimeStart).format('YYYY')
  const yearEnd = moment(dateTimeEnd).format('YYYY')

  // values for statement
  const eventDayMonthStart = moment(dateTimeStart).format('DD/MMM')
  const eventDayMonthEnd = moment(dateTimeEnd).format('DD/MMM')

  // if event is on the same day, display a single date
  if (eventDayMonthStart === eventDayMonthEnd) {
    return (
      <TextDate>
        <Day>{dayStart}</Day>
        <MonthYear>{`${monthStart} ${yearStart}`}</MonthYear>
      </TextDate>
    )
  } else {
    return (
      <DoubleTextDate>
        <TextDate $double>
          <Day $double>{dayStart}</Day>
          <MonthYear $double>
            {monthStart} {yearStart}
          </MonthYear>
        </TextDate>
        <DoubleSeparator />
        <TextDate $double>
          <Day $double>{dayEnd}</Day>
          <MonthYear $double>
            {monthEnd} {yearEnd}
          </MonthYear>
        </TextDate>
      </DoubleTextDate>
    )
  }
}

const EventInfos = styled.div`
  padding-top: 24px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  ${media.desktop`
    ${({ $showTopSeparator }) => ($showTopSeparator ? `border-top: 1px solid ${colors.moduleGreyLight};` : ``)}
  `}
`

const Top = styled.div`
  padding: 24px;
  color: ${colors.bodyBg};
  background-color: ${colors.moduleDarkBlue};
  ${media.desktop`
    width: 24%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
  `}
  ${media.desktopLarge`
    width: 22%;
  `}
`

const DoubleTextDate = styled.div`
  display: flex;
  margin-bottom: 32px;
`

const DoubleSeparator = styled.div`
  margin: 0 24px;
  width: 1px;
  background-color: ${colors.moduleGreyLight};
  ${media.desktop`
    margin: 0 12px;
  `}
`
const TextDate = styled.div`
  display: flex;
  align-items: flex-end;
  gap: 16px;
  ${({ $double }) =>
    $double
      ? `
  flex-direction: column;
  align-items: center;
  gap: 16px;
  `
      : ``}

  ${media.desktop`
    flex-direction: column;
    align-items: center;
    padding-bottom: 0;
    margin-bottom: 0;
    gap: 0;
    ${({ $double }) =>
      $double
        ? `
      border-bottom: 0;
    `
        : ``}
  `}
`

const Day = styled.div`
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 68px;
  line-height: 50px;
  letter-spacing: 0.015em;
  display: inline-block;
  ${({ $double }) =>
    $double
      ? `
  font-size: 36px;
  line-height: 40px;`
      : ''}
  ${media.desktop`
    ${({ $double }) =>
      $double
        ? `
    font-size: 48px;
    line-height: 50px;
    `
        : `
    font-size: 82px;
    line-height: 84px;
    `}
  `}
  ${media.desktopLarge`
  ${({ $double }) =>
    $double
      ? ``
      : `
    font-size: 82px;
    line-height: 84px;
    `}
  `}
`

const MonthYear = styled.div`
  font-family: ${font.fontFamilyBase};
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.07em;
  font-size: 22px;
  line-height: 22px;

  ${media.desktop`
  font-size: 20px;
  line-height: 24px;
  margin-bottom: 24px;
    ${({ $double }) =>
      $double
        ? `
        text-align: center;
        margin-bottom: 0;
    `
        : ''}
  `}
`

const BottomLabel = styled.div`
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;
  ${media.desktop`
    text-align: center;
    margin-bottom: 24px;
    &:last-child {
      margin-bottom: 0;
    }
  `}
`

const PastEvent = styled.div`
  background-color: ${colors.moduleGreyLight};
  color: ${colors.moduleDarkBlue};
  padding: 5px;
  display: inline-block;
  font-weight: 700;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.1em;
`

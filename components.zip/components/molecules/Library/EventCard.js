import React, { useState } from 'react'
import styled from 'styled-components'
import moment from 'moment'

import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { colors, font } from '@axacom-client/base/style/variables'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { Skeleton } from '@axacom-client/components/atoms/Skeleton/Skeleton'
import { Typo14 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import media, { mediaQueries } from '@axacom-client/base/style/media'
import LegacyShare from '@axacom-client/components/organisms/EventHeader/LegacyShare'
import { DownloadButton } from '@axacom-client/components/organisms/EventHeader/EventHeader.style'

import EventCountryDate from './EventCountryDate'
import ShareActions from './ShareActions'
import { useMediaQuery } from 'react-responsive'

export default function EventCard({ eventTimeEnd, eventTimeStart, audiences, city, country, title, description, href, ical }) {
  const { i18n } = useGlobalContext()
  const isDesktop = useMediaQuery({ query: mediaQueries.desktopLarge })
  const isMobile = useMediaQuery({ query: mediaQueries.phone })

  const isBeforeToday = !moment(eventTimeEnd ?? eventTimeStart).isAfter(moment().startOf('day'))
  const [isSharingVisible, setIsSharingVisible] = useState(false)

  const location = [city, country].filter((x) => !!x).join(', ')
  return (
    <EventItem>
      {/* Blue content */}
      <EventCountryDate dateTimeStart={eventTimeStart} dateTimeEnd={eventTimeEnd} isBeforeToday={isBeforeToday} location={location} />

      {/* Grey content */}
      <Bottom>
        <Audience>{audiences}</Audience>
        <Title href={href}>{title}</Title>
        {description ? <Description>{description}</Description> : null}

        {!isDesktop ? (
          <ReadMore href={href}>
            {i18n.t('eventsBlock.moreDetails')}
            <Icon name="IconArrow" color={colors.brandOrange} width={12} height={12} style={{ marginLeft: '16px' }} />
          </ReadMore>
        ) : null}

        {isMobile ? (
          <MobileActions>
            <DownloadButton type="ghost" color="blue" href={ical} download={title.replace(/\.| /gm, '-')} target="_self">
              {i18n.t('eventBlock.addToCalendar')}
            </DownloadButton>
            <LegacyShare title={title} setVisible={setIsSharingVisible} isVisible={isSharingVisible} />
          </MobileActions>
        ) : (
          <Buttons>
            <AddToCalendar href={ical} download={title.replace(/\.| /gm, '-')} target="_self" color={colors.actionBtnBlueHover}>
              <Icon name="IconCalendar" color={colors.actionBtnBlueHover} width={20} height={20} style={{ marginRight: '16px' }} />
              {i18n.t('eventBlock.addToCalendar')}
            </AddToCalendar>

            <ShareActions url={href} title={title} description={description || title} />
            {isDesktop ? (
              <ReadMore href={href}>
                {i18n.t('eventsBlock.moreDetails')}
                <Icon name="IconArrow" color={colors.brandOrange} width={12} height={12} style={{ marginLeft: '16px' }} />
              </ReadMore>
            ) : null}
          </Buttons>
        )}
      </Bottom>
    </EventItem>
  )
}

export const EventSkeletonItem = () => {
  return (
    <EventCardSkeleton>
      <Skeleton style={{ height: '60px' }} />
      <Skeleton style={{ height: 60 }} />
    </EventCardSkeleton>
  )
}

const EventCardSkeleton = styled.div`
  padding: 0 32px;
  ${media.tablet`
    padding-left: 0;
  `}
`

const MobileActions = styled.div`
  display: flex;
  flex-direction: column;
  align-items: stretch;
  width: 100%;
`

const EventItem = styled.div`
  padding: 0 32px;
  display: flex;
  flex-direction: column;
  margin-bottom: 32px;
  ${media.tablet`
    padding: 0;
    margin-right: 32px;
  `}
  ${media.desktop`
    flex-direction: row;
  `}
`

const Bottom = styled.div`
  padding: 32px;
  background-color: ${colors.moduleGreyLight};
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  ${media.desktop`
    width: 76%;
  `}
  ${media.desktopLarge`
    width: 78%;
  `}
`

const Audience = styled.div`
  margin-top: 0;
  color: ${colors.des_blueDark};
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.1em;
  line-height: 1.5;
`

const Title = styled(SmartLink)`
  display: block;
  cursor: pointer;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 22px;
  line-height: 28px;
  letter-spacing: 0.015em;
  color: ${colors.textColor};
  &:hover {
    color: ${colors.grey500};
  }
  ${media.desktop`
    flex: 1;
  `}
`

const Description = styled.p`
  margin: 0;
  font-family: 'Source Sans Pro', sans-serif;
  font-size: 18px;
  line-height: 1.5;
  margin-bottom: 32px;
`

const ReadMore = styled(SmartLink)`
  color: ${colors.brandRed};
  transition: color 0.3s linear;
  cursor: pointer;
  display: inline-block;
  vertical-align: middle;
  text-align: center;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.1em;
  margin-bottom: 32px;
  &:last-child {
    margin-bottom: 0;
  }
`

const Buttons = styled.div`
  height: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`

const AddToCalendar = styled(SmartLink)`
  ${Typo14}
  text-decoration: none;
  text-transform: uppercase;
  font-weight: 700;
  color: ${(props) => props.color};
  display: flex;
  align-items: center;
  &:hover {
    cursor: pointer;
    color: ${(props) => props.color};
  }
`

import React from 'react'
import styled from 'styled-components'
import { font, colors } from '@axacom-client/base/style/variables'
import { useLibraryProvider } from '@axacom-client/store/LibraryContext'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

export default function DateFilters() {
  const { year: currentYear, yearFilters, handleDateChange, type } = useLibraryProvider()
  return (
    <DateList style={{ marginBottom: type === 'events' ? 32 : 0 }}>
      {yearFilters.map((year, i) => (
        <DateItem $active={currentYear === year.value} $alternative={year.alternative} key={year.value + i} onClick={() => handleDateChange(year)}>
          {year.icon ? <Icon name={year.icon} color={currentYear === year.value ? (year.alternative ? colors.brandBlue : colors.brandOrange) : colors.grey500} width={16} height={16} /> : null}
          <DateValue $active={currentYear === year.value} $alternative={year.alternative}>
            {year.date}
          </DateValue>
        </DateItem>
      ))}
    </DateList>
  )
}

const DateList = styled.ul`
  border-top: 1px solid #eee;
  border-bottom: 1px solid #eee;
  margin-bottom: 32px;

  display: flex;
  overflow-x: visible;
  overflow-y: hidden;
  list-style-type: none;
  padding-left: 0;
  margin-bottom: 32px;
`

const DateItem = styled.button`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-shrink: 0;
  position: relative;
  background-color: transparent;
  align-self: flex-end;
  vertical-align: middle;
  cursor: pointer;
  position: relative;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  font-size: 13px;
  line-height: 1.5;
  letter-spacing: 0.1em;
  border: 0;
  color: ${colors.grey500};
  transition: color 0.2s, border-color 0.2s;

  border-bottom: 3px;
  border-bottom-style: solid;
  border-bottom-color: transparent;
  &:hover {
    color: ${colors.brandOrange};
    border-bottom-color: ${colors.brandOrange};
  }
  ${({ $active }) =>
    $active
      ? `
    color: ${({ $alternative }) => ($alternative ? 'green' : colors.brandOrange)};
    border-bottom-color: ${colors.brandOrange};
    svg > path {
      background: ${({ $alternative }) => ($alternative ? colors.brandBlue : colors.brandOrange)};

    }
    svg path {
      fill: ${({ $alternative }) => ($alternative ? colors.brandBlue : colors.brandOrange)};
    }
  `
      : ''}
`

const DateValue = styled.div`
  padding: 16px 16px 16px;
  ${({ $active, $alternative }) => ($active ? `color: ${$alternative ? colors.brandBlue : colors.brandOrange}` : '')}
`

import React from 'react'
import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import styled from 'styled-components'
import { Skeleton } from '@axacom-client/components/atoms/Skeleton/Skeleton'

export default function Card({ href, date, title, sub }) {
  return (
    <OuterItem>
      <Item href={href}>
        <Date>{date}</Date>
        <Details>
          <Title>{title}</Title>
          <Sub>{sub}</Sub>
        </Details>
      </Item>
    </OuterItem>
  )
}

export const CardSkeletonItem = () => (
  <div style={{ padding: '32px 32px 0' }}>
    <Skeleton style={{ width: '120px' }} />
    <Skeleton style={{ height: 32 }} />
    <Skeleton style={{ width: '160px' }} />
  </div>
)

const OuterItem = styled.div`
  cursor: pointer;
  display: block;
  transition: background-color 0.2s;
  background-color: white;
  &:hover {
    background-color: ${colors.grayLighter};
  }
  padding: 0 24px;
  ${media.tablet`
    padding: 0;
  `}
`

const Item = styled(SmartLink)`
  ${media.tablet`
    display: flex;
    gap: 8px;
  `}

  padding: 25px 15px;
  border-bottom: 1px solid #eee;
  ${media.tablet`
    padding: 20px 20px 30px;
    margin: 0;
  `}

  ${media.desktop`
    padding: 30px;
  `}

  transition: transform 0.3s ease;
  transform: translateX(0px);
  &:hover {
    transform: translateX(10px);
  }
`

const Date = styled.div`
  color: ${colors.textColor};
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  text-transform: uppercase;
  font-size: 13px;
  line-height: 1.5;
  letter-spacing: 0.085em;

  ${media.tablet`
    width: 25%;
    margin-top: 10px;
  `}

  ${media.desktop`
    width: 20%;
  `}
`

const Details = styled.div`
  display: block;

  ${media.tablet`
    width: 75%;
  `}

  ${media.desktop`
    width: 80%;
  `}
`

const Title = styled.div`
  display: inline-block;
  vertical-align: middle;
  margin: 5px 0;
  color: ${colors.textColor};
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 22px;
  line-height: 28px;
  letter-spacing: 0.015em;

  ${media.desktopLarge`
    font-size: 28px;
    line-height: 34px;
  `}
`

const Sub = styled.div`
  color: ${colors.grey500};
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.regular};
  text-transform: uppercase;
  font-size: 13px;
  line-height: 1.5;
  letter-spacing: 0.08em;

  ${media.desktopLarge`
    font-size: 13px;
  `}
`

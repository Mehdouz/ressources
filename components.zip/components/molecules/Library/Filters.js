import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { colors, font } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { useLibraryProvider } from '@axacom-client/store/LibraryContext'
import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import media from '@axacom-client/base/style/media'
import NewsletterContent from './NewsletterContent'

export function ModalFilters({ onClose }) {
  const { i18n } = useGlobalContext()

  return (
    <SideMenuModal transition={{ type: 'tween', duration: 0.1 }} initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}>
      <StyledSliceModal bgColor="gray">
        {/* Close button */}
        <FiltersButton onClick={onClose}>
          {i18n.t('library.filters')}
          <Icon name="IconCross" color={colors.brandRed} width={16} height={16} />
        </FiltersButton>

        <FilterSettings />
      </StyledSliceModal>
    </SideMenuModal>
  )
}

export function SideMenuFilters() {
  return (
    <RightWrapper>
      <FilterSettings />
    </RightWrapper>
  )
}

function FilterSettings() {
  const { i18n } = useGlobalContext()

  const { filterLabel, defaultFilters, activefilters, total, handleActiveFilterChange, type } = useLibraryProvider()

  const handleFilterClick = (filter) => {
    const newFilters = activefilters.includes(filter.id) ? activefilters.filter((f) => f !== filter.id) : [...activefilters, filter.id]
    handleActiveFilterChange(newFilters)
  }

  const handleClearFilters = () => {
    handleActiveFilterChange([])
  }

  const disabledClear = activefilters.length === 0 || activefilters.length === defaultFilters.length

  return (
    <>
      {type === 'pressReleases' ? <NewsletterContent /> : null}

      {/* label & count */}
      <LibraryTotalLabel>{'Total ' + i18n.t(`${type}.library.doc`)}</LibraryTotalLabel>
      <Count>{total || 0}</Count>

      {/* Filter list */}
      {defaultFilters?.length > 0 && (
        <>
          {/* Clear filters */}
          <FiltersButton disabled={disabledClear} onClick={handleClearFilters}>
            {i18n.t('filter.clear.all')}
            <Icon name="IconCross" color={colors.brandRed} width={16} height={16} />
          </FiltersButton>
          <FiltersGroup>
            <FiltersGroupTitle>{filterLabel}</FiltersGroupTitle>
            <FilterItemGroup>
              {defaultFilters.map((filter, i) => {
                return (
                  <FilterItem key={i} $activefilters={activefilters} $active={activefilters.includes(filter.id)} onClick={() => handleFilterClick(filter)}>
                    {filter?.title}
                  </FilterItem>
                )
              })}
            </FilterItemGroup>
          </FiltersGroup>
        </>
      )}
    </>
  )
}

export const FilterSettingsWrapper = styled.div`
  background-color: red;
`
export const RightWrapper = styled.div`
  overflow: auto;
  padding: 32px 0;
  transform: translate(0, 0);
  transform: translate3d(0, 0, 0);
  transition: transform 0.4s ease;
  background: ${colors.grayLighter};

  ${media.tablet`
    width: 30%;
  `}

  ${media.desktop`
    width: 25%;
  `}

  ${media.desktopLarge`
    width: 20%;
  `}
`

const FiltersButton = styled.button`
  background: transparent;
  border: 0;
  padding: 8px 24px;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  font-size: 13px;
  line-height: 1;
  letter-spacing: 0.1em;
  color: ${colors.brandRed};
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  transition: color 0.2s ease;
  &:hover {
    color: ${colors.brandRedHover};
  }
  &:disabled {
    color: ${colors.grey400};
    cursor: initial;
    & svg,
    & g {
      fill: ${colors.grey400};
    }
  }
  margin-bottom: 16px;
`

export const SideMenuModal = styled(motion.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  transform: translate3d(50%, 0, 0);
  transition: transform 0.4s ease;
  z-index: 1050;
  display: block;
  width: 100%;
  height: 100vh;
  overflow: hidden;
  outline: 0;
`

export const StyledSliceModal = styled(Slice)`
  overflow: auto;
  height: 100vh;
`

export const LibraryTotalLabel = styled.div`
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;
  margin-bottom: 16px;
  padding: 0 24px;
`

export const Count = styled.div`
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 32px;
  line-height: 34px;
  letter-spacing: 0.015em;
  line-height: normal;
  font-size: 75px;
  color: ${colors.grey400};
  padding: 0 24px;
  margin-bottom: 64px;
`

export const FiltersGroup = styled.div`
  border-top: 1px solid #dadada;
  padding: 40px 0;
`

export const FiltersGroupTitle = styled.div`
  font-family: ${font.fontFamilyBase};
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;
  padding-left: 24px;
`

export const FilterItemGroup = styled.div`
  padding: 32px 0;
  display: flex;
  flex-wrap: wrap;
  flex-direction: column;
  align-items: flex-start;
`

export const FilterItem = styled.button`
  display: block;
  text-align: left;
  line-height: 1.5;
  text-transform: uppercase;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  font-size: 13px;
  letter-spacing: 0.1em;
  border: 0;
  border-left: 4px;
  border-left-style: solid;
  border-left-color: transparent;
  padding: 0 8px;
  color: ${colors.grey400};

  cursor: pointer;
  background: transparent;
  padding: 8px 16px 8px calc(24px - 4px);
  ${(props) =>
    props.$active &&
    `
      color: ${colors.brandOrange};
      border-left-color: ${colors.brandOrange};
  `}

  ${media.desktop`
    &:hover {
      color: ${colors.brandOrange};
    }`}
`

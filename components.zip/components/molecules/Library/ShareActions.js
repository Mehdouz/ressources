import React, { useState } from 'react'
import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import { colors, font } from '@axacom-client/base/style/variables'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Typo14 } from '@axacom-client/base/style/typoStyle/typoStyle'

import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { getLocation } from '@axacom-client/services/window-service'
import { getFacebookUrl, getLinkedinUrl, getTwitterUrl } from '@axacom-client/services/social-media-service'
import Icon from '@axacom-client/components/atoms/Icon/Icon'

export default function ShareActions({ title, description, url }) {
  const [open, setOpen] = useState(false)

  const completeUrl = `${getLocation('protocol')}//${getLocation('host')}${url}`

  const facebookUrl = getFacebookUrl(completeUrl)
  const twitterUrl = getTwitterUrl(completeUrl, 'AXA', title || description)
  const linkedinUrl = getLinkedinUrl(completeUrl, title, description, completeUrl)

  const handleClick = () => setOpen(!open)
  return (
    <Share>
      {open ? (
        <ShareSocials>
          <ShareLabel key={url + 'inside'} layoutId={url + 'shareButton'} onClick={handleClick} />
          <SmartLink target="_blank" href={facebookUrl}>
            <span style={{ display: 'none' }} aria-hidden="true">
              Facebook
            </span>
            <Icon name="IconFacebook" color={colors.actionBtnBlueHover} width={20} height={20} />
          </SmartLink>
          <SmartLink target="_blank" href={twitterUrl}>
            <span style={{ display: 'none' }} aria-hidden="true">
              Twitter
            </span>
            <Icon name="IconTwitter" color={colors.actionBtnBlueHover} width={20} height={20} />
          </SmartLink>
          <SmartLink target="_blank" href={linkedinUrl}>
            <span style={{ display: 'none' }} aria-hidden="true">
              Linkedin
            </span>
            <Icon name="IconLinkedin" color={colors.actionBtnBlueHover} width={20} height={20} />
          </SmartLink>
        </ShareSocials>
      ) : (
        <ShareLabel key={url + 'outside'} layoutId={url + 'shareButton'} onClick={handleClick} />
      )}
    </Share>
  )
}

function ShareLabel({ ...rest }) {
  const { i18n } = useGlobalContext()
  return (
    <ShareLabelContainer {...rest}>
      <Icon name="IconShare" color={colors.actionBtnBlueHover} width={16} height={16} style={{ marginRight: '16px' }} />
      {i18n.t('pressrelease.share')}
    </ShareLabelContainer>
  )
}

const ShareLabelContainer = styled(motion.button)`
  border: 0;
  background: ${colors.moduleGreyLight};
  color: ${colors.actionBtnBlueHover};
  ${Typo14}
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  display: flex;
  height: 24px;
  align-items: center;
`

const ShareSocials = styled(motion.div)`
  display: flex;
  height: 24px;
  align-items: center;
  gap: 16px;
`

const Share = styled.div`
  ${Typo14}
  border: 0;
  background-color: transparent;
  text-decoration: none;
  text-transform: uppercase;
  font-weight: 700;
  color: ${colors.actionBtnBlueHover};
  display: flex;
  align-items: center;
  &:hover {
    cursor: pointer;
    color: ${colors.actionBtnBlueHover};
  }
`

import { colors, font } from '@axacom-client/base/style/variables'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import styled from 'styled-components'
import media from '@axacom-client/base/style/media'

export const LibraryWrapper = styled.div`
  position: relative;
  overflow: hidden;
  ${media.tablet`
    background: linear-gradient(to right, ${colors.white} 70%, ${colors.grayLighter} 30%, ${colors.grayLighter});
`}
`
export const Wrapper = styled.div`
  width: 100%;

  ${media.tablet` // 767px
    max-width: 750px;
    position: relative;
    display: inline-block;
    vertical-align: middle;
  `}

  ${media.desktop`
    max-width: 970px;
  `}

  ${media.desktopLarge`
    max-width: 1170px;
  `}
`
export const FilterContent = styled.div`
  padding: 0 32px;
  ${media.tablet`
    padding: 0;
  `}
`

export const LibraryContainer = styled(Container)`
  display: flex;
  ${media.phone`
    padding: 0;
  `}
`

export const LeftWrapper = styled.div`
  padding-top: 32px;
  padding-bottom: 32px;
  background-color: white;
  width: 100%;

  ${media.tablet`
    padding-top: 48px;
    padding-bottom: 48px;
    width: 70%;
  `}

  ${media.desktop`
    width: 75%;
  `}

  ${media.desktopLarge`
    width: 80%;
  `}

  ${media.desktopVeryLarge`
    padding-top: 64px;
    padding-bottom: 64px;
  `}
`

export const Title = styled.div`
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  font-size: 28px;
  line-height: 28px;
  letter-spacing: 0.015em;
  margin-bottom: 16px;
  ${media.tablet`
    margin-bottom: 32px;
  `}

  ${media.desktop`
    font-size: 48px;
    margin-bottom: 64px;
  `}
`

export const FiltersButton = styled.button`
  background: transparent;
  border: 0;
  padding: 8px 24px 8px 0;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  text-transform: uppercase;
  font-size: 13px;
  line-height: 1;
  letter-spacing: 0.1em;
  color: ${colors.brandRed};
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  transition: color 0.2s ease;
  &:hover {
    color: ${colors.brandRedHover};
  }
  margin-bottom: 16px;
`

export const Filters = styled.div`
  display: flex;
  gap: 16px;
  list-style: none;
  margin-bottom: 32px;
  flex-wrap: wrap;

  ${media.desktop`
    display: inline-flex;
  `}
`

export const Filter = styled.button`
  line-height: 32px;
  text-transform: uppercase;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  font-size: 13px;
  letter-spacing: 0.1em;
  border: 0;
  padding: 0 8px;
  background: ${colors.grey200};
  color: ${colors.brandOrange};
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
`

export const StyledLibrarySlice = styled(Slice)`
  background: transparent;
`

export const ActiveFiltersLabel = styled.span`
  font-family: ${font.familyBase};
  font-weight: ${font.weight.regular};
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 30px;
  margin: 0 20px 0 0;
  width: 20%;
`

export const FiltersWrapper = styled.div`
  ${media.desktop`
    display: flex;
  `}
`

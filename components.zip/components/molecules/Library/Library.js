import React, { useState } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { createPortal } from 'react-dom'
import { useLibraryProvider } from '@axacom-client/store/LibraryContext'
import { useMediaQuery } from 'react-responsive'
import { mediaQueries } from '@axacom-client/base/style/media'
import { ShortMessage } from '@axacom-client/components/organisms/Slices/Message/Message'
import { LibraryWrapper, LeftWrapper, Title, Filters, FiltersButton, Filter, LibraryContainer, FilterContent } from './Library.style'
import { ModalFilters, SideMenuFilters } from './Filters'
import DateFilters from './DateFilters'
import ResultsView from './ResultsView'
import { getDocument } from '@axacom-client/services/window-service'

export default function Library({ title }) {
  const { i18n } = useGlobalContext()

  const isAboveMobile = useMediaQuery({ query: mediaQueries.tablet })

  const { error } = useLibraryProvider()

  return (
    <LibraryWrapper>
      <LibraryContainer>
        {/* <Wrapper> */}
        <LeftWrapper>
          <FilterContent>
            <Title>{title}</Title>

            {/* Filters */}
            <FilterView />
          </FilterContent>

          {/* DateFilters */}
          <DateFilters />

          {/* Errors */}
          {error ? <ShortMessage title={i18n.t('search.error.title')} content={i18n.t('search.error.content')} /> : null}

          {/* Results */}
          <ResultsView />
        </LeftWrapper>
        {/* </Wrapper> */}
        {isAboveMobile ? <SideMenuFilters /> : null}
      </LibraryContainer>
    </LibraryWrapper>
  )
}

const FilterView = () => {
  const { i18n } = useGlobalContext()

  const isMobile = useMediaQuery({ query: mediaQueries.phone })

  const { activefilters, defaultFilters, handleActiveFilterChange } = useLibraryProvider()

  const [displaySideMenu, setDisplaySideMenu] = useState(false)

  const handleSideMenu = () => setDisplaySideMenu(!displaySideMenu)

  const handleRemoveFilter = (removedFilter) => {
    const newFilters = activefilters?.filter((f) => f !== removedFilter.id)
    handleActiveFilterChange(newFilters)
  }

  const hasFilters = defaultFilters?.length > 0
  const filteredFilters = hasFilters && defaultFilters?.filter((f) => activefilters.includes(f.id))

  const hasActiveFilters = filteredFilters?.length > 0

  if (!hasFilters) return null

  return (
    <>
      {isMobile ? (
        <>
          <FiltersButton onClick={handleSideMenu}>
            {i18n.t('library.filters')}
            <Icon name="IconPlus" color={colors.brandRed} width={16} height={16} />
          </FiltersButton>
          {displaySideMenu && createPortal(<ModalFilters onClose={() => setDisplaySideMenu(false)} />, getDocument().body)}
        </>
      ) : null}
      {hasActiveFilters ? (
        <Filters>
          {filteredFilters.map((filter, i) => (
            <Filter key={i} onClick={() => handleRemoveFilter(filter)}>
              {filter?.title}
              <Icon name="IconCross" color={colors.brandRed} width={16} height={16} />
            </Filter>
          ))}
        </Filters>
      ) : null}
    </>
  )
}

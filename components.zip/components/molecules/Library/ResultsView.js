import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { useLibraryProvider } from '@axacom-client/store/LibraryContext'
import Pagination from '@axacom-client/components/molecules/Pagination/Pagination'
import EventCard, { EventSkeletonItem } from './EventCard'
import Card, { CardSkeletonItem } from './Card'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { ShortMessage } from '@axacom-client/components/organisms/Slices/Message/Message'

const RESULTS_COMPONENTS = {
  events: EventCard,
  publications: Card,
  pressReleases: Card,
}

const SKELETONS_COMPONENTS = {
  events: EventSkeletonItem,
  publications: CardSkeletonItem,
  pressReleases: CardSkeletonItem,
}

function SkeletonItems({ type, count = 5 }) {
  const SkeletonItem = SKELETONS_COMPONENTS[type]

  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonItem key={i} />
      ))}
    </>
  )
}

export default function ResultsView() {
  const { i18n, bookmarks } = useGlobalContext()

  const { type, loading, results, error, pageCount, page, handlePageChange } = useLibraryProvider()
  if (loading) return <SkeletonItems type={type} />

  const ComponentResultItem = RESULTS_COMPONENTS[type]

  if (!loading && !error && results.length === 0) {
    return (
      <ShortMessage
        title={
          <span>
            {i18n.t('search.noResults')} <SmartLink href={bookmarks.search.url}>{i18n.t('search.engine')}</SmartLink>
          </span>
        }
      />
    )
  }
  return (
    <div data-testid={`library__results--${type}`}>
      {results.map(({ url, ...result }, index) => {
        return (
          <React.Fragment key={index}>
            <ComponentResultItem href={url} {...result}></ComponentResultItem>
          </React.Fragment>
        )
      })}
      {pageCount > 1 ? <Pagination data-testid="library__pagination" currentPage={page} totalPages={pageCount || 0} onPageChange={handlePageChange} /> : null}
    </div>
  )
}

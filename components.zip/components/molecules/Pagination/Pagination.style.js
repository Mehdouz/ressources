import styled, { css } from 'styled-components'

import { colors } from '@axacom-client/base/style/variables'

export const Container = styled.div`
  text-align: center;
`

export const List = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  justify-content: center;
  align-items: baseline;
  border-bottom: 1px solid ${colors.grayLighter};
`

const activeListItem = css`
  margin-top: -2px;
  color: ${colors.brandRed};
  border-bottom: 2px solid ${colors.brandRed};
`

export const ListItem = styled.li`
  ${({ $active }) => css`
    padding: 15px;
    color: ${colors.creditColor};
    float: left;
    cursor: pointer;

    ${$active && activeListItem}

    @media (hover: hover) {
      &:hover,
      &:focus {
        ${activeListItem}
      }
    }
  `}
`

export const ListItemLabel = styled.div`
  ${({ $active }) => {
    $active &&
      css`
        top: 2px;
        position: relative;
      `
  }}
`

const previousNext = css`
  position: relative;
  padding: 16px;
  transform: translate(0, 33%);
  color: ${colors.grayLighter};
`

const afterPreviousNext = css`
  content: '';
  position: absolute;
  top: 34%;
  width: 10px;
  height: 10px;
  border-top: 2px solid ${colors.grayLighter};
`

const activePreviousNext = css`
  cursor: pointer;

  &::after {
    border-color: ${colors.brandRed};
  }
`

export const Previous = styled.li`
  ${({ $active }) => css`
    ${previousNext}

    &::after {
      ${afterPreviousNext}

      left: 42%;
      border-left: 2px solid ${colors.grayLighter};
      transform: rotate(-45deg);
    }

    ${$active && activePreviousNext}
  `}
`

export const Next = styled.li`
  ${({ $active }) => css`
    ${previousNext}

    &::after {
      ${afterPreviousNext}
      left: 28%;
      border-right: 2px solid ${colors.grayLighter};
      transform: rotate(45deg);
    }

    ${$active && activePreviousNext}
  `}
`

import React, { useState, useCallback } from 'react'
import { number, func } from 'prop-types'

import { Container, List, ListItem, ListItemLabel, Previous, Next } from './Pagination.style'

function Pagination({ currentPage, totalPages, onPageChange, ...rest }) {
  const [nextPrev, setNextPrev] = useState(0)
  const onPrevious = useCallback(() => {
    setNextPrev(nextPrev - 1)
  }, [nextPrev])
  const onNext = useCallback(() => {
    setNextPrev(nextPrev + 1)
  }, [nextPrev])
  const onPageClick = useCallback(
    (pageNumber) => () => {
      if (pageNumber === currentPage) {
        return
      }
      setNextPrev(0)
      onPageChange?.(pageNumber)
    },
    [currentPage, onPageChange]
  )

  const groupLength = 5
  const totalGroups = Math.ceil(totalPages / groupLength)
  const currentGroup = Math.ceil(currentPage / groupLength) + nextPrev
  const currentGroupLength = currentGroup === totalGroups ? (totalPages % groupLength === 0 ? groupLength : totalPages % groupLength) : groupLength
  const previousActive = currentGroup > 1
  const nextActive = currentGroup !== totalGroups

  const pageNumbers = []
  for (let i = 1; i <= currentGroupLength; i++) {
    pageNumbers.push(i + (currentGroup - 1) * groupLength)
  }

  return (
    <Container data-testid="pagination__container" {...rest}>
      <List data-testid="pagination__list">
        <Previous $active={previousActive} onClick={previousActive ? onPrevious : undefined} data-testid="pagination__previous" />
        {pageNumbers.map((pageNumber) => (
          <ListItem key={pageNumber} onClick={onPageClick(pageNumber)} $active={pageNumber === currentPage} data-testid="pagination__list-item">
            <ListItemLabel data-testid="pagination__list-item__label">{pageNumber}</ListItemLabel>
          </ListItem>
        ))}
        <Next $active={nextActive} onClick={nextActive ? onNext : undefined} data-testid="pagination__next" />
      </List>
    </Container>
  )
}

Pagination.propTypes = {
  currentPage: number,
  totalPages: number,
  onPageChange: func,
}

export default Pagination

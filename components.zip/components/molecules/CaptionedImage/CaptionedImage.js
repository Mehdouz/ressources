import React from 'react'
import { object, string } from 'prop-types'
import styled from 'styled-components'
import { colors } from '../../../base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { Typo16 } from '@axacom-client/base/style/typoStyle/typoStyle'

const CaptionText = styled.div`
  ${Typo16}
  margin-top: ${getSpacing(2)};
  text-align: left;
  color: ${colors.creditColor};
  padding: 0 ${getSpacing(2)};
`

const CaptionedImage = ({ image, caption, dataTestid }) => {
  return (
    <figure>
      <img src={image?.main?.url} alt={image?.main?.alt} data-testid={`CaptionImage-${dataTestid}`} />
      {caption && (
        <figcaption>
          <CaptionText data-testid={`CaptionText-${dataTestid}`}>
            <Icon name="IconCamera" style={{ marginRight: getSpacing(1), marginTop: '-4px' }} color={colors.creditColor} /> {caption}
          </CaptionText>
        </figcaption>
      )}
    </figure>
  )
}

export default CaptionedImage

CaptionedImage.propTypes = {
  image: object,
  caption: string,
  dataTestid: string,
}

CaptionedImage.defaultProps = {}

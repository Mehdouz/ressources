import styled from 'styled-components'
import { Typo16 } from '../../../base/style/typoStyle/typoStyle'
import { colors } from '../../../base/style/variables'
import { getSpacing } from '../../../base/style/spacing'

export const Wrapper = styled.div`
  display: flex;
  height: 100%;
  width: 100%;
`

export const Text = styled.span`
  ${Typo16}
  color: ${(props) => props.color || colors.greenSuccess};
  margin-left: ${getSpacing(1)};
`

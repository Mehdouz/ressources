import React from 'react'
import { oneOfType, object, array, string } from 'prop-types'

import Icon from '../../atoms/Icon/Icon'
import { Text, Wrapper } from './TextWithIcon.style'

const TextWithIcon = ({ iconName, children, color }) => (
  <Wrapper>
    <Icon name={iconName} color={color} width={20} height={20} />
    <Text color={color}>{children}</Text>
  </Wrapper>
)

export default TextWithIcon

TextWithIcon.propTypes = {
  children: oneOfType([string, object, array]),
  iconName: string,
  color: string,
}

import React from 'react'

import CardDocument from '../CardDocument/CardDocument'
import { object, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

const CardPressRelease = ({ reference, surtitle, title, subtitle, link, document, dataTestid, ...rest }) => {
  const { i18n } = useGlobalContext()

  return (
    <CardDocument
      surtitle={surtitle || i18n.t('pressrelease')}
      title={title || reference?.title}
      link={link || { url: reference?.url }}
      subtitle={subtitle}
      document={document === undefined ? reference?.document : document}
      dataTestid={dataTestid || 'CardPressRelease'}
      {...rest}
    />
  )
}

export default CardPressRelease

CardPressRelease.propTypes = {
  reference: object,
  surtitle: string,
  title: string,
  subtitle: string,
  titleLink: object,
  link: object,
  document: object,
  dataTestid: string,
}

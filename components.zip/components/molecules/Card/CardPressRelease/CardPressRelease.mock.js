import pressRelease from '../../../pages/press-release/press-release.mock'

export default {
  reference: pressRelease,
}

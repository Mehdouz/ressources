import { Link, Image, Text } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  reference: Link('Press release', 'document', ['press-release']),
  image: Image('Image'),
  surtitle: Text('Surtitle'),
  title: Text('Title'),
  subtitle: Text('Subtitle'),
  link: Link('Link'),
}

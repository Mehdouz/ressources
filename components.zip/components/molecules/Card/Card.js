import React from 'react'
import { Card as CardStrap, CardBody, CardTitle } from 'reactstrap'
import { array, bool, node, object, oneOf, oneOfType, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { colors } from '@axacom-client/base/style/variables'
import { SecondaryText } from '@axacom-client/base/style/typography'
import { getSpacing } from '@axacom-client/base/style/spacing'
import Button from '@axacom-client/components/atoms/Button/Button'
import Image from '@axacom-client/components/atoms/Image/Image'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { AltText, BadgeWrapper, CardBodyImg, Content, CustomBadge, Header, Link, Subtitle, Title, TitleButton } from './Card.styles'
import MetaInfos from './MetaInfos'

const Body = ({ background, children }) => {
  if (background === 'image') {
    return <CardBodyImg data-testid="CardStrapBody">{children}</CardBodyImg>
  }
  return (
    <CardBody data-testid="CardStrapBody" style={{ padding: getSpacing(2) }}>
      {children}
    </CardBody>
  )
}

Body.propTypes = {
  background: string,
  children: node.isRequired,
}

export default function Card({
  icon,
  image,
  imageRatio = '16:9',
  theme,
  altText,
  title,
  titleLink,
  subtitle,
  text,
  buttonLink,
  buttonText,
  buttonPosition = 'left',
  buttonIcon = 'IconArrowRight',
  bgColor = 'transparent',
  borderColor = 'transparent',
  fontColor = '#000000',
  center = false,
  display = 'flex',
  width = '100%',
  type,
  shadow = false,
  dataTestid = 'CardStrap',
  background,
  highlight,
  style,
  parentColor,
  readingTime,
  contentType,
} = {}) {
  const { i18n } = useGlobalContext()
  const $isBackgroundImage = background === 'image'
  return (
    <CardStrap
      tag="article"
      inverse={$isBackgroundImage}
      style={{
        ...style,
        backgroundColor: bgColor,
        borderColor,
        width: width,
        color: $isBackgroundImage ? colors.white : fontColor,
        display: display,
        ...(shadow && { boxShadow: 'rgba(224, 224, 224, 1) 5px 5px 10px 5px' }),
      }}
      className={center ? 'text-center' : ''}
      data-testid={dataTestid}
    >
      {icon && <Icon name={icon.image} color={icon.color} width={icon.size} height={icon.size} className={center ? 'text-center' : ''} dataTestid="CardIcon" />}
      {image && (
        <div style={!$isBackgroundImage ? { margin: `0 ${getSpacing(2)}` } : {}}>
          <Image
            animation="scale"
            ratio={imageRatio}
            src={image.views?.thumbnails?.url}
            alt={image.views?.thumbnails?.alt}
            image={image}
            isBackground={$isBackgroundImage}
            dataTestid="CardStrapImage"
          />
        </div>
      )}
      {highlight && (
        <BadgeWrapper>
          <CustomBadge>
            <Icon name="IconLang" color={colors.white} width={18} height={18} style={{ marginRight: getSpacing(1) }} />
            <SecondaryText style={{ marginRight: getSpacing(1), fontWeight: 700, texttransform: 'uppercase' }}>{i18n.t('card.spotlightBadge')}</SecondaryText>
          </CustomBadge>
        </BadgeWrapper>
      )}
      <Body background={background}>
        <Header $isBackgroundImage={$isBackgroundImage}>
          {theme && (
            <Button type="link" color={$isBackgroundImage ? 'white' : 'red'} url={theme.linkTopicPage?.url || theme.url} style={{ marginRight: '5px' }} dataTestId="CardTheme">
              {theme.metaContent?.[0].title}
            </Button>
          )}
          {altText && (
            <AltText type={type} $isBackgroundImage={$isBackgroundImage}>
              {altText}
            </AltText>
          )}
        </Header>
        {title && (
          <CardTitle tag={highlight ? 'h2' : 'h3'} data-testid="CardStrapTitle">
            {titleLink?.url || titleLink ? (
              <TitleButton type="link" highlight={highlight} $isBackgroundImage={$isBackgroundImage} url={titleLink?.url || titleLink}>
                {title}
              </TitleButton>
            ) : (
              <Title highlight={highlight} $isBackgroundImage={$isBackgroundImage}>
                {title}
              </Title>
            )}
          </CardTitle>
        )}
        {subtitle && <Subtitle data-testid="CardStrapSubtitle">{subtitle}</Subtitle>}
        {text && (
          <Content highlight={highlight} bgColor={parentColor} data-testid="CardStrapContent">
            {text}
          </Content>
        )}
        {(contentType || readingTime) && <MetaInfos justifyContent={highlight ? 'left' : 'space-between'} contentType={contentType} readingTime={readingTime}></MetaInfos>}
        {buttonLink && (
          <Link
            url={buttonLink.url || buttonLink}
            type="link"
            ariaLabel={!buttonText ? `${i18n.t('readmore')}, ${title}` : ''}
            color="red"
            size="small"
            iconRight={buttonIcon}
            target={buttonLink.target && buttonLink.target === 'web' ? '_blank' : '_self'}
            data-testid="CardStrapLinkReadmore"
            style={buttonPosition === 'right' ? { float: 'right' } : {}}
          >
            {buttonText || i18n.t('readmore')}
          </Link>
        )}
      </Body>
    </CardStrap>
  )
}

Card.propTypes = {
  icon: object,
  image: object,
  imageRatio: string,
  theme: object,
  title: oneOfType([object, string]),
  titleLink: oneOfType([object, string]),
  subtitle: oneOfType([string, array]),
  text: oneOfType([string, array]),
  altText: oneOfType([object, string]),
  buttonLink: oneOfType([object, string]),
  buttonText: string,
  buttonPosition: string,
  buttonIcon: string,
  bgColor: string,
  borderColor: string,
  fontColor: string,
  center: bool,
  width: string,
  type: string,
  display: string,
  shadow: bool,
  dataTestid: string,
  highlight: bool,
  background: oneOf(['image']),
  style: object,
  parentColor: string,
  readingTime: string,
  contentType: string,
}

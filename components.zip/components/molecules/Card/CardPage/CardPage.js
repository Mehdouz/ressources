import React from 'react'
import { object, oneOfType, string } from 'prop-types'
import { getArticleMeta } from '@axacom-client/services/document-service'
import Card from '../Card'

const CardPage = (props) => {
  const { reference, image, surtitle, title, subtitle, link, dataTestid, ...rest } = props
  return (
    <Card
      image={image === undefined ? getArticleMeta('cover', reference) : image}
      altText={surtitle || 'Page'}
      title={title || getArticleMeta('title', reference)}
      titleLink={link || { url: reference?.url }}
      text={subtitle === undefined ? getArticleMeta('subtitle', reference) : subtitle}
      dataTestid={dataTestid || 'CardPage'}
      {...rest}
    />
  )
}

export default CardPage

CardPage.propTypes = {
  reference: object,
  image: object,
  surtitle: string,
  title: string,
  subtitle: oneOfType([object, string]),
  dataTestid: string,
  link: object,
}

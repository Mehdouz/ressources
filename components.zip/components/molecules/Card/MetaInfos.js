import React from 'react'
import { MetaInfosGroup, ContentType, RightReadTime, IconAlarm } from './Card.styles.js'
import { string } from 'prop-types'
import { colors } from '@axacom-client/base/style/variables'

export default function MetaInfos({ contentType, readingTime, ...rest }) {
  return (
    <MetaInfosGroup {...rest}>
      <ContentType>{contentType}</ContentType>
      {readingTime && (
        <RightReadTime hasContentType={!!contentType}>
          <IconAlarm name="IconAlarm" color={colors.gray} width={16} height={16} />
          {readingTime}
        </RightReadTime>
      )}
    </MetaInfosGroup>
  )
}

MetaInfos.propTypes = {
  justifyContent: string,
  contentType: string,
  readingTime: string,
}

MetaInfos.defaultProps = {
  justifyContent: 'space-between',
}

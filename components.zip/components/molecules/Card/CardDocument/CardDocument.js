import React from 'react'
import { object, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { bytesToSize } from '@axacom-client/services/string-service'
import Card from '../Card'

export default function CardDocument({ title, surtitle, link, document, reference, dataTestid, ...rest }) {
  const { i18n, currentLocale } = useGlobalContext()
  const file = document?.file || reference?.document?.file || link?.file
  const linkProps = file?.url
    ? {
        buttonText: `${i18n.t('button.download')} | PDF ${bytesToSize(file.size, currentLocale)}`,
        buttonLink: { url: file?.url, target: 'web' },
        buttonPosition: 'right',
        buttonIcon: 'IconDownload',
      }
    : {}
  return <Card altText={surtitle || 'Document'} title={title || reference?.title} titleLink={link || { url: reference?.url }} {...linkProps} dataTestid={dataTestid || 'CardDocument'} {...rest} />
}

CardDocument.propTypes = {
  reference: object,
  surtitle: string,
  title: string,
  link: object,
  document: object,
  dataTestid: string,
}

const propsDocument = {
  cardType: 'Document',
  image: null,
  title: 'Titre document',
  subtitle: null,
  link: {
    file: {
      name: 'axa_declaration_20200531_vf.pdf',
      kind: 'document',
      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F1737ca63-09c6-4d0d-827f-137e24915626_axa_declaration_20200531_vf.pdf',
      size: '191173',
    },
    target: 'file',
    url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F1737ca63-09c6-4d0d-827f-137e24915626_axa_declaration_20200531_vf.pdf',
  },
}

export default propsDocument

export const propsDocumentWithFile = { ...propsDocument, document: { file: { url: 'file.pdf', size: '8191173' } } }

export const propsDocumentWithReference = {
  ...propsDocument,
  title: undefined,
  link: undefined,
  reference: { title: 'Titre reference', url: 'reference.pdf', document: { file: { url: 'reference.pdf', size: '2358191173' } } },
}

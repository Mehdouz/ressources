import React from 'react'
import { object, oneOfType, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { getArticleMeta } from '@axacom-client/services/document-service'
import Card from '../Card'

export default function CardArticle({ reference, image, surtitle, title, subtitle, link, dataTestid, ...rest }) {
  const { currentLocale } = useGlobalContext()
  return (
    <Card
      image={image === undefined ? getArticleMeta('cover', reference) : image}
      theme={reference?.theme}
      altText={surtitle}
      title={title || getArticleMeta('shortTitle', reference, { shortToLongTitle: true, language: currentLocale })}
      titleLink={link || { url: reference?.url }}
      text={subtitle === undefined ? getArticleMeta('subtitle', reference) : subtitle}
      dataTestid={dataTestid || 'CardArticle'}
      readingTime={getArticleMeta('readTimeShort', reference)}
      contentType={reference?.contentType}
      {...rest}
    />
  )
}

CardArticle.propTypes = {
  reference: object,
  image: oneOfType([object, string]),
  surtitle: oneOfType([object, string]),
  title: oneOfType([object, string]),
  subtitle: oneOfType([object, string]),
  link: object,
  dataTestid: string,
}

import { Link } from '../../../../../tools/prismic/backup-types/generic-type'

export default {
  cardArticle: Link('Article', 'document', ['article-v2']),
}

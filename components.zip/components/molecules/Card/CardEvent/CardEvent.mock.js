export default {
  cardType: 'Event',
  image: null,
  title: 'Évènement live',
  subtitle: null,
  link: {
    url: 'https://www.twitch.tv/',
    target: 'web',
  },
}

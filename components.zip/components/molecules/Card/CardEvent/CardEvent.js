import React from 'react'

import Card from '../Card'
import { string, object } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

const CardEvent = ({ surtitle, title, link, reference, dataTestid, ...rest }) => {
  const { i18n } = useGlobalContext()
  return (
    <Card altText={surtitle || i18n.t('card.live')} title={title || reference.title} titleLink={link || reference.url} image={null} type="event" dataTestid={dataTestid || 'CardEvent'} {...rest} />
  )
}

export default CardEvent

CardEvent.propTypes = {
  surtitle: string,
  title: string,
  link: object,
  reference: object,
  dataTestid: string,
}

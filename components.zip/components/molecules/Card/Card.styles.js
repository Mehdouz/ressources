import React from 'react'
import styled from 'styled-components'
import { Badge, CardImgOverlay } from 'reactstrap'
import { darken, lighten } from 'polished'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { colors } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { Typo18, Typo20, Typo24, Typo28, Typo36 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { CategoryTitle } from '@axacom-client/base/style/typography'
import Button from '@axacom-client/components/atoms/Button/Button'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import Text from '../Text/Text'

export const Header = React.memo(styled.div`
  display: flex;
  padding-bottom: ${getSpacing(1)};
`)

export const AltText = React.memo(styled(CategoryTitle)`
  text-transform: uppercase;
  color: ${(props) => (props.$isBackgroundImage ? colors.white : props.type === 'event' ? '#914146' : colors.gray)};
`)

export const TitleButton = React.memo(styled(Button)`
  display: flex;
  ${(props) => (props.highlight ? Typo36 : Typo28)}
  text-align: left;
  justify-content: flex-start;
  text-transform: none;
  margin: 0 0 ${getSpacing(1)};
  color: ${(props) => (props.$isBackgroundImage ? colors.white : colors.textColor)};
  &:hover,
  &:focus {
    color: ${(props) => (props.url ? (props.$isBackgroundImage ? darken(0.25, colors.white) : lighten(0.25, colors.textColor)) : '')};
  }
`)

export const Title = React.memo(styled(Text)`
  ${Typo24}
`)

export const Subtitle = styled(Text)`
  ${Typo18}
`

export const Content = styled(Text)`
  ${(props) => (props.highlight ? Typo20 : Typo18)}
  color: ${(props) => (props.bgColor === 'blue' ? colors.white : colors.textColor)};
  margin: 10px 0 10px 0;
`

export const Link = styled(Button)`
  margin-top: 15px;
`

export const BadgeWrapper = styled.div`
  position: absolute;
  top: ${getSpacing(3)};
  ${media.desktop`top: ${getSpacing(4)};`}
  left: 15px;
  ${media.desktop`left: 36px;`}
`

export const CustomBadge = styled(Badge)`
  display: flex !important;
  background-color: ${colors.teal} !important;
  border-radius: 0 !important;
`

export const CardBodyImg = styled(CardImgOverlay)`
  padding: 30% 15px 24px !important;
  ${media.desktop`padding: 30% 32px 32px !important;`}
  top: auto !important;
  background: linear-gradient(transparent, rgba(0, 0, 0, 1)) !important;
`

export const IconAlarm = styled(Icon)`
  margin-right: 8px;
`

export const MetaInfosGroup = styled.div`
  display: flex;
  justify-content: ${(props) => (props.justifyContent ? props.justifyContent : 'space-between')};
`

export const ContentType = styled(CategoryTitle)`
  color: ${colors.gray};
  text-transform: uppercase;
  flexbasis: 50%;
`

export const RightReadTime = styled(CategoryTitle)`
  color: ${colors.gray};
  ${(props) => (props.hasContentType ? 'margin-left: 10px;' : '')}
  text-align: right;
`

import React from 'react'
import { array, bool, object, oneOfType, string } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { Mobile } from '@axacom-client/components/utils/Responsive'
import { AsideRow, Content, StyledText, Img, Link, Title } from './AsideBlock.styles'

import { mediaQueries } from '@axacom-client/base/style/media'
import useBetterMediaQueries from '@axacom-client/hooks/useBetterMediaQueries'

export default function AsideBlock({ isReverse = false, image, title, text, buttonLink, buttonText }) {
  const isTablet = useBetterMediaQueries({ query: mediaQueries.tablet }, false)
  const { i18n } = useGlobalContext()
  return (
    <AsideRow isReverse={isReverse} data-testid="AsideBlockRow">
      <Content>
        {title ? <Title>{title}</Title> : null}
        {image && (
          <Mobile>
            <Img ratio="16:9" src={image?.main?.url} alt={image.main?.alt} dataTestid="AsideBlockImage" />
          </Mobile>
        )}
        {text ? <StyledText data-testid="AsideBlockContent">{text}</StyledText> : null}
        {buttonLink ? (
          <Link
            url={buttonLink.url}
            type="link"
            ariaLabel={!buttonText ? `${i18n.t('readmore')}, ${title}` : ''}
            color="red"
            size="large"
            iconRight="IconArrowRight"
            data-testid="AsideBlockButton"
            target={buttonLink.target && buttonLink.target === 'web' ? '_blank' : '_self'}
          >
            {buttonText || i18n.t('readmore')}
          </Link>
        ) : null}
      </Content>
      {image && isTablet ? (
        <Content asImage>
          <Img src={image?.main?.url} alt={image.main?.alt} dataTestid="AsideBlockImage" />
        </Content>
      ) : null}
    </AsideRow>
  )
}

AsideBlock.propTypes = {
  isReverse: bool,
  image: object,
  title: string,
  text: oneOfType([string, array]),
  buttonLink: object,
  buttonText: string,
}

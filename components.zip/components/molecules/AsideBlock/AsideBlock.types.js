export default {
  referrer: {
    type: 'Link',
    config: {
      select: 'document',
      placeholder: 'Choose a referrer document',
    },
  },
  image: {
    type: 'Image',
    config: {
      label: 'Side image',
      placeholder: 'Upload an image...',
      constraint: {
        width: 1920,
      },
      thumbnails: [
        {
          name: 'thumbnails',
          width: 768,
          height: 432,
        },
      ],
    },
  },
  title: {
    type: 'Text',
    config: {
      label: "Card's Title",
      placeholder: 'Select a Text',
    },
  },
  text: {
    type: 'StructuredText',
    config: {
      label: "Side's Text",
      placeholder: 'Select a StructuredText',
    },
  },
  buttonText: {
    type: 'Text',
    config: {
      label: "Link's Text",
      placeholder: 'Select a Text',
    },
  },
  buttonLink: {
    type: 'Link',
    config: {
      label: 'Link',
      placeholder: 'Choose your link',
    },
  },
}

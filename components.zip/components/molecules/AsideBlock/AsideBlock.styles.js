import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { Typo18, Typo36 } from '@axacom-client/base/style/typoStyle/typoStyle'
import Button from '@axacom-client/components/atoms/Button/Button'

import Text from '@axacom-client/components/molecules/Text/Text'

export const AsideRow = styled.div`
  ${media.tablet`
    display: flex;
    flex-direction: ${(props) => (!props.isReverse ? 'row-reverse' : 'row')};
    gap: 48px;
    margin-bottom: 32px;
  `}
`

export const Content = styled.div`
  ${media.tablet`
    width: ${(props) => (!props.asImage ? '42%' : '58%')};
  `}
`

export const Img = styled.img`
  width: 100%;
  aspect-ratio: 16/9;
  object-fit: cover;
  margin-bottom: 24px;
`

export const Title = styled.h3`
  ${Typo36}
  margin: 0 0 20px 0;
`

export const StyledText = styled(Text)`
  ${Typo18}
  margin: 0;
`

export const Link = styled(Button)`
  margin-top: 15px;
`

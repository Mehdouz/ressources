import React from 'react'
import { string } from 'prop-types'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { CardWrapper, Card, CardTitle, Overlay, Duration, CardImage } from './CardStories.style'

export default function CardStories({ title, image, readTime, href, ...props }) {
  return (
    <Card data-testid="CardStories" href={href} {...props}>
      <CardImage visibleByDefault src={image} />
      <CardWrapper>
        <CardTitle title={image} data-testid="CardStoriesTitle">
          {title}
        </CardTitle>
        <Duration data-testid="CardStoriesReadTime">
          <Icon name="IconAlarm" color="white" width={15} height={15} /> {readTime}
        </Duration>
      </CardWrapper>
      <Overlay />
    </Card>
  )
}

CardStories.propTypes = {
  title: string,
  image: string,
  readTime: string,
  href: string,
}

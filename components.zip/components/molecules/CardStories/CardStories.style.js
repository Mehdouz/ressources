import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import { LazyLoadImage } from 'react-lazy-load-image-component'

import media from '@axacom-client/base/style/media'
import { font } from '@axacom-client/base/style/variables'

export const Card = styled(motion.a)`
  position: relative;
  width: 80vw;
  height: auto;
  overflow: hidden;

  &:before {
    content: '';
    float: left;
    padding-top: 80%;
  }
  &:hover {
    > img {
      transform: scale(1.03);
    }
  }
`

export const CardImage = styled(LazyLoadImage)`
  position: absolute;
  top: 0;
  left: 0;
  transform-origin: 50% 50%;
  transition: transform 0.2s ease-in-out;
  will-change: transform;
  transform: scale(1);
`

export const CardWrapper = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  width: 100%;
  height: 100%;
  padding: 0 20px 30px;
  bottom: 0;
  position: absolute;

  ${media.tablet`
    padding: 20px;
  `}

  ${media.desktopVeryLarge`
    padding: 35px 40px;
  `}
`

export const CardTitle = styled.h2`
  font-family: ${font.fontFamilyBase};
  font-size: 1.25rem; //20px
  line-height: 1.75rem; // 28px
  font-weight: ${font.weight.bold};
  color: #fff;
  z-index: 1;

  ${media.tablet`
    font-size: 16px;
    line-height: 22px;
  `}

  ${media.desktopVeryLarge`
    font-size: 1.5rem; //24px
    line-height: 2.125rem; // 32px
  `}
`

export const Overlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  z-index: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(to bottom, transparent, rgba(0, 0, 0, 0.8));
`

export const Duration = styled.p`
  color: #fff;
  z-index: 1;

  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.semiBold};
  font-size: 12px;
  line-height: 16px;
  letter-spacing: 1px;
  text-transform: uppercase;

  ${media.desktopVeryLarge`
    font-size: 20px;
    line-height: 26px;
    letter-spacing: 1.6px;
  `}

  svg {
    margin-top: -2px;
    margin-right: 5px;
  }
`

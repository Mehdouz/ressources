import React from 'react'
import { bool, func, node, string, number } from 'prop-types'
import styled from 'styled-components'
import { Button, Modal, ModalHeader, ModalBody } from 'reactstrap'

import { getSpacing } from '../../../base/style/spacing'

const Header = styled(ModalHeader)`
  position: absolute;
  right: 0;
  border: none;
`

const Body = styled(ModalBody)`
  padding: ${(props) => props.padding};
`

const CloseButtonStyle = styled(Button)`
  font-size: ${getSpacing(4)};
  line-height: 22px;
  border: none;
  padding-bottom: 11px;
  z-index: 1;
`

const ModalDefault = ({ toggle, isOpen, size, modalTitle, children, padding = getSpacing(4) }) => {
  const CloseBtn = <CloseButtonStyle onClick={toggle}>&times;</CloseButtonStyle>
  return (
    <Modal size={size} isOpen={isOpen} toggle={toggle} centered={true} aria-label={modalTitle}>
      <Header toggle={toggle} close={CloseBtn} />
      <Body padding={padding}>{children}</Body>
    </Modal>
  )
}

export default ModalDefault

ModalDefault.propTypes = {
  toggle: func,
  size: string,
  isOpen: bool,
  modalTitle: string,
  padding: number,
  children: node.isRequired,
}

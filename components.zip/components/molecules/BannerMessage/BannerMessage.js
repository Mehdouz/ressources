import React, { useEffect, useState } from 'react'
import { array, object, string } from 'prop-types'
import { useCookies } from 'react-cookie'
import { Desktop, LargeDesktop, MinTablet, Mobile, Tablet } from '@axacom-client/components/utils/Responsive'
import { getTimeInMs } from '@axacom-client/services/date-service'
import Link from './Link/Link'
import Icon from './icon/icon'
import './BannerMessage.scss'

export default function BannerMessage({ closeLabel, ctaLink, ctaText, images, subtitle, titleCollapse, titleHeader }) {
  const [cookies, setCookie] = useCookies(['showBannerMessage'])
  const [opened, setOpened] = useState(cookies.showBannerMessage === undefined || cookies.showBannerMessage === 'true')

  useEffect(() => {
    const expires = new Date()
    expires.setTime(expires.getTime() + getTimeInMs().withDays(183))
    setCookie('showBannerMessage', opened, { expires })
  }, [opened])

  function handleClick(e) {
    e.preventDefault()
    setOpened((prevState) => !prevState)
  }

  function bannerCollapse(titleCollapse, subtitle, ctaText, ctaLink, closeLabel, images) {
    return (
      <div
        className={`banner-message__collapse ${opened ? 'banner-message__collapse--open' : ''}`}
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(59, 63, 216, 0.45), rgba(59, 63, 216, 0.45)), url(${images.imageL.main.url})`,
        }}
      >
        {collapse(titleCollapse, subtitle, ctaText, ctaLink, closeLabel)}
      </div>
    )
  }

  function collapse(titleCollapse, subtitle, ctaText, ctaLink, closeLabel) {
    return (
      <div className="container">
        <div className="banner-message__collapse__wrapper">
          <p className="banner-message__collapse__title">{titleCollapse}</p>
          <div className="banner-message__collapse__subtitle">
            {subtitle.map((text, index) => (
              <p key={index}>{text.text}</p>
            ))}
          </div>
          <button role="button" aria-expanded={opened} tabIndex={`${opened ? '0' : '-1'}`} className="banner-message__collapse__close" onClick={(e) => handleClick(e)}>
            <Icon className="banner-message__collapse__close--icon" name="chevron-up" />
            {closeLabel}
          </button>
          <Link
            href={ctaLink.url}
            target={ctaLink.target}
            tabIndex={`${opened ? '0' : '-1'}`}
            labelContent=""
            className="banner-message__collapse__cta"
            // prettier-ignore
            analytics={JSON.stringify({"block_name":"CTA Brand Campaign", "event_type":"Brand Campaign"})}
            type="button-secondary"
            color="white"
          >
            {ctaText}
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="banner-message">
      <Mobile>
        <Link
          href={ctaLink.url}
          target={ctaLink.target}
          labelContent=""
          className="banner-message__header banner-message__header--mobile"
          analytics={JSON.stringify({ block_name: 'CTA Brand Campaign', event_type: 'Brand Campaign' })}
          type=""
          color=""
          tabIndex={`${!opened ? '0' : '-1'}`}
        >
          {titleHeader}
        </Link>
      </Mobile>

      <MinTablet>
        <button className={`banner-message__header ${opened ? 'banner-message__header--close' : ''}`} tabIndex={`${!opened ? '0' : '-1'}`} onClick={handleClick} aria-expanded={opened}>
          {
            <div className="container">
              <div className="banner-message__header__wrapper">
                <p className="banner-message__header__title">{titleHeader}</p>
              </div>
            </div>
          }
        </button>

        {images.imageXL && <LargeDesktop>{bannerCollapse(titleCollapse, subtitle, ctaText, ctaLink, closeLabel, images)}</LargeDesktop>}
        {images.imageL && <Desktop>{bannerCollapse(titleCollapse, subtitle, ctaText, ctaLink, closeLabel, images)}</Desktop>}
        {images.imageM && <Tablet>{bannerCollapse(titleCollapse, subtitle, ctaText, ctaLink, closeLabel, images)}</Tablet>}
      </MinTablet>
    </div>
  )
}

BannerMessage.propTypes = {
  closeLabel: string,
  ctaLink: object,
  ctaText: string,
  images: object,
  subtitle: array,
  titleCollapse: string,
  titleHeader: string,
}

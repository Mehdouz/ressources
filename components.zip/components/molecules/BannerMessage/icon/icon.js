import React from 'react'
import { bool, number, string } from 'prop-types'

export default function Icon({ ariaHidden, className, name = '#', width }) {
  return <i className={className + ` icon-${name}` + ` icon-${width}`} aria-hidden={ariaHidden} />
}

Icon.propTypes = {
  ariaHidden: bool,
  className: string,
  name: string,
  width: number,
}

import React from 'react'
import { bool, string } from 'prop-types'

export default function Link({ analytics = '', arrow = false, className = '', color = 'red', href = '#', tabIndex = '', target = '_self', type = '', children }) {
  return (
    <a
      href={href}
      target={`${target === 'web' ? '_blank' : target}`}
      tabIndex={tabIndex}
      data-analytics={analytics}
      className={`${className}${type ? ` ${type} ${type}--${color}` : ''}${arrow ? ' icon-arrow-right' : ''}`}
    >
      {children}
    </a>
  )
}

Link.propTypes = {
  analytics: string,
  arrow: bool,
  className: string,
  color: string,
  href: string,
  tabIndex: string,
  target: string,
  type: string,
  children: string,
}

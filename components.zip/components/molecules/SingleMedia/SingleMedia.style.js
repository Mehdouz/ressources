import styled from 'styled-components'
import Text from '@axacom-client/components/molecules/Text/Text'
import Button from '@axacom-client/components/atoms/Button/Button'
import { Typo16, Typo18, Typo20, Typo24 } from '@axacom-client/base/style/typoStyle/typoStyle'
import media from '@axacom-client/base/style/media'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { colors, font } from '@axacom-client/base/style/variables'

const CaptionText = styled(Text)`
  ${media.phone`
    margin-top: ${getSpacing(2)};
    ${Typo20}
    font-weight: ${font.weight.bold};
  `}

  ${media.tablet`
    margin-top: ${getSpacing(2)};
    ${Typo20}
    font-weight: ${font.weight.bold};
  `}

  ${media.desktop`
    margin-top: 0;
    padding-top: ${getSpacing(4)};
      ${Typo24}
  `}
`

const CreditText = styled.div`
  margin-top: ${getSpacing(1)};
  color: ${colors.creditColor};
  text-align: left;

  ${media.phone`
    ${Typo16}
  `}

  ${media.tablet`
    ${Typo16}
  `}

  ${media.desktop`
    ${Typo18}
  `};
`

const CustomLink = styled(Button)`
  color: ${colors.black};
  text-transform: none;

  ${media.phone`
    ${Typo18}
    font-weight: ${font.weight.bold};
  `}

  ${media.tablet`
    ${Typo20}
    font-weight: ${font.weight.bold};
  `}

  ${media.desktop`
    ${Typo24}
  `}
`

const Line = styled.div`
  box-sizing: border-box;
  height: 0;
  width: 100%;
  border-top: 1px solid ${colors.gray};
`

export { CreditText, CaptionText, Line, CustomLink }

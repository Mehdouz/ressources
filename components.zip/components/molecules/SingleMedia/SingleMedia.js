import React from 'react'
import { Col, Container, Row } from 'reactstrap'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { colors } from '@axacom-client/base/style/variables'
import { MinDesktop, MobilesDevices } from '@axacom-client/components/utils/Responsive'
import { getSpacing } from '@axacom-client/base/style/spacing'
import YoutubePlayer from '@axacom-client/components/molecules/YoutubePlayer/YoutubePlayer'
import { CaptionText, CreditText, Line } from '@axacom-client/components/molecules/SingleMedia/SingleMedia.style'

const SingleMedia = (props) => {
  // eslint-disable-next-line react/prop-types
  const item = props[0] || props
  const { illustration, videoUrl, caption, credit } = item
  const mediaIcon = illustration ? 'IconInstagram' : 'IconYoutube'
  const htmlPlayer = videoUrl?.[0]?.type === 'embed' ? videoUrl?.[0]?.oembed?.html || '' : `src="${videoUrl?.[0]?.text}"` || ''
  const captionText = (
    <Col md={{ size: 10, offset: 1 }} lg={{ size: 3, offset: 0 }} xl={{ size: 3, offset: 0 }} xs={{ size: 12 }} sm={{ size: 12 }}>
      <MinDesktop>
        <Line />
      </MinDesktop>
      {caption && <CaptionText dataTestid="CaptionText">{caption}</CaptionText>}
    </Col>
  )
  return (
    <>
      <Row>
        <Col md={{ size: 12 }} lg={{ size: 8 }} xl={{ size: 8 }} xs={{ size: 12 }} sm={{ size: 12 }}>
          {videoUrl && <YoutubePlayer html={htmlPlayer} />}
          {illustration && <img src={illustration?.main?.url} alt={illustration?.main?.alt} data-testid="illustration_SingleImage" />}
        </Col>
        <MobilesDevices>
          <Container>{captionText}</Container>
        </MobilesDevices>
        <MinDesktop>{captionText}</MinDesktop>
      </Row>
      <Row>
        <Container>
          {credit && (
            <Col xs={{ size: 12 }} md={{ size: 10, offset: 1 }} lg={{ size: 12, offset: 0 }}>
              <CreditText data-testid="CreditText">
                <Icon name={mediaIcon} color={colors.creditColor} style={{ marginRight: getSpacing(1) }} />
                {credit}
              </CreditText>
            </Col>
          )}
        </Container>
      </Row>
    </>
  )
}

export default SingleMedia

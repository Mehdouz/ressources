import CookieService, { oneTrustCategories } from '@axacom-client/base/scripts/Cookies/cookie-service'
import NotAllowed from '@axacom-client/components/molecules/NotAllowed/NotAllowed'
import { oneTrustAddConsentChanged, windowAddEventListener, windowRemoveEventListener } from '@axacom-client/services/window-service'
import { motion } from 'framer-motion/dist/framer-motion'
import { string } from 'prop-types'
import React, { useEffect, useState } from 'react'
import styled from 'styled-components'

const YoutubePlayerContainer = styled(motion.div)`
  position: relative;
  padding-top: 0;
  aspect-ratio: 16/9;
  width: 100%;
  height: auto;
  overflow: hidden;

  .not-allowed,
  iframe,
  object,
  embed {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
`

export default function YoutubePlayer({ html, ...rest }) {
  const [isAllowed, setAllowed] = useState(undefined)

  useEffect(() => {
    setYoutubeAllowed()
    oneTrustAddConsentChanged('YoutubePlayer', setYoutubeAllowed)
    windowAddEventListener('setCookieChoice', setYoutubeAllowed)
    return () => windowRemoveEventListener('setCookieChoice', setYoutubeAllowed)
  }, [])

  function setYoutubeAllowed() {
    return setAllowed(() => CookieService.getConsents().social)
  }

  function getEmbedSrc(html) {
    let src = html?.match(/src="([^"]+)"/)?.[1] || ''

    if (src.includes('/watch')) {
      src = src.replace(/.*\?v=(.*)$/, 'https://www.youtube.com/embed/$1')
    } else if (src.includes('youtu.be')) {
      src = src.replace(/.*\/([^/]*)$/, 'https://www.youtube.com/embed/$1')
    }

    return src
  }

  return (
    <YoutubePlayerContainer data-testid="YoutubePlayer" {...rest}>
      {typeof isAllowed === 'boolean' &&
        (!isAllowed ? <NotAllowed category={oneTrustCategories.social} cookie="Youtube" /> : <iframe type="text/html" src={getEmbedSrc(html)} frameBorder="0" allowFullScreen />)}
    </YoutubePlayerContainer>
  )
}

YoutubePlayer.propTypes = { html: string.isRequired }

import React from 'react'
import { array, number } from 'prop-types'
import styled from 'styled-components'
import { rgba } from 'polished'
import { colors } from '../../../base/style/variables'
import { Typo20Bold } from '../../../base/style/typoStyle/typoStyle'
import media from '../../../base/style/media'
import { useGlobalContext } from './../../../store/GlobalContext'

const Wrapper = styled.div`
  background-color: ${colors.teal};
  color: ${colors.bodyBg};
  display: flex;
  align-items: center;
  ${media.tablet`
    padding: 0 32px;
  `}
  ${media.desktop`
    padding: 0 100px;
  `}
`

const ProgressBarContainer = styled.div`
  padding: 0 4px;
  width: 100%;
  display: flex;

  ${media.tablet`
     padding: 0 4px 0 20px;
  `}
`

const ProgressBar = styled.div`
  flex: 1;
  position: relative;
  height: 6px;
  border-radius: 6px;
  background-color: ${rgba(colors.bodyBg, 0.6)};
  margin: 0 4px;
  ${media.tablet`
    height: 8px;
  `}
`

const Label = styled.div`
  ${Typo20Bold}
  margin: 8px;
  white-space: nowrap;
`

const Filler = styled.div`
  background-color: ${colors.bodyBg};
  height: 100%;
  border-radius: inherit;
  width: ${(props) => `${props.percentage}%`};
  transition: width 0.5s ease-in;
`

const Stepper = ({ steps, currentStep }) => {
  const { currentLocale } = useGlobalContext()
  return (
    <Wrapper>
      <Label>{`${currentLocale === 'en' ? 'Step' : 'Étape'} ${currentStep}/${steps.length}`}</Label>
      <ProgressBarContainer>
        {steps.map((step, index) => (
          <ProgressBar key={index} data-testid={`step${step}`}>
            <Filler percentage={step.progress} />
          </ProgressBar>
        ))}
      </ProgressBarContainer>
    </Wrapper>
  )
}

export default Stepper

Stepper.propTypes = {
  steps: array,
  currentStep: number,
}

Stepper.defaultProps = {}

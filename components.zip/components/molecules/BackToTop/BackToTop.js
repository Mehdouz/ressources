import React from 'react'
import styled from 'styled-components'
import { motion } from 'framer-motion/dist/framer-motion'
import { colors } from '@axacom-client/base/style/variables'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { getWindow } from '@axacom-client/services/window-service'

const BackTopButton = styled(motion.button)`
  display: flex;
  width: 60px;
  height: 60px;
  position: fixed;
  bottom: 35px;
  right: 35px;
  border-radius: 50%;
  justify-content: center;
  align-items: center;
  border: 1px solid ${({ $color }) => $color};
  background-color: white;
  z-index: 100;

  &:hover {
    cursor: pointer;
  }
`

const socialVariants = {
  visible: {
    scale: 1,
    transition: { ease: [0.34, 1.56, 0.64, 1] }, // some bouncy animation <3
  },
  hidden: {
    scale: 0,
  },
  exit: {
    opacity: 0,
  },
}

export function BackToTop({ color = colors.brandRed }) {
  const handleClick = () => {
    getWindow().scrollTo({
      top: 0,
      behavior: 'smooth',
    })
  }

  return (
    <BackTopButton data-test-id="BackToTop" animate="visible" exit="exit" initial="hidden" variants={socialVariants} $color={color} onClick={handleClick}>
      <Icon name="IconArrowTop" color={color} width={15} height={15} />
    </BackTopButton>
  )
}

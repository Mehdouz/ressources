import React, { useState, useEffect } from 'react'
import { string, number, func, object } from 'prop-types'

import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { useAnimation } from 'framer-motion/dist/framer-motion'

import { Container, PrevAnimatedBackground, ProgressBackground, TextContainer, PlayPauseContainer, TitleContainer, ArrowRightContainer, ArrowRight, TimerContainer } from './SliderProgressBar.style'

import useCountDown from '@axacom-client/hooks/useCountDown'

const SLIDE_DURATION = 7
const INITIAL_COUNT_DOWN = SLIDE_DURATION * 1000 // ms
const INTERVAL = 100

const variants = {
  initial: { scaleX: 0, transformOrigin: '0%' },
  visible: { scaleX: 1, transformOrigin: '0%', transition: { duration: SLIDE_DURATION, type: 'tween' }, transitionEnd: { transformOrigin: '100%' } },
  exit: { scaleX: 0, transformOrigin: '100%', transition: { duration: 1, ease: 'backOut' } },
}

const SliderProgressBar = ({ title, prevColors, colors, onComplete = () => {}, ...rest }) => {
  const [isRunning, setIsRunning] = useState(true)
  const [timeLeft, { start, pause, resume }] = useCountDown(INITIAL_COUNT_DOWN, INTERVAL)
  const controls = useAnimation()

  useEffect(() => {
    start()
    controls.start('visible')
  }, [])

  // when time ended call onComplete
  useEffect(() => {
    if (timeLeft <= 0) onComplete()
  }, [timeLeft])

  const handleArrowNext = () => onComplete()

  const handlePlayPause = () => {
    if (isRunning) {
      pause()
      controls.stop()
    } else {
      resume()
      controls.start({ ...variants.visible, transition: { duration: timeLeft / 1000 } })
    }
    setIsRunning(!isRunning)
  }

  return (
    <TimerContainer {...rest} initial="initial" animate="visible" exit="exit" data-testid="SpotlightStoriesTimer">
      <Container data-testid="SliderProgressBar">
        <PrevAnimatedBackground animate={{ scaleX: 0, transition: { duration: 0.2 } }} $backgroundColor={prevColors.progressBar}></PrevAnimatedBackground>
        <ProgressBackground $backgroundColor={colors.progressBar}></ProgressBackground>
        <ProgressBackground $backgroundColor={colors.progressBarDark} initial="initial" variants={variants} animate={controls} exit="exit" />
        <TextContainer data-testid="SliderProgressTextContainer">
          <PlayPauseContainer onClick={handlePlayPause} data-testid="SliderProgressBarIcon">
            <Icon name={isRunning ? 'IconPause' : 'IconPlay'} color="white" width={15} height={15} />
          </PlayPauseContainer>
          <TitleContainer data-testid="SliderProgressBarTitle" initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1, transition: { delay: 0.1 } }} exit={{ x: 30 }}>
            {title}
          </TitleContainer>
          <ArrowRightContainer onClick={handleArrowNext} data-testid="SliderProgressBarArrow">
            <ArrowRight />
          </ArrowRightContainer>
        </TextContainer>
      </Container>
    </TimerContainer>
  )
}

SliderProgressBar.propTypes = {
  className: string,
  title: string,
  url: string,
  colors: object,
  prevColors: object,
  onComplete: func,
  duration: number,
  steps: number,
}

export default SliderProgressBar

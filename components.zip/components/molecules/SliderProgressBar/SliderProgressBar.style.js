import styled from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'
import { Typo20Bold } from '@axacom-client/base/style/typoStyle/typoStyle'
import { motion } from 'framer-motion/dist/framer-motion'
import media from '@axacom-client/base/style/media'
import { animateArrowRight } from '@axacom-client/base/style/animation'

export const Container = styled(motion.div)`
  position: relative;
  background-color: ${({ $backgroundColor }) => $backgroundColor};
`

export const ProgressBackground = styled(motion.div)`
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
  z-index: 1;
  background-color: ${({ $backgroundColor }) => $backgroundColor};
`

export const PrevAnimatedBackground = styled(motion.div)`
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
  z-index: 2;
  transform-origin: 100%;
  background-color: ${({ $backgroundColor }) => $backgroundColor};
`

export const TextContainer = styled.div`
  position: relative;
  z-index: 2;
  padding: 0 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  ${Typo20Bold}
  color: ${colors.white};
  height: 60px;
`

export const PlayPauseContainer = styled.div`
  cursor: pointer;
  margin-left: -20px; // Cancel the left padding but makes a bigger touch/click area
  padding-left: 20px;
  padding-right: 20px;
  margin-right: 0.5rem;
  transition: transform 0.15s ease-in;

  &:hover {
    transform: scale(1.13);
    will-change: transform;
    transition: transform 0.15s ease-in;
  }
`

export const TitleContainer = styled(motion.div)`
  flex-grow: 1;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
`

export const ArrowRightContainer = styled.div`
  cursor: pointer;
  user-select: none;
  align-self: stretch;
  margin-right: -24px; // Cancel the right padding but makes a bigger touch/click area
  padding-right: 24px;
  padding-left: 20px;
  display: flex;
  transition: all 0.5s ease-out;
  animation-duration: 0.2s;

  &:hover {
    animation-name: ${animateArrowRight};
  }
`

export const ArrowRight = styled.div`
  align-self: center;
  width: 8px;
  height: 8px;
  border-top: 2px solid ${colors.white};
  border-right: 2px solid ${colors.white};
  transform: rotate(45deg);
`

export const TimerContainer = styled(motion.div)`
  ${media.desktop`
    position: absolute;
    top: 0px;
    right: 0;
    width: 47%;
  `}
`

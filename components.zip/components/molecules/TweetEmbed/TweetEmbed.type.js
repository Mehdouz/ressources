import { Text, Select } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  tweet_id: Text('Tweet ID'),
  hide_conversation: Select(['No', 'Yes'], 'Hide conversation', 'Yes or no', 'No'),
  hide_cards: Select(['No', 'Yes'], 'Hide cards', 'Yes or no', 'No'),
}

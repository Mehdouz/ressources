import React, { useEffect, useState } from 'react'
import { string } from 'prop-types'
import styled from 'styled-components'
import { TwitterTweetEmbed } from 'react-twitter-embed'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import CookieService, { oneTrustCategories } from '@axacom-client/base/scripts/Cookies/cookie-service'
import NotAllowed from '@axacom-client/components/molecules/NotAllowed/NotAllowed'
import { oneTrustAddConsentChanged, windowAddEventListener, windowRemoveEventListener } from '@axacom-client/services/window-service'

const TwitterCardContainer = styled.div`
  position: relative;
  min-height: 210px;
  width: 500px;
  margin: 10px auto;
  max-width: 100%;
  min-width: 220px;

  .not-allowed,
  iframe,
  object,
  embed {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
`

export default function TweetsEmbed({ tweet_id, hide_conversation, hide_cards }) {
  const { currentLocale } = useGlobalContext()
  const [isAllowed, setAllowed] = useState(undefined)

  useEffect(() => {
    setTwitterAllowed()
    oneTrustAddConsentChanged('TweetEmbed', setTwitterAllowed)
    windowAddEventListener('setCookieChoice', setTwitterAllowed)
    return () => windowRemoveEventListener('setCookieChoice', setTwitterAllowed)
  }, [])

  function setTwitterAllowed() {
    return setAllowed(() => CookieService.getConsents().social)
  }

  return (
    <TwitterCardContainer data-testid="TwitterCard">
      {typeof isAllowed === 'boolean' && !isAllowed ? (
        <NotAllowed category={oneTrustCategories.social} cookie="Twitter" />
      ) : (
        <TwitterTweetEmbed
          tweetId={tweet_id}
          options={{ lang: currentLocale, align: 'center', ...(hide_conversation === 'Yes' && { conversation: 'none' }), ...(hide_cards === 'Yes' && { cards: 'hidden' }) }}
        />
      )}
    </TwitterCardContainer>
  )
}

TweetsEmbed.propTypes = { tweet_id: string, hide_conversation: string, hide_cards: string }

import React, { useState } from 'react'
import { node } from 'prop-types'
import styled from 'styled-components'
import { colors } from './../../../base/style/variables'
import { Typo14 } from '../../../base/style/typoStyle/typoStyle'
import Icon from '../Icon/Icon'

const Container = styled.div`
  ${Typo14};
  position: relative;
  display: inline-block;
  width: inherit;
`

export default function Tooltip({ children }) {
  const [show, setShow] = useState(false)
  return (
    <Container role="tooltip" onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      <Message $show={show} aria-hidden={show}>
        {children}
      </Message>
      <Icon name="IconHelp" />
    </Container>
  )
}

Tooltip.propTypes = {
  text: node,
}

const Message = styled.div`
  display: ${({ $show }) => ($show ? 'block' : 'none')};
  transform: translate(100%, -50%);
  position: absolute;
  top: 50%;
  right: -13px;
  transform: translate(100%, -50%);
  z-index: 10;
  & > * {
    margin-right: -5px;
    margin-top: -5px;
    width: 240px;
    padding: 8px 8px 8px 24px;
    color: rgb(51, 51, 51);
    border: 1px solid rgb(240, 118, 98);
    background-color: rgb(245, 245, 245);
  }
  & > *:after {
    border: 5px solid transparent;
    content: ' ';
    height: 0px;
    width: 0px;
    position: absolute;
    pointer-events: none;
    margin-left: -5px;
    top: 50%;
    right: 100%;
    margin-right: -7px;
    margin-top: -5px;
    height: 10px;
    width: 10px;
    transform: rotate(45deg);
    border-bottom-color: ${colors.brandRed};
    border-bottom-width: 1px;

    border-left-color: ${colors.brandRed};
    border-left-width: 1px;
    background-color: ${colors.wildSand};
  }
`

Tooltip.defaultProps = {
  textColor: colors.textColor,
  borderColor: colors.brandRed,
  backgroundColor: colors.wildSand,
  placement: 'right',
}

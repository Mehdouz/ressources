import React from 'react'
import styled from 'styled-components'
import SmartLink from '../SmartLink/SmartLink'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { animateArrowRight } from '../../../base/style/animation'
import { colors } from '@axacom-client/base/style/variables'

const StyledButton = styled(SmartLink)`
  display: inline-flex;
  justify-content: space-between;
  align-items: center;
  color: ${colors.brandRed};
  text-transform: uppercase;
  letter-spacing: 0.1em;

  &:hover,
  &:focus,
  &:active {
    & svg {
      animation-name: ${animateArrowRight};
      animation-duration: 0.3s;
      & path {
        stroke: #ec4d33;
      }
    }
  }
`

const StyledIcon = styled(Icon)`
  margin-left: 10px;
`

export default function Button({ children, ...rest }) {
  return (
    <StyledButton {...rest}>
      {children} <StyledIcon name="IconArrowRight" color={colors.brandRed} width={14} height={14} />
    </StyledButton>
  )
}

import React from 'react'
import { object, string } from 'prop-types'

import styled from 'styled-components'

const Img = styled.img`
  max-width: 100%;
  height: auto;
`

export default function Logo({ src, alt, style }) {
  return <Img src={src} alt={alt} style={style} />
}

Logo.propTypes = {
  src: string,
  alt: string,
  style: object,
}

Logo.defaultProps = {
  src: '/base/images/logo.svg',
  alt: '',
}

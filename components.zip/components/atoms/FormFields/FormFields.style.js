import styled from 'styled-components'
import Button from '../Button/Button'
import media from '../../../base/style/media'
import { getSpacing } from '../../../base/style/spacing'
import { Typo13 } from '../../../base/style/typoStyle/typoStyle'
import Text from '@axacom-client/components/molecules/Text/Text'

export const SubmitButton = styled(Button)`
  display: flex;
  justify-content: center;
  margin: auto;
  margin-top: ${getSpacing(3)};
  width: 100%;
  ${media.tablet`width: auto;`}
`

export const RecaptchaContainer = styled.div`
  display: flex;
  justify-content: center;
`

export const TextContentStyle = styled(Text)`
  ${Typo13}
  margin-bottom: 24px;

  p {
    ${Typo13}
    padding-bottom: 16px;
  }
`

import React from 'react'
import { array, bool, func, node, object, oneOfType, string } from 'prop-types'
import IntlTelInput from 'react-intl-tel-input'
import { FastField, useField } from 'formik'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { MinTablet, Mobile } from '@axacom-client/components/utils/Responsive'
import { slugify } from '@axacom-client/services/string-service'
import {
  CheckboxLabelStyle,
  CheckboxSquareStyle,
  CustomField,
  Description,
  ErrorMessage,
  Fieldset,
  FrozenFieldWrapper,
  HiddenCheckbox,
  Horizontal,
  IconButton,
  IconButtonContainer,
  Label,
  Messages,
  Optional,
  OptionStyle,
  RadioStyle,
  SelectStyle,
  SelectWrapper,
  SimpleField,
  Value,
} from './Fields.style'
import './IntlTelInput.scss'
import CustomTooltip from '../Tooltip/Tooltip'
import Icon from '../Icon/Icon'

export const notRequiredLabel = () => {
  const { currentLocale } = useGlobalContext()
  return <Optional>{currentLocale === 'fr' ? 'optionnel' : 'optional'}</Optional>
}

export const ValidateField = ({ name, label, description, helpText, validate, errors = {}, touched = {}, children }) => {
  return (
    <>
      {label && (
        <Label htmlFor={name}>
          {label} {!validate?.isRequired && notRequiredLabel()} {helpText && <CustomTooltip>{helpText}</CustomTooltip>}
          {description && <Description>{description}</Description>}
        </Label>
      )}
      <Horizontal>{children}</Horizontal>
      <Messages style={{ justifyContent: 'space-between' }} errors={errors[name] && touched[name]}>
        {errors[name] && touched[name] && (
          <ErrorMessage id={`error-${name}`} className="error">
            {errors[name]}
          </ErrorMessage>
        )}
      </Messages>
    </>
  )
}

ValidateField.propTypes = {
  name: string,
  label: string,
  description: string,
  helpText: node,
  validate: object,
  errors: object,
  touched: object,
  children: node.isRequired,
}

export const FieldWrapper = ({ children, ...rest }) => {
  return (
    <SimpleField>
      <ValidateField {...rest}>{children}</ValidateField>
    </SimpleField>
  )
}

FieldWrapper.propTypes = {
  children: node.isRequired,
}

const FieldsetWrapper = ({ children, ...rest }) => (
  <Fieldset>
    <ValidateField {...rest}>{children}</ValidateField>
  </Fieldset>
)

FieldsetWrapper.propTypes = {
  children: node.isRequired,
}

export const PhoneField = ({ name, label, description, helpText, validate, errors, touched }) => {
  const isError = errors[name] && touched[name]
  return (
    <FieldWrapper name={name} label={label} description={description} helpText={helpText} validate={validate} errors={errors} touched={touched}>
      <FastField validate={validate}>
        {({ field, form: { setFieldValue, setFieldTouched } }) => {
          return (
            <IntlTelInput
              fieldId={name}
              fieldName={name}
              containerClassName="intl-tel-input"
              inputClassName="form-control"
              onPhoneNumberChange={(isValidPhoneNumber, fullNumber) => {
                return setFieldValue(name, isValidPhoneNumber || fullNumber === '' ? fullNumber : 'phone-not-valid')
              }}
              preferredCountries={['fr']}
              onPhoneNumberBlur={() => {
                setFieldTouched(name)
              }}
              autoComplete="off"
              aria-invalid={isError}
              aria-describedby={`error-${name}`}
              data-testid={`${name}_input`}
              defaultValue={field.value[name] !== 'phone-not-valid' ? field.value[name] : ''}
            />
          )
        }}
      </FastField>
    </FieldWrapper>
  )
}

PhoneField.propTypes = {
  name: string,
  label: string,
  description: string,
  helpText: string,
  errors: object,
  touched: object,
  validate: object,
  dataTestId: string,
}

export const InputField = ({
  type = 'text',
  name,
  label,
  description,
  placeholder = '',
  validate,
  className,
  getInputProps = (p) => p,
  autocomplete = 'on',
  helpText,
  icon = false,
  onIconClick = null,
  isElementShown,
  errors,
  touched,
  ...rest
}) => {
  const isError = errors && errors[name] && touched && touched[name]
  return (
    <FieldWrapper name={name} label={label} description={description} helpText={helpText} validate={validate} errors={errors} touched={touched}>
      <CustomField
        border={isError && 'red'}
        type={type}
        id={name}
        name={name}
        placeholder={placeholder}
        className={className}
        {...getInputProps}
        autoComplete={autocomplete}
        aria-invalid={!!isError}
        aria-required={validate?.isRequired}
        aria-describedby={`error-${name}`}
        data-testid={`${name}_input`}
        {...rest}
      />
      {icon && (
        <IconButtonContainer onClick={onIconClick}>
          <IconButton aria-label={icon.label}>
            <Icon aria-hidden={!isElementShown} focusable={isElementShown} name={icon.name} width={40} color={icon.color} style={{ marginTop: '4px' }} />
          </IconButton>
        </IconButtonContainer>
      )}
    </FieldWrapper>
  )
}

InputField.propTypes = {
  type: string,
  name: string,
  placeholder: string,
  label: string,
  className: string,
  autocomplete: string,
  description: string,
  validate: object,
  touched: object,
  icon: object,
  isElementShown: bool,
  onIconClick: func,
  getInputProps: func,
  helpText: node,
  errors: object,
  border: string,
  dataTestId: string,
}

export const InputFile = ({ name, label, description, validate, helpText, accept, errors, touched }) => {
  const isError = errors[name] && touched[name]
  return (
    <FieldWrapper name={name} label={label} description={description} helpText={helpText} validate={validate} errors={errors} touched={touched}>
      <FastField validate={validate}>
        {({ form: { setFieldTouched, setFieldValue } }) => {
          return (
            <input
              id={name}
              name={name}
              type="file"
              accept={accept}
              onChange={(event) => {
                setFieldValue(name, event.currentTarget.files[0])
              }}
              onBlur={() => {
                setFieldTouched(name)
              }}
              aria-required={validate.isRequired}
              aria-invalid={isError}
              aria-describedby={`error-${name}`}
              data-testid={`${name}_input`}
              style={{ border: 'none', boxShadow: 'none' }}
            />
          )
        }}
      </FastField>
    </FieldWrapper>
  )
}

InputFile.propTypes = {
  type: string,
  name: string,
  placeholder: string,
  label: string,
  className: string,
  autocomplete: string,
  description: string,
  validate: object,
  touched: object,
  icon: object,
  isElementShown: bool,
  onIconClick: func,
  getInputProps: func,
  helpText: string,
  errors: object,
  border: string,
  accept: string,
  dataTestId: string,
}

export const CheckboxField = ({ label, option, name, validate, errors, touched, ...rest }) => {
  return (
    <FieldWrapper name={name} label={label} validate={validate} errors={errors} touched={touched}>
      <Checkbox id={name} name={name} label={option} validate={validate} errors={errors} touched={touched} {...rest} />
    </FieldWrapper>
  )
}

CheckboxField.propTypes = {
  name: string,
  option: string,
  label: oneOfType([string, object]),
  validate: object,
  errors: object,
  touched: object,
}

export const SelectField = ({ label, name, options, validate, placeholder, errors, touched, ...rest }) => {
  return (
    <FieldWrapper name={name} label={label} validate={validate} errors={errors} touched={touched}>
      <Select id={name} name={name} options={options} placeholder={placeholder} validate={validate} errors={errors} touched={touched} {...rest} />
    </FieldWrapper>
  )
}

SelectField.propTypes = {
  name: string,
  label: string,
  description: string,
  placeholder: string,
  options: oneOfType([object, array]),
  helpText: string,
  errors: object,
  touched: object,
  option: array,
  validate: object,
}

export const MultipleSelectField = ({ children, ...rest }) => {
  return <FieldsetWrapper {...rest}>{children}</FieldsetWrapper>
}

MultipleSelectField.propTypes = {
  children: node,
}

export const CheckboxList = ({ label, name, options, defaultCheck = [], validate = {}, errors, touched }) => {
  const handleChange = (event) => {
    const target = event.currentTarget
    let valueArray = [...this.props.value] || []

    if (target.checked) {
      valueArray.push(target.id)
    } else {
      valueArray.splice(valueArray.indexOf(target.id), 1)
    }

    this.props.onChange(this.props.id, valueArray)
  }

  const handleBlur = () => {
    // take care of touched
    this.props.onBlur(this.props.id, true)
  }

  return (
    <FieldsetWrapper label={label} name={name} validate={validate} errors={errors} touched={touched}>
      {options &&
        Object.entries(options).map(([value, label], index) => (
          <div key={'div' + index} style={{ width: '100%' }}>
            <Mobile>
              <Checkbox
                key={index}
                name={name}
                value={value}
                label={label}
                defaultChecked={defaultCheck.includes(value)}
                style={{ marginRight: '8px', ...(index !== 0 && { marginTop: '8px' }) }}
                onChange={(e) => handleChange(e)}
                onBlur={() => handleBlur()}
                validate={validate}
              />
            </Mobile>
            <MinTablet>
              <Checkbox
                key={index}
                name={name}
                value={value}
                label={label}
                defaultChecked={defaultCheck.includes(value)}
                style={{ marginRight: '52px', ...(index !== 0 && { marginTop: '8px' }) }}
                onChange={(e) => handleChange(e)}
                onBlur={() => handleBlur()}
                validate={validate}
              />
            </MinTablet>
          </div>
        ))}
    </FieldsetWrapper>
  )
}

CheckboxList.propTypes = {
  name: string,
  label: string,
  description: string,
  defaultCheck: array,
  options: oneOfType([object, array]),
  validate: object,
  helpText: string,
  errors: object,
  touched: object,
}

export const RadioList = ({ name, label, description, defaultCheck, options, helpText, validate, errors, touched, ...rest }) => {
  return (
    <FieldsetWrapper name={name} label={label} description={description} validate={validate} helpText={helpText} errors={errors} touched={touched}>
      {options &&
        Object.entries(options).map(([option, label], index) => (
          <div key={'div' + index}>
            <Mobile>
              <Radio defaultChecked={option === defaultCheck} key={index} name={name} label={label} option={option} style={{ marginRight: '8px' }} {...rest} />
            </Mobile>
            <MinTablet>
              <Radio defaultChecked={option === defaultCheck} key={index} name={name} label={label} option={option} style={{ marginRight: '52px' }} {...rest} />
            </MinTablet>
          </div>
        ))}
    </FieldsetWrapper>
  )
}

RadioList.propTypes = {
  name: string,
  label: string,
  description: string,
  defaultCheck: string,
  options: oneOfType([object, array]),
  validate: object,
  helpText: string,
  errors: object,
  touched: object,
}

export const Select = ({ name, options, placeholder = '', style, ariaLabel, errors, touched, onChange, onBlur, validate, ...rest }) => {
  const isError = errors[name] && touched[name]
  const map = Array.isArray(options)
    ? options.map((option) => (
        <OptionStyle key={option} value={slugify(option.toString())}>
          {option}
        </OptionStyle>
      ))
    : Object.entries(options).map(([key, value]) => (
        <OptionStyle key={key} value={key}>
          {value}
        </OptionStyle>
      ))
  return (
    <SelectWrapper style={style}>
      <FastField>
        {({ field }) => {
          return (
            <SelectStyle
              name={name}
              aria-label={ariaLabel}
              aria-required={validate.isRequired}
              border={isError && 'red'}
              defaultValue={field.value[name]}
              onChange={onChange}
              onBlur={onBlur}
              data-testid={`${name}_select`}
              {...rest}
            >
              {placeholder && (
                <OptionStyle key="" value="">
                  {placeholder}
                </OptionStyle>
              )}
              {map}
            </SelectStyle>
          )
        }}
      </FastField>
    </SelectWrapper>
  )
}

Select.propTypes = {
  id: string,
  name: string,
  options: oneOfType([object, array]),
  placeholder: string,
  validate: object,
  defaultValue: string,
  style: object,
  ariaLabel: string,
  errors: object,
  touched: object,
  onChange: func,
  onChangeValue: func,
  onBlur: func,
  group: bool,
}

// pure html5 <select /> no logic only visual stuff.
// TODO: Rework the parent wrapper <SelectWrapper /> in order to expose className / style
export const PureSelect = ({ name, group, placeholder, options, ariaLabel, required, ...rest }) => {
  return (
    <SelectWrapper name={name} {...rest}>
      <SelectStyle group={group} aria-label={ariaLabel} aria-required={required}>
        {placeholder && (
          <OptionStyle key="" value="">
            {placeholder}
          </OptionStyle>
        )}
        {options}
      </SelectStyle>
    </SelectWrapper>
  )
}

PureSelect.propTypes = {
  name: string,
  group: bool,
  placeholder: string,
  ariaLabel: string,
  required: bool,
  options: oneOfType([array, object]).isRequired,
}

export const Checkbox = ({ name, value, label, style, onChange, onBlur, validate }) => {
  const [field] = useField({ name, value, type: 'checkbox' })

  return (
    <div style={style}>
      <CheckboxLabelStyle htmlFor={slugify(field.value)}>
        <HiddenCheckbox id={slugify(field.value)} type="checkbox" data-testid={`${name}_checkbox`} onChange={onChange} onBlur={onBlur} aria-required={validate.isRequired} {...field} />
        <CheckboxSquareStyle isChecked={field.checked} />
        <OptionStyle as="span" isChecked={field.checked}>
          {label}
        </OptionStyle>
      </CheckboxLabelStyle>
    </div>
  )
}

Checkbox.propTypes = {
  name: string,
  label: oneOfType([string, object]),
  value: string,
  onChange: func,
  onBlur: func,
  style: object,
  validate: object,
}

export const Radio = ({ name, option, label, style, onChange, defaultChecked }) => {
  return (
    <div style={style}>
      <RadioStyle name={name} id={slugify(option)} type="radio" value={slugify(option)} defaultChecked={defaultChecked} onChange={onChange} data-testid={`${name}_radio`} />
      <label style={{ marginLeft: '8px' }} htmlFor={slugify(option)}>
        {label}
      </label>
    </div>
  )
}

Radio.propTypes = {
  id: string,
  name: string,
  label: string,
  option: string,
  style: object,
  defaultValue: string,
  defaultChecked: bool,
  onChange: func,
}

export const FrozenField = ({ name, label, value }) => (
  <FrozenFieldWrapper>
    <Label htmlFor={name}>{label}</Label>
    <Value name={name}>{value}</Value>
  </FrozenFieldWrapper>
)

FrozenField.propTypes = {
  name: string,
  label: string,
  value: string,
}

import React from 'react'
import { string, bool, node, func } from 'prop-types'
import * as moment from 'moment'

import { slugify } from '@axacom-client/services/string-service'
import useFirstMountState from '@axacom-client/hooks/useFirstMountState'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

import { Fieldset, Horizontal, OptionStyle, Messages, Label, ErrorMessage, Description } from './Fields.style'

import { PureSelect, notRequiredLabel } from './Fields'
import Tooltip from '../Tooltip/Tooltip'

/**
 * This file include 2 components:
 * - <PureSelect />: the classic html <select />. (can be used as a standalone as one single select).
 * - <DatePicker />: this datePicker includes 3 select (year, month date). (can be used out of the box as well, we can even implement the package react-forms on top of it)
 *
 *
 */
const DEFAULT_FORMAT = 'YYYY-MM-DD'
const DAY_LENGTH = 31
const MAX_YEAR = 100

function createKeyValueFromArray(array) {
  return array.reduce((acc, str, index) => {
    index += 1
    acc[index] = str
    return acc
  }, {})
}

const buildOptionsFrom = (options) => {
  if (Array.isArray(options)) {
    return options.map((option) => (
      <OptionStyle key={option} value={slugify(option.toString())}>
        {option}
      </OptionStyle>
    ))
  } else {
    return Object.entries(options).map(([key, value]) => (
      <OptionStyle key={key} value={key}>
        {value}
      </OptionStyle>
    ))
  }
}

/**
 * Custom Hook to aggregate all the state.
 * This component expose the dob state as a value ('YYYY-MM-DD')
 * (day / month / year) are used internally in order to have more controls over dates
 */

const reducer = (state, action) => ({ ...state, ...action })

const useDob = ({ name, value, onChange }) => {
  const isFirst = useFirstMountState()

  const [state, setState] = React.useReducer(reducer, {
    day: moment(value).isValid() ? moment(value).date() : '',
    month: moment(value).isValid() ? moment(value).month() + 1 : '',
    year: moment(value).isValid() ? moment(value).year() : '',
  })

  // when the user update one of these values
  React.useEffect(() => {
    if (!isFirst && state.day && state.month && state.year) {
      const newDate = moment()
        .year(state.year)
        .month(state.month - 1)
        .date(state.day)
      if (newDate.isValid())
        onChange({
          name,
          value: newDate.format(DEFAULT_FORMAT),
        })
    }
  }, [state.day, state.month, state.year])

  // when value (value got from formik) is updated, we refresh our UI date values
  React.useEffect(() => {
    const currentValState = moment()
      .date(state.day)
      .month(state.month - 1)
      .year(state.year)
      .format(DEFAULT_FORMAT)

    if (moment(value).isValid() && value !== currentValState) {
      const { years, months, date } = moment(value).toObject()
      setState({ day: date, month: months + 1, year: years })
    }
  }, [value])

  const setDate = (typename, value) => setState({ ...state, [typename]: value })

  return {
    ...state,
    setDate,
  }
}

export default function DatePicker({ name, value, required, helpText, label, description, dayPlaceholder, monthPlaceholder, yearPlaceholder, error, onBlur = () => {}, onChange = () => {} }) {
  const { currentLocale } = useGlobalContext()

  const { day, month, year, setDate } = useDob({ name, value, onChange })

  // TODO: retrieve days count based on month value
  const dayOptions = React.useMemo(() => buildOptionsFrom(Array.from(Array(DAY_LENGTH).keys(), (n) => n + 1)), [])
  const monthOptions = React.useMemo(() => {
    // TODO: There is a better way to set moment locale across the whole app ? SSR seems to mess this up...
    moment.locale(currentLocale)
    return buildOptionsFrom(createKeyValueFromArray(moment.months('M')))
  }, [])
  const yearOptions = React.useMemo(() => buildOptionsFrom(Array.from(Array(MAX_YEAR).keys(), (n) => new Date().getFullYear() - n)), [])

  const handleBlur = (e) => onBlur && onBlur(e)
  const handleChange = (typename) => (e) => setDate(typename, parseInt(e.target.value))

  // prepare days and months order
  const daysAndMonths = [
    <PureSelect
      key="day"
      value={day}
      onChange={handleChange('day')}
      onBlur={handleBlur}
      style={{ marginRight: '8px' }}
      name={`${name}__day`}
      placeholder={dayPlaceholder}
      options={dayOptions}
      group
      data-testid={`${name}__day`}
    />,
    <PureSelect
      key="month"
      value={month}
      onChange={handleChange('month')}
      onBlur={handleBlur}
      style={{ marginRight: '8px' }}
      name={`${name}__months`}
      placeholder={monthPlaceholder}
      options={monthOptions}
      group
      data-testid={`${name}__months`}
    />,
  ]

  return (
    <Fieldset>
      {label && (
        <Label htmlFor={name}>
          {label} {!required && notRequiredLabel()} {helpText && <Tooltip>{helpText}</Tooltip>}
          {description && <Description>{description}</Description>}
        </Label>
      )}

      <Horizontal>
        {currentLocale === 'fr' ? daysAndMonths : daysAndMonths.reverse()}
        <PureSelect group value={year} onChange={handleChange('year')} onBlur={handleBlur} name={`${name}__year`} placeholder={yearPlaceholder} options={yearOptions} data-testid={`${name}__year`} />
      </Horizontal>

      {error && (
        <Messages style={{ justifyContent: 'space-between' }} errors={error}>
          <ErrorMessage id={`error-${name}`} className="error">
            {error}
          </ErrorMessage>
        </Messages>
      )}
    </Fieldset>
  )
}

DatePicker.propTypes = {
  name: string.isRequired,
  // might be good to have object({ key, value }) to allows nested values
  helpText: node,
  value: string,
  label: node,
  description: node,
  dayPlaceholder: string,
  monthPlaceholder: string,
  yearPlaceholder: string,
  ariaLabel: string,
  required: bool,
  error: string,
  onBlur: func,
  onChange: func,
}

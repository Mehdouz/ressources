import React, { useEffect, useCallback } from 'react'
import { func } from 'prop-types'
import { GoogleReCaptchaProvider, useGoogleReCaptcha } from 'react-google-recaptcha-v3'
import log from '@axacom-client/logger'
import { useGlobalContext } from '../../../store/GlobalContext'
import { RecaptchaContainer } from './FormFields.style'

/**
 * Wrapper recaptcha that can work with pure html
 * TODO: The reCaptchaKey is coming from a personal account. Change this when its necessary
 **/

const RECAPTCHA_KEY = '6Le1RfIUAAAAAD01Jpeg_p-kjFDr2hdKni1d8c3D'

export function Recaptcha({ ...rest }) {
  const { currentLocale } = useGlobalContext()

  return (
    <RecaptchaContainer>
      <GoogleReCaptchaProvider reCaptchaKey={RECAPTCHA_KEY} language={currentLocale} {...rest}></GoogleReCaptchaProvider>
    </RecaptchaContainer>
  )
}
/**
 * This hook need to be a child of his provider so creating a new component is necessary
 */
export function PureRecaptcha({ onVerify }) {
  const { executeRecaptcha } = useGoogleReCaptcha()
  const handleReCaptchaVerify = useCallback(async () => {
    try {
      const token = await executeRecaptcha('yourAction')
      onVerify && onVerify(token)
    } catch (e) {
      log.error('[Recaptcha] error: ', { e })
    }
  }, [])

  useEffect(() => {
    handleReCaptchaVerify()
  }, [handleReCaptchaVerify])
  return null
}

PureRecaptcha.propTypes = {
  onVerify: func,
}

import styled, { css } from 'styled-components'
import media from '../../../base/style/media'
import { Typo13, Typo16, Typo18, Typo20 } from '../../../base/style/typoStyle/typoStyle'
import { colors } from '../../../base/style/variables'
import { FastField } from 'formik'
import { getSpacing } from '../../../base/style/spacing'
import { timingFunctions } from 'polished'

export const Optional = styled.span`
  ${Typo16}
  color: ${colors.creditColor};
`

export const Horizontal = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  flex-wrap: wrap;

  > select {
    flex: 1;
  }

  ${media.tablet`
    justify-content: start;
  `}
`
export const Description = styled.div`
  ${Typo13}
  color: ${colors.creditColor};
`

export const Fieldset = styled.fieldset`
  display: flex;
  flex-direction: column;
  position: relative;
  margin-bottom: ${getSpacing(2)};
  border: none;
  padding-bottom: 0;
  padding-left: 0;
  padding-right: 0;
`

export const SimpleField = styled.div`
  display: flex;
  flex-direction: column;
  position: relative;
  margin-bottom: ${getSpacing(2)};
  border: none;
  padding-bottom: 0;
  padding-left: 0;
  padding-right: 0;
`
export const FrozenFieldWrapper = styled.div`
  margin-bottom: 24px;
`

export const Label = styled.label`
  ${Typo20}
  font-weight: bold;
  display: flex;
  align-items: center;
  gap: 10px;
`
export const Value = styled.span`
  ${Typo18}
  padding-left: 16px;
`

export const Legend = styled.legend`
  ${Typo20}
  font-weight: bold;
`

export const FieldStyle = css`
  ${Typo18}
  background-color: ${colors.bodyBg};
  border: 1px solid #e5e5e5;
  box-shadow: 0 1px 10px 0px rgba(224, 224, 224, 0.5);
  padding: 0 8px;
  height: ${getSpacing(5)};
  margin-top: 8px;

  ${media.tablet`height: ${getSpacing(6)};`}
`

export const CustomField = styled(FastField)`
  ${FieldStyle}
  width: 100%;

  ::placeholder {
    opacity: 1;
    color: ${colors.creditColor} !important;
  }
  ::-webkit-input-placeholder {
    /* Chrome/Opera/Safari */
    opacity: 1;
    color: ${colors.creditColor} !important;
  }
  ::-moz-placeholder {
    /* Firefox 19+ */
    opacity: 1;
    color: ${colors.creditColor} !important;
  }
  :-ms-input-placeholder {
    /* IE 10+ */
    opacity: 1;
    color: ${colors.creditColor} !important;
  }
  :-moz-placeholder {
    /* Firefox 18- */
    opacity: 1;
    color: ${colors.creditColor} !important;
  }

  ${(props) => {
    if (props.border === 'none') {
      return `border: none;
              box-shadow: none;`
    } else {
      return props.border === 'red' && `border: 1px solid ${colors.errorRed}`
    }
  }};
`

export const SelectWrapper = styled.div`
  display: inline-block;
  flex: 1;
  max-width: 90%;

  ${media.tablet`
    flex: 0;
  `}
`

export const RightChildren = styled.div`
  margin-top: 8px;
`

export const IconButtonContainer = styled.span`
  position: absolute;
  right: 0;
  top: 30px;
  padding: 10px 8px;
`

export const IconButton = styled.span`
  cursor: pointer;
`

export const Messages = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: ${(props) => (props.errors ? getSpacing(1) : getSpacing(3))};
`
export const ErrorMessage = styled.p`
  ${Typo13}
  color: ${colors.errorRed};
`

export const SelectStyle = styled.select`
  ${FieldStyle}
  appearance: none;

  padding: 0 26px 0 8px;
  ${(props) => props.border === 'red' && `border: 1px solid ${colors.errorRed}`};
  background-image: linear-gradient(45deg, transparent 50%, gray 50%), linear-gradient(135deg, gray 50%, transparent 50%);
  background-position: calc(100% - 13px) calc(1em + 3px), calc(100% - 8px) calc(1em + 3px), calc(100% - 2.5em) 0.5em;
  background-size: 5px 5px, 5px 5px, 1px 1.5em;
  background-repeat: no-repeat;

  width: ${(props) => (props.group ? '100%' : 'inherit')};
  ${media.tablet`
     width: ${(props) => (props.group ? 'auto' : 'inherit')};
  `}
`

export const OptionStyle = styled.option`
  display: block;
  padding: 8px;
  margin-top: -2px;
`

export const CheckboxLabelStyle = styled.label`
  position: relative;
  padding-left: 40px;
  margin: 0;
  cursor: pointer;
  color: ${colors.textColor};

  &:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 30px;
    height: 30px;
    border: 1px solid ${colors.gray};
    background: white;
  }
`

export const HiddenCheckbox = styled.input`
  opacity: 0;
  position: absolute;
  left: -9999px;
`

export const CheckboxSquareStyle = styled.span`
  position: absolute;
  top: 0;
  left: 0;
  display: block;
  width: 30px;
  height: 30px;

  ${(props) =>
    props.disabled &&
    css`
      cursor: not-allowed;
      opacity: 0.5;
    `}

  &:before, &:after {
    position: absolute;
    content: '';
    display: block;
    background-color: ${colors.brandBlue};
    transform-origin: 0 0;
    width: 3px;
  }

  &:before {
    transform: rotate(-45deg);
    top: 15px;
    left: 5px;
    border-radius: 20px 20px 0 0;
    height: ${(props) => (props.isChecked ? '10px' : '0px')};
    transition: height 0.15s ${(props) => !props.isChecked && `${timingFunctions('easeOutQuart')} 0.1s`};
  }

  &:after {
    transform: rotate(-135deg);
    left: 13px;
    top: 21px;
    border-radius: 0 0 20px 20px;
    height: ${(props) => (props.isChecked ? '17px' : '0px')};
    transition: height 0.15s ${(props) => props.isChecked && `${timingFunctions('easeOutQuart')} 0.1s`};
  }
`

export const RadioStyle = styled.input`
  ${FieldStyle}
  height: auto;
  ${media.tablet`height: auto;`}
`

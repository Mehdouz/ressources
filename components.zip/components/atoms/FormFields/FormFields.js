import React, { useEffect, useState } from 'react'
import { bool, func, node, number, object, oneOfType, string } from 'prop-types'
import * as moment from 'moment'
import { useFormikContext, useField } from 'formik'
import { useGlobalContext } from '../../../store/GlobalContext'
import { CheckboxList, InputField, InputFile, MultipleSelectField, PhoneField, RadioList, Select, SelectField } from './Fields'
import { SubmitButton, TextContentStyle } from './FormFields.style'
import { Recaptcha as RecaptchaProvider, PureRecaptcha } from './Recaptcha'

import DatePicker from './DatePicker'

export function Submit({ label, type = 'primary', color = 'red', ariaLabel = '', errors, touched, children, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const translations = { defaultLabel: { en: 'Submit', fr: 'Envoyer' } }

  // If touched fields has error
  const isError = Object.entries(touched).length === 0 || Object.entries(errors).length > 0

  return (
    <SubmitButton disabled={isError} action="button" type={type} color={color} ariaLabel={ariaLabel} data-testid="SubmitButton" {...rest}>
      {label || children || translations.defaultLabel[currentLocale]}
    </SubmitButton>
  )
}

Submit.propTypes = {
  label: string,
  type: string,
  color: string,
  ariaLabel: string,
  errors: object,
  touched: object,
  children: string,
}
// TODO: use <PureSelect /> (only html5 select) and a formik wrapper instead when <Form /> will handle name attrribute
export function Gender({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const config = {
    en: { options: { 1: 'Mrs', 2: 'Mr' }, defaultLabel: 'Title', defaultPlaceholder: 'Select' },
    fr: { options: { 1: 'Madame', 2: 'Monsieur' }, defaultLabel: 'Civilité', defaultPlaceholder: 'Sélectionner' },
  }
  const validate = { isRequired: required }

  return (
    <SelectField
      name="gender"
      label={config[currentLocale].defaultLabel}
      options={config[currentLocale].options}
      placeholder={config[currentLocale].defaultPlaceholder}
      validate={validate}
      {...rest}
    />
  )
}

Gender.propTypes = {
  required: bool,
}

// TODO: use <PureSelect /> (only html5 select) and a formik wrapper instead when <Form /> will handle name attrribute
export function BusinessTeam({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const config = {
    en: {
      defaultLabel: 'I want to contact :',
      defaultPlaceholder: 'Select a team',
      options: {
        privacy: 'Data Privacy Department',
        shareholders: 'Individual Shareholders Relations',
        investor: 'Investor Relations',
        media: 'Media Relations',
        webmaster: 'Webmaster',
      },
    },
    fr: {
      defaultLabel: 'Je veux contacter :',
      defaultPlaceholder: 'Sélectionner un contact',
      options: {
        privacy: 'Equipe confidentialité des données',
        shareholders: 'Relations actionnaires individuels',
        investor: 'Relations investisseurs',
        media: 'Relations presse',
        webmaster: 'Webmaster',
      },
    },
  }
  const validate = { isRequired: required }

  return (
    <SelectField
      name="businessTeam"
      label={config[currentLocale].defaultLabel}
      options={config[currentLocale].options}
      placeholder={config[currentLocale].defaultPlaceholder}
      validate={validate}
      {...rest}
    />
  )
}

BusinessTeam.propTypes = {
  defaultValue: string,
  required: bool,
}

export function LastName({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { maximumLength: 50, alphaSpecial: true, isRequired: required }
  const defaultLabel = { en: 'Last name', fr: 'Nom' }
  return <InputField name="lastName" label={defaultLabel[currentLocale]} type="text" validate={validate} {...rest} />
}

LastName.propTypes = {
  required: bool,
}

export function FirstName({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { maximumLength: 50, alphaSpecial: true, isRequired: required }
  const defaultLabel = { en: 'First name', fr: 'Prénom' }
  return <InputField name="firstName" label={defaultLabel[currentLocale]} type="text" validate={validate} {...rest} />
}

FirstName.propTypes = {
  required: bool,
}

export function Company({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { isRequired: required }
  const defaultLabel = { en: 'Company', fr: 'Société' }
  return <InputField name="company" label={defaultLabel[currentLocale]} type="text" validate={validate} {...rest} />
}

Company.propTypes = {
  required: bool,
}

export function Location({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { maximumLength: 50, isRequired: required }
  const defaultLabel = { en: 'Country', fr: 'Pays' }
  return <InputField name="location" label={defaultLabel[currentLocale]} type="text" validate={validate} {...rest} />
}

Location.propTypes = {
  required: bool,
}

export function Message({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { isRequired: required }
  const defaultLabel = { en: 'Message', fr: 'Message' }
  return <InputField name="message" label={defaultLabel[currentLocale]} as="textarea" cols={50} validate={validate} style={{ padding: 8, minHeight: '120px', height: '240px' }} {...rest} />
}

Message.propTypes = {
  required: bool,
}

export function Justificatif({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { isRequired: required }
  const defaultLabel = { en: 'Upload a file', fr: 'Télécharger un fichier' }
  return <InputFile name="justificatif" label={defaultLabel[currentLocale]} type="file" validate={validate} {...rest} accept="image/jpg, image/jpeg, image/png, application/pdf" />
}

Justificatif.propTypes = {
  required: bool,
}

// Formik wrapper
export const BirthdayField = ({ name, required, ...rest }) => {
  const [field, meta, helpers] = useField(name)
  const { currentLocale } = useGlobalContext()

  // TODO: Default i18n, maybe we should lift to default config
  const config = {
    en: {
      label: 'Date of birth',
      description: '',
      dayPlaceholder: 'Day',
      monthPlaceholder: 'Month',
      yearPlaceholder: 'Year',
    },
    fr: {
      label: 'Date de naissance',
      description: '',
      dayPlaceholder: 'Jour',
      monthPlaceholder: 'Mois',
      yearPlaceholder: 'Année',
    },
  }

  const handleChange = (e) => helpers.setValue(e.value)
  const handleBlur = () => helpers.setTouched(true)

  return (
    <DatePicker
      name={name}
      required={required}
      value={field.value}
      error={meta.touched && meta.error ? meta.error : ''}
      onBlur={handleBlur}
      onChange={handleChange}
      {...config[currentLocale]}
      {...rest}
    />
  )
}

BirthdayField.propTypes = {
  name: string,
  required: bool,
}

// TODO: remove this when the current form system will allow the "name" attributes for fields and use <BirthdayField /> instead
export function Birthday({ required, onChange, onBlur, setFieldValue, setFieldTouched, ...rest }) {
  const {
    values: { day, month, year },
  } = useFormikContext()

  const [dob, setDob] = useState(() => ({ day, month: parseInt(month) - 1, year }))
  const { currentLocale } = useGlobalContext()

  const config = {
    en: {
      defaultLabel: 'Date of birth',
      defaultDescription: '',
      dayPlaceholder: 'Day',
      monthPlaceholder: 'Month',
      yearPlaceholder: 'Year',
    },
    fr: {
      defaultLabel: 'Date de naissance',
      defaultDescription: '',
      dayPlaceholder: 'Jour',
      monthPlaceholder: 'Mois',
      yearPlaceholder: 'Année',
    },
  }

  const dayOptions = React.useMemo(() => Array.from(Array(31).keys(), (n) => n + 1), [])
  const monthOptions = React.useMemo(() => createKeyValueFromArray(moment.months('M')), [])
  const yearOptions = React.useMemo(() => Array.from(Array(100).keys(), (n) => new Date().getFullYear() - n), [])

  function createKeyValueFromArray(array) {
    return array.reduce((acc, str, index) => {
      index += 1
      acc[index] = str
      return acc
    }, {})
  }

  const validate = { isRequired: required }
  const validateDob = { isRequired: required, dateValidation: true }

  const onBirthdayChange = (e) => {
    onChange(e)
    // month started at index 0 in moment...
    setDob({ ...dob, [e.currentTarget.name]: e.currentTarget.name === 'month' ? e.currentTarget.value - 1 : e.currentTarget.value })
  }

  const onBirthdayBlur = (e) => {
    onBlur(e)
    setFieldTouched('birthday')
  }

  useEffect(() => {
    setFieldValue('birthday', dob?.year && dob?.month?.toString() >= 0 && dob?.day ? moment(dob).format('YYYY-MM-DD') : 'date-not-valid')
  }, [dob])

  const selectDay = (
    <Select
      name="day"
      options={dayOptions}
      placeholder={config[currentLocale].dayPlaceholder}
      style={{ marginRight: '8px' }}
      group
      onChange={(e) => onBirthdayChange(e)}
      onBlur={(e) => onBirthdayBlur(e)}
      validate={validate}
      {...rest}
    />
  )

  return (
    <MultipleSelectField
      name="birthday"
      label={config[currentLocale].defaultLabel}
      description={config[currentLocale].defaultDescription}
      onChange={onChange}
      onBlur={onBlur}
      validate={validateDob}
      {...rest}
    >
      {currentLocale === 'fr' && selectDay}
      <Select
        name="month"
        options={monthOptions}
        placeholder={config[currentLocale].monthPlaceholder}
        style={{ marginRight: '8px' }}
        group
        onChange={(e) => onBirthdayChange(e)}
        onBlur={(e) => onBirthdayBlur(e)}
        validate={validate}
        {...rest}
      />
      {currentLocale === 'en' && selectDay}
      <Select
        name="year"
        options={yearOptions}
        placeholder={config[currentLocale].yearPlaceholder}
        group
        onChange={(e) => onBirthdayChange(e)}
        onBlur={(e) => onBirthdayBlur(e)}
        validate={validate}
        {...rest}
      />
    </MultipleSelectField>
  )
}

Birthday.propTypes = {
  required: bool,
  onBlur: func,
  onChange: func,
  setFieldValue: func,
  setFieldTouched: func,
}

export function ShareholderType({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const config = {
    en: { defaultLabel: 'Type of shareholding', options: { employeeShareholder: 'Employee Shareholder', bearer: 'Bearer', pureRegisteredShares: 'Pure registered shares' } },
    fr: { defaultLabel: 'Mode de détention', options: { employeeShareholder: 'Salarié Actionnaire', bearer: 'Au porteur', pureRegisteredShares: 'Au nominatif' } },
  }
  const validate = { isRequired: required }
  return <RadioList name="shareholderType" defaultCheck="bearer" label={config[currentLocale].defaultLabel} options={config[currentLocale].options} validate={validate} {...rest} />
}

ShareholderType.propTypes = {
  required: bool,
}

export function Address({ name = 'address', label, placeholder, required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { maximumLength: 96, isRequired: required }
  const config = { en: { defaultLabel: 'Address', defaultPlaceholder: '(number, street name…)' }, fr: { defaultLabel: 'Adresse', defaultPlaceholder: '(numéro, nom de rue…)' } }
  return <InputField name={name} label={label || config[currentLocale].defaultLabel} placeholder={placeholder || config[currentLocale].defaultPlaceholder} type="text" validate={validate} {...rest} />
}

Address.propTypes = {
  name: string,
  label: string,
  placeholder: string,
  required: bool,
}

export function AdditionalAddress({ number = 1, required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const config = {
    en: { label: `Additional Address ${number}`, placeholder: '(building, staircase, apartment, locality…)' },
    fr: { label: `Complément d’adresse ${number}`, placeholder: '(bâtiment, escalier, appartement, lieu-dit…)' },
  }
  return <Address name={`additionalAddress${number}`} required={required} {...config[currentLocale]} {...rest} />
}

AdditionalAddress.propTypes = {
  number: number,
  required: bool,
}

export function ZipCode({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { maximumLength: 50, alphaNumber: true, isRequired: required }
  const defaultLabel = { en: 'Zip/Postal Code', fr: 'Code postal' }
  return <InputField name="zipCode" label={defaultLabel[currentLocale]} type="text" validate={validate} {...rest} />
}

ZipCode.propTypes = {
  required: bool,
}

export function City({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { maximumLength: 50, alphaSpecial: true, isRequired: required }
  const defaultLabel = { en: 'City', fr: 'Ville' }
  return <InputField name="city" label={defaultLabel[currentLocale]} type="text" validate={validate} {...rest} />
}

City.propTypes = {
  required: bool,
}

export function Country({ options, required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { isRequired: required }
  const config = {
    en: { defaultLabel: 'Country', defaultPlaceholder: 'Select', options },
    fr: { defaultLabel: 'Pays', defaultPlaceholder: 'Sélectionner', options },
  }
  return (
    <SelectField
      name="country"
      label={config[currentLocale].defaultLabel}
      placeholder={config[currentLocale].defaultPlaceholder}
      options={config[currentLocale].options}
      validate={validate}
      group
      {...rest}
    />
  )
}

Country.propTypes = {
  required: bool,
  options: object,
}

export function Phone({ name = 'phone', label, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const defaultLabel = { en: 'Phone', fr: 'Téléphone' }
  return <PhoneField name={name} label={label || defaultLabel[currentLocale]} {...rest} />
}

Phone.propTypes = { name: string, label: string, required: bool }

export function AdditionalPhone({ number = 1, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const defaultLabel = { en: `Phone ${number + 1}`, fr: `Téléphone ${number + 1}` }
  return <Phone name={`additionalPhone${number}`} label={defaultLabel[currentLocale]} {...rest} />
}

AdditionalPhone.propTypes = { number: number, required: bool }

// eslint-disable-next-line no-unused-vars
export function Email({ required, email, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = { maximumLength: 50, mail: true, isRequired: required }
  const defaultLabel = { en: 'Email Address', fr: 'Adresse mail' }

  return <InputField name="email" label={defaultLabel[currentLocale]} type="email" validate={validate} {...rest} />
}

Email.propTypes = {
  required: bool,
  email: bool,
}

export function EmailConfirmation({ required, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const validate = {
    maximumLength: 50,
    mail: true,
    isRequired: required,
  }
  const defaultLabel = { en: 'Confirm Email Address', fr: 'Confirmer l’adresse mail' }

  return <InputField name="emailConfirmation" label={defaultLabel[currentLocale]} type="text" validate={validate} {...rest} />
}

EmailConfirmation.propTypes = {
  required: bool,
}

export function TextContent({ children }) {
  return <TextContentStyle>{children}</TextContentStyle>
}

TextContent.propTypes = { children: node.isRequired }

export function NewsletterChoice({ groupRequired, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const config = {
    en: { label: 'Choose your alerts', options: { article: 'News and Stories', pressRelease: 'Press Releases' } },
    fr: { label: 'Choisissez vos alertes', options: { article: 'Actualités et Histoires', pressRelease: 'Communiqués de presse' } },
  }
  const validate = { isRequired: groupRequired }
  return <CheckboxList name="newsletterChoice" label={config[currentLocale].label} options={config[currentLocale].options} defaultCheck={['article']} validate={validate} {...rest} />
}

NewsletterChoice.propTypes = {
  groupRequired: bool,
}

export function Agreement({ required, label, ...rest }) {
  const { currentLocale } = useGlobalContext()
  const config = {
    en: { options: { agreement: label } },
    fr: { options: { agreement: label } },
  }
  const validate = { isRequired: required }
  return <CheckboxList name="agreement" options={config[currentLocale].options} validate={validate} {...rest} />
}

Agreement.propTypes = {
  required: bool,
  label: oneOfType([string, object]),
}

export function RecaptchaField({ name, isVisible }) {
  const [, , { setValue, setTouched }] = useField(name)
  return !isVisible ? (
    <></>
  ) : (
    <RecaptchaProvider>
      <PureRecaptcha
        onVerify={(token) => {
          setValue(token)
          setTouched(true)
        }}
      ></PureRecaptcha>
    </RecaptchaProvider>
  )
}

RecaptchaField.defaultProps = {
  isVisible: true,
}

RecaptchaField.propTypes = {
  name: string,
  isVisible: bool,
}

/** TODO: Anti-pattern: Once all those fields have theire own <Field /> remove all exports */
export { Agreement as agreement }
export { NewsletterChoice as newsletterChoice }
export { TextContent as textContent }
export { Submit as submit }
export { Gender as gender }
export { BusinessTeam as businessTeam }
export { LastName as lastName }
export { FirstName as firstName }
export { Company as company }
export { Location as location }
export { Message as message }
export { Justificatif as justificatif }
export { Birthday as birthday }
export { ShareholderType as shareholderType }
export { Address as address }
export { AdditionalAddress as additionalAddress }
export { ZipCode as zipCode }
export { City as city }
export { Country as country }
export { Phone as phone }
export { AdditionalPhone as additionalPhone }
export { Email as email }
export { EmailConfirmation as emailConfirmation }
export { RecaptchaField as recaptcha }

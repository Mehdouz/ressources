import { Link, PrismicNumber } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  link: Link('iframe Link'),
  height: PrismicNumber("Height (only use to calculate the iframe's ratio, not the real height)"),
  width: PrismicNumber("Width (only use to calculate the iframe's ratio, not the real width)"),
}

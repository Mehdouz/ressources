import React, { useEffect, useRef } from 'react'
import { number, object } from 'prop-types'
import styled from 'styled-components'
import iFrameResize from 'iframe-resizer/js/iframeResizer'
import { getWindow } from '@axacom-client/services/window-service'

// To use the autoResize functionality, the page in the iframe then needs iframeResizer.contentWindow.min.js
// You can find this file from [iframe-resizer](https://github.com/davidjbradshaw/iframe-resizer).
// _This file is designed to be a guest on someone else's system, so has no dependencies and won't do anything until it's activated by a message from the containing page_.

const IframeWrapper = styled.div`
  ${(props) => (props.height && props.width ? `padding-top: ${100 / (props.width / props.height)}%;` : '')}
  position: relative;
  height: 100%;
  overflow: hidden;
`

const SimpleIframe = styled.iframe`
  position: absolute;
  top: 0;
  left: 0;
  z-index: 0;
`
export default function Iframe({ link, width, height, allowScrollMessage }) {
  const iframeRef = useRef()

  useEffect(() => {
    iFrameResize({ autoResize: true }, iframeRef.current)
  })

  useEffect(() => {
    if (allowScrollMessage === 'true') {
      const onScroll = () => {
        iframeRef.current?.contentWindow.postMessage(
          {
            axa: true,
            iframeRect: iframeRef.current?.getBoundingClientRect(),
            innerHeight: getWindow().innerHeight,
            scrollY: getWindow().scrollY,
          },
          '*'
        )
      }
      getWindow().addEventListener('scroll', onScroll)
      return () => getWindow().removeEventListener('scroll', onScroll)
    }
  })

  return (
    <IframeWrapper width={width} height={height}>
      {width && height ? (
        <SimpleIframe src={link.url} frameBorder="0" height="100%" width="100%" />
      ) : (
        <iframe ref={iframeRef} src={link.url} style={{ width: '1px', minWidth: '100%', border: 'none', display: 'block' }} />
      )}
    </IframeWrapper>
  )
}

Iframe.propTypes = {
  link: object,
  width: number,
  height: number,
}

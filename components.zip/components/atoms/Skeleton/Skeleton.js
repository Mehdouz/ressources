import styled, { keyframes } from 'styled-components'
import { colors } from '@axacom-client/base/style/variables'

export const SkeletonList = styled.div`
  padding: 32px 0;
`

const waves = keyframes`
  0% {
    transform: translateX(-100%);
  }
  50% {
    transform: translateX(100%);
  }
  100% {
    transform: translateX(100%);
  }
`

export const Skeleton = styled.div`
  min-height: 16px;
  max-width: 100%;
  background-color: ${colors.grey200};
  margin-bottom: 16px;
  position: relative;
  overflow: hidden;
  &:after {
    animation: ${waves} 1.6s linear 0.5s infinite normal forwards running;
    content: '';
    position: absolute;
    transform: translateX(-100%);
    background: linear-gradient(90deg, transparent, ${colors.grey300}, transparent);
    inset: 0px;
  }
`

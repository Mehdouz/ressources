import React from 'react'
import { bool, object, string } from 'prop-types'

import styled, { css } from 'styled-components'

const ImgWrapper = styled.div`
  width: 100%;
  position: relative;
  overflow: hidden;
  ${(props) => props.round && 'border-radius: 50%;'}

  ${(props) => props.ratio === '2:1' && 'padding-top: 50%;'}
  ${(props) => props.ratio === '16:9' && 'padding-top: 56.25%;'}
  ${(props) => props.ratio === '4:3' && 'padding-top: 75%;'}
  ${(props) => props.ratio === '3:4' && 'padding-top: 133.33%;'}
  ${(props) => props.ratio === '100:143' && 'padding-top: 143%;'} 
  ${(props) => props.ratio === '9:16' && 'padding-top: 177.78%;'}
  ${(props) => props.ratio === '1:1' && 'padding-top: 100%;'}
  ${(props) => props.ratio === '1:2' && 'padding-top: 200%;'}
`

const Img = styled.img`
  position: absolute;
  width: 100%;
  top: 50%;
  left: 50%;
  transition: transform 0.5s ease;
  transform: translate(-50%, -50%);

  ${(props) =>
    props.isBackground &&
    css`
      background-image: url('${props.src}');
      background-repeat: no-repeat;
      background-size: contain;
      background-position: center;
    `}

  ${(props) =>
    props.animation === 'scale' &&
    css`
      &:hover {
        transform: translate(-50%, -50%) scale(1.1);
      }
    `}
`

const BackgroundImage = styled.div`
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;

  background-image: url('${(props) => props.src}');
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
`

export default function Image({ src, alt = '', ratio = '4:3', isBackground = false, animation, image = {}, className, style, dataTestid = 'Image', round = false }) {
  return (
    <ImgWrapper ratio={ratio} className={className} style={style} data-testid={dataTestid} round={round}>
      {isBackground ? <BackgroundImage src={src || image?.main?.url} /> : <Img src={src || image?.main?.url} alt={alt || image?.main?.alt} animation={animation} />}
    </ImgWrapper>
  )
}

Image.propTypes = {
  src: string,
  alt: string,
  ratio: string,
  isBackground: bool,
  animation: string,
  image: object,
  className: string,
  style: object,
  dataTestid: string,
  round: bool,
}

import media from '@axacom-client/base/style/media'
import styled from 'styled-components'

export const CenteredReadingContainer = styled.div`
  margin: 0 auto;
  max-width: 470px;
  position: relative;

  ${media.desktop`
    max-width: 620px;
  `}

  ${media.desktopLarge`
    max-width: 750px;
  `}
`

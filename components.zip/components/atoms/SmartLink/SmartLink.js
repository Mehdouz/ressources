import React from 'react'
import { node, string, any, bool } from 'prop-types'
import NextLink from 'next/link'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { motion } from 'framer-motion/dist/framer-motion'

/**
 * TODO: https://jira.axa.com/jira/browse/AXACO-4090
 * Since we are in a middle of a migration (currently removing express for next.js)
 * It's neccessary to have all our pages in next.js if we want to use client-side rendering
 * for navigation.
 * Before turning CSR_ENABLED to true, make sure to have all our pages in next.js
 * WARNING: Using link to a page that is not a a next.js page will trigger an error.
 */

const CSR_ENABLED = false
export default function SmartLink({ href, passHref, shallow, prefetch, as = '', children, Component = motion.a, ...rest }) {
  const { domain } = useGlobalContext()
  const isRelative = href && (href.startsWith('/') || href.startsWith('#') || href.includes(domain))

  if (!href) return <Component {...rest}>{children}</Component>

  if (!isRelative) {
    return (
      <Component {...rest} href={href} target="_blank" rel="noopener noreferrer">
        {children}
      </Component>
    )
  }
  if (!CSR_ENABLED) {
    return (
      <Component {...rest} href={href}>
        {children}
      </Component>
    )
  }
  return (
    <NextLink href={href} passHref={passHref} shallow={shallow} prefrech={prefetch} as={as || href}>
      <Component {...rest}>{children}</Component>
    </NextLink>
  )
}

SmartLink.propTypes = {
  className: string,
  href: string,
  style: string,
  passHref: bool,
  prefetch: bool,
  shallow: bool,
  as: string,
  Component: any,
  children: node.isRequired,
}

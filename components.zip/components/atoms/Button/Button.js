import React, { useState } from 'react'
import { any, bool, object, oneOf, string, oneOfType } from 'prop-types'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { colors } from '@axacom-client/base/style/variables'
import Icon from '../Icon/Icon'
import { buttonColor, ButtonStyle, ButtonText, IconStyle } from './Button.styles'

export { buttonColor }

/**
 *
 * <button /> html tag already have "type" attribute. So we can't use this attribute for our design system.
 * Therefore, this component need to be reworked. "type“ cannot be used to define color or any design thing.
 *
 *
 * TODO:
 * - Find a way to add the native html5 "type" attribute with our "type" design attribute. Maybe we should rename "type" to "variant" ?
 * - /!\ We need to define if we use a home made <Button /> component OR we use <Buttonstrap /> /!\
 *
 * NOTE: Reactstrap has a "variant" variable and this component use "type"....
 *
 * type: "button|submit|reset"
 * variant: "primary|ghost|link"
 *
 * eg: <Button type="submit" variant="primary">Submit</Button>
 *
 */
export default function Button({
  $isAnimated = true,
  size = 'medium',
  color = 'grey',
  iconType = 'relative',
  iconLeft,
  iconRight,
  type = 'primary',
  url, // Deprecated, DO NOT use this prop : use href instead
  href, // Use this one instead of url
  target,
  disabled,
  dataTestId = 'Button',
  children,
  ariaLabel,
  ...rest
} = {}) {
  const [isHovered, setHovered] = useState(false)
  const { domain } = useGlobalContext()

  let attrs
  if (url && url.length > 0) {
    attrs = { href: url, target: target || (url.startsWith('/') || url.includes(domain) ? '_self' : '_blank') }
  } else if (href && href.length > 0) {
    attrs = { href, target: target || (href.startsWith('/') || href.includes(domain) ? '_self' : '_blank') }
  } else {
    attrs = { type: type, disabled: disabled }
  }
  if (attrs.disabled) {
    $isAnimated = false
  }

  return (
    <ButtonStyle
      {...attrs}
      aria-label={ariaLabel}
      $isAnimated={$isAnimated}
      type={type}
      icontype={iconType}
      iconleft={iconLeft}
      iconright={iconRight}
      size={size}
      color={color}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      data-testid={dataTestId}
      {...rest}
    >
      {iconLeft && (
        <IconStyle type={type} icontype={iconType} size={size} iconLeft={iconLeft}>
          <Icon
            name={iconLeft}
            width={20}
            height={20}
            type={type}
            color={type !== 'primary' ? (isHovered ? (type !== 'ghost' ? buttonColor[color].hover : buttonColor[color].fontColorHover) : buttonColor[color].pristine) : colors.bodyBg}
          />
        </IconStyle>
      )}
      <ButtonText icontype={iconType} paddingLeft={!iconLeft} paddingRight={!iconRight}>
        {children}
      </ButtonText>
      {iconRight && (
        <IconStyle type={type} icontype={iconType} size={size} iconRight={iconRight}>
          <Icon
            name={iconRight}
            width={20}
            height={20}
            type={type}
            color={type !== 'primary' ? (isHovered ? (type !== 'ghost' ? buttonColor[color].hover : buttonColor[color].fontColorHover) : buttonColor[color].pristine) : colors.bodyBg}
          />
        </IconStyle>
      )}
    </ButtonStyle>
  )
}

Button.isLink = (element) => {
  const isLink = ({ tagName, type } = {}) => tagName === 'A' || type === 'link'
  return isLink(element) || isLink(element.parentNode)
}

Button.propTypes = {
  $isAnimated: bool,
  size: oneOf(['small', 'medium', 'large']),
  type: oneOf(['primary', 'ghost', 'link', 'button', 'submit', 'reset']), // This is bad check the TODO above :-(
  action: oneOf(['submit', 'button', 'reset']),
  children: any.isRequired,
  url: oneOfType([string, object]), // Deprecated, DO NOT use this prop : use href instead
  href: oneOfType([string, object]), // Use this one instead of url
  target: oneOf(['_blank', '_self']),
  color: string,
  iconType: oneOf(['fixed', 'relative']),
  iconRight: string,
  iconLeft: string,
  tabIndex: string,
  ariaPressed: bool,
  ariaHasPopup: bool,
  ariaExpanded: bool,
  ariaDisabled: bool,
  ariaLabel: string,
  disabled: bool,
  dataAnalytics: object,
  dataTestId: string,
  style: object,
  texttransform: string,
  className: string,
  width: string,
}

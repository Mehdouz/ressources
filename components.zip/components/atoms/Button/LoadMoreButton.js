import React from 'react'
import { string } from 'prop-types'
import Button from '@axacom-client/components/atoms/Button/Button'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'

// TODO: rework button
function LoadMoreButton({ color = 'red', type = 'link', ...rest }) {
  const { i18n } = useGlobalContext()
  return (
    <Button dataTestId="LoadMoreButton" aria-label={i18n.t('ariaLabelLoadMore')} iconRight="IconArrowDown" color={color} type={type} {...rest}>
      {i18n.t('loadMore')}
    </Button>
  )
}

LoadMoreButton.propTypes = { color: string, type: string }

export default LoadMoreButton

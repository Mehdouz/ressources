const Button = (label) => {
  return {
    buttonText: {
      type: 'Text',
      config: {
        label: `${label || 'Button'} text`,
        placeholder: 'Select a Text',
      },
    },
    buttonLink: {
      type: 'Link',
      config: {
        label: `${label || 'Button'} link`,
        placeholder: 'Choose your link',
      },
    },
  }
}
const Buttons = (nb, label) => {
  let retour = {}
  for (let index = 0; index < nb; index++) {
    retour[`buttonText_${index}`] = {
      type: 'Text',
      config: {
        label: `${label || 'Button'} ${index} text`,
        placeholder: 'Select a Text',
      },
    }

    retour[`buttonLink_${index}`] = {
      type: 'Link',
      config: {
        label: `${label || 'Button'} ${index} link`,
        placeholder: 'Choose your link',
      },
    }
  }
  return retour
}

export { Button, Buttons }

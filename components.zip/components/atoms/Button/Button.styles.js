import React from 'react'
import styled, { css } from 'styled-components'
import { timingFunctions } from 'polished'
import { Typo14 } from './../../../base/style/typoStyle/typoStyle'
import { animateArrowDown, animateArrowLeft, animateArrowRight, animateArrowUp, animateGeneric } from '../../../base/style/animation'
import { getSpacing } from '../../../base/style/spacing'
import { colors, font } from './../../../base/style/variables'
import media from './../../../base/style/media'
import { motion } from 'framer-motion/dist/framer-motion'

export const ButtonText = styled.span`
  margin: 0 20px;

  ${(props) =>
    props.icontype === 'fixed'
      ? css`
          flex: 1;
          padding: 0;
        `
      : css`
          padding: 0 8px;
        `};
`

const buttonHeight = {
  small: { mobile: '40px', tablet: '30px' },
  medium: { mobile: '48px', tablet: '40px' },
  large: { mobile: '48px', tablet: '48px' },
}

const buttonIconAnimation = {
  Generic: { animation: animateGeneric, timing: timingFunctions('easeOutQuart') },
  IconArrowRight: { animation: animateArrowRight, timing: timingFunctions('easeInOutQuart') },
  IconArrowLeft: { animation: animateArrowLeft, timing: timingFunctions('easeInOutQuart') },
  IconArrowDown: { animation: animateArrowDown, timing: timingFunctions('easeInOutQuart') },
  IconArrowUp: { animation: animateArrowUp, timing: timingFunctions('easeInOutQuart') },
}

export const buttonColor = {
  blue: {
    pristine: colors.brandBlue,
    hover: colors.brandBlueDark,
    fontColor: colors.white,
    fontColorHover: colors.white,
  },
  red: {
    pristine: colors.brandRed,
    hover: colors.brandRedFlash,
    fontColor: colors.white,
    fontColorHover: colors.white,
  },
  success: {
    pristine: colors.greenSuccess,
    hover: colors.greenSuccess,
    fontColor: colors.white,
    fontColorHover: colors.white,
  },
  lightGrey: {
    pristine: colors.gray,
    hover: colors.white,
    fontColor: colors.gray,
    fontColorHover: colors.white,
  },
  grey: {
    pristine: colors.gray,
    hover: colors.grayDark,
    fontColor: colors.white,
    fontColorHover: colors.white,
  },
  darkGrey: {
    pristine: colors.grayDark,
    hover: colors.grayDarker,
    fontColor: colors.white,
    fontColorHover: colors.white,
  },
  white: {
    pristine: colors.white,
    hover: colors.AXABlue,
    fontColor: colors.AXABlue,
    fontColorHover: colors.white,
  },
  dark: {
    pristine: colors.textColor,
    hover: colors.grayDark,
    fontColor: colors.textColor,
    fontColorHover: colors.textColor,
  },
}

const ghostButton = css`
  color: ${(props) => buttonColor[props.color].pristine};
  border: 2px solid ${(props) => buttonColor[props.color].pristine};
  background-color: transparent;
  border-radius: 0;

  &:hover,
  &:focus,
  &:active {
    border-color: ${(props) => buttonColor[props.color].pristine};
    color: ${(props) => buttonColor[props.color].fontColor};
  }
`

const linkButton = css`
  font-weight: ${font.weight.semiBold};
  border: none;
  color: ${(props) => buttonColor[props.color].pristine};
  background-color: transparent;
  padding: 0;
  height: auto;

  ${ButtonText} {
    margin: 0;
    padding: 0;
  }

  &:before {
    float: right;
    margin-left: ${getSpacing(1)};
  }

  &:hover,
  &:focus,
  &:active {
    color: ${(props) => (props.color === 'white' ? buttonColor[props.color].pristine : buttonColor[props.color].hover)};
    span {
      stroke: ${(props) => buttonColor[props.color].hover};
    }
    &:before {
      color: ${(props) => buttonColor[props.color].hover};
      stroke: ${(props) => buttonColor[props.color].hover};
    }
  }

  ${media.tablet`
    height: auto;
    padding-left: 0;
    padding-right: 0;
  `}
`

const animatedButton = css`
  z-index: 0; // for animation
  transition: color 0.3s;
  position: relative;
  overflow: hidden;
  border-radius: 0;
  &:after {
    content: '';
    position: absolute;
    z-index: -1;
    transition: width 0.3s, opacity 0.3s;
    width: 0;
    height: 530px;
    top: 50%;
    left: 50%;
    opacity: 0;
    background: ${(props) => (props.type === 'ghost' ? buttonColor[props.color].pristine : buttonColor[props.color].hover)};
    transform: translate(-50%, -50%) rotate(45deg);
    transform: translate3d(-50%, -50%, 0) rotate(45deg);
    backface-visibility: hidden;
  }

  &:hover,
  &:active,
  &:focus {
    color: ${(props) => buttonColor[props.color].fontColorHover};
    &:after {
      width: 100%;
      opacity: 1;
    }
  }
`

export const IconStyle = styled.span`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  ${(props) => {
    if (props.type === 'link') {
      return `${props.iconLeft ? 'margin-right' : 'margin-left'}: ${props.type === 'link' ? getSpacing(1) : getSpacing(2)};`
    } else {
      return `${props.iconLeft ? 'margin-left' : 'margin-right'}: ${props.type === 'link' ? getSpacing(1) : getSpacing(2)};`
    }
  }}

  ${(props) =>
    props.icontype === 'fixed' &&
    css`
      margin: 0;
      width: ${buttonHeight[props.size].mobile};
      height: ${buttonHeight[props.size].mobile};

      ${media.tablet`
        width: ${buttonHeight[props.size].tablet};
        height: ${buttonHeight[props.size].tablet};
      `}
    `}
`

function FilteredButton(props) {
  if (props.href) return <motion.a {...props} />
  return <motion.button {...props} />
}

export const ButtonStyle = styled(FilteredButton)`
  display: inline-flex;
  position: relative;
  height: ${(props) => buttonHeight[props.size].mobile};
  align-items: center;
  justify-content: center;
  vertical-align: top;
  ${Typo14};
  width: ${(props) => props.width};
  font-weight: ${font.weight.semiBold};
  padding: 0;
  border: none;
  border-radius: 0;
  border-bottom: 2px solid ${(props) => buttonColor[props?.color]?.hover};
  cursor: pointer;

  text-align: center;
  text-decoration: none;
  text-transform: ${(props) => (props.texttransform ? `${props.texttransform} !important` : 'uppercase')};
  transition: all 0.25s ease;
  background-color: ${(props) => buttonColor[props.color]?.pristine};
  color: ${(props) => buttonColor[props.color]?.fontColor};

  &:disabled {
    background-color: ${colors.disabledButton};
    border-bottom: ${colors.disabledButton};
    color: inherit;
    cursor: not-allowed;
  }

  &:hover,
  &:focus,
  &:active {
    ${IconStyle} {
      ${(props) =>
        props.$isAnimated &&
        css`
          animation-name: ${buttonIconAnimation['Generic'].animation};
          animation-timing-function: ${buttonIconAnimation['Generic'].timing};

          ${(props) => {
            if (props.iconleft && buttonIconAnimation[props.iconleft])
              css`
                animation-name: ${buttonIconAnimation[props.iconleft].animation};
                animation-timing-function: ${buttonIconAnimation[props.iconleft].timing};
              `
            else if (props.iconright && buttonIconAnimation[props.iconright]) {
              css`
                animation-name: ${buttonIconAnimation[props.iconright].animation};
                animation-timing-function: ${buttonIconAnimation[props.iconright].timing};
              `
            }
          }}

          animation-duration: 0.4s;
        `}
    }
  }

  ${media.tablet`
    max-height: 805px;
    height: ${(props) => buttonHeight[props.size].tablet};
  `}

  ${(props) => props.$isAnimated && props.type !== 'link' && animatedButton}
  ${({ type }) => type === 'ghost' && ghostButton}
  ${({ type }) => type === 'link' && linkButton}
  ${(props) =>
    props.icontype === 'fixed' &&
    css`
      border-bottom: none;
      justify-content: space-between;
    `}
`

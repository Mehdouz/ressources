const $anchor = {
  type: 'Group',
  fieldset: 'anchors block',
  config: {
    fields: {
      anchorId: {
        type: 'StructuredText',
        config: {
          placeholder: 'my-anchor-id',
          label: 'Anchor ID',
        },
      },
      anchorLabel: {
        type: 'StructuredText',
        config: {
          placeholder: 'My anchor label',
          label: 'Anchor Label',
        },
      },
    },
  },
}

export default $anchor

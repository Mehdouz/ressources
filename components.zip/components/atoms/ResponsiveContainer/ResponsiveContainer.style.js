import styled from 'styled-components'
import media from '@axacom-client/base/style/media'
import { motion } from 'framer-motion/dist/framer-motion'

export const Container = styled(motion.div)`
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  position: relative;

  ${media.phone` // 767px
    padding: 0 24px;
  `}

  ${media.tablet` // 768px
    max-width: 744px;
    padding: 0 24px;
  `}

  ${media.desktop` // 992px
    max-width: 970px;
  `}

  ${media.desktopLarge` // 1200px
    max-width: 1170px;
  `}

  ${media.desktopVeryLarge` // 1920px
    max-width: 1368px;
  `};
`

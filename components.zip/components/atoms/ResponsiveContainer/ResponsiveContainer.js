import React from 'react'

import { Mobile, Tablet, Desktop, LargeDesktop, VeryLargeDesktop } from '@axacom-client/components/utils/Responsive'

import { Container } from './ResponsiveContainer.style'
export { Container }
const ResponsiveContainer = ({ children, mobile, tablet, desktop, largeDesktop, veryLargeDesktop, ...rest }) => {
  const content = (hasContainer) => (hasContainer ? <Container {...rest}>{children}</Container> : <>{children}</>)

  return (
    <>
      <Mobile>{content(mobile)}</Mobile>
      <Tablet>{content(tablet)}</Tablet>
      <Desktop>{content(desktop)}</Desktop>
      <LargeDesktop>{content(largeDesktop)}</LargeDesktop>
      <VeryLargeDesktop>{content(veryLargeDesktop)}</VeryLargeDesktop>
    </>
  )
}

export default ResponsiveContainer

const icons = {
  iconImage: {
    type: 'Select',
    fieldset: 'Icon Image',
    config: {
      label: 'Select your icon',
      options: ['IconCheck', 'IconInstagram', 'IconDocument', 'IconYoutube', 'IconStar', 'IconLinkedin', 'IconValidation', 'IconContract', 'IconCalendar', 'IconCalendarFull', 'IconWine'],
      default_value: 'IconCheck',
    },
  },
  iconColor: {
    type: 'Select',
    fieldset: 'Icon color',
    config: {
      label: 'Select the icon color',
      options: ['white', 'gray', 'blue'],
      default_value: 'white',
    },
  },
}

export default icons

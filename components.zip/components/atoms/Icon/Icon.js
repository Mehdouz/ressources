import React from 'react'
import { object, string } from 'prop-types'
import log from '@axacom-client/logger'
import svg from '@axacom-client/base/svg'

const IconArrow = svg.IconArrow

function Icon(props) {
  let Component
  switch (props.name) {
    case 'IconArrowRight':
      return <IconArrow {...props} />
    case 'IconArrowLeft':
      return <IconArrow {...props} style={{ ...props.style, transform: 'rotate(180deg)' }} />
    case 'IconArrowDown':
      return <IconArrow {...props} style={{ ...props.style, transform: 'rotate(90deg)' }} />
    default:
      Component = svg[props.name]
      if (Component) {
        return <Component {...props} />
      }
      log.info(`[Icon] name ${props.name} not found`)
      return <div />
  }
}

Icon.propTypes = {
  name: string.isRequired,
  style: object,
}

export default Icon

import React from 'react'
import MediaQuerySSR from './MediaQuerySSR'

/*
NOTE/TODO:
There is a simplier way to define responsiveness in React by using hooks.
So instead of having this:

function Image(props) => {
  return (<Mobile>
    <img {...props)} />}
  </Mobile>)

We can have this:
function Image(props) => {
  const isMobile = useMediaQuery("mobile") // or useMediaQuery('(max-width:767px)')
  return isMobile ? <Image {...props} /> : null
}

- more declarative, we explicitly says that it can renders null
- We can combine easier them because they are just booleans and not components!
- Only one import/export for all sizes
- Easier/simplier to read ?
- Hooks <3
--> https://github.com/streamich/react-use/blob/master/docs/useMedia.md

*/

const Mobile = (props) => <MediaQuerySSR {...props} maxWidth={767} />
const MinTablet = (props) => <MediaQuerySSR {...props} minWidth={768} />
const Tablet = (props) => <MediaQuerySSR {...props} minWidth={768} maxWidth={991} />
const MobilesDevices = (props) => <MediaQuerySSR {...props} maxWidth={991} />
const MinDesktop = (props) => <MediaQuerySSR {...props} minWidth={992} />
const Desktop = (props) => <MediaQuerySSR {...props} minWidth={992} maxWidth={1199} />
const SmallDesktopAndMobile = (props) => <MediaQuerySSR {...props} maxWidth={1199} />
const LargeDesktop = (props) => <MediaQuerySSR {...props} minWidth={1200} maxWidth={1919} />
const VeryLargeDesktop = (props) => <MediaQuerySSR {...props} minWidth={1920} />

export { Mobile, MinTablet, Tablet, MobilesDevices, MinDesktop, Desktop, LargeDesktop, SmallDesktopAndMobile, VeryLargeDesktop }

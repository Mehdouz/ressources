import React, { useEffect, useState } from 'react'
import { object } from 'prop-types'
import MediaQuery from 'react-responsive'
import { withResponsiveContext } from '@axacom-client/store/ResponsiveContext'

export default withResponsiveContext(MediaQueryComponent)

function MediaQueryComponent({ responsive, ...rest }) {
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), []) // empty array ensure effect only run on mount and unmount
  const values = mounted ? undefined : { deviceWidth: responsive && responsive.fakeWidth, width: responsive && responsive.fakeWidth }
  return <MediaQuery device={values} {...rest} />
}

MediaQueryComponent.propTypes = { responsive: object }

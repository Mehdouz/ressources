import { useEffect, useState } from 'react'
import _debounce from 'lodash/debounce'

export function useWindowSize() {
  // Initialize state with undefined width/height so server and client renders match
  // Learn more here: https://joshwcomeau.com/react/the-perils-of-rehydration/
  const isSSRCompatible = typeof window !== 'undefined'
  const [windowSize, setWindowSize] = useState({
    // eslint-disable-next-line no-undef
    width: isSSRCompatible ? window.innerWidth : undefined,
    // eslint-disable-next-line no-undef
    height: isSSRCompatible ? window.innerHeight : undefined,
  })

  useEffect(() => {
    // Handler to call on window resize
    function handleResize() {
      // Set window width/height to state
      // eslint-disable-next-line no-undef
      const { innerWidth, innerHeight } = window
      setWindowSize({
        width: innerWidth,
        height: innerHeight,
      })
    }

    const debouncedHandleWindowResize = _debounce(handleResize, 500)
    // Add event listener
    // eslint-disable-next-line no-undef
    window.addEventListener('resize', debouncedHandleWindowResize)

    // Call handler right away so state gets updated with initial window size
    handleResize()

    // Remove event listener on cleanup
    // eslint-disable-next-line no-undef
    return () => window.removeEventListener('resize', debouncedHandleWindowResize)
  }, []) // Empty array ensures that effect is only run on mount

  return windowSize
}

import { media } from '@axacom-client/base/style/variables'
import { parser } from './parser'

export class ResponsiveSSR {
  fakeWidth
  device

  constructor(req) {
    this.fakeWidth = media.desktop
    this.device = 'desktop'
    if (req) this.update(req)
  }

  update(req) {
    const { phone = false, tablet = false, mobile = false, desktop = false } = parser(req)

    if (mobile) {
      if (phone) {
        this.fakeWidth = media.phoneMax
        this.device = 'phone'
      } else if (tablet) {
        this.fakeWidth = media.tabletMax
        this.device = 'tablet'
      } else {
        // TODO - should we ever get here? default to the lowest value i guess
        this.fakeWidth = media.phoneMax
        this.device = 'mobile'
      }
    } else if (desktop) {
      this.fakeWidth = media.desktopMax
      this.device = 'desktop'
    } else {
      // nothing set, default to our defaultSize
      this.fakeWidth = media.desktopXLMin
      this.device = 'desktopXL'
    }
  }
}

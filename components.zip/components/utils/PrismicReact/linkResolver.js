const linkResolver = function (doc, isBroken) {
  if (isBroken) return '#broken'
  if (doc.document && doc.document.url) return doc.document.url
  return '/' + doc.id
}

export default linkResolver

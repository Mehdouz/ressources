import log from '../../../logger'
export function isFieldFulfilled(field) {
  const isStructuredText = field?.[0]?.text

  return isStructuredText === '' || isStructuredText ? field[0].text.length > 0 : ![undefined, null].includes(field)
}

export function mandatoryFieldRule({ mandatoryFields = [] }) {
  return (document) => mandatoryFields.every((fieldName) => document[fieldName])
}

export function mandatorySliceFieldRule({ mandatoryFields = [], sliceName = '', isRepeatable = false, isRealSlice = true }) {
  return (document) => {
    if (isRealSlice) {
      return document.body
        .filter((slice) => slice.sliceType === sliceName)
        .every((slice) => {
          const isGroup = slice.value[0]

          if (isRepeatable) {
            return slice.value.items.every((itemGroup) => mandatoryFields.every((fieldName) => isFieldFulfilled(itemGroup[fieldName])))
          }

          return mandatoryFields.every((fieldName) => (isGroup ? isFieldFulfilled(slice.value[0][fieldName]) : isFieldFulfilled(slice.value[fieldName])))
        })
    }

    if (!document[sliceName]) {
      log.error(`[fieldValidation] You are looking for "${sliceName}" but ${sliceName} is not defined in your validation file`)
      return false
    }

    const isGroup = document[sliceName][0]

    return mandatoryFields.every((fieldName) => (isGroup ? document[sliceName][0][fieldName] : document[sliceName][fieldName]))
  }
}

export function multipleMandatorySliceFieldRule({ mandatoryFields = [], sliceName = '' }) {
  return (document) =>
    document.body
      .filter((slice) => slice.sliceType === sliceName)
      .every((slice) => {
        const isGroup = slice.value[0]

        return mandatoryFields.some((fieldName) => (isGroup ? isFieldFulfilled(slice.value[0][fieldName]) : isFieldFulfilled(slice.value[fieldName])))
      })
}

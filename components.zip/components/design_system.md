# Migration React & Design system

Quelques liens utilent :

Présentation rapide du projet Axa.com et de l'industrialisation avec le design system atomique : https://confluence.axa.com/confluence/pages/viewpage.action?pageId=158125428

Cadrage de la migration react
https://confluence.axa.com/confluence/display/AXACOM/Cadrage+migration+React

Etat d'avancement de la migration react
https://confluence.axa.com/confluence/display/AXACOM/Etat+d%27avancement
https://confluence.axa.com/confluence/pages/viewpage.action?pageId=176367450

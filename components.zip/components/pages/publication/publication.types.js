import paragraph from '../../organisms/Slices/Paragraph/Paragraph.types'
import highlight from '../../organisms/Slices/Highlight/Highlight.types'
import documentsSlice from '../../organisms/Slices/Documents/Documents.types'
import longQuote from '../../organisms/Slices/LongQuote/LongQuote.types'
import videoEmbedded from '../../organisms/Slices/VideoEmbedded/VideoEmbedded.types'

export default {
  $slug: {
    fieldset: 'SEO',
    type: 'Text',
    config: {
      label: 'Slug',
      placeholder: 'Slug',
      useAsTitle: true,
    },
  },
  $seoDescription: {
    type: 'Text',
    config: {
      label: 'SEO Description',
      placeholder: 'SEO Description',
    },
  },
  $tweet: {
    type: 'Text',
    fieldset: 'Social network sharing',
    config: {
      placeholder: 'Tweet',
      label: 'Tweet',
    },
  },
  $sharingImage: {
    type: 'Image',
    config: {
      placeholder: 'Sharing image',
      constraint: {
        width: 1200,
        height: 630,
      },
    },
  },
  $sharingDescription: {
    type: 'Text',
    config: {
      placeholder: 'Sharing Description',
      label: 'Sharing Description',
    },
  },
  topic_en: {
    type: 'Link',
    fieldset: 'Topic',
    config: {
      select: 'document',
      masks: ['publication-topic'],
      placeholder: 'Topic',
    },
  },
  $title: {
    fieldset: 'Title',
    type: 'Text',
    config: {
      label: 'Title',
    },
  },
  date_en: {
    type: 'Date',
    config: {
      label: 'Date',
    },
  },
  $cover: {
    type: 'Image',
    config: {
      placeholder: ' cover',
      constraint: {
        width: 400,
      },
    },
  },
  $document: {
    type: 'Link',
    fieldset: 'Document',
    config: {
      placeholder: 'Document / Link',
    },
  },
  $documentTitle: {
    type: 'Text',
    config: {
      placeholder: 'Document title',
    },
  },
  $webLink: {
    type: 'Link',
    fieldset: 'Web link',
    config: {
      label: 'Web link',
    },
  },
  $nameLink: {
    type: 'Text',
    fieldset: 'Name link',
    config: {
      label: 'Name link',
      placeholder: '',
    },
  },
  $body: {
    fieldset: 'Body',
    type: 'Slices',
    config: {
      choices: {
        ...paragraph,
        ...highlight,
        ...videoEmbedded,
        ...longQuote,
        ...documentsSlice,
      },
    },
  },
}

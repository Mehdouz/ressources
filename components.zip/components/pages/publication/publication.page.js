import React from 'react'
import * as components from '@axacom-client/components/organisms/Slices'
import log from '@axacom-client/logger'
import { camelCase } from 'lodash/string'
import axacomClient from '@axacom-client/clients/axacom'
import { ErrorSliceBoundary } from '@axacom-client/components/organisms/Error/Error'
import PublicationBody from '@axacom-client/components/organisms/PublicationBody/PublicationBody'

export default function Publication({ title, cover, document, documentTitle, url, body, topic, date, webLink, nameLink }) {
  return (
    <>
      <PublicationBody
        title={title}
        cover={cover}
        document={document}
        url={url}
        documentTitle={documentTitle}
        topic={topic}
        date={date}
        webLink={webLink}
        nameLink={nameLink}
        $hasSlices={body?.length > 0}
      />
      {body &&
        body.map((slice, index) => {
          const Component = components[camelCase(slice.sliceType)]
          if (Component)
            return (
              <ErrorSliceBoundary sliceType={slice.sliceType} key={index}>
                <Component {...slice.value} />
              </ErrorSliceBoundary>
            )
        })}
    </>
  )
}

export const getPublicationProcData = async ({ language, slug }) => {
  log.debug('[Publication] getInitialProps')

  const publication = (await axacomClient().get(`/_api/publications/${slug}`, { params: { language } })).data

  return publication
}

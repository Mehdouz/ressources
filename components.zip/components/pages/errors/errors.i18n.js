export default {
  somethingWrong: {
    title: {
      en: 'An error occurred',
      fr: 'Une erreur est survenue',
    },
    text: {
      en: 'This service is temporarily unavailable due to a technical issue. We sincerely apologize for the inconvenience and invite you to try again later.',
      fr: "En raison d'un problème technique, ce service est momentanément indisponible. Nous vous prions de bien vouloir nous excuser pour ce désagrément et nous vous invitons à réessayer ultérieurement.",
    },
    cta: {
      en: 'Go back to home page.',
      fr: "Retourner sur la page d'accueil.",
    },
  },
  requiredFields: {
    text: {
      en: 'Required field is missing.',
      fr: 'Champs obligatoire non renseigné.',
    },
  },
}

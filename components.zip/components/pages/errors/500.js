import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Message from '@axacom-client/components/organisms/Slices/Message/Message'
import { getBookmarks } from '@axacom-client/services/urlResolver'

export default function page500() {
  const { currentLocale } = useGlobalContext()
  return (
    <Message
      image={{ main: { url: '/base/images/space_invader_yellow.png' } }}
      title="Error 500"
      content="Oups! Looks like something went wrong! We track these errors automatically, but if the problem persists feel free to contact us. In the meantime, try refreshing."
      cta={{
        content: 'Back to home',
        color: 'red',
        type: 'link',
        iconRight: 'IconArrowRight',
        url: getBookmarks('home', currentLocale),
      }}
    />
  )
}

import { useRouter } from 'next/router'
import React, { useState } from 'react'
import { object, string } from 'prop-types'
import styled from 'styled-components'
import { Col, Container, Row } from 'reactstrap'
import { getSpacing } from '@axacom-client/base/style/spacing'
import media from '@axacom-client/base/style/media'
import { colors } from '@axacom-client/base/style/variables'
import { Typo16, Typo18, Typo20Bold, Typo24, Typo61 } from '@axacom-client/base/style/typoStyle/typoStyle'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { FieldStyle } from '@axacom-client/components/atoms/FormFields/Fields.style'
import YoutubePlayer from '@axacom-client/components/molecules/YoutubePlayer/YoutubePlayer'
import Button from '@axacom-client/components/atoms/Button/Button'
import { MinDesktop, MobilesDevices } from '@axacom-client/components/utils/Responsive'
import { isServer } from '@axacom-client/services/window-service'

const Background = styled.div`
  display: none;
  ${media.desktop`
    display: flex;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: 50vw;
    background: ${colors.white};
  `}
`

const Wrapper = styled.div`
  background-color: ${colors.brandBlue};
  position: relative;
  height: 100%;
`
const LeftCol = styled(Col)`
  background-color: ${colors.white};
  padding-top: ${getSpacing(8)};
  padding-bottom: ${getSpacing(8)};
  ${media.desktop`
    margin-top: ${getSpacing(12)};
    margin-bottom: ${getSpacing(12)};
    padding-right: ${getSpacing(12)};
  `}
`
const RightCol = styled(Col)`
  padding-top: ${getSpacing(8)};
  padding-bottom: ${getSpacing(8)};
  color: ${colors.white};
  ${media.desktop`
    margin-top: ${getSpacing(12)};
    margin-bottom: ${getSpacing(12)};
    padding-left: ${getSpacing(12)};
  `};
`

const Title = styled.h1`
  ${Typo61}
  color: ${colors.brandBlue};
  margin: 0 0 ${getSpacing(4)};
`
const Subtitle = styled.h2`
  ${Typo18}
  margin: 0 0 ${getSpacing(4)};
`

const Search = styled.div`
  margin-bottom: ${getSpacing(3)};
`
const SearchTitle = styled.p`
  ${Typo24}
  margin-bottom: ${getSpacing(3)};
`
const SearchInput = styled.input`
  ${FieldStyle}
  width: 100%;
  margin-bottom: ${getSpacing(3)};
  box-shadow: none;
`
const SearchMessage = styled.p`
  ${Typo16}
`

const Video = styled.div`
  padding-top: ${getSpacing(3)};
`
const VideoTitle = styled.p`
  ${Typo20Bold}
  padding-bottom: ${getSpacing(3)};
`

const ButtonReadMore = styled(Button)``

export default function page404({ videoLink }) {
  const { i18n, bookmarks, domain } = useGlobalContext()
  const [value, setValue] = useState('')
  const router = useRouter()

  function handleChange(e) {
    setValue(e.target.value)
  }

  async function handleKeyPress(e) {
    const key = e.which || e.keyCode
    if (key === 13 && e.target.value) {
      // eslint-disable-next-line no-undef
      document.location.href = `${bookmarks.search.url}?q=${e.target.value}`
    }
  }

  const pathSegments = router.asPath.split('/')
  const slugAsText = pathSegments && pathSegments.length ? pathSegments[pathSegments.length - 1].replace(/-/g, ' ') : ''

  const content = (
    <Row>
      <LeftCol lg="6">
        <Title>{i18n.t('404.title')}</Title>
        <Subtitle>{i18n.t('404.subtitle')}</Subtitle>
        <ButtonReadMore url="/" type="primary" color="red" ariaLabel={i18n.t('backToHome')}>
          {i18n.t('backToHome')}
        </ButtonReadMore>
      </LeftCol>
      <RightCol lg="6">
        <Search>
          <SearchTitle>{i18n.t('404.searchTitle')}</SearchTitle>
          <SearchInput type="search" role="search" aria-label={i18n.t('search.label')} placeholder={i18n.t('search.input')} value={value} onChange={handleChange} onKeyPress={handleKeyPress} />
          {!isServer() && (
            <SearchMessage>
              {`${i18n.t('404.searchHelp1')} ${domain}${router.asPath}, `}
              <a href={`${bookmarks.search.url}#query=${slugAsText}`}>{`${i18n.t('404.searchHelp2')} "${slugAsText}"`}</a>
              {` ${i18n.t('404.searchHelp3')}`}
            </SearchMessage>
          )}
        </Search>
        {videoLink && (
          <Video>
            <VideoTitle>{i18n.t('404.videoTitle')}</VideoTitle>
            <YoutubePlayer {...videoLink} />
          </Video>
        )}
      </RightCol>
    </Row>
  )

  return (
    <Wrapper>
      <Background />
      <MobilesDevices>
        <Container fluid>{content}</Container>
      </MobilesDevices>
      <MinDesktop>
        <Container>{content}</Container>
      </MinDesktop>
    </Wrapper>
  )
}

page404.propTypes = {
  videoLink: object,
  asPath: string,
}

import styled from 'styled-components'
import { colors, font } from '@axacom-client/base/style/variables'
import media from '@axacom-client/base/style/media'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import { motion } from 'framer-motion/dist/framer-motion'

export const Header = styled.div`
  overflow: hidden;
  position: relative;
  background-size: cover;
  background-position: center;
  padding: 50px 30px;
  text-align: center;
  height: inherit;
`

export const PageHeader = styled(Container)`
  padding: 60px 32px 20px;

  ${media.tablet`
    text-align: center;
    padding: 90px 95px 45px;
    margin-top: -150px;
    background-color: white;

  `}
`

export const PageTitle = styled.h1`
  display: block;
  font-family: ${font.fontFamilyHeading};
  font-weight: ${font.weight.bold};
  line-height: 30px;
  font-size: 32px;
  line-height: 34px;
  max-width: 405px;
  margin: 0 auto;

  ${media.tablet`
    font-size: 58px;
    line-height: 60px;
    max-width: inherit;
  `}

  ${media.desktopLarge`
    font-size: 72px;
    line-height: 74px;
  `}
`

export const SubTitle = styled.p`
  font-size: 18px;
  line-height: 24px;
  max-width: 405px;
  margin: 30px auto 0;

  ${media.tablet`
    font-size: 20px;
    line-height: 28px;
    max-width: inherit;
  `}
`

export const TabTitleBlock = styled.div`
  margin-top: 80px;
  text-align: center;
  margin-bottom: 30px;
  font-family: ${font.fontFamilyBase};
  font-weight: ${font.weight.bold};
  font-size: 12px;
  letter-spacing: 0.1em;
  line-height: 1.5;
  text-transform: uppercase;
  display: flex;
  flex-direction: column;
  gap: 35px;

  ${media.tablet`
    flex-direction: row;
    justify-content: center;
    margin-bottom: 110px;
    margin-top: 110px;
    gap: 0;
  `}

  ${media.desktop`
    margin-bottom: 120px;
    margin-top: 140px;
  `}

  ${media.desktopLarge`
    font-size: 13px;
  `}
`

export const TabLink = styled(SmartLink)`
  color: ${colors.white};
  display: inline-block;
  position: relative;
  ${(props) =>
    props.$isActive &&
    `
        &:after {
          content: "";
          width: 100%;
          background: ${colors.white};
          height: 1px;
          position: absolute;
          left: 0;
          top: 20px;
        }
  `}

  &:hover,
  &:active,
  &:focus {
    color: ${colors.white};
  }

  ${media.tablet`
    &:after {
      content: none;
    }
  `}
`

export const TabItem = styled.li`
  list-style: none;
  position: relative;

  ${media.phone`
    &:not(:last-child):after {
      display: block;
      content: '';
      height: 1px;
      background-color: ${({ $hasImage }) => ($hasImage ? '#6d6d6d' : '#ddd')};
      position: absolute;
      width: 30px;
      bottom: -17px;
      left: 50%;
      transform: translateX(-50%);
    }
  `}

  ${media.tablet`
      padding: 0 15px;

      &:not(:last-child){
        border-right: 1px solid ${({ $hasImage }) => ($hasImage ? '#6d6d6d' : '#ddd')};
      }
  `}
`

export const Underline = styled(motion.div)`
  width: 100%;
  height: 3px;
  left: 0;
  bottom: -20px;
  background: ${colors.white};
  position: absolute;
  padding: 0 15px;
  display: none;

  ${media.tablet`
    display: block;

  `}
`

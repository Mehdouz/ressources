import { Group, Link, Text, Select, Image } from '../../../../tools/prismic/backup-types/generic-type'
import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'

export default {
  $slug: Text('Slug', 'Slug', true),
  $sectionReferrer: Select(['Commitments', 'About us', 'Press', 'Investor', 'Careers'], 'Referrer', 'Choose your referrer'),
  ...getMetaContent(['sharingImage', 'seoDescription', 'tweet', 'title']),
  $title: Text('Title', 'Title (Mandatory) (70 characters max)'),
  $subtitle: Text('Subtitle', 'Subtitle'),
  $banner: Image('Image', { width: 1920 }, [
    { name: 'small', width: 768, height: 576 },
    { name: 'Medium', width: 970, height: 576 },
  ]),
  $page: Group({ page: Link('Pages', 'document', ['page-v2'], true, 'Reference') }, 'Pages list: 3 pages recommended (without restriction)', true, 'Pages list'),
}

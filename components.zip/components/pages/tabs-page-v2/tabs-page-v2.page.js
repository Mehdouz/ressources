import React, { useState, useEffect } from 'react'
import log from '@axacom-client/logger'
import axacomClient from '@axacom-client/clients/axacom'
import { camelCase } from 'lodash/string'
import * as components from '@axacom-client/components/organisms/Slices'
import { PageHeader, PageTitle, SubTitle, TabTitleBlock, TabLink, TabItem, Underline } from './tabs-page-v2.style'
import { sliceBlock } from '../page-v2/page-v2.page'
import RestrictionForm from '@axacom-client/components/molecules/Form/Restriction/RestrictionForm'
import FullBanner from '@axacom-client/components/organisms/FullBanner/FullBanner'
import { AnimatePresence, motion } from 'framer-motion/dist/framer-motion'
import { loadCSV } from '@axacom-client/services/chart-service'
import { addSlugifiedAnchor, getAsideGroupItems, getComponentProps } from '@axacom-client/services/component-service'
import { buildGrid } from '@axacom-server/services/grid-service'
import { getLocation } from '@axacom-client/services/window-service'
import getTableBlockProcData from '@axacom-client/components/organisms/Slices/TableBlock/getTableBlockProcData'

const variants = {
  visible: {
    y: 0,
    opacity: 1,
    transition: { duration: 0.2 },
  },
  hidden: {
    y: 30,
    opacity: 0,
  },
  exit: {
    y: 20,
    opacity: 0,
    transition: { duration: 0.2 },
  },
}
export default function TabsPageV2({ page, sectionReferrer, banner, title, subtitle }) {
  const [isAllowed, setIsAllowed] = useState(false)
  const [isHovered, setIsHovered] = useState(0)
  const [activeTab, setActiveTab] = useState(0)

  function handleItemEnter(index) {
    setIsHovered(index)
  }

  function handelItemLeave() {
    setIsHovered(activeTab)
  }

  useEffect(() => {
    const tabUrl = getLocation('hash').split('#')[1]
    const pageIndex = page.findIndex((p) => p?.slug === tabUrl)
    if (pageIndex !== -1) {
      setActiveTab(pageIndex)
    }
  }, [])

  return (
    <>
      <FullBanner title={sectionReferrer} bannerImage={banner} bannerTitle={title} bannerSubtitle={subtitle}>
        <TabTitleBlock onMouseLeave={handelItemLeave}>
          {page &&
            page.map((p, index) => (
              <TabItem key={index} $hasImage={banner?.main}>
                <TabLink
                  key={index}
                  href={`#${p?.slug}`}
                  $isActive={index === activeTab}
                  onMouseEnter={() => handleItemEnter(index)}
                  onFocus={() => handleItemEnter(index)}
                  onBlur={() => handelItemLeave(index)}
                  onClick={() => setActiveTab(index)}
                >
                  {p?.metaContent[0].title}
                  {index === isHovered || index === activeTab ? <Underline layoutId="underline" /> : null}
                </TabLink>
              </TabItem>
            ))}
        </TabTitleBlock>
      </FullBanner>
      {!isAllowed && page[activeTab]?.restriction ? (
        <RestrictionForm data={page[activeTab].page?.restriction} setIsAllowed={setIsAllowed} />
      ) : (
        <>
          <PageHeader>
            <AnimatePresence exitBeforeEnter>
              <motion.div key={activeTab} animate="visible" exit="exit" initial="hidden" variants={variants}>
                <PageTitle>{page[activeTab]?.metaContent && page[activeTab]?.metaContent[0].title}</PageTitle>
                <SubTitle>{page[activeTab]?.metaContent && page[activeTab]?.metaContent[0].summary}</SubTitle>
              </motion.div>
            </AnimatePresence>
          </PageHeader>
          <AnimatePresence exitBeforeEnter>
            <motion.div key={activeTab} animate="visible" exit="exit" initial="hidden" variants={variants}>
              <div>
                {page[activeTab]?.body &&
                  page[activeTab].body.map((slice, index) => {
                    if (slice.sliceType == 'cover') return null
                    if (slice.sliceType == 'coverTextOnly') return null
                    if (slice.sliceType == 'coverColorBackground') return null
                    if (slice.sliceType == 'contactUsBlock') return null
                    if (slice.sliceType == 'thumbnailGallery') return null
                    return sliceBlock(slice, index)
                  })}
              </div>
            </motion.div>
          </AnimatePresence>
        </>
      )}
    </>
  )
}

export const getTabsPageProcData = async ({ language, id, slug, translation, sectionReferrer }) => {
  log.debug('[Tabs-Page V2] getInitialProps')

  const document = (await axacomClient().get('/_api/documents/tabs-page-v2', { params: { language, id, slug, translation, sectionReferrer } })).data

  document.page = await Promise.all(
    document?.page?.map(async ({ page }) => {
      if (page.body) {
        // FIXME move all of this in server
        const componentsProps = await Promise.all(
          page.body.map(async (slice) => {
            const Component = components[camelCase(slice.sliceType)]
            slice = addSlugifiedAnchor(slice)
            if (slice.sliceType === 'lineChart') slice = await loadCSV(slice)
            if (slice.sliceType === 'pieChart') slice = await loadCSV(slice)
            if (slice.sliceType === 'grid' || slice.sliceType === 'thumbnailGallery') {
              slice = buildGrid(slice)
              return getComponentProps('PageV2', Component, { language }, slice)
            }
            if (slice.sliceType === 'asideGroup') {
              slice.value.items = getAsideGroupItems(slice.value.items)
              return getComponentProps('PageV2', Component, { language }, slice)
            }
            if (slice.sliceType === 'tableBlockSlice') {
              slice.value.markdown = getTableBlockProcData(slice.value.markdown)
            }
            if (slice.sliceType === 'pressReleaseList') {
              slice.value.items = (await axacomClient().get('/_api/press-release', { params: { size: 3, language } })).data
              return getComponentProps('PageV2', Component, { language }, slice)
            }
            return getComponentProps('PageV2', Component, { language }, slice.value)
          })
        )

        componentsProps.forEach((componentProps, index) => (page.body[index].value = { ...page.body[index].value, ...componentProps }))
      }

      return page
    })
  )

  return document
}

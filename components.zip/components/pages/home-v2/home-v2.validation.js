import { mandatoryFieldRule } from '../../utils/FieldValidation'

import leadersVoice from '../../organisms/LeadersVoiceCarrousel/LeadersVoiceCarrousel.validation'
import storiesPromotion from '../../organisms/Slices/StoriesPromotion/StoriesPromotion.validation'
import spotlightHome from '../../organisms/SpotlightHome/SpotlightHome.validation'
import homeIdCard from '../../organisms/Slices/HomeIdCard/HomeIdCard.validation'
import commitmentCarousel from '../../organisms/CommitmentCarousel/CommitmentCarousel.validation'
import latestPrAndNextEvents from '../../organisms/LatestPrAndNextEvents/LatestPrAndNextEvents.validation'

export default [
  ...leadersVoice,
  ...storiesPromotion,
  ...spotlightHome,
  ...homeIdCard,
  ...commitmentCarousel,
  ...latestPrAndNextEvents,
  mandatoryFieldRule({ mandatoryFields: ['publicationsTitle', 'publicationsLinkLabel', 'publicationsLink'] }),
  (document) => document.publications.length >= 2,
]

import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import liveNotifications from '../../../components/organisms/SpotlightHome/LiveNotifications.types'
import spotlightHome from '../../../components/organisms/SpotlightHome/SpotlightHome.types'
import homeIdCard from '../../../components/organisms/Slices/HomeIdCard/HomeIdCard.types'
import commitmentCarousel from '../../../components/organisms/CommitmentCarousel/CommitmentCarousel.types'
import storiesPromotion from '../../../components/organisms/Slices/StoriesPromotion/StoriesPromotion.types'
import leadersVoice from '../../../components/organisms/LeadersVoiceCarrousel/LeadersVoiceCarrousel.types'
import latestPrAndNextEvents from '../../../components/organisms/LatestPrAndNextEvents/LatestPrAndNextEvents.types'
import { getPublications } from '../../../components/organisms/Slices/Publications/Publications.types'

export default {
  ...getMetaContent(['sharingImage', 'seoDescription', 'tweet', 'title', 'summary']),
  ...liveNotifications,
  ...spotlightHome,
  ...homeIdCard,
  ...commitmentCarousel,
  ...storiesPromotion,
  ...leadersVoice,
  ...latestPrAndNextEvents,
  ...getPublications({ asSlice: false, withAnchor: false }),
}

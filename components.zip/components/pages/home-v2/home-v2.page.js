import React from 'react'
import { bool, array, string, object } from 'prop-types'
import log from '@axacom-client/logger'
import { i18n } from '@i18n-axa'
import StoriesPromotion from '@axacom-client/components/organisms/Slices/StoriesPromotion/StoriesPromotion'
import HomeIdCard from '@axacom-client/components/organisms/Slices/HomeIdCard/HomeIdCard'
import Publications from '@axacom-client/components/organisms/Slices/Publications/Publications'
import { RequirementsErrorMessage } from '@axacom-client/components/organisms/Error/Error'
import SpotlightHome from '@axacom-client/components/organisms/SpotlightHome/SpotlightHome'
import { dateTime } from '@axacom-client/services/date-service'
import LeadersVoiceCarrousel from '@axacom-client/components/organisms/LeadersVoiceCarrousel/LeadersVoiceCarrousel'
import CommitmentCarousel from '@axacom-client/components/organisms/CommitmentCarousel/CommitmentCarousel'
import LatestPrAndNextEvents from '@axacom-client/components/organisms/LatestPrAndNextEvents/LatestPrAndNextEvents'

import { getHomeV2 } from '@axacom-client/repositories/documents'
function HomeV2({
  hasMissingRequirements,
  storiesPromotion,
  liveNotificationDate,
  liveNotifications,
  spotlightHome,
  idCardBoxTitle,
  idCardBoxLinks,
  idCardSurtitle,
  idCardTitle,
  idCardLinkName,
  idCardLink,
  idCardFigures,
  commitmentCarouselSurtitle,
  commitmentCarouselTitle,
  commitmentCarouselCards,
  leadersVoiceTitle,
  leadersVoiceText,
  leadersVoiceLink,
  leadersVoiceLinkName,
  leadersVoiceLeader,
  latestPressReleasesTitle,
  latestPressReleasesLinkName,
  latestPressReleasesLink,
  nextEventsTitle,
  nextEventsLinkName,
  nextEventsLink,
  latestPressReleases,
  nextEvents,
  publicationsTitle,
  publicationsLinkLabel,
  publicationsLink,
  publications,
}) {
  if (hasMissingRequirements) {
    return <RequirementsErrorMessage />
  }

  return (
    <>
      <SpotlightHome items={spotlightHome} liveDate={liveNotificationDate} liveNotifications={liveNotifications} />
      <HomeIdCard
        idCardBoxTitle={idCardBoxTitle}
        idCardBoxLinks={idCardBoxLinks}
        idCardSurtitle={idCardSurtitle}
        idCardTitle={idCardTitle}
        idCardLinkName={idCardLinkName}
        idCardLink={idCardLink}
        idCardFigures={idCardFigures}
      />
      <CommitmentCarousel surtitle={commitmentCarouselSurtitle} title={commitmentCarouselTitle} cards={commitmentCarouselCards} />
      <StoriesPromotion storiesPromotion={storiesPromotion} />
      <LeadersVoiceCarrousel
        leadersVoiceTitle={leadersVoiceTitle}
        leadersVoiceText={leadersVoiceText}
        leadersVoiceLink={leadersVoiceLink}
        leadersVoiceLinkName={leadersVoiceLinkName}
        leadersVoiceLeader={leadersVoiceLeader}
      />
      <LatestPrAndNextEvents
        latestPressReleasesTitle={latestPressReleasesTitle}
        latestPressReleasesLinkName={latestPressReleasesLinkName}
        latestPressReleasesLink={latestPressReleasesLink}
        nextEventsTitle={nextEventsTitle}
        nextEventsLinkName={nextEventsLinkName}
        nextEventsLink={nextEventsLink}
        latestPressReleases={latestPressReleases}
        nextEvents={nextEvents}
      />
      <Publications title={publicationsTitle} linkName={publicationsLinkLabel} link={publicationsLink} publications={publications} />
    </>
  )
}

HomeV2.getInitialProps = async (context) => {
  log.debug('[HomeV2] getInitialProps')
  const language = (context.req || i18n).language
  const document = await getHomeV2({ language })

  if (document.liveNotificationDate) {
    document.liveNotificationDate = dateTime(document.liveNotificationDate, 'LL', language)
  }

  if (document.latestPressReleases) {
    document.latestPressReleases = document.latestPressReleases.map((item) => ({
      title: item.title,
      date: dateTime(item.date, 'LL', language),
      url: item.url,
    }))
  }

  if (document.nextEvents) {
    document.nextEvents = document.nextEvents.map((item) => {
      const formattedStart = dateTime(item.eventTimeStart, 'LL', language)
      const formattedEnd = dateTime(item.eventTimeEnd, 'LL', language)
      const isSameDateOrHasNoEnd = !item.eventTimeEnd || formattedStart === formattedEnd

      return {
        title: item.title,
        date: isSameDateOrHasNoEnd ? formattedStart : `${i18n.t('from.alt')} ${formattedStart} ${i18n.t('to.alt')} ${formattedEnd}`,
        url: item.url,
      }
    })
  }

  return document
}

HomeV2.propTypes = {
  liveNotificationDate: string,
  liveNotifications: array,
  hasMissingRequirements: bool,
  spotlightHome: array,
  storiesPromotion: array,
  idCardBoxTitle: string,
  idCardBoxLinks: array,
  idCardSurtitle: string,
  idCardTitle: string,
  idCardLinkName: string,
  idCardLink: object,
  idCardFigures: array,
  commitmentCarouselSurtitle: string,
  commitmentCarouselTitle: string,
  commitmentCarouselCards: array,
  leadersVoiceTitle: string,
  leadersVoiceText: string,
  leadersVoiceLink: object,
  leadersVoiceLinkName: string,
  leadersVoiceLeader: array,
  latestPressReleasesTitle: string,
  latestPressReleasesLinkName: string,
  latestPressReleasesLink: object,
  nextEventsTitle: string,
  nextEventsLinkName: string,
  nextEventsLink: object,
  latestPressReleases: array,
  nextEvents: array,
  publicationsTitle: string,
  publicationsLinkLabel: string,
  publicationsLink: object,
  publications: array,
}

export default HomeV2

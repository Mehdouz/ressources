import { Slices } from '../../../../tools/prismic/backup-types/generic-type'
import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import { Group, Link } from '../../../../tools/prismic/backup-types/generic-type'
import AllStories from '../../organisms/Slices/AllStories/AllStories.types'
import MostPopularStories from '../../organisms/Slices/MostPopularStories/MostPopularStories.types'

export default {
  ...getMetaContent(['sharingImage', 'seoDescription', 'tweet', 'title']),
  $spotlightStories: Group(
    {
      stories: Link('Stories', 'document', ['stories'], true, 'Spotlight Stories'),
    },
    'Spotlight Stories',
    true,
    'Spotlight Stories'
  ),
  $body: Slices({
    ...AllStories,
    ...MostPopularStories,
  }),
}

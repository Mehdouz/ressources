import mostPopularStories from '../../organisms/Slices/MostPopularStories/MostPopularStories.validation'
import allStories from '../../organisms/Slices/AllStories/AllStories.validation'

export default [
  (document) => {
    return document.spotlightStories.length >= 2
  },
  ...mostPopularStories,
  ...allStories,
]

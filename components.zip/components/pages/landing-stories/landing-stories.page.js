import React from 'react'
import { bool, array } from 'prop-types'
import { i18n } from '@i18n-axa'
import { camelCase } from 'lodash/string'

import log from '@axacom-client/logger'
import * as components from '@axacom-client/components/organisms/Slices'
import { RequirementsErrorMessage } from '@axacom-client/components/organisms/Error/Error'
import { MIN_MAX_MOST_POPULAR_STORIES } from '@axacom-client/components/organisms/Slices/MostPopularStories/MostPopularStories'
import { MAX_TAGS_FILTERS } from '@axacom-client/components/organisms/Slices/AllStories/AllStories'
import SpotlightStories, { MAX_SPOTLIGHT_STORIES } from '@axacom-client/components/organisms/Slices/SpotlightStories/SpotlightStories'
import { getLanding } from '@axacom-client/repositories/documents'
import { timeToSentence, truncate, wordsReadTime } from '@axacom-client/services/string-service'
import { getBodyAsString } from '@axacom-client/services/document-service'

export default function LandingStories({ body, hasMissingRequirements, spotlightStories }) {
  if (hasMissingRequirements) {
    return <RequirementsErrorMessage />
  }

  return (
    <div data-testid="LandingStories">
      <SpotlightStories spotlightStories={spotlightStories} />
      {body &&
        body.map((slice, index) => {
          const Component = components[camelCase(slice.sliceType)]
          if (Component) return <Component {...slice.value} key={index} />
        })}
    </div>
  )
}

LandingStories.getInitialProps = async (context) => {
  log.debug('[LandingStories] getInitialProps')

  const language = (context.req || i18n).language
  const document = await getLanding('landing-stories', context.query)

  // [AllStories] Get only the 12 last tags
  const sliceAllStories = document.body.find((slice) => slice.sliceType === 'allStories')

  if (sliceAllStories) {
    sliceAllStories.value.items = sliceAllStories.value.items.slice(0, MAX_TAGS_FILTERS).map((item) => {
      return { ...item.tag }
    })
  }

  // [SpotlightStories] Add readtime & format data in spotlightStoriesContent
  if (document?.spotlightStories) {
    document.spotlightStories = document.spotlightStories
      .map((item) => item.stories)
      .map((story) => {
        // Add readtime
        const wordTime = wordsReadTime(getBodyAsString(story)).wordTime
        const readTime = timeToSentence(wordTime, language, true)

        // Take title from the story itself
        const summary = story.body.filter((slice) => slice.sliceType === 'storyFirstContents').map((slice) => slice.value.summary)[0]

        return {
          readTime,
          url: story.url,
          color: story.color,
          coverImage: story.cover[0].landingImage,
          title: story.cover[0].title,
          tabletSummary: truncate(summary, 250),
          desktopSummary: truncate(summary, 160),
          largeDesktopSummary: truncate(summary, 398),
          veryLargeDesktopSummary: truncate(summary, 400),
        }
      })
      .slice(0, MAX_SPOTLIGHT_STORIES)
  }

  // [MostPopularStories] format data
  const sliceMostPopularStories = document.body.find((slice) => slice.sliceType === 'mostPopularStories')

  if (sliceMostPopularStories) {
    sliceMostPopularStories.value.stories = sliceMostPopularStories.value.items
      .slice(0, MIN_MAX_MOST_POPULAR_STORIES)
      .map((item) => item.story)
      .map((story) => {
        const summary = story.body.filter((slice) => slice.sliceType === 'storyFirstContents').map((slice) => slice.value.summary)[0]
        const wordTime = wordsReadTime(getBodyAsString(story)).wordTime
        const readTime = timeToSentence(wordTime, language, true)
        const coverImage = story.cover[0].landingImage
        const smallTruncate = truncate(summary, 250)
        const bigTruncate = truncate(summary, 300)

        return {
          coverImage: {
            main: coverImage.main,
            desktop: coverImage.views.desktop,
            mobile: coverImage.views.mobile,
          },
          title: story.cover[0].title,
          readTime: readTime,
          summary: {
            main: summary,
            mobile: smallTruncate,
            tablet: smallTruncate,
            desktop: smallTruncate,
            largeDesktop: bigTruncate,
            veryLargeDesktop: bigTruncate,
          },
          url: story.url,
        }
      })
  }

  return document
}

LandingStories.propTypes = {
  body: array,
  spotlightStories: array,
  hasMissingRequirements: bool,
}

import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import { Link } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $slug: {
    type: 'Text',
    fieldset: 'Slug',
    config: {
      placeholder: 'Slug',
      label: 'Slug',
      useAsTitle: true,
    },
  },
  ...getMetaContent(['seoDescription', 'tweet', 'sharingImage', 'sharingDescription', 'title', 'summary', 'summaryStructured']),
  $description: {
    type: 'StructuredText',
    fieldset: 'Description',
  },
  $highlighted_article: {
    type: 'Link',
    fieldset: 'Highlighted news',
    config: {
      select: 'document',
      masks: ['article-v2'],
      placeholder: 'Highlighted news',
    },
  },
  $linkTopicPage: Link('Link to the topic page'),
}

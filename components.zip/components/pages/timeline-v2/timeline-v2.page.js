import React, { useRef, useEffect } from 'react'
import { camelCase } from 'lodash/string'
import * as components from '@axacom-client/components/organisms/Slices'
import { ErrorSliceBoundary } from '@axacom-client/components/organisms/Error/Error'
import TimelineSummary from '@axacom-client/components/organisms/TimelineSummary/TimelineSummary'
import TimelineCover from '@axacom-client/components/organisms/TimelineCover/TimelineCover'
import { createContext } from 'react'
import { useContext } from 'react'
import TimelineHeader from '@axacom-client/components/organisms/TimelineHeader/TimelineHeader'
import { useScroll, useMotionValue } from 'framer-motion/dist/framer-motion'
import { TIMELINE_COLORS } from '@axacom-client/pages/[language]/timeline/[slug]'
import { slugify } from '@axacom-client/services/string-service'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Publications from '@axacom-client/components/organisms/Slices/Publications/Publications'

const TIMELINE_COLORS_HOVER = ['#e7f5ed', '#fef4e2', '#edf4fb', '#fcecf1', '#c6ebf1']

const useTimelineState = ({ periods }) => {
  const step = useMotionValue(-1)
  const y = useMotionValue(0)

  return {
    onScroll: (p) => {
      if (step.get() !== p.position) step.set(p.position)
      if (y.current !== p.y) y.set(p.y)
    },
    periods,
    colors: TIMELINE_COLORS,
    hovers: TIMELINE_COLORS_HOVER,
    step,
    y,
  }
}

const TimelineContext = createContext({})
export const useTimeline = () => useContext(TimelineContext)

export default function TimelineV2({ cover, periodCoverList, periods, publications, publicationsLinkLabel, publicationsTitle, publicationsLink }) {
  const value = useTimelineState({ periods })
  const { currentLocale } = useGlobalContext()

  const headerTitle = currentLocale === 'en' ? "Discover the major periods of AXA's adventure" : "Découvrez les grandes périodes de l'aventure AXA"

  return (
    <div data-testid="TimelineV2">
      <TimelineContext.Provider value={value}>
        <TimelineHeader title={headerTitle} />
        <TimelineCover {...cover} />
        <TimelineSummary title={headerTitle} />
        {periodCoverList.map((group, i) => {
          const id = slugify(periods[i]?.title).toLowerCase()
          return <PeriodCoverGroup data-testid={`periodCoverGroup__step${i}`} group={group} key={i} position={i} id={id} />
        })}
      </TimelineContext.Provider>
      <Publications publications={publications} linkName={publicationsLinkLabel} title={publicationsTitle} link={publicationsLink} />
    </div>
  )
}

function PeriodCoverGroup({ group, position, ...rest }) {
  const containerRef = useRef(null)
  const { onScroll } = useTimeline()

  let { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', '0.98 start'],
  })
  useEffect(() => {
    return scrollYProgress.onChange((y) => {
      onScroll({ position, y })
    })
  }, [scrollYProgress])

  return (
    <div {...rest} ref={containerRef}>
      {group.map((slice, index) => {
        const Component = components[camelCase(slice.sliceType)]
        if (Component) {
          return (
            <ErrorSliceBoundary sliceType={slice.sliceType} key={index}>
              <Component {...slice.value} />
            </ErrorSliceBoundary>
          )
        }
      })}
    </div>
  )
}

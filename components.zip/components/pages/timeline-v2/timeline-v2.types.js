import { Slices, Text } from '../../../../tools/prismic/backup-types/generic-type'
import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import linkSlice from '../../organisms/Slices/Link/Link.types'
import eventFocus from '../../organisms/Slices/EventFocus/EventFocus.types'
import yearTitle from '../../organisms/Slices/YearTitle/YearTitle.types'
import { paragraphSlice } from '../../organisms/Slices/Paragraph/Paragraph.types'
import paragraphWithVideo from '../../organisms/Slices/ParagraphWithVideo/ParagraphWithVideo.types'
import yearFocus from '../../organisms/Slices/YearFocus/YearFocus.types'
import periodCover from '../../organisms/Slices/PeriodCover/PeriodCover.types'
import timelineCover from '../../organisms/TimelineCover/TimelineCover.types'
import quote from '../../organisms/Slices/Quote/Quote.types'
import keyDates from '../../organisms/Slices/KeyDates/KeyDates.types'
import { getPublications } from '../../organisms/Slices/Publications/Publications.types'

export default {
  $slug: Text('Slug', 'Slug', true),
  ...getMetaContent(['sharingImage', 'seoDescription', 'tweet', 'title']),
  ...timelineCover,
  $body: Slices({
    ...linkSlice,
    ...eventFocus,
    ...yearTitle,
    ...paragraphSlice,
    ...paragraphWithVideo,
    ...yearFocus,
    ...periodCover,
    ...quote,
    ...keyDates,
  }),
  ...getPublications({ asSlice: false, withAnchor: false }),
}

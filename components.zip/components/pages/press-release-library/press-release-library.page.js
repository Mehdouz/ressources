import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Library from '@axacom-client/components/molecules/Library/Library'
import { LibraryContext, useLibrary } from '@axacom-client/store/LibraryContext'
import NewsletterContent from '@axacom-client/components/molecules/Library/NewsletterContent'
import { useMediaQuery } from 'react-responsive'
import { mediaQueries } from '@axacom-client/base/style/media'
import Head from 'next/head'

export default function PRLibraryPage({ title, filterTitle }) {
  const { i18n } = useGlobalContext()
  const labelOlder = i18n.t('library.older')
  const labelLatest = i18n.t('pressReleases.library.latest')

  const isMobile = useMediaQuery({ query: mediaQueries.phone })

  let years = []
  let currentYear = new Date().getFullYear()

  for (let i = 0; i < 6; i++) {
    years.push({
      value: i === 5 ? 'before_' + (currentYear - i).toString() : (currentYear - i).toString(),
      date: i === 5 ? labelOlder : (currentYear - i).toString(),
    })
  }

  const yearFilters = [
    {
      date: labelLatest,
      value: 'latest',
    },
    ...years,
  ]

  const config = {
    type: 'pressReleases',
    apiUrl: '/_api/press-releases',
    year: 'latest',
    yearFilters,
    filterLabel: filterTitle,
  }
  const defaultState = useLibrary(config)

  return (
    <>
      <Head>
        <title>{title}</title>
      </Head>
      <LibraryContext.Provider value={defaultState}>
        <Library title={title} />
        {isMobile ? <NewsletterContent /> : null}
      </LibraryContext.Provider>
    </>
  )
}

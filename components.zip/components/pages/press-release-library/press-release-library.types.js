import { Text } from '../../../../tools/prismic/backup-types/generic-type'
import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'

export default {
  ...getMetaContent(['tweet', 'sharingImage', 'seoDescription', 'sharingDescription']),
  $title: Text('Title', 'Title'),
  $filterTitle: Text('Filter Title', 'Filter Title'),
}

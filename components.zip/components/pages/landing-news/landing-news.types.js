import { Slices } from '../../../../tools/prismic/backup-types/generic-type'
import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import SpotlightNews from '../../organisms/Slices/SpotlightNews/SpotlightNews.types'
import AllArticles from '../../organisms/Slices/AllArticles/AllArticles.types'
import { getPublications } from '../../organisms/Slices/Publications/Publications.types'
import CoverWithSocialMedia from '../../organisms/Slices/CoverWithSocialMedia/CoverWithSocialMedia.types'
import PressReleaseBlock from '../../organisms/Slices/PressReleaseBlock/PressReleaseBlock.types'

export default {
  ...getMetaContent(['sharingImage', 'seoDescription', 'tweet', 'title']),
  $body: Slices({
    ...SpotlightNews,
    ...AllArticles,
    ...getPublications({ asSlice: true, withAnchor: true }),
    ...CoverWithSocialMedia,
    ...PressReleaseBlock,
  }),
}

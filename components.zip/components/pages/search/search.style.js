import media from '@axacom-client/base/style/media'
import { colors, font } from '@axacom-client/base/style/variables'
import SmartLink from '@axacom-client/components/atoms/SmartLink/SmartLink'
import styled from 'styled-components'

const legacyTypo13 = `
font-weight: 700;
text-transform: uppercase;
font-size: 13px;
letter-spacing: 0.1em;
line-height: 13px;

@media (min-width: $screen-sm-min) {
  font-size: 12px;
}

@media (min-width: $screen-lg-min) {
  font-size: 13px;
}`

export const Count = styled.div`
  color: ${colors.brandBlue};
  ${legacyTypo13}
`

export const Input = styled.input`
  font-family: ${font.fontFamilyHeading};
  font-weight: 700;
  font-size: 25px;
  text-transform: capitalize;
  margin: 32px 0;
  padding: 0;
  padding-left: 2px; // show the ticker on the left
  width: 100%;
  border: 0 none;
  line-height: 1em;
  color: ${colors.brandBlue};

  ::placeholder {
    color: ${colors.grey400};
    font-size: 25px;
  }

  &::-ms-clear {
    display: none;
  }

  ${media.tablet`
    font-size: 90px;

    ::placeholder {
      color: ${colors.grey400};
      font-size: 90px;
    }

  `}

  ${media.desktop`
    font-size: 100px;

    ::placeholder {
      color: ${colors.grey400};
      font-size: 100px;
    }

  `}
`

export const ResultInner = styled.div`
  transition: transform 0.2s ease;
  transform: translateX(0px);
  will-change: transform;
  // padding: 16px 0;
`

export const ResultWrapper = styled.div`
  padding: 32px 0;
  border-bottom: 1px solid ${colors.grayLighter};
  transition: background-color 0.2s ease;

  &:first-child {
    border-top: 1px solid ${colors.grayLighter};
  }

  &:hover,
  &:focus {
    background-color: ${colors.grayLighter};
    ${ResultInner} {
      transform: translateX(10px);
    }
  }
`

export const ResultInfo = styled.div`
  ${legacyTypo13}
  color: ${colors.brandRed};
  margin-bottom: 16px;
`

export const ResultLink = styled(SmartLink)`
  font-family: ${font.fontFamilyHeading};
  font-weight: 700;
  font-size: 22px;
  line-height: 28px;
  letter-spacing: 0.015em;
  margin-bottom: 8px;
  display: block;
  cursor: pointer;

  ${media.desktop`
    font-size: 28px;
    line-height: 34px;
  `}

  color: ${colors.textColor};
  &:hover,
  &:focus {
    color: ${colors.grey700};
  }
`

export const LinkTitle = styled.div`
  font-weight: 400;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;
  margin-bottom: 8px;
`

export const LinkItem = styled(SmartLink)`
  display: block;
  color: ${colors.brandBlue};

  margin-bottom: 8px;
  &:hover,
  &:focus,
  &:active {
    color: ${colors.axaBlue400};
  }
`

export const SearchWrapper = styled.div`
  margin-bottom: 32px;
`

export const LinkWrapper = styled.div`
  margin: 32px 0;
`

export const ResultContent = styled.div`
  font-family: ${font.fontFamilyBase};
  font-weight: 400;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;
  margin-bottom: 8px;
`

export const ResultDate = styled.div`
  font-family: ${font.fontFamilyBase};
  font-weight: 400;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.08em;
  line-height: 1.5;
  color: ${colors.grey500};
`

export default {
  EN: {
    slug_en: {
      type: 'Text',
      fieldset: 'Seo',
      config: {
        placeholder: 'Slug',
        useAsTitle: true,
      },
    },
    subtitle_en: {
      type: 'Text',
      fieldset: 'Search links',
      config: {
        label: 'Title',
      },
    },
    links_en: {
      type: 'Group',
      fieldset: 'Links',
      config: {
        fields: {
          link: {
            type: 'Link',
            config: {
              placeholder: 'link',
              select: 'document',
            },
          },
          title: {
            type: 'Text',
            config: {
              placeholder: 'link title',
              label: 'Title',
            },
          },
        },
      },
    },
  },
  FR: {
    slug_fr: {
      type: 'Text',
      fieldset: 'Seo',
      config: {
        placeholder: 'Slug',
      },
    },
    subtitle_fr: {
      type: 'Text',
      fieldset: 'Liens de recherche',
      config: {
        label: 'Titre',
      },
    },
    links_fr: {
      type: 'Group',
      fieldset: 'Liens',
      config: {
        fields: {
          link: {
            type: 'Link',
            config: {
              placeholder: 'Lien',
              select: 'document',
            },
          },
          title: {
            type: 'Text',
            config: {
              placeholder: 'Titre du lien',
              label: 'Title',
            },
          },
        },
      },
    },
  },
}

import React from 'react'
import { useRouter } from 'next/router'
import { queryTypes, useQueryState } from 'next-usequerystate'
import Pagination from '@axacom-client/components/molecules/Pagination/Pagination'
import getClient from '@axacom-client/clients/axacom'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { ShortMessage } from '@axacom-client/components/organisms/Slices/Message/Message'
import log from '@axacom-client/logger'
import { Slice } from '@axacom-client/components/organisms/SimpleSlice/SimpleSlice'
import { Count, Input, LinkWrapper, LinkItem, LinkTitle, ResultInfo, ResultInner, ResultLink, ResultWrapper, ResultContent, ResultDate, SearchWrapper } from './search.style'

import useDebounce from '@axacom-client/hooks/useDebounce'
import { getWindow } from '@axacom-client/services/window-service'
import { Skeleton, SkeletonList } from '@axacom-client/components/atoms/Skeleton/Skeleton'

function reducer(state, action) {
  let newState = { ...action }
  // the line below force the deep merge of the results
  if (action.results) newState.results = action.results
  return { ...state, ...newState }
}

function Search({ links, subtitle, slug }) {
  const {
    i18n: { t },
    currentLocale,
  } = useGlobalContext()

  const [q, setQ] = useQueryState('q', queryTypes.string.withDefault(''))
  const [currentPage, setCurrentPage] = useQueryState('page', queryTypes.integer.withDefault(1))

  const router = useRouter()
  const debouncedOnChange = useDebounce(update, 300)

  const [state, dispatch] = React.useReducer(reducer, {
    loading: true,
    pageCount: 0,
    total: 0,
    results: [],
    error: undefined,
  })

  React.useEffect(() => {
    if (q) {
      update()
    }
  }, [])

  // some easter eggs
  React.useEffect(() => {
    if (q.toLowerCase() === 'rick roll') return router.push('https://www.youtube.com/watch?v=dQw4w9WgXcQ')
    if (q.toLowerCase() === 'dealers dehors') return router.push('https://www.youtube.com/watch?v=5R5Wc-FW0uc')
  }, [q])

  async function update() {
    if (q) {
      try {
        let result = (await getClient().get('/_api/search', { cache: 'no-cache', params: { query: q, page: currentPage, locale: currentLocale, size: 10 } })).data
        dispatch({ error: undefined, loading: false, results: result?.items || [], pageCount: result?.pagination?.pageCount, total: result?.pagination?.total })
      } catch (err) {
        dispatch({ error: err, loading: false, results: [], pageCount: 0, total: 0 })
        log.error('[Search] Error during search', err)
      }
    } else {
      dispatch({ loading: false, results: [], pageCount: 0, total: 0 })
    }
  }

  const handleQueryChange = (e) => {
    setQ(e.target.value, { shallow: true })
    getWindow().scrollTo(0, 0)
    dispatch({ loading: true, error: undefined })
    if (currentPage !== 1) setCurrentPage(1, { shallow: true })
    debouncedOnChange()
  }

  const handlePaginationChange = async (index) => {
    getWindow().scrollTo(0, 0)
    dispatch({ loading: true, error: undefined })
    setCurrentPage(index, { shallow: true })
    debouncedOnChange()
  }

  let count = `${slug}...`
  if (!state.loading) count = `${state.total || 0} ${t(`search.${state.total === 1 ? 'result' : 'results'}`)}`

  return (
    <Slice>
      <Container>
        <Count data-testid="search__count">{count}</Count>
        <Input
          data-testid="search__input"
          autoFocus
          placeholder={slug}
          aria-placeholder={slug}
          type="text"
          defaultValue={q}
          onChange={handleQueryChange}
          onKeyUp={(e) => {
            // if enter key
            if (e.keyCode === 13) {
              handleQueryChange(e)
            }
          }}
        />
      </Container>
      <SearchView {...state} page={parseInt(currentPage) || 1} query={q} onPageChange={handlePaginationChange} />

      {links.length >= 0 ? <Links subtitle={subtitle} items={links} /> : null}
    </Slice>
  )
}

function SearchView({ loading, error, results, page, pageCount, onPageChange, query }) {
  const { i18n } = useGlobalContext()
  const { t } = i18n

  if (loading) return <SkeletonItems />
  if (error) return <ShortMessage title={t('search.error.title')} content={t('search.error.content')} />
  if (!loading && query && results.length === 0) return <ShortMessage title={t('search.noResults.title', { query })} content={t('search.noResults.content')} />

  if (results.length > 0) {
    return (
      <SearchWrapper data-testid="search__results">
        {/* results */}
        {results.map(({ id, title, type, summary, link, date }) => (
          <ResultItem key={id} title={title} type={type} summary={summary} link={link} date={date} />
        ))}
        {/* pagination */}
        {pageCount > 1 ? <Pagination data-testid="search__pagination" currentPage={page} totalPages={pageCount || 0} onPageChange={onPageChange} /> : null}
      </SearchWrapper>
    )
  }

  // when there is no queries yet
  return null
}

function SkeletonItems({ count = 5 }) {
  return (
    <SearchWrapper>
      <Container>
        <ResultInner>
          {Array.from({ length: count }).map((_, i) => {
            return (
              <SkeletonList key={i}>
                <Skeleton style={{ width: 120 }} />
                <Skeleton style={{ height: 32 }} />
                <Skeleton style={{ width: 160 }} />
                <Skeleton style={{ width: 80 }} />
              </SkeletonList>
            )
          })}
        </ResultInner>
      </Container>
    </SearchWrapper>
  )
}

function ResultItem({ type, title, summary, link, date }) {
  return (
    <ResultWrapper>
      <Container>
        <ResultInner>
          <ResultInfo>{type}</ResultInfo>
          <ResultLink href={link}>{title}</ResultLink>
          <ResultContent>{summary}</ResultContent>
          <ResultDate>{date}</ResultDate>
        </ResultInner>
      </Container>
    </ResultWrapper>
  )
}

function Links({ items, subtitle }) {
  return (
    <LinkWrapper>
      <Container>
        <LinkTitle>{subtitle}</LinkTitle>
        {items.map(({ link, title }) => (
          <LinkItem key={link.id} href={link.url}>
            {title}
          </LinkItem>
        ))}
      </Container>
    </LinkWrapper>
  )
}

export default Search

import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import { Group, Link, Text } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  ...getMetaContent(['tweet', 'sharingImage', 'seoDescription', 'sharingDescription']),
  $title: Text('Title', 'Title'),
  $filterTitle: Text('Filter Title', 'Filter Title'),
  link: Group({ page: Link('Link', 'document', null, null, 'Filter') }, 'Filter', true),
}

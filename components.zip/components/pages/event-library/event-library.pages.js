import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import dynamic from 'next/dynamic'
import { LibraryContext, useLibrary } from '@axacom-client/store/LibraryContext'
import Head from 'next/head'

const Library = dynamic(() => import('@axacom-client/components/molecules/Library/Library'), { ssr: false })

export default function EventLibraryPage({ title, filters, filterTitle }) {
  const { i18n } = useGlobalContext()

  const labelPast = i18n.t('events.library.past')
  const labelOlder = i18n.t('library.older')
  const labelLatest = i18n.t('events.library.latest')

  // derived years
  let years = []
  let currentYear = new Date().getFullYear()

  for (let i = 0; i < 6; i++) {
    years.push({
      value: i === 5 ? 'before_' + (currentYear - i).toString() : (currentYear - i).toString(),
      date: i === 5 ? labelOlder : (currentYear - i).toString(),
    })
  }

  const yearFilters = [
    {
      date: labelLatest,
      value: 'upcoming',
      icon: 'IconCalendar',
      alternative: true,
    },
    {
      date: labelPast,
      value: 'past',
      color: 'blue',
      alternative: true,
    },
    ...years,
  ]

  const defaultState = useLibrary({
    type: 'events',
    apiUrl: '/_api/events',
    apiUrlFilterLabel: 'audiences[audiences.audience]',
    year: 'upcoming',
    filterLabel: filterTitle,
    filters,
    yearFilters,
  })

  return (
    <>
      <Head>
        <title>{title}</title>
      </Head>
      <LibraryContext.Provider value={defaultState}>
        <Library title={title} />
      </LibraryContext.Provider>
    </>
  )
}

export default {
  $slug: {
    type: 'Text',
    fieldset: 'SEO',
    config: {
      placeholder: 'Slug',
      label: 'Slug',
      useAsTitle: true,
    },
  },
  $seoDescription: {
    type: 'Text',
    config: {
      placeholder: 'SEO Description',
      label: 'SEO Description',
    },
  },
  $tweet: {
    type: 'Text',
    fieldset: 'Social network sharing',
    config: {
      placeholder: 'Tweet',
      label: 'Tweet',
    },
  },
  $sharingImage: {
    type: 'Image',
    config: {
      placeholder: 'Sharing image',
      constraint: {
        width: 1200,
        height: 630,
      },
    },
  },
  $sharingDescription: {
    type: 'Text',
    config: {
      placeholder: 'Sharing Description',
      label: 'Sharing Description',
    },
  },
  $title: {
    type: 'Text',
    fieldset: 'Title',
    config: {
      label: 'Title',
      placeholder: 'Title',
    },
  },
  $bannerLink: {
    type: 'Link',
    fieldset: 'Banner',
    config: {
      placeholder: 'Reference',
      select: 'document',
    },
  },
  $bannerImage: {
    type: 'Image',
    config: {
      placeholder: 'Banner Image',
      constraint: {
        width: 1920,
      },
      thumbnails: [
        {
          name: 'small',
          width: 768,
          height: 432,
        },
        {
          name: 'Medium',
          width: 970,
          height: 545,
        },
      ],
    },
  },
  $bannerTitle: {
    type: 'Text',
    config: {
      label: 'Title',
      placeholder: 'Title',
    },
  },
  $bannerSubtitle: {
    type: 'Text',
    config: {
      label: 'Subtitle',
      placeholder: 'Subtitle',
    },
  },
  $bannerButtonName: {
    type: 'Text',
    fieldset: 'Banner button',
    config: {
      label: 'Button name',
      placeholder: 'Button name',
    },
  },
  $bannerButtonReference: {
    type: 'Link',
    config: {
      label: 'Button reference',
    },
  },
  $threeFiguresTitle: {
    type: 'Text',
    fieldset: 'Three Figures Block',
    config: {
      label: 'Title',
    },
  },
  $threeFiguresSubtitle: {
    type: 'Text',
    config: {
      label: 'subtitle',
    },
  },
  $threeFiguresGroup: {
    type: 'Group',
    config: {
      fields: {
        number: {
          type: 'Number',
          config: {
            label: 'Number',
            max: 999,
          },
        },
        value: {
          type: 'Text',
          config: {
            label: 'Value',
          },
        },
        title: {
          type: 'Text',
          config: {
            label: 'Title',
          },
        },
        subtitle: {
          type: 'Text',
          config: {
            label: 'Subtitle',
          },
        },
      },
    },
  },
  $threeFiguresLink: {
    type: 'Link',
    config: {
      placeholder: 'threeFigure button link',
    },
  },
  $ctaTitle: {
    type: 'Text',
    fieldset: 'CTA Group',
    config: {
      placeholder: 'CTA title',
      label: 'Title',
    },
  },
  $ctaSubTitle: {
    type: 'Text',
    config: {
      placeholder: 'CTA SubTitle',
      label: 'SubTitle',
    },
  },
  $ctaForm: {
    type: 'Select',
    config: {
      options: ['no', 'yes'],
      label: 'Form',
      placeholder: 'Yes or no',
    },
  },
  $externalCtaImage: {
    type: 'Image',
    config: {
      placeholder: 'Image',
      constraint: {
        width: 1920,
        height: 1080,
      },
      thumbnails: [
        {
          name: 'small',
          width: 768,
          height: 432,
        },
        {
          name: 'Medium',
          width: 970,
          height: 545,
        },
      ],
    },
  },
  $ctalUrl: {
    type: 'Link',
    config: {
      placeholder: 'Link',
    },
  },
  $ctaUrlTitle: {
    type: 'Text',
    config: {
      placeholder: 'Link title',
      label: 'Link title',
    },
  },
  $referenceModuleTitle: {
    type: 'Text',
    fieldset: 'Reference module',
    config: {
      label: 'Title',
    },
  },
  $referenceModuleSubtitle: {
    type: 'Text',
    config: {
      label: 'Subtitle',
    },
  },
  $referenceModule: {
    type: 'Group',
    config: {
      fields: {
        link: {
          type: 'Link',
          config: {
            placeholder: 'Link',
          },
        },
      },
    },
  },
  $corporateTitle: {
    type: 'Text',
    fieldset: 'Corporate responsibility',
    config: {
      label: 'Title',
    },
  },
  $corporateSubtitle: {
    type: 'Text',
    config: {
      label: 'Subtitle',
    },
  },
  $corporateResponsibility: {
    type: 'Group',
    config: {
      fields: {
        title: {
          type: 'Text',
          config: {
            placeholder: 'Title',
            label: 'Title',
          },
        },
        summary: {
          type: 'Text',
          config: {
            label: 'Description',
            placeholder: 'Description',
          },
        },
        buttonName: {
          type: 'Text',
          config: {
            label: 'Link name',
            placeholder: 'Link name',
          },
        },
        link: {
          type: 'Link',
          config: {
            select: 'document',
            placeholder: 'Link',
          },
        },
      },
    },
  },
  $locationsTitle: {
    type: 'Text',
    fieldset: 'Locations block',
    config: {
      label: 'Title',
    },
  },
  $locationsSubtitle: {
    type: 'Text',
    config: {
      label: 'Subtitle',
    },
  },
  $locationslink: {
    type: 'Link',
    fieldset: '',
    config: {
      placeholder: 'Choose your page',
    },
  },
  $locationslinkName: {
    type: 'Text',
    fieldset: '',
    config: {
      placeholder: 'Name your link',
      label: 'Name of your link',
    },
  },
}

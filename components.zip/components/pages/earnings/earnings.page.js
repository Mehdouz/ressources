import React, { useEffect, useState } from 'react'
import log from '@axacom-client/logger'
import { getDocumentData } from '@axacom-client/repositories/documents'
import { AnimatePresence, useScroll } from 'framer-motion/dist/framer-motion'
import EarningsTable from '@axacom-client/components/organisms/EarningsTable/EarningsTable'
import { BackToTop } from '@axacom-client/components/molecules/BackToTop/BackToTop'
import { colors } from '@axacom-client/base/style/variables'
import LightBanner from '@axacom-client/components/organisms/LightBanner/LightBanner'
import FullBanner from '@axacom-client/components/organisms/FullBanner/FullBanner'
import Paragraph from '@axacom-client/components/organisms/Slices/Paragraph/Paragraph'

export default function Earnings({ props }) {
  const [isBackToTopVisible, setIsBackToTopVisible] = useState(false)
  const { scrollY } = useScroll()

  const { bannerStyle, bannerTitle, title, bannerSubtitle, bannerImage, bannerButtonName, bannerButtonReference, presentationContent, tableResults } = props

  useEffect(() => {
    return scrollY.onChange((latest) => {
      if (latest >= 300) {
        setIsBackToTopVisible(true)
      } else {
        setIsBackToTopVisible(false)
      }
    })
  }, [scrollY])

  return (
    <>
      {bannerStyle === 'Full banner' ? (
        <FullBanner
          title={title}
          bannerTitle={bannerTitle}
          bannerSubtitle={bannerSubtitle}
          bannerButtonName={bannerButtonName}
          bannerButtonReference={bannerButtonReference}
          bannerImage={bannerImage}
        />
      ) : (
        <LightBanner title={title} bannerTitle={bannerTitle} bannerSubtitle={bannerSubtitle} />
      )}
      <Paragraph text={presentationContent} />
      <EarningsTable tableResults={tableResults} />
      <AnimatePresence>{isBackToTopVisible && <BackToTop color={colors.brandBlue} />}</AnimatePresence>
    </>
  )
}

export const getEarningsProcData = async ({ language }) => {
  log.debug('[Earnings] getInitialProps')
  const document = await getDocumentData('earnings-page', { language })

  document.tableResults = document.tableResults.map((tableResult) => {
    // Filter the yearResults object to keep only the required keys
    const filtered = Object.entries(tableResult.yearResults).filter(([key]) => {
      let str = key.substring(0, 2)
      return str === 't1' || str === 't2' || str === 't3' || str === 't4' || key === 'year' || key === 'CEOname'
    })

    // Group the filtered key-value pairs by their group key (t1, t2, t3, t4, year, or CEOname)
    const grouped = filtered.reduce((acc, [key, value]) => {
      let str = key.substring(0, 2)
      let groupKey

      if (str === 't1' || str === 't2' || str === 't3' || str === 't4') {
        groupKey = str
      } else if (key === 'year') {
        groupKey = 'year'
      } else if (key === 'CEOname') {
        groupKey = 'CEOname'
      }

      if (!acc[groupKey]) {
        acc[groupKey] = []
      }

      acc[groupKey].push([key, value])
      return acc
    }, {})

    // Process the grouped key-value pairs
    const mapped = Object.fromEntries(
      Object.entries(grouped).map(([key, value]) => {
        const newValue = value.map(([k, v]) => {
          if (k === 'year' || k === 'CEOname') {
            return [k, v]
          } else {
            return [k.substring(2), v]
          }
        })

        // Convert the array of key-value pairs back to an object
        const newObject = Object.fromEntries(newValue)

        // If the key is 'year' or 'CEOname', return only the value for that key, otherwise return the entire object
        if (key === 'year' || key === 'CEOname') {
          return [key, newObject[key]]
        } else {
          return [key, newObject]
        }
      })
    )

    return mapped
  })

  return document
}

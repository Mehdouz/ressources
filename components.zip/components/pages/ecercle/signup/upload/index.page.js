import React, { useState, useEffect } from 'react'
import { bool, object, string } from 'prop-types'
import { Col, Container, Fade, Row } from 'reactstrap'
import { ecercleApiPost } from '@axacom-client/repositories/ecercle'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import { getRouterPushParams } from '@axacom-client/services/urlResolver'
import log from '@axacom-client/logger'
import { Form as FormikForm, Formik } from 'formik'

import { ErrorHeadband, FormWrapper, Subtitle, Title, Wrapper } from './../signup.style'
import { TechnicalError } from '@axacom-client/domains/errors'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import { colors } from '@axacom-client/base/style/variables'
import { getInitialValues } from '@axacom-client/services/form-service'
import { buildSchema } from '@axacom-client/services/validation-service'
import { Justificatif, Submit } from '@axacom-client/components/atoms/FormFields/FormFields'
import message from '@axacom-client/components/pages/ecercle/signup/signup.18n'

import { getWindowProp, setWindowProp } from '@axacom-client/services/window-service'

let timeoutDuration = 3600 * 12 * 1000

const UploadForm = ({ email, token }) => {
  const { currentLocale, i18n, Router } = useGlobalContext()
  const [error, setError] = useState(false)
  const formFields = { justificatif: { required: true } }
  const initialValues = getInitialValues(formFields)
  const formSchema = buildSchema(formFields, currentLocale)

  useEffect(() => {
    setWindowProp('winReload', getWindowProp('winReload') || (() => getWindowProp('location').reload()))
    const timer = setTimeout(() => getWindowProp('winReload')(), timeoutDuration)
    return () => clearTimeout(timer)
  }, [])

  const handleSubmit = async (values) => {
    try {
      // eslint-disable-next-line no-undef
      const formData = new FormData()
      formData.append('justificatif', values.justificatif)
      formData.append('email', email)
      formData.append('token', token)
      await ecercleApiPost('/signup/upload', formData, { headers: { 'content-type': 'multipart/form-data' } })

      const [pathname, as] = getRouterPushParams('signup-upload-confirmation', currentLocale)
      log.info('[Upload] successful, redirecting to confirmation', { pathname, as })
      Router.push(pathname, as).catch((e) => log.error('[Router] cannot redirect to confirmation page', e))
    } catch (e) {
      setError((message[e.message]?.text || message.somethingWrong.text)[currentLocale])
      log.error('[Upload] error: ', e)
      throw new TechnicalError()
    }
  }

  return (
    <Wrapper>
      <Container style={{ marginTop: '24px' }}>
        {error && (
          <Fade in={!!error}>
            <Row fluid="true">
              <Col>
                <ErrorHeadband className="error">
                  <Container>
                    <Icon name="IconFilledAlert" width={14} color={colors.textColor} style={{ float: 'left', marginRight: '2px', marginTop: '1px' }} /> {error}
                  </Container>
                </ErrorHeadband>
              </Col>
            </Row>
          </Fade>
        )}
        <Row>
          <Col sm={{ size: 10, offset: 1 }}>
            <FormWrapper>
              <Row>
                <Col sm={{ size: 10, offset: 1 }}>
                  <Title data-testid="step1_title">{i18n.t('shareholders-circle:uploadTitle')}</Title>
                  <Subtitle data-testid="step1_subtitle">{i18n.t('shareholders-circle:uploadSubtitle')}</Subtitle>
                </Col>
              </Row>
              <Row>
                <Col sm={{ size: 10, offset: 1 }}>
                  <Formik
                    initialValues={initialValues}
                    initialErrors={formSchema.isValidSync(initialValues)}
                    validationSchema={formSchema}
                    validateOnBlur={true}
                    validateOnChange={true}
                    onSubmit={handleSubmit}
                  >
                    {({ errors, touched, handleChange, handleBlur, isSubmitting }) => {
                      return (
                        <FormikForm>
                          <Row>
                            <Col sm={{ size: 12 }}>
                              <Justificatif onChange={handleChange} onBlur={handleBlur} errors={errors} touched={touched} required={true} />
                            </Col>
                          </Row>
                          <Row>
                            <Submit
                              label={i18n.t('form.contact.send')}
                              ariaLabel={i18n.t('form.contact.send')}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              errors={errors}
                              touched={touched}
                              disabled={isSubmitting}
                            />
                          </Row>
                        </FormikForm>
                      )
                    }}
                  </Formik>
                </Col>
              </Row>
            </FormWrapper>
          </Col>
        </Row>
      </Container>
    </Wrapper>
  )
}

export default UploadForm

UploadForm.propTypes = {
  isVisible: bool,
  email: string,
  token: string,
  defaultValue: object,
}

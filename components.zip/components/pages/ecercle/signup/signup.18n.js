import errors from '@axacom-client/components/pages/errors/errors.i18n'

export default {
  ...errors,
  userExist: {
    text: {
      en: 'An account is already registered with this email address',
      fr: 'Un compte est déjà enregistré avec cette adresse mail',
    },
  },
}

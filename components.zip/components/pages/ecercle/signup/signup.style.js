import styled from 'styled-components'
import Button from '../../../atoms/Button/Button'
import { Typo14, Typo16, Typo18, Typo36 } from '../../../../base/style/typoStyle/typoStyle'
import { colors } from '../../../../base/style/variables'
import { FormWrapper, Wrapper } from '../ecercle.styles'
import { getSpacing } from '@axacom-client/base/style/spacing'

const Title = styled.div`
  ${Typo36}
  margin-bottom: 24px;
`

const Subtitle = styled.div`
  ${Typo18}
  margin-top: 8px;
  margin-bottom: 24px;
`
const ButtonWrapper = styled.div`
  text-align: center;
`

const ErrorHeadband = styled.div`
  ${Typo16}
  background: ${colors.redAlert};
  color: ${colors.textColor};
  width: 100vw;
  position: relative;
  margin-left: -50vw;
  left: 50%;
  padding-bottom: ${getSpacing(2)} !important;
  padding-top: ${getSpacing(2)} !important;
  margin-bottom: ${getSpacing(4)} !important;
  text-align: left;

  svg,
  p {
    display: inline-flex;
  }
`

const ButtonForm = styled(Button)`
  margin-top: 32px;
  width: 100%;
`
const PreviousStepLink = styled.div`
  color: ${colors.creditColor};
  ${Typo14}
  text-transform: uppercase;
  font-weight: bold;
  display: inline-block;
`
export { ButtonForm, ButtonWrapper, FormWrapper, Wrapper, Subtitle, Title, PreviousStepLink, ErrorHeadband }

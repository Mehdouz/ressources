export const formStep1 = {
  gender: {
    required: true,
  },
  lastName: {
    required: true,
    maximumLength: 50,
    alphaSpecial: true,
  },
  firstName: {
    required: true,
    maximumLength: 50,
    alphaSpecial: true,
  },
  birthday: {
    required: true,
    dateValidation: true,
    is18: true,
  },
  shareholderType: {
    required: true,
    defaultValue: 'employeeShareholder',
  },
}

export const formStep2 = {
  address: {
    required: true,
    maximumLength: 96,
  },
  additionalAddress1: {
    required: false,
    maximumLength: 96,
  },
  additionalAddress2: {
    required: false,
    maximumLength: 96,
  },
  zipCode: {
    required: true,
    maximumLength: 50,
    alphaNumber: true,
  },
  city: {
    required: true,
    maximumLength: 50,
  },
  country: {
    required: true,
  },
  phone: {
    phoneValidation: true,
  },
  additionalPhone1: {
    phoneValidation: true,
  },
}

export const formStep3 = {
  email: {
    required: true,
    maximumLength: 50,
    email: true,
  },
  emailConfirmation: {
    required: true,
    maximumLength: 50,
    emailConfirmation: true,
  },
  agreement: {
    defaultValue: false,
  },
  recaptcha: {
    required: true,
  },
}

export const fields = {
  ...formStep1,
  ...formStep2,
  ...formStep3,
}

export const dataButton = {
  stepButton: {
    en: {
      id: 'stepButton',
      label: 'Next Step',
    },
    fr: {
      id: 'stepButton',
      label: 'Étape suivante',
    },
  },
  previousButton: {
    en: {
      id: 'previousButton',
      label: 'previous step',
    },
    fr: {
      id: 'previousButton',
      label: 'étape précédente',
    },
  },
  submitButton: {
    en: {
      id: 'submitButton',
      label: 'Sign up',
    },
    fr: {
      id: 'submitButton',
      label: "S'inscrire",
    },
  },
}

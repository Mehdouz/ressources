import React, { useState } from 'react'
import { object, string } from 'prop-types'
import { Col, Container, Fade, Row } from 'reactstrap'
import { Form, Formik } from 'formik'
import { getInitialValues } from '@axacom-client/services/form-service'
import { buildSchema } from '@axacom-client/services/validation-service'
import { MinTablet, Mobile } from '@axacom-client/components/utils/Responsive'
import { colors } from '@axacom-client/base/style/variables'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import {
  AdditionalAddress,
  AdditionalPhone,
  Address,
  Agreement,
  BirthdayField,
  City,
  Country,
  Email,
  EmailConfirmation,
  FirstName,
  Gender,
  LastName,
  Phone,
  RecaptchaField,
  ShareholderType,
  TextContent,
  ZipCode,
} from '@axacom-client/components/atoms/FormFields/FormFields'
import Stepper from '@axacom-client/components/molecules/Stepper/Stepper'
import Icon from '@axacom-client/components/atoms/Icon/Icon'
import message from './signup.18n'
import { dataButton, fields, formStep1, formStep2, formStep3 } from './signup.conf'
import { ButtonForm, ButtonWrapper, ErrorHeadband, FormWrapper, PreviousStepLink, Subtitle, Title, Wrapper } from './signup.style'
import { ecercleApiPost } from '@axacom-client/repositories/ecercle'
import { getSpacing } from '@axacom-client/base/style/spacing'
import { getRouterPushParams } from '@axacom-client/services/urlResolver'
import Tabs, { TabPanel } from '@axacom-client/components/molecules/Tabs/Tabs'
import log from '@axacom-client/logger'

export default function Signup({ countries }) {
  const { currentLocale, i18n, Router } = useGlobalContext()
  const [error, setError] = useState(false)
  const [activeTab, setActiveTab] = useState(1)
  const initialValues = getInitialValues(fields)
  const signUpSchema = buildSchema(fields, currentLocale)

  const handleSubmit = async (values, { setSubmitting }) => {
    setSubmitting(true) // TODO: fix it, formik is supposed to do it by himself
    try {
      log.info('[Signup] saving user', values)
      await ecercleApiPost('/signup', values)
      const [pathname, as] = getRouterPushParams('signup-confirmation', currentLocale)
      log.info('[Signup] successful, redirecting to confirmation', { pathname, as })
      Router.push(pathname, as).catch((e) => log.error('[Router] cannot redirect to confirmation page', e))
    } catch (e) {
      log.error('[Signup] error: ', e)
      setSubmitting(false)
      return setError((message[e.message]?.text || message.somethingWrong.text)[currentLocale])
    }
  }

  const handleTabChange = (tab) => {
    if (activeTab !== tab) {
      setActiveTab(tab)
    }
  }

  const previousStep = activeTab > 1 && (
    <Row>
      <Col sm={{ size: 5 }} md={{ size: 5 }} lg={{ size: 5 }}>
        <div style={{ marginBottom: '24px', cursor: 'pointer' }}>
          <PreviousStepLink
            onClick={() => {
              handleTabChange(activeTab - 1)
            }}
          >
            {dataButton.previousButton[currentLocale].label}
          </PreviousStepLink>
          <Icon name="IconArrowLeft" width={20} color={colors.creditColor} style={{ float: 'left', marginTop: '7px', marginRight: getSpacing(1) }} />
        </div>
      </Col>
    </Row>
  )

  return (
    <>
      <Mobile>
        <Stepper currentStep={activeTab} steps={[{ progress: 100 }, { progress: activeTab > 1 ? 100 : 0 }, { progress: activeTab > 2 ? 100 : 0 }]} />
      </Mobile>
      <Wrapper className="ecercle-signup-form">
        <Container style={{ marginTop: activeTab === 1 ? '24px' : 0 }}>
          {previousStep}
          {error && (
            <Fade in={!!error}>
              <Row fluid="true">
                <Col>
                  <ErrorHeadband className="error">
                    <Container>
                      <Icon name="IconFilledAlert" width={14} color={colors.textColor} style={{ float: 'left', marginRight: '2px', marginTop: '1px' }} /> {error}
                    </Container>
                  </ErrorHeadband>
                </Col>
              </Row>
            </Fade>
          )}
          <Row>
            <Col sm={{ size: 10, offset: 1 }}>
              <MinTablet>
                <Stepper currentStep={activeTab} steps={[{ progress: 100 }, { progress: activeTab > 1 ? 100 : 0 }, { progress: activeTab > 2 ? 100 : 0 }]} />
              </MinTablet>
              <FormWrapper>
                <Formik
                  initialValues={initialValues}
                  initialErrors={signUpSchema.isValidSync(initialValues)}
                  validationSchema={signUpSchema}
                  validateOnBlur={true}
                  validateOnChange={true}
                  onSubmit={handleSubmit}
                >
                  {({ errors, touched, handleChange, handleBlur, isSubmitting }) => {
                    function foundError(activeTab) {
                      let step

                      switch (activeTab) {
                        case 1:
                          step = formStep1
                          break
                        case 2:
                          step = formStep2
                          break
                        case 3:
                          step = formStep3
                          break
                        default:
                      }

                      // if untouched
                      if (!Object.entries(touched).length) return true
                      return Object.keys(errors).some((r) => Object.keys(step).includes(r))
                    }

                    const ButtonNext = (
                      <ButtonWrapper>
                        <ButtonForm
                          disabled={foundError(activeTab)}
                          type="button"
                          color="red"
                          ariaLabel={dataButton.stepButton[currentLocale].label}
                          data-testid={`NextStepButton_${activeTab}`}
                          size="large"
                          onClick={() => {
                            handleTabChange(activeTab + 1)
                          }}
                        >
                          {dataButton.stepButton[currentLocale].label}
                        </ButtonForm>
                      </ButtonWrapper>
                    )

                    return (
                      <Form>
                        <Tabs activeTab={activeTab.toString()}>
                          <TabPanel tabId="1">
                            <Row>
                              <Col md={{ size: 10, offset: 1 }}>
                                <Title data-testid="step1_title">{i18n.t('shareholders-circle:signupTitle')}</Title>
                                <Subtitle data-testid="step1_subtitle">{i18n.t('shareholders-circle:signupSubtitle')}</Subtitle>
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 6, offset: 1 }}>
                                <Gender required={true} onChange={handleChange} onBlur={handleBlur} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col xs={12} md={{ size: 7, offset: 1 }} lg={{ size: 5, offset: 1 }}>
                                <LastName helpText={i18n.t('shareholders-circle:signupLastNameHelpText')} required={true} errors={errors} touched={touched} />
                              </Col>
                              <Col xs={12} md={{ size: 7, offset: 1 }} lg={{ size: 5, offset: 0 }}>
                                <FirstName required={true} errors={errors} touched={touched} />
                              </Col>
                            </Row>

                            <Row>
                              <Col md={{ size: 10, offset: 1 }}>
                                <BirthdayField name="birthday" required />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 10, offset: 1 }}>
                                <ShareholderType required={true} onChange={handleChange} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 6, offset: 3 }} lg={{ size: 4, offset: 4 }}>
                                {ButtonNext}
                              </Col>
                            </Row>
                          </TabPanel>
                          <TabPanel tabId="2">
                            <Row>
                              <Col md={{ size: 10, offset: 1 }}>
                                <Title data-testid="step2_title">{i18n.t('shareholders-circle:signupTitle')}</Title>
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 7, offset: 1 }}>
                                <Address required={true} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 7, offset: 1 }}>
                                <AdditionalAddress errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 7, offset: 1 }}>
                                <AdditionalAddress number={2} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col xs={{ size: 6 }} md={{ size: 4, offset: 1 }}>
                                <ZipCode required={true} errors={errors} touched={touched} />
                              </Col>
                              <Col xs={{ size: 6 }} md={{ size: 5 }}>
                                <City required={true} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 5, offset: 1 }}>
                                <Country required={true} options={countries} onChange={handleChange} onBlur={handleBlur} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 5, offset: 1 }}>
                                <Phone errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 5, offset: 1 }}>
                                <AdditionalPhone number={1} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 6, offset: 3 }} lg={{ size: 4, offset: 4 }}>
                                {ButtonNext}
                              </Col>
                            </Row>
                          </TabPanel>
                          <TabPanel tabId="3">
                            <Row>
                              <Col md={{ size: 10, offset: 1 }}>
                                <Title data-testid="step3_title">{i18n.t('shareholders-circle:signupTitle')}</Title>
                              </Col>
                            </Row>

                            <Row>
                              <Col md={{ size: 6, offset: 1 }}>
                                <Email required={true} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 6, offset: 1 }}>
                                <EmailConfirmation required={true} errors={errors} touched={touched} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 10, offset: 1 }}>
                                <TextContent>{i18n.t('shareholders-circle-step3:signup-text-gdpr')}</TextContent>
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 8, offset: 1 }}>
                                <Agreement errors={errors} touched={touched} label={i18n.t('shareholders-circle-step3:signup-text-checkbox-gdpr')} required={true} />
                              </Col>
                            </Row>
                            <Row>
                              <Col md={{ size: 6, offset: 3 }}>
                                <RecaptchaField name="recaptcha" />
                              </Col>
                            </Row>

                            <Row>
                              <Col md={{ size: 4, offset: 4 }}>
                                <ButtonWrapper>
                                  <ButtonForm
                                    disabled={foundError(activeTab) || isSubmitting}
                                    color="red"
                                    size="large"
                                    ariaLabel={dataButton.submitButton[currentLocale].label}
                                    data-testid="SubmitSignupButton"
                                  >
                                    {dataButton.submitButton[currentLocale].label}
                                  </ButtonForm>
                                </ButtonWrapper>
                              </Col>
                            </Row>
                          </TabPanel>
                        </Tabs>
                      </Form>
                    )
                  }}
                </Formik>
              </FormWrapper>
            </Col>
          </Row>
        </Container>
      </Wrapper>
    </>
  )
}

Signup.propTypes = {
  title: string,
  countries: object,
}

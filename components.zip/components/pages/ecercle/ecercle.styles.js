import styled from 'styled-components'
import media from '../../../base/style/media'

import { colors } from '../../../base/style/variables'

const Wrapper = styled.div`
  background-color: ${colors.bgColor};
  padding: 32px 0 40px 0;
  ${media.tablet`background-color: #f1f1f1;`}
  ${media.tablet`
    padding: 24px 0;
  `}
`

const FormWrapper = styled.div`
  background-color: ${colors.bodyBg};
  margin: 0 16px;
  ${media.tablet`
    box-shadow: 0 1px 10px 0 rgba(0, 0, 0, 0.15);
    margin: 0;
    padding: 24px 0 24px 0;
  `}
`

export { Wrapper, FormWrapper }

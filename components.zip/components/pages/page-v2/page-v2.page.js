import React, { useState, useEffect } from 'react'
import { array, object, oneOfType, string } from 'prop-types'
import { camelCase } from 'lodash/string'
import * as components from '@axacom-client/components/organisms/Slices'
import { getPageV2 } from '@axacom-client/repositories/documents'
import { addSlugifiedAnchor, getAsideGroupItems, getComponentProps } from '@axacom-client/services/component-service'
import axacomClient from '@axacom-client/clients/axacom'
import log from '@axacom-client/logger'
// TODO: remove the alias axacom-server
import { buildGrid } from '@axacom-server/services/grid-service'
import { getWindow } from '@axacom-client/services/window-service'
import { loadCSV } from '@axacom-client/services/chart-service'
import { ErrorSliceBoundary } from '@axacom-client/components/organisms/Error/Error'
import { i18n } from '@i18n-axa'
import RestrictionForm from '@axacom-client/components/molecules/Form/Restriction/RestrictionForm'
import getTableBlockProcData from '@axacom-client/components/organisms/Slices/TableBlock/getTableBlockProcData'

export default function PageV2(document) {
  const [isAllowed, setIsAllowed] = useState(false)

  useEffect(() => {
    getWindow().scrollTo(0, 0)
  }, [isAllowed])

  const { body, ...props } = document

  return (
    <>
      {!isAllowed && document?.restriction ? (
        <RestrictionForm data={document.restriction} setIsAllowed={setIsAllowed} />
      ) : (
        body &&
        body.map((slice, index) => {
          return sliceBlock(slice, index, props)
        })
      )}
    </>
  )
}

export const sliceBlock = (slice, index, props) => {
  const Component = components[camelCase(slice.sliceType)]

  if (Component)
    return (
      /* preparing for react suspense */
      <ErrorSliceBoundary key={index} sliceType={slice.sliceType}>
        <Component key={index} {...slice.value} {...props} />
      </ErrorSliceBoundary>
    )
}

PageV2.getInitialProps = async (context) => {
  log.debug('[PageV2] getInitialProps')
  const language = (context.req || i18n).language
  const document = await getPageV2(context.query)

  if (document.body) {
    // FIXME move all of this in server
    const componentsProps = await Promise.all(
      document.body.map(async (slice) => {
        const Component = components[camelCase(slice.sliceType)]
        slice = addSlugifiedAnchor(slice)
        if (slice.sliceType === 'lineChart') slice = await loadCSV(slice)
        if (slice.sliceType === 'pieChart') slice = await loadCSV(slice)
        if (slice.sliceType === 'grid' || slice.sliceType === 'thumbnailGallery') {
          slice = buildGrid(slice)
          return getComponentProps('PageV2', Component, context, slice)
        }
        if (slice.sliceType === 'asideGroup') {
          slice.value.items = getAsideGroupItems(slice.value.items)
          return getComponentProps('PageV2', Component, context, slice)
        }
        if (slice.sliceType === 'tableBlockSlice') {
          slice.value.markdown = getTableBlockProcData(slice.value.markdown)
        }
        if (slice.sliceType === 'pressReleaseList') {
          slice.value.items = (await axacomClient().get('/_api/press-releases', { params: { size: 3, language } })).data
          return getComponentProps('PageV2', Component, context, slice)
        }
        return getComponentProps('PageV2', Component, context, slice.value)
      })
    )
    componentsProps.forEach((componentProps, index) => (document.body[index].value = { ...document.body[index].value, ...componentProps }))
  }
  return document
}

PageV2.propTypes = {
  title: string,
  summary_structured: array,
  video: oneOfType([string, object]),
  banner: object,
  bannerButtonName: string,
  bannerButtonLink: object,
  sectionName: string,
  currentLocale: string,
  body: array,
}

export default {
  type: 'page-v2',
  _tags: ['rédaction', 'actualites'],
  id: 'XuHkchIAACwA3m96',
  uid: null,
  slug: 'qa-landing-press',
  slug_en: 'qa-landing-press',
  slug_fr: 'qa-landing-press',
  metaContent: [
    {
      seoDescription: 'Press',
      tweet: 'Discover an entirely dedicated section to journalists on the #AXA corporate website.',
      sharingImage: {
        main: {
          dimensions: {
            width: 1200,
            height: 628,
          },
          alt: '',
          copyright: '',
          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/98b2ab644f3cccaf0f5651575f7b022d9d0686a2_170223axa_resultats-annuels238.jpeg',
        },
        views: {},
      },
      sharingDescription: 'Discover an entirely dedicated section to journalists on the #AXA corporate website.',
      title: 'Home Press',
      sectionReferrer: 'Press',
      summary:
        "This section gives you access to content and services primarily designed to meet the journalist's needs. Read our latest press releases along with exclusive interviews of our leaders.",
      summaryStructured: [
        {
          type: 'paragraph',
          text: '',
          spans: [],
        },
      ],
    },
  ],
  anchor: [],
  sectionName: 'June 3, 2020',
  body: [
    {
      sliceType: 'cover',
      sliceLabel: null,
      value: {
        items: [
          {
            bannerButtonName: 'Press release',
            bannerButtonLink: {
              type: 'press-release',
              _tags: [],
              id: 'XtZ8oxIAACsArCAY',
              uid: null,
              slug: 'decision-of-the-board-of-directors-in-respect-of-axa-dividend-proposal-for-2019',
              slug_en: 'decision-of-the-board-of-directors-in-respect-of-axa-dividend-proposal-for-2019',
              slug_fr: 'decision-du-conseil-administration-relative-au-versement-du-dividende-pour-exercice-2019',
              seoDescription:
                'Following recent communications from the European Insurance and Occupational Pensions Authority (“EIOPA”) and the Autorité de Contrôle Prudentiel et de Résolution (“ACPR”), relating to the adoption of a prudent approach towards dividend distributions during the Covid-19 pandemic, AXA’s Board of Directors, at its meeting on June 2nd, decided to reduce its dividend proposal from Euro 1.43 per share to Euro 0.73 per share.',
              tweet: 'Decision of the Board of Directors in respect of #AXA dividend proposal for 2019',
              sharingDescription: 'Decision of the Board of Directors in respect of #AXA dividend proposal for 2019',
              title: 'Decision of the Board of Directors in respect of AXA’s dividend proposal for 2019',
              date: '2020-06-03T05:00:00+0000',
              document: {
                file: {
                  name: 'AXA_PR_20200603.pdf',
                  kind: 'document',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fcc159dd2-55a7-402e-906f-2bfacb64c7b3_axa_pr_20200603.pdf',
                  size: '280143',
                },
                target: 'file',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fcc159dd2-55a7-402e-906f-2bfacb64c7b3_axa_pr_20200603.pdf',
              },
              body: [
                {
                  sliceType: 'paragraph',
                  sliceLabel: null,
                  value: [
                    {
                      text: [
                        {
                          type: 'paragraph',
                          text: 'Following recent communications from the European Insurance and Occupational Pensions Authority (“EIOPA”) and the Autorité de Contrôle Prudentiel et de Résolution (“ACPR”), relating to the adoption of a prudent approach towards dividend distributions during the Covid-19 pandemic, AXA’s Board of Directors, at its meeting on June 2nd, decided to reduce its dividend proposal from Euro 1.43 per share to Euro 0.73 per share. This proposal is subject to approval by shareholders at AXA’s Annual General Meeting on June 30, 2020. The dividend is expected to be paid on July 9, 2020 with an ex-dividend date of July 7, 2020.',
                          spans: [
                            {
                              start: 114,
                              end: 162,
                              type: 'em',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'The Board may consider proposing an additional payment to shareholders in 4Q 2020, up to Euro 0.70 per share*, as an exceptional distribution of reserves, subject to favorable market and regulatory conditions at that time. In the event that the Board decides to propose an additional payment, the proposal would then be subject to approval by shareholders at an adhoc General Meeting.',
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'long-quote',
                  sliceLabel: null,
                  value: [
                    {
                      author: {
                        type: 'person',
                        _tags: ['Finance &Strategy', 'Team'],
                        id: 'ViDH8BkAABkABS2w',
                        uid: null,
                        _meta: {
                          avatar: 'Image',
                          lastname: 'Text',
                          lastname_en: 'Text',
                          lastname_fr: 'Text',
                          firstname: 'Text',
                          firstname_en: 'Text',
                          firstname_fr: 'Text',
                          slug: 'Text',
                          slug_en: 'Text',
                          slug_fr: 'Text',
                          seoDescription: 'Text',
                          seoDescription_en: 'Text',
                          seoDescription_fr: 'Text',
                          role: 'Text',
                          role_en: 'Text',
                          role_fr: 'Text',
                          shortRole: 'Text',
                          shortRole_en: 'Text',
                          shortRole_fr: 'Text',
                          organizationLink: 'Group',
                          linkedin: 'Text',
                          linkedin_en: 'Text',
                          linkedin_fr: 'Text',
                          birthdate: 'Date',
                          nationality: 'Text',
                          nationality_en: 'Text',
                          nationality_fr: 'Text',
                          content: 'SliceZone',
                        },
                        avatar: {
                          main: {
                            dimensions: {
                              width: 100,
                              height: 100,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/4a3678db1d8bbd436739e4bbffc69bbbdd8c9661_duverne_100.jpg',
                          },
                          views: {},
                        },
                        lastname: 'Duverne',
                        firstname: 'Denis',
                        slug: 'denis-duverne',
                        slug_en: 'denis-duverne',
                        slug_fr: 'denis-duverne',
                        seoDescription: 'Biography of Denis Duverne',
                        role: 'Chairman of the Board of Directors of AXA',
                        shortRole: 'Chairman of the Board of Directors of AXA',
                        organizationLink: [
                          {
                            _meta: {
                              organizationChart: 'Link.document',
                              organizationRanking: 'Number',
                            },
                            organizationChart: {
                              id: 'Ve2VAh4AAABIP2Fd',
                              type: 'organization-chart',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            organizationRanking: 1,
                          },
                        ],
                        linkedin: 'https://www.linkedin.com/in/denis-duverne-76b03784',
                        birthdate: '1953-10-31',
                        nationality: 'French nationality',
                        content: [
                          {
                            sliceType: 'paragraph',
                            sliceLabel: null,
                            _meta: {
                              value: 'Group',
                            },
                            value: [
                              {
                                _meta: {
                                  text: 'StructuredText',
                                },
                                text: [
                                  {
                                    type: 'heading2',
                                    text: 'Directorship and number of AXA shares',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: "Appointed on April 25, 2018 - Term expires at the 2022 Shareholders' Meeting",
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'First appointment on April 29, 2010',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Number of AXA shares / ADS AXA held on December 31, 2018: 1,595,071',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading3',
                                    text: 'On December 31, 2019',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Expertise and experience',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Mr. Denis Duverne is a graduate of the École des Hautes Études Commerciales (HEC). After graduating from the École Nationale d’Administration (ENA), he started his career in 1979 at the Tax Department of the French Ministry of Finance, and after 2 years as commercial counsellor for the French Consulate General in New York (1984-1986), he became director of the Corporate Taxes Department and then responsible for tax policy within the French Ministry of Finance from 1986 to 1991. In 1991, he was appointed Corporate Secretary of Compagnie Financière IBI. In 1992, he became a member of the Executive Committee of Banque Colbert, in charge of operations. In 1995, Mr. Denis Duverne joined the AXA Group and assumed responsibility for supervision of AXA’s operations in the US and the UK and managed the reorganization of AXA companies in Belgium and the United Kingdom. From February 2003 until December 2009, Mr. Denis Duverne was the Management Board member in charge of Finance, Control and Strategy. From January 2010 until April 2010, Mr. Denis Duverne assumed broader responsibilities as Management Board member in charge of Finance, Strategy and Operations. From April 2010 to August 31, 2016, Mr. Denis Duverne was director and Deputy Chief Executive Off icer of AXA, in charge of Finance, Strategy and Operations. Mid-2014, Mr. Denis Duverne became a member of the Private Sector Advisory Group (PSAG), which brings together international leaders of the private sector whose shared goal is to help developing countries improve their corporate governance, co-founded in 1999 by the World Bank and the Organisation for Economic Cooperation and Development (OECD). Since September 1, 2016, Mr. Denis Duverne has been non-executive Chairman of the Board of Directors of AXA. Since September 2018, he has been Chairman of the Insurance Development Forum (IDF). The IDF is a public-private partnership led by the insurance industry and supported by the World Bank and the United Nations, aiming to enhance the use of insurance to build greater resilience against disasters and to help achieve the United Nations Global 2030 Agenda.',
                                    spans: [
                                      {
                                        start: 39,
                                        end: 76,
                                        type: 'em',
                                      },
                                      {
                                        start: 109,
                                        end: 142,
                                        type: 'em',
                                      },
                                    ],
                                  },
                                  {
                                    type: 'heading3',
                                    text: '',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held within the AXA Group',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Board of Directors: AXA',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman: AXA Millésimes (SAS)',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorship held outside the AXA Group',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'None',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held during the last five years',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Deputy Chief Executive Officer: AXA',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman & Chief Executive Officer: AXA America Holdings, Inc. (United States)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Board of Directors: AXA Holdings Belgium (Belgium), AXA Financial, Inc. (United States)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director or member of the Management Committee: AXA ASIA (SAS), AllianceBernstein Corporation (United States), AXA Assicurazioni S.p.A. (Italy), AXA Belgium SA (Belgium), AXA Equitable Life Insurance Company (United States), AXA Italia S.p.A. (Italy), AXA MPS Assicurazioni Danni S.p.A. (Italy), AXA MPS Assicurazioni Vita S.p.A. (Italy), AXA UK plc (United Kingdom), MONY Life Insurance Company (United States), MONY Life Insurance Company of America (United States)',
                                    spans: [],
                                  },
                                ],
                              },
                            ],
                          },
                        ],
                        url: '/en/about-us/profile/denis-duverne',
                        url_en: '/en/about-us/profile/denis-duverne',
                        url_fr: '/fr/a-propos-d-axa/profil/denis-duverne',
                        prismic: {
                          creationDate: null,
                          updateDate: '2020-05-20T15:54:20+0000',
                        },
                      },
                      quote: [
                        {
                          type: 'paragraph',
                          text: 'From the very beginning of the Covid-19 crisis, AXA’s priority has been to act responsibly towards all its stakeholders.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'AXA’s first priority has been to help its customers navigate through this crisis and to protect the safety of its employees, including guaranteeing their full employment for the duration of the confinement period. The Group also continues to support its most impacted customers by taking a range of exceptional measures beyond its contractual obligations, and the wider community by participating in national solidarity efforts including contributions to various public funds. Reflecting the strength of the Group’s balance sheet, AXA has fulfilled these undertakings without requesting any government aid.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'The Board of Directors’ decision to reduce the proposed dividend demonstrates the same sense of responsibility towards AXA’s institutional and individual shareholders, while adopting a prudent approach in the current environment.',
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'paragraph',
                  sliceLabel: null,
                  value: [
                    {
                      text: [
                        {
                          type: 'paragraph',
                          text: 'During the meeting, AXA’s management also updated the Board on its current best estimate of the impact on 2020 underlying earnings for the Group from claims related to Covid-19. These estimates add further precision to the indications already provided in the 1Q20 disclosure, notably',
                          spans: [],
                        },
                        {
                          type: 'list-item',
                          text: 'P&C: an overall claims cost of ca. Euro -1.2 billion** post-tax and net of reinsurance. Consistent with indications given in the 1Q20 disclosure, management expects the most material impacts from Business Interruption and Event Cancellation, and to a lesser extent from other lines (e.g. D&O, Liability and Travel), partly offset by reduced claims in some areas, notably from Motor.',
                          spans: [],
                        },
                        {
                          type: 'list-item',
                          text: 'Life and Health: no material deviation has been observed in current claims experience.',
                          spans: [],
                        },
                        {
                          type: 'list-item',
                          text: 'Solidarity measures: an overall impact of ca. Euro -0.3 billion** post-tax. This includes extended health and disability coverage to vulnerable customers, most notably in France.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'The estimates provided above are based on management’s current assessment and are subject to change depending on the continued evolution of the Covid-19 pandemic and its related impacts. For investment margin, unit-linked and asset management fees, no estimate is provided as the impact will depend on the evolution of financial market conditions through the remainder of the year.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: '',
                          spans: [],
                        },
                        {
                          type: 'heading6',
                          text: '*This amount will be allocated to “Other reserves” under Shareholders’ Equity in AXA Group’s HY2020 financial statements, and will continue to be deducted in AXA Group’s HY2020 Solvency II ratio.',
                          spans: [
                            {
                              start: 0,
                              end: 195,
                              type: 'em',
                            },
                          ],
                        },
                        {
                          type: 'heading6',
                          text: '**As a reminder, AXA Group’s Underlying Earnings in 2019 were Euro 6.5 billion',
                          spans: [
                            {
                              start: 0,
                              end: 78,
                              type: 'em',
                            },
                          ],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'contacts',
                  sliceLabel: null,
                  value: [
                    {
                      contact: {
                        type: 'contact',
                        _tags: [],
                        id: 'Vl7CqCAAAJEjR7_o',
                        uid: null,
                        _meta: {
                          name: 'Text',
                          name_en: 'Text',
                          name_fr: 'Text',
                          section: 'Text',
                          section_en: 'Text',
                          section_fr: 'Text',
                          phone: 'Text',
                          phone_en: 'Text',
                          phone_fr: 'Text',
                        },
                        name: 'Investor Relations team',
                        section: 'Investor Relations',
                        phone: '+33 1 40 75 48 42',
                        url: '/not-resolved',
                        url_en: '/not-resolved',
                        url_fr: '/not-resolved',
                        prismic: {
                          creationDate: null,
                          updateDate: null,
                        },
                      },
                    },
                    {
                      contact: {
                        type: 'contact',
                        _tags: ['Contact'],
                        id: 'Veh3JR4AAKAAILFL',
                        uid: null,
                        _meta: {
                          name: 'Text',
                          name_en: 'Text',
                          name_fr: 'Text',
                          section: 'Text',
                          section_en: 'Text',
                          section_fr: 'Text',
                          phone: 'Text',
                          phone_en: 'Text',
                          phone_fr: 'Text',
                        },
                        name: 'Axa Media Relations',
                        section: 'Media relations',
                        phone: '+33.1.40.75.46.68',
                        url: '/not-resolved',
                        url_en: '/not-resolved',
                        url_fr: '/not-resolved',
                        prismic: {
                          creationDate: null,
                          updateDate: null,
                        },
                      },
                    },
                  ],
                },
              ],
              url: '/en/press/press-releases/decision-of-the-board-of-directors-in-respect-of-axa-dividend-proposal-for-2019',
              url_en: '/en/press/press-releases/decision-of-the-board-of-directors-in-respect-of-axa-dividend-proposal-for-2019',
              url_fr: '/fr/presse/communiques-de-presse/decision-du-conseil-administration-relative-au-versement-du-dividende-pour-exercice-2019',
              prismic: {
                creationDate: '2020-06-03T05:00:36+0000',
                updateDate: '2020-06-03T14:10:37+0000',
              },
            },
          },
        ],
        title: 'Decision of the Board of Directors in respect of AXA’s dividend proposal',
        shortTitle: 'Decision of the Board of Directors in respect of AXA’s dividend proposal',
        subtitle:
          'From the very beginning of the Covid-19 crisis, AXA’s priority has been to act responsibly towards its employees and customers. The Board of Directors’ decision to reduce the proposed dividend demonstrates the same sense of responsibility towards AXA’s shareholders, while adopting a prudent approach in the current environment.',
        banner: {
          main: {
            dimensions: {
              width: 1920,
              height: 1280,
            },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d4e7a8f47573c9af185bc1f78f81314ccdcf26e1_thomas_buberl_press.jpg',
          },
          views: {
            medium: {
              dimensions: {
                width: 970,
                height: 576,
              },
              alt: '',
              copyright: '',
              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f6f60cf9a8663e592d06f75099921d22df444a43_thomas_buberl_press.jpg',
            },
            small: {
              dimensions: {
                width: 768,
                height: 576,
              },
              alt: '',
              copyright: '',
              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/81d2f096f57601637632c160b1d7f9997004cb2a_thomas_buberl_press.jpg',
            },
          },
        },
      },
    },
    {
      sliceType: 'spotLight',
      sliceLabel: null,
      value: {
        items: [
          {
            surtitle: 'Press release',
            date: 'April 1, 2020',
            surtitleLink: {
              type: 'repository',
              _tags: [],
              id: 'VjtzFhwAAK3xMb6G',
              uid: 'repository-press-release',
              slug: 'press-releases',
              slug_en: 'press-releases',
              slug_fr: 'communiques-de-presse',
              seoDescription: 'This section provides access to the most recent press releases issued by the AXA Group.',
              maskType: 'press-release',
              title: 'Press Releases',
              backLink: {
                type: 'page-v2',
                _tags: ['rédaction', 'actualites'],
                id: 'Xrul9BEAACoAoLul',
                uid: null,
                _meta: {
                  slug: 'Text',
                  slug_en: 'Text',
                  slug_fr: 'Text',
                  metaContent: 'Group',
                  anchor: 'Group',
                  sectionName: 'Text',
                  sectionName_en: 'Text',
                  sectionName_fr: 'Text',
                  body: 'SliceZone',
                },
                slug: 'press',
                slug_en: 'press',
                slug_fr: 'presse',
                metaContent: [
                  {
                    _meta: {
                      seoDescription: 'Text',
                      tweet: 'Text',
                      sharingImage: 'Image',
                      sharingDescription: 'Text',
                      title: 'Text',
                      sectionReferrer: 'Select',
                      summary: 'Text',
                      summaryStructured: 'StructuredText',
                    },
                    seoDescription: 'Press',
                    tweet: 'Discover an entirely dedicated section to journalists on the #AXA corporate website.',
                    sharingImage: {
                      main: {
                        dimensions: {
                          width: 1200,
                          height: 628,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/98b2ab644f3cccaf0f5651575f7b022d9d0686a2_170223axa_resultats-annuels238.jpeg',
                      },
                      views: {},
                    },
                    sharingDescription: 'Discover an entirely dedicated section to journalists on the #AXA corporate website.',
                    title: 'Home Press',
                    sectionReferrer: 'Press',
                    summary:
                      "This section gives you access to content and services primarily designed to meet the journalist's needs. Read our latest press releases along with exclusive interviews of our leaders.",
                    summaryStructured: [
                      {
                        type: 'paragraph',
                        text: '',
                        spans: [],
                      },
                    ],
                  },
                ],
                anchor: [],
                sectionName: 'June 3, 2020',
                body: [
                  {
                    sliceType: 'cover',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            bannerButtonName: 'Text',
                            bannerButtonLink: 'Link.document',
                          },
                          bannerButtonName: 'Press release',
                          bannerButtonLink: {
                            id: 'XtZ8oxIAACsArCAY',
                            type: 'press-release',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        shortTitle: 'Text',
                        subtitle: 'Text',
                        banner: 'Image',
                      },
                      title: 'Decision of the Board of Directors in respect of AXA’s dividend proposal',
                      shortTitle: 'Decision of the Board of Directors in respect of AXA’s dividend proposal',
                      subtitle:
                        'From the very beginning of the Covid-19 crisis, AXA’s priority has been to act responsibly towards its employees and customers. The Board of Directors’ decision to reduce the proposed dividend demonstrates the same sense of responsibility towards AXA’s shareholders, while adopting a prudent approach in the current environment.',
                      banner: {
                        main: {
                          dimensions: {
                            width: 1920,
                            height: 1280,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d4e7a8f47573c9af185bc1f78f81314ccdcf26e1_thomas_buberl_press.jpg',
                        },
                        views: {
                          medium: {
                            dimensions: {
                              width: 970,
                              height: 576,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f6f60cf9a8663e592d06f75099921d22df444a43_thomas_buberl_press.jpg',
                          },
                          small: {
                            dimensions: {
                              width: 768,
                              height: 576,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/81d2f096f57601637632c160b1d7f9997004cb2a_thomas_buberl_press.jpg',
                          },
                        },
                      },
                    },
                  },
                  {
                    sliceType: 'spotLight',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            surtitle: 'Text',
                            date: 'Text',
                            surtitleLink: 'Link.document',
                            title: 'Text',
                            titleLink: 'Link.document',
                            image: 'Image',
                          },
                          surtitle: 'Press release',
                          date: 'April 1, 2020',
                          surtitleLink: {
                            id: 'VjtzFhwAAK3xMb6G',
                            type: 'repository',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          title: 'AXA strengthens its commitments to tackle an unprecedented health, economic and social challenge',
                          titleLink: {
                            id: 'XoRT_xMAAC_mQJdg',
                            type: 'press-release',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          image: {
                            main: {
                              dimensions: {
                                width: 1920,
                                height: 1080,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/e50e7e8957e28501e47901c9c73123ed936b24f0_covid19.jpg',
                            },
                            views: {
                              small: {
                                dimensions: {
                                  width: 768,
                                  height: 432,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f3d28a069ff38f1784d8e1bfb8d939d348f633e6_covid19.jpg',
                              },
                              medium: {
                                dimensions: {
                                  width: 970,
                                  height: 545,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/6680193200995b13f65d9c8f130a2677d8a4b120_covid19.jpg',
                              },
                            },
                          },
                        },
                        {
                          _meta: {
                            surtitle: 'Text',
                            date: 'Text',
                            surtitleLink: 'Link.document',
                            title: 'Text',
                            titleLink: 'Link.document',
                            image: 'Image',
                          },
                          surtitle: 'Press release',
                          date: 'May 5, 2020',
                          surtitleLink: {
                            id: 'VjtzFhwAAK3xMb6G',
                            type: 'repository',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          title: '1Q20 Activity Indicators: AXA performed well in the 1Q20',
                          titleLink: {
                            id: 'XrF6sREAACcAc93j',
                            type: 'press-release',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          image: {
                            main: {
                              dimensions: {
                                width: 1920,
                                height: 1080,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/ad58ff3dc3b206894bafe9575b5cb61a2c8a8657_thomas_buberl_press.jpg',
                            },
                            views: {
                              small: {
                                dimensions: {
                                  width: 768,
                                  height: 432,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/fc897693d7a1630d778670adb143455b42d3ad51_thomas_buberl_press.jpg',
                              },
                              medium: {
                                dimensions: {
                                  width: 970,
                                  height: 545,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/bf43878a5ec4ed8eb78b29a195f23d8958fe87d4_thomas_buberl_press.jpg',
                              },
                            },
                          },
                        },
                        {
                          _meta: {
                            surtitle: 'Text',
                            date: 'Text',
                            surtitleLink: 'Link.document',
                            title: 'Text',
                            titleLink: 'Link.document',
                            image: 'Image',
                          },
                          surtitle: "Leader's voice",
                          date: 'June 10, 2020',
                          surtitleLink: {
                            id: 'Xr1JDhEAACgAqALl',
                            type: 'page-v2',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          title: '"Covid-19: a tipping point for the industry?" by Alban de Mailly Nesle, Group Chief Risk & Investment Officer',
                          titleLink: {
                            id: 'XsQ_VREAACwAxsXv',
                            type: 'article-v2',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          image: {
                            main: {
                              dimensions: {
                                width: 1920,
                                height: 1080,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/16f387436a2c4cabb34bd9edecca90b36bae3b5f_alban_1200x628.jpg',
                            },
                            views: {
                              medium: {
                                dimensions: {
                                  width: 970,
                                  height: 545,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/52c6edf34754960a8579ce88663b59315d69fdc2_alban_1200x628.jpg',
                              },
                              small: {
                                dimensions: {
                                  width: 768,
                                  height: 432,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/24f394a801e6b60d490d273028b6b3832593c170_alban_1200x628.jpg',
                              },
                            },
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        item1title: 'Text',
                        item1subtitle: 'Text',
                        item1primaryButtonName: 'Text',
                        item1primaryButtonLink: 'Link.document',
                        item1secondaryButtonName: 'Text',
                        item1secondaryButtonLink: 'Link.document',
                        item1Image: 'Image',
                      },
                      title: 'Top of mind',
                      item1title: 'AXA and Accor: offering unique medical assistance in hotels',
                      item1subtitle:
                        'AXA and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
                      item1primaryButtonName: 'Press release',
                      item1primaryButtonLink: {
                        id: 'Xr4xwhEAAC4ArAYv',
                        type: 'press-release',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      item1secondaryButtonName: 'Interview with Gilbert Chahine, CEO of AXA Partners',
                      item1secondaryButtonLink: {
                        id: 'Xr1PlREAACwAqCDD',
                        type: 'article-v2',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      item1Image: {
                        main: {
                          dimensions: {
                            width: 1920,
                            height: 1080,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/a4b1f276af4bb36df037f209a0a5bcbd42c1e7f4_eydztsux0amghms.jpg',
                        },
                        views: {
                          small: {
                            dimensions: {
                              width: 768,
                              height: 432,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/dcb56d0109655c04b4c624e8310e7b89adbde0b8_eydztsux0amghms.jpg',
                          },
                          medium: {
                            dimensions: {
                              width: 970,
                              height: 545,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/3addee3fdf6c725a19ec567b06b53b52ef6b1b38_eydztsux0amghms.jpg',
                          },
                        },
                      },
                    },
                  },
                  {
                    sliceType: 'publications',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            publication: 'Link.document',
                          },
                          publication: {
                            id: 'XL8ZPxEAACAA0FxN',
                            type: 'publication',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            publication: 'Link.document',
                          },
                          publication: {
                            id: 'XsKDLxEAAC4AvxjU',
                            type: 'publication',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            publication: 'Link.document',
                          },
                          publication: {
                            id: 'XnOiuRMAACwA9uJB',
                            type: 'publication',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            publication: 'Link.document',
                          },
                          publication: {
                            id: 'XTHfNREAACEAyaC0',
                            type: 'publication',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        link: 'Link.document',
                        linkName: 'Text',
                      },
                      title: 'Key publications',
                      link: {
                        id: 'VjtzaRwAAK3xMcBC',
                        type: 'repository',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      linkName: 'All publications',
                    },
                  },
                  {
                    sliceType: 'calendar',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            audience: 'Link.document',
                          },
                          audience: {
                            id: 'VkzBQB8AAEc90sZm',
                            type: 'audience',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            audience: 'Link.document',
                          },
                          audience: {
                            id: 'Vpz3WhsAADWYyOec',
                            type: 'audience',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        subtitleNoEvent: 'Text',
                        calendarLink: 'Link.document',
                        calendarLinkName: 'Text',
                      },
                      title: 'Upcoming events',
                      subtitleNoEvent: 'No events',
                      calendarLink: {
                        id: 'VkRz1h8AAFBAOKQy',
                        type: 'repository',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      calendarLinkName: 'All events',
                    },
                  },
                  {
                    sliceType: 'newsletterBlock',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [],
                      _meta: {
                        title: 'Text',
                        subtitle: 'Text',
                        buttonName: 'Text',
                        image: 'Image',
                      },
                      title: 'Get the latest updates',
                      subtitle: 'Subscribe to receive alerts when new items are published on this section (press release or news).',
                      buttonName: 'Subscribe',
                      image: {
                        main: {
                          dimensions: {
                            width: 600,
                            height: 600,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/bd8a639ecaac1522c43215bbe8489480753aeb3d_bg.jpg',
                        },
                        views: {
                          thumbnails: {
                            dimensions: {
                              width: 300,
                              height: 300,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d38e6cbf26a4ee409146349f91443c6a9f5a283d_bg.jpg',
                          },
                        },
                      },
                    },
                  },
                  {
                    sliceType: 'contacts',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            contact: 'Link.document',
                          },
                          contact: {
                            id: 'Xr1IAREAACkAp_4a',
                            type: 'contact',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            contact: 'Link.document',
                          },
                          contact: {
                            id: 'XlaHlxMAACoAdn52',
                            type: 'contact',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            contact: 'Link.document',
                          },
                          contact: {
                            id: 'Xle9kBMAACoAe9Ym',
                            type: 'contact',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            contact: 'Link.document',
                          },
                          contact: {
                            id: 'XsJnYREAACgAvp1-',
                            type: 'contact',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        link: 'Link.document',
                        linkName: 'Text',
                      },
                      title: 'Contacts',
                      link: {
                        id: 'WFgN3yAAANHE5JU-',
                        type: 'page-v2',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      linkName: 'Contact us',
                    },
                  },
                ],
                url: '/en/press',
                url_en: '/en/press',
                url_fr: '/fr/presse',
                prismic: {
                  creationDate: '2020-06-10T07:24:51+0000',
                  updateDate: '2020-06-10T12:48:43+0000',
                },
              },
              backLabel: 'Press',
              filtersRef: [{}],
              url: '/en/press/press-releases',
              url_en: '/en/press/press-releases',
              url_fr: '/fr/presse/communiques-de-presse',
              prismic: {
                creationDate: null,
                updateDate: '2020-06-10T07:26:17+0000',
              },
            },
            title: 'AXA strengthens its commitments to tackle an unprecedented health, economic and social challenge',
            titleLink: {
              type: 'press-release',
              _tags: [],
              id: 'XoRT_xMAAC_mQJdg',
              uid: null,
              slug: 'covid-19-axa-strengthens-its-commitments-to-tackle-an-unprecedented-health-economic-and-social-challenge',
              slug_en: 'covid-19-axa-strengthens-its-commitments-to-tackle-an-unprecedented-health-economic-and-social-challenge',
              slug_fr: 'covid-19-axa-renforce-ses-engagements-pour-repondre-a-un-defi-sanitaire-economique-et-social-inedit',
              seoDescription: 'As the COVID-19 crisis continues to spread globally, AXA today announces the strengthening of its action plan to tackle the health, economic and social emergency.',
              tweet: 'Covid-19 #AXA strengthens its commitments to tackle an unprecedented health, economic and social challenge',
              sharingDescription: 'As the COVID-19 crisis continues to spread globally, AXA today announces the strengthening of its action plan to tackle the health, economic and social emergency.',
              title: 'COVID-19: AXA strengthens its commitments to tackle an unprecedented health, economic and social challenge',
              date: '2020-04-01T13:30:00+0000',
              document: {
                file: {
                  name: '2020-04-01 - COVID-19 - AXA strengthens its commitments.pdf',
                  kind: 'document',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fead2164b-729b-444c-903e-692aeccb08be_2020-04-01+-+covid-19+-+axa+strengthens+its+commitments.pdf',
                  size: '332010',
                },
                target: 'file',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fead2164b-729b-444c-903e-692aeccb08be_2020-04-01+-+covid-19+-+axa+strengthens+its+commitments.pdf',
              },
              documentTitle: 'PDF Format',
              body: [
                {
                  sliceType: 'paragraph',
                  sliceLabel: null,
                  value: [
                    {
                      text: [
                        {
                          type: 'paragraph',
                          text: 'As the COVID-19 crisis continues to spread globally, AXA today announces the strengthening of its action plan to tackle the health, economic and social emergency.',
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'long-quote',
                  sliceLabel: null,
                  value: [
                    {
                      author: {
                        type: 'person',
                        _tags: ['Health insurance', 'Team'],
                        id: 'Vhe9iRwAABJWde4I',
                        uid: null,
                        _meta: {
                          avatar: 'Image',
                          lastname: 'Text',
                          lastname_en: 'Text',
                          lastname_fr: 'Text',
                          firstname: 'Text',
                          firstname_en: 'Text',
                          firstname_fr: 'Text',
                          slug: 'Text',
                          slug_en: 'Text',
                          slug_fr: 'Text',
                          seoDescription: 'Text',
                          seoDescription_en: 'Text',
                          seoDescription_fr: 'Text',
                          sharingImage: 'Image',
                          role: 'Text',
                          role_en: 'Text',
                          role_fr: 'Text',
                          shortRole: 'Text',
                          shortRole_en: 'Text',
                          shortRole_fr: 'Text',
                          organizationLink: 'Group',
                          twitter: 'Text',
                          twitter_en: 'Text',
                          twitter_fr: 'Text',
                          linkedin: 'Text',
                          linkedin_en: 'Text',
                          linkedin_fr: 'Text',
                          birthdate: 'Date',
                          nationality: 'Text',
                          nationality_en: 'Text',
                          nationality_fr: 'Text',
                          content: 'SliceZone',
                        },
                        avatar: {
                          main: {
                            dimensions: {
                              width: 100,
                              height: 100,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/2a6c3ce22017732579a2b6ce7cc1a5ee246e6816_thomas-buberl.png',
                          },
                          views: {},
                        },
                        lastname: 'Buberl',
                        firstname: 'Thomas',
                        slug: 'thomas-buberl',
                        slug_en: 'thomas-buberl',
                        slug_fr: 'thomas-buberl',
                        seoDescription: 'Biography of Thomas Buberl',
                        sharingImage: {
                          main: {
                            dimensions: {
                              width: 1200,
                              height: 630,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/9c25e575e30c174bc7f0850a9fb99c95f87d04c5_thomas-buberl.png',
                          },
                          views: {
                            twitter: {
                              dimensions: {
                                width: 120,
                                height: 120,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/26db25fe1a9ae123a3fc7adc244f1e38e4991bc5_thomas-buberl.png',
                            },
                            facebook: {
                              dimensions: {
                                width: 600,
                                height: 315,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f63a3b129c84789edf74f7df050d9fdb526c8c25_thomas-buberl.png',
                            },
                            linkedin: {
                              dimensions: {
                                width: 180,
                                height: 110,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/610dab8b7ac3a328408f2f13de2eafce00862b8a_thomas-buberl.png',
                            },
                          },
                        },
                        role: 'Chief Executive Officer of AXA',
                        shortRole: 'Chief Executive Officer of AXA',
                        organizationLink: [
                          {
                            _meta: {
                              organizationChart: 'Link.document',
                              organizationRanking: 'Number',
                            },
                            organizationChart: {
                              id: 'VidrvBwAAPEhicwJ',
                              type: 'organization-chart',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            organizationRanking: 1,
                          },
                          {
                            _meta: {
                              organizationChart: 'Link.document',
                              organizationRanking: 'Number',
                            },
                            organizationChart: {
                              id: 'Ve2VAh4AAABIP2Fd',
                              type: 'organization-chart',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            organizationRanking: 2,
                          },
                        ],
                        twitter: 'https://twitter.com/thomasbuberl',
                        linkedin: 'https://www.linkedin.com/in/thomas-buberl-13a30b61/?ppe=1',
                        birthdate: '1973-03-24',
                        nationality: 'German and Swiss nationalities',
                        content: [
                          {
                            sliceType: 'paragraph',
                            sliceLabel: null,
                            _meta: {
                              value: 'Group',
                            },
                            value: [
                              {
                                _meta: {
                                  text: 'StructuredText',
                                },
                                text: [
                                  {
                                    type: 'heading2',
                                    text: 'Directorship and number of AXA shares',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: "Appointed on April 25, 2018 - Term expires at the 2022 Shareholders' Meeting",
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'First appointment on September 1, 2016',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Number of AXA shares held on December 31, 2019: 320,305',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading3',
                                    text: 'On April 28, 2020',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Expertise and experience',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Mr. Thomas Buberl holds a Master of Economics degree from WHU Koblenz (Germany), a MBA from Lancaster University (UK) and a Ph.D. in Economics from the University of St Gallen (Switzerland). In 2008 he was nominated as a Young Global Leader by the World Economic Forum. From 2000 to 2005, Mr. Thomas Buberl worked at the Boston Consulting Group as a consultant for the banking & insurance sector in Germany and abroad. From 2005 to 2008, he had worked for the Winterthur Group as member of the Management Board of Winterthur in Switzerland, first as Chief Operating Officer and then as Chief Marketing and Distribution Officer. Then, he joined Zurich Financial Services where he had been Chief Executive Officer for Switzerland. From 2012 to April 2016, he was Chief Executive Officer of AXA Konzern AG (Germany). In 2012, he has been member of the AXA Executive Committee. In March 2015, he became Chief Executive Officer of the Global Business Line for the Health Business and joined the AXA Management Committee. In January 2016, Mr. Thomas Buberl was also appointed Chief Executive Officer of the global business line Life & Savings. From March 21, 2016 to August 31, 2016, Mr. Thomas Buberl was Deputy Chief Executive Officer (Directeur Général Adjoint ) of AXA. Since September 1, 2016, Mr. Thomas Buberl has been Chief Executive Officer and director of AXA.',
                                    spans: [
                                      {
                                        start: 1232,
                                        end: 1258,
                                        type: 'em',
                                      },
                                    ],
                                  },
                                  {
                                    type: 'heading3',
                                    text: '',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held within the AXA Group',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director and Chief Executive Officer: AXA',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held outside the AXA Group (1)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director or member of the Supervisory Board: Bertelsmann SE & Co. KGaA (Germany), IBM (United States)',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held during the last five years',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Management Board: AXA Konzern AG (Germany), AXA Krankenversicherung AG (Germany), AXA Lebensversicherung AG (Germany), AXA Versicherung AG (Germany), DBV Deutsche Beamtenversicherung AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Board of Directors: AXA Equitable Holdings, Inc. (United States), AXA Financial, Inc. (United States), AXA Leben AG (Switzerland), AXA Versicherungen AG (Switzerland), XL Group Ltd (Bermuda)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Supervisory Board: AXA Konzern AG (Germany), AXA Krankenversicherung AG (Germany), AXA Lebensversicherung AG (Germany), AXA Versicherung AG (Germany), Deutsche Ärzteversicherung AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Deputy Chairman of the Supervisory Board: Roland Rechtsschutz-Versicherungs-AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Managing Director and Chief Executive Officer: Vinci B.V. (the Netherlands)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director or member of the Management Committee or member of the Supervisory Board: AXA ASIA (SAS), AXA ART Versicherung AG (Germany), AXA Equitable Holdings, Inc. (United States), AXA Equitable Life Insurance Company (United States), AXA Life Insurance Co. Ltd (Japan), MONY Life Insurance Company of America (United States), Tertia GmbH (Germany).',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: '',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: "(1) Mr. Thomas Buberl requested the Board of Directors' approval before accepting new directorships in companies outside the AXA Group.",
                                    spans: [],
                                  },
                                ],
                              },
                            ],
                          },
                        ],
                        url: '/en/about-us/profile/thomas-buberl',
                        url_en: '/en/about-us/profile/thomas-buberl',
                        url_fr: '/fr/a-propos-d-axa/profil/thomas-buberl',
                        prismic: {
                          creationDate: null,
                          updateDate: '2020-05-20T15:55:56+0000',
                        },
                      },
                      quote: [
                        {
                          type: 'paragraph',
                          text: 'The world is going through a crisis that will stand in collective memory. In an unstable environment, AXA has been fully mobilized since the outbreak of the pandemic to respond to two challenges: the health emergency, by protecting its employees and clients, and the economic and social emergency, by ensuring the continuity of a business that is essential to society. In line with our mission, and consistent with the actions taken by public authorities around the world, we are announcing today new commitments to reinforce the impact of initiatives already underway',
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'paragraph',
                  sliceLabel: null,
                  value: [
                    {
                      text: [
                        {
                          type: 'list-item',
                          text: 'Responding to the economic and social emergency',
                          spans: [
                            {
                              start: 0,
                              end: 47,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'AXA’s 160,000 employees and partners have been available and fully operational, notably thanks to remote working tools, from the start of the crisis to meet client needs and continue to play their role in the economy.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Jobs maintained, without resorting to short-time working',
                          spans: [
                            {
                              start: 0,
                              end: 56,
                              type: 'em',
                            },
                            {
                              start: 0,
                              end: 56,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'AXA announces today that the crisis will have no impact on employment or on the remuneration of employees during the confinement period; AXA will not use temporary unemployment. The Group also undertakes not to defer any social security or tax payments in France during the period.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'AXA is a Group that has its social responsibility at heart and wishes the financial efforts of public authorities to be primarily directed towards the most vulnerable individuals and businesses.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Exceptional measures for our most affected customers',
                          spans: [
                            {
                              start: 0,
                              end: 52,
                              type: 'em',
                            },
                            {
                              start: 0,
                              end: 52,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'These announcements come in addition to exceptional measures that have already been taken to provide flexibility to business customers, particularly SMEs.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'In several countries, including France, the Group will continue to insure businesses even in the event of late payment due to the pandemic, for the duration of the containment period, and will ensure prompt payment to all suppliers to enable them to maintain the cash and liquidity needed to overcome the crisis.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Euro 37 million for solidarity funds',
                          spans: [
                            {
                              start: 0,
                              end: 36,
                              type: 'em',
                            },
                            {
                              start: 0,
                              end: 36,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'AXA will also be the leading contributor, with Euro 27 million, to the solidarity effort coordinated by the Fédération Française de l’Assurance (FFA). In total Euro 200 million will be contributed to the solidarity fund set up by the French government for small businesses and the self-employed.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'This is in addition to AXA partner association AGIPI’s creation of the “AGIPI Covid 19 Solidarity Fund”, endowed with Euro 10 million to support clients experiencing economic difficulties.',
                          spans: [],
                        },
                        {
                          type: 'list-item',
                          text: 'Responding to the health emergency',
                          spans: [
                            {
                              start: 0,
                              end: 34,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'In response to the health emergency, as a major international healthcare company, AXA is committed to directly helping its employees and clients, while supporting medical actions in the regions in which it operates. AXA has extended coverage and services to healthcare professionals in several countries and leveraged its own medical networks and teleconsulting services to contribute to the healthcare effort. Finally, the Group has taken full action to support and compensate its customers affected by the virus.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: '2 million masks distributed as part of an emergency plan to support healthcare professionals',
                          spans: [
                            {
                              start: 0,
                              end: 92,
                              type: 'em',
                            },
                            {
                              start: 0,
                              end: 92,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'To strengthen its support for healthcare professionals on the frontline against the virus, AXA announced today that it will provide 2 million masks to help healthcare workers. The first 350,000, which will be sent out in the coming days, and distributed to French hospitals, are much-needed FFP2 masks. AXA France has set up psychological support resources for healthcare workers.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Support will also be provided to the AP-HP (Assistance Publique-Hôpitaux de Paris), the public hospital system of the city of Paris and the Ile-de-France region. AXA will donate 20,000 meals to the AP-HP care community for lunch or dinner at home.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'These solidarity measures for health professionals come in addition to donations already made to hospitals and intensive care units in several countries. AXA is also supporting intensive care units through a partnership with the 101 Fund, a network of 1200 intensive care centers in over 60 countries, that aims to share real-time information from each unit to accelerate the improvement of therapeutic protocols. This funding will also make it possible to set up accelerated training for caregivers in order to increase the staffing capacity of these units.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Euro 5 million to fund research on infectious diseases, including COVID-19',
                          spans: [
                            {
                              start: 0,
                              end: 74,
                              type: 'em',
                            },
                            {
                              start: 0,
                              end: 74,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'Finally, AXA Research Fund, which has made a steadfast commitment over the years to support research on infectious diseases and pandemics (35 projects from leading institutions worldwide for a total of Euro 7.4 million), has decided to mobilize an additional Euro 5 million for the development of responses to infectious diseases and COVID-19, including the implementation of post-crisis solutions.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: "AXA also supports the creation of the Institut Pasteur's COVID-19 Task Force and the OpenCOVID-19 initiative launched by Just One Giant Lab (JOGL), an open-source research platform aimed at providing low-cost emergency solutions to respond to the pandemic, with a particular focus on low-income countries.",
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'long-quote',
                  sliceLabel: null,
                  value: [
                    {
                      author: {
                        type: 'person',
                        _tags: ['Health insurance', 'Team'],
                        id: 'Vhe9iRwAABJWde4I',
                        uid: null,
                        _meta: {
                          avatar: 'Image',
                          lastname: 'Text',
                          lastname_en: 'Text',
                          lastname_fr: 'Text',
                          firstname: 'Text',
                          firstname_en: 'Text',
                          firstname_fr: 'Text',
                          slug: 'Text',
                          slug_en: 'Text',
                          slug_fr: 'Text',
                          seoDescription: 'Text',
                          seoDescription_en: 'Text',
                          seoDescription_fr: 'Text',
                          sharingImage: 'Image',
                          role: 'Text',
                          role_en: 'Text',
                          role_fr: 'Text',
                          shortRole: 'Text',
                          shortRole_en: 'Text',
                          shortRole_fr: 'Text',
                          organizationLink: 'Group',
                          twitter: 'Text',
                          twitter_en: 'Text',
                          twitter_fr: 'Text',
                          linkedin: 'Text',
                          linkedin_en: 'Text',
                          linkedin_fr: 'Text',
                          birthdate: 'Date',
                          nationality: 'Text',
                          nationality_en: 'Text',
                          nationality_fr: 'Text',
                          content: 'SliceZone',
                        },
                        avatar: {
                          main: {
                            dimensions: {
                              width: 100,
                              height: 100,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/2a6c3ce22017732579a2b6ce7cc1a5ee246e6816_thomas-buberl.png',
                          },
                          views: {},
                        },
                        lastname: 'Buberl',
                        firstname: 'Thomas',
                        slug: 'thomas-buberl',
                        slug_en: 'thomas-buberl',
                        slug_fr: 'thomas-buberl',
                        seoDescription: 'Biography of Thomas Buberl',
                        sharingImage: {
                          main: {
                            dimensions: {
                              width: 1200,
                              height: 630,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/9c25e575e30c174bc7f0850a9fb99c95f87d04c5_thomas-buberl.png',
                          },
                          views: {
                            twitter: {
                              dimensions: {
                                width: 120,
                                height: 120,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/26db25fe1a9ae123a3fc7adc244f1e38e4991bc5_thomas-buberl.png',
                            },
                            facebook: {
                              dimensions: {
                                width: 600,
                                height: 315,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f63a3b129c84789edf74f7df050d9fdb526c8c25_thomas-buberl.png',
                            },
                            linkedin: {
                              dimensions: {
                                width: 180,
                                height: 110,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/610dab8b7ac3a328408f2f13de2eafce00862b8a_thomas-buberl.png',
                            },
                          },
                        },
                        role: 'Chief Executive Officer of AXA',
                        shortRole: 'Chief Executive Officer of AXA',
                        organizationLink: [
                          {
                            _meta: {
                              organizationChart: 'Link.document',
                              organizationRanking: 'Number',
                            },
                            organizationChart: {
                              id: 'VidrvBwAAPEhicwJ',
                              type: 'organization-chart',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            organizationRanking: 1,
                          },
                          {
                            _meta: {
                              organizationChart: 'Link.document',
                              organizationRanking: 'Number',
                            },
                            organizationChart: {
                              id: 'Ve2VAh4AAABIP2Fd',
                              type: 'organization-chart',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            organizationRanking: 2,
                          },
                        ],
                        twitter: 'https://twitter.com/thomasbuberl',
                        linkedin: 'https://www.linkedin.com/in/thomas-buberl-13a30b61/?ppe=1',
                        birthdate: '1973-03-24',
                        nationality: 'German and Swiss nationalities',
                        content: [
                          {
                            sliceType: 'paragraph',
                            sliceLabel: null,
                            _meta: {
                              value: 'Group',
                            },
                            value: [
                              {
                                _meta: {
                                  text: 'StructuredText',
                                },
                                text: [
                                  {
                                    type: 'heading2',
                                    text: 'Directorship and number of AXA shares',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: "Appointed on April 25, 2018 - Term expires at the 2022 Shareholders' Meeting",
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'First appointment on September 1, 2016',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Number of AXA shares held on December 31, 2019: 320,305',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading3',
                                    text: 'On April 28, 2020',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Expertise and experience',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Mr. Thomas Buberl holds a Master of Economics degree from WHU Koblenz (Germany), a MBA from Lancaster University (UK) and a Ph.D. in Economics from the University of St Gallen (Switzerland). In 2008 he was nominated as a Young Global Leader by the World Economic Forum. From 2000 to 2005, Mr. Thomas Buberl worked at the Boston Consulting Group as a consultant for the banking & insurance sector in Germany and abroad. From 2005 to 2008, he had worked for the Winterthur Group as member of the Management Board of Winterthur in Switzerland, first as Chief Operating Officer and then as Chief Marketing and Distribution Officer. Then, he joined Zurich Financial Services where he had been Chief Executive Officer for Switzerland. From 2012 to April 2016, he was Chief Executive Officer of AXA Konzern AG (Germany). In 2012, he has been member of the AXA Executive Committee. In March 2015, he became Chief Executive Officer of the Global Business Line for the Health Business and joined the AXA Management Committee. In January 2016, Mr. Thomas Buberl was also appointed Chief Executive Officer of the global business line Life & Savings. From March 21, 2016 to August 31, 2016, Mr. Thomas Buberl was Deputy Chief Executive Officer (Directeur Général Adjoint ) of AXA. Since September 1, 2016, Mr. Thomas Buberl has been Chief Executive Officer and director of AXA.',
                                    spans: [
                                      {
                                        start: 1232,
                                        end: 1258,
                                        type: 'em',
                                      },
                                    ],
                                  },
                                  {
                                    type: 'heading3',
                                    text: '',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held within the AXA Group',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director and Chief Executive Officer: AXA',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held outside the AXA Group (1)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director or member of the Supervisory Board: Bertelsmann SE & Co. KGaA (Germany), IBM (United States)',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held during the last five years',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Management Board: AXA Konzern AG (Germany), AXA Krankenversicherung AG (Germany), AXA Lebensversicherung AG (Germany), AXA Versicherung AG (Germany), DBV Deutsche Beamtenversicherung AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Board of Directors: AXA Equitable Holdings, Inc. (United States), AXA Financial, Inc. (United States), AXA Leben AG (Switzerland), AXA Versicherungen AG (Switzerland), XL Group Ltd (Bermuda)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Supervisory Board: AXA Konzern AG (Germany), AXA Krankenversicherung AG (Germany), AXA Lebensversicherung AG (Germany), AXA Versicherung AG (Germany), Deutsche Ärzteversicherung AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Deputy Chairman of the Supervisory Board: Roland Rechtsschutz-Versicherungs-AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Managing Director and Chief Executive Officer: Vinci B.V. (the Netherlands)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director or member of the Management Committee or member of the Supervisory Board: AXA ASIA (SAS), AXA ART Versicherung AG (Germany), AXA Equitable Holdings, Inc. (United States), AXA Equitable Life Insurance Company (United States), AXA Life Insurance Co. Ltd (Japan), MONY Life Insurance Company of America (United States), Tertia GmbH (Germany).',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: '',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: "(1) Mr. Thomas Buberl requested the Board of Directors' approval before accepting new directorships in companies outside the AXA Group.",
                                    spans: [],
                                  },
                                ],
                              },
                            ],
                          },
                        ],
                        url: '/en/about-us/profile/thomas-buberl',
                        url_en: '/en/about-us/profile/thomas-buberl',
                        url_fr: '/fr/a-propos-d-axa/profil/thomas-buberl',
                        prismic: {
                          creationDate: null,
                          updateDate: '2020-05-20T15:55:56+0000',
                        },
                      },
                      quote: [
                        {
                          type: 'paragraph',
                          text: 'I would like to thank all of our employees and partners who, thanks to their actions and commitments, enable AXA to fulfill all of its operations in an unprecedented context and to provide valuable assistance to those who are fighting the virus on the frontline. More than ever, this crisis confirms what the Group has always worked for: protecting what matters most to society',
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'contacts',
                  sliceLabel: null,
                  value: [
                    {
                      contact: {
                        type: 'contact',
                        _tags: [],
                        id: 'Vl7CqCAAAJEjR7_o',
                        uid: null,
                        _meta: {
                          name: 'Text',
                          name_en: 'Text',
                          name_fr: 'Text',
                          section: 'Text',
                          section_en: 'Text',
                          section_fr: 'Text',
                          phone: 'Text',
                          phone_en: 'Text',
                          phone_fr: 'Text',
                        },
                        name: 'Investor Relations team',
                        section: 'Investor Relations',
                        phone: '+33 1 40 75 48 42',
                        url: '/not-resolved',
                        url_en: '/not-resolved',
                        url_fr: '/not-resolved',
                        prismic: {
                          creationDate: null,
                          updateDate: null,
                        },
                      },
                    },
                    {
                      contact: {
                        type: 'contact',
                        _tags: ['Contact'],
                        id: 'Veh3JR4AAKAAILFL',
                        uid: null,
                        _meta: {
                          name: 'Text',
                          name_en: 'Text',
                          name_fr: 'Text',
                          section: 'Text',
                          section_en: 'Text',
                          section_fr: 'Text',
                          phone: 'Text',
                          phone_en: 'Text',
                          phone_fr: 'Text',
                        },
                        name: 'Axa Media Relations',
                        section: 'Media relations',
                        phone: '+33.1.40.75.46.68',
                        url: '/not-resolved',
                        url_en: '/not-resolved',
                        url_fr: '/not-resolved',
                        prismic: {
                          creationDate: null,
                          updateDate: null,
                        },
                      },
                    },
                  ],
                },
              ],
              url: '/en/press/press-releases/covid-19-axa-strengthens-its-commitments-to-tackle-an-unprecedented-health-economic-and-social-challenge',
              url_en: '/en/press/press-releases/covid-19-axa-strengthens-its-commitments-to-tackle-an-unprecedented-health-economic-and-social-challenge',
              url_fr: '/fr/presse/communiques-de-presse/covid-19-axa-renforce-ses-engagements-pour-repondre-a-un-defi-sanitaire-economique-et-social-inedit',
              prismic: {
                creationDate: '2020-04-01T13:30:20+0000',
                updateDate: '2020-04-01T14:19:07+0000',
              },
            },
            image: {
              main: {
                dimensions: {
                  width: 1920,
                  height: 1080,
                },
                alt: '',
                copyright: '',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/e50e7e8957e28501e47901c9c73123ed936b24f0_covid19.jpg',
              },
              views: {
                small: {
                  dimensions: {
                    width: 768,
                    height: 432,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f3d28a069ff38f1784d8e1bfb8d939d348f633e6_covid19.jpg',
                },
                medium: {
                  dimensions: {
                    width: 970,
                    height: 545,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/6680193200995b13f65d9c8f130a2677d8a4b120_covid19.jpg',
                },
              },
            },
          },
          {
            surtitle: 'Press release',
            date: 'May 5, 2020',
            surtitleLink: {
              type: 'repository',
              _tags: [],
              id: 'VjtzFhwAAK3xMb6G',
              uid: 'repository-press-release',
              slug: 'press-releases',
              slug_en: 'press-releases',
              slug_fr: 'communiques-de-presse',
              seoDescription: 'This section provides access to the most recent press releases issued by the AXA Group.',
              maskType: 'press-release',
              title: 'Press Releases',
              backLink: {
                type: 'page-v2',
                _tags: ['rédaction', 'actualites'],
                id: 'Xrul9BEAACoAoLul',
                uid: null,
                _meta: {
                  slug: 'Text',
                  slug_en: 'Text',
                  slug_fr: 'Text',
                  metaContent: 'Group',
                  anchor: 'Group',
                  sectionName: 'Text',
                  sectionName_en: 'Text',
                  sectionName_fr: 'Text',
                  body: 'SliceZone',
                },
                slug: 'press',
                slug_en: 'press',
                slug_fr: 'presse',
                metaContent: [
                  {
                    _meta: {
                      seoDescription: 'Text',
                      tweet: 'Text',
                      sharingImage: 'Image',
                      sharingDescription: 'Text',
                      title: 'Text',
                      sectionReferrer: 'Select',
                      summary: 'Text',
                      summaryStructured: 'StructuredText',
                    },
                    seoDescription: 'Press',
                    tweet: 'Discover an entirely dedicated section to journalists on the #AXA corporate website.',
                    sharingImage: {
                      main: {
                        dimensions: {
                          width: 1200,
                          height: 628,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/98b2ab644f3cccaf0f5651575f7b022d9d0686a2_170223axa_resultats-annuels238.jpeg',
                      },
                      views: {},
                    },
                    sharingDescription: 'Discover an entirely dedicated section to journalists on the #AXA corporate website.',
                    title: 'Home Press',
                    sectionReferrer: 'Press',
                    summary:
                      "This section gives you access to content and services primarily designed to meet the journalist's needs. Read our latest press releases along with exclusive interviews of our leaders.",
                    summaryStructured: [
                      {
                        type: 'paragraph',
                        text: '',
                        spans: [],
                      },
                    ],
                  },
                ],
                anchor: [],
                sectionName: 'June 3, 2020',
                body: [
                  {
                    sliceType: 'cover',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            bannerButtonName: 'Text',
                            bannerButtonLink: 'Link.document',
                          },
                          bannerButtonName: 'Press release',
                          bannerButtonLink: {
                            id: 'XtZ8oxIAACsArCAY',
                            type: 'press-release',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        shortTitle: 'Text',
                        subtitle: 'Text',
                        banner: 'Image',
                      },
                      title: 'Decision of the Board of Directors in respect of AXA’s dividend proposal',
                      shortTitle: 'Decision of the Board of Directors in respect of AXA’s dividend proposal',
                      subtitle:
                        'From the very beginning of the Covid-19 crisis, AXA’s priority has been to act responsibly towards its employees and customers. The Board of Directors’ decision to reduce the proposed dividend demonstrates the same sense of responsibility towards AXA’s shareholders, while adopting a prudent approach in the current environment.',
                      banner: {
                        main: {
                          dimensions: {
                            width: 1920,
                            height: 1280,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d4e7a8f47573c9af185bc1f78f81314ccdcf26e1_thomas_buberl_press.jpg',
                        },
                        views: {
                          medium: {
                            dimensions: {
                              width: 970,
                              height: 576,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f6f60cf9a8663e592d06f75099921d22df444a43_thomas_buberl_press.jpg',
                          },
                          small: {
                            dimensions: {
                              width: 768,
                              height: 576,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/81d2f096f57601637632c160b1d7f9997004cb2a_thomas_buberl_press.jpg',
                          },
                        },
                      },
                    },
                  },
                  {
                    sliceType: 'spotLight',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            surtitle: 'Text',
                            date: 'Text',
                            surtitleLink: 'Link.document',
                            title: 'Text',
                            titleLink: 'Link.document',
                            image: 'Image',
                          },
                          surtitle: 'Press release',
                          date: 'April 1, 2020',
                          surtitleLink: {
                            id: 'VjtzFhwAAK3xMb6G',
                            type: 'repository',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          title: 'AXA strengthens its commitments to tackle an unprecedented health, economic and social challenge',
                          titleLink: {
                            id: 'XoRT_xMAAC_mQJdg',
                            type: 'press-release',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          image: {
                            main: {
                              dimensions: {
                                width: 1920,
                                height: 1080,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/e50e7e8957e28501e47901c9c73123ed936b24f0_covid19.jpg',
                            },
                            views: {
                              small: {
                                dimensions: {
                                  width: 768,
                                  height: 432,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f3d28a069ff38f1784d8e1bfb8d939d348f633e6_covid19.jpg',
                              },
                              medium: {
                                dimensions: {
                                  width: 970,
                                  height: 545,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/6680193200995b13f65d9c8f130a2677d8a4b120_covid19.jpg',
                              },
                            },
                          },
                        },
                        {
                          _meta: {
                            surtitle: 'Text',
                            date: 'Text',
                            surtitleLink: 'Link.document',
                            title: 'Text',
                            titleLink: 'Link.document',
                            image: 'Image',
                          },
                          surtitle: 'Press release',
                          date: 'May 5, 2020',
                          surtitleLink: {
                            id: 'VjtzFhwAAK3xMb6G',
                            type: 'repository',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          title: '1Q20 Activity Indicators: AXA performed well in the 1Q20',
                          titleLink: {
                            id: 'XrF6sREAACcAc93j',
                            type: 'press-release',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          image: {
                            main: {
                              dimensions: {
                                width: 1920,
                                height: 1080,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/ad58ff3dc3b206894bafe9575b5cb61a2c8a8657_thomas_buberl_press.jpg',
                            },
                            views: {
                              small: {
                                dimensions: {
                                  width: 768,
                                  height: 432,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/fc897693d7a1630d778670adb143455b42d3ad51_thomas_buberl_press.jpg',
                              },
                              medium: {
                                dimensions: {
                                  width: 970,
                                  height: 545,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/bf43878a5ec4ed8eb78b29a195f23d8958fe87d4_thomas_buberl_press.jpg',
                              },
                            },
                          },
                        },
                        {
                          _meta: {
                            surtitle: 'Text',
                            date: 'Text',
                            surtitleLink: 'Link.document',
                            title: 'Text',
                            titleLink: 'Link.document',
                            image: 'Image',
                          },
                          surtitle: "Leader's voice",
                          date: 'June 10, 2020',
                          surtitleLink: {
                            id: 'Xr1JDhEAACgAqALl',
                            type: 'page-v2',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          title: '"Covid-19: a tipping point for the industry?" by Alban de Mailly Nesle, Group Chief Risk & Investment Officer',
                          titleLink: {
                            id: 'XsQ_VREAACwAxsXv',
                            type: 'article-v2',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                          image: {
                            main: {
                              dimensions: {
                                width: 1920,
                                height: 1080,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/16f387436a2c4cabb34bd9edecca90b36bae3b5f_alban_1200x628.jpg',
                            },
                            views: {
                              medium: {
                                dimensions: {
                                  width: 970,
                                  height: 545,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/52c6edf34754960a8579ce88663b59315d69fdc2_alban_1200x628.jpg',
                              },
                              small: {
                                dimensions: {
                                  width: 768,
                                  height: 432,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/24f394a801e6b60d490d273028b6b3832593c170_alban_1200x628.jpg',
                              },
                            },
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        item1title: 'Text',
                        item1subtitle: 'Text',
                        item1primaryButtonName: 'Text',
                        item1primaryButtonLink: 'Link.document',
                        item1secondaryButtonName: 'Text',
                        item1secondaryButtonLink: 'Link.document',
                        item1Image: 'Image',
                      },
                      title: 'Top of mind',
                      item1title: 'AXA and Accor: offering unique medical assistance in hotels',
                      item1subtitle:
                        'AXA and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
                      item1primaryButtonName: 'Press release',
                      item1primaryButtonLink: {
                        id: 'Xr4xwhEAAC4ArAYv',
                        type: 'press-release',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      item1secondaryButtonName: 'Interview with Gilbert Chahine, CEO of AXA Partners',
                      item1secondaryButtonLink: {
                        id: 'Xr1PlREAACwAqCDD',
                        type: 'article-v2',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      item1Image: {
                        main: {
                          dimensions: {
                            width: 1920,
                            height: 1080,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/a4b1f276af4bb36df037f209a0a5bcbd42c1e7f4_eydztsux0amghms.jpg',
                        },
                        views: {
                          small: {
                            dimensions: {
                              width: 768,
                              height: 432,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/dcb56d0109655c04b4c624e8310e7b89adbde0b8_eydztsux0amghms.jpg',
                          },
                          medium: {
                            dimensions: {
                              width: 970,
                              height: 545,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/3addee3fdf6c725a19ec567b06b53b52ef6b1b38_eydztsux0amghms.jpg',
                          },
                        },
                      },
                    },
                  },
                  {
                    sliceType: 'publications',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            publication: 'Link.document',
                          },
                          publication: {
                            id: 'XL8ZPxEAACAA0FxN',
                            type: 'publication',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            publication: 'Link.document',
                          },
                          publication: {
                            id: 'XsKDLxEAAC4AvxjU',
                            type: 'publication',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            publication: 'Link.document',
                          },
                          publication: {
                            id: 'XnOiuRMAACwA9uJB',
                            type: 'publication',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            publication: 'Link.document',
                          },
                          publication: {
                            id: 'XTHfNREAACEAyaC0',
                            type: 'publication',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        link: 'Link.document',
                        linkName: 'Text',
                      },
                      title: 'Key publications',
                      link: {
                        id: 'VjtzaRwAAK3xMcBC',
                        type: 'repository',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      linkName: 'All publications',
                    },
                  },
                  {
                    sliceType: 'calendar',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            audience: 'Link.document',
                          },
                          audience: {
                            id: 'VkzBQB8AAEc90sZm',
                            type: 'audience',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            audience: 'Link.document',
                          },
                          audience: {
                            id: 'Vpz3WhsAADWYyOec',
                            type: 'audience',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        subtitleNoEvent: 'Text',
                        calendarLink: 'Link.document',
                        calendarLinkName: 'Text',
                      },
                      title: 'Upcoming events',
                      subtitleNoEvent: 'No events',
                      calendarLink: {
                        id: 'VkRz1h8AAFBAOKQy',
                        type: 'repository',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      calendarLinkName: 'All events',
                    },
                  },
                  {
                    sliceType: 'newsletterBlock',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [],
                      _meta: {
                        title: 'Text',
                        subtitle: 'Text',
                        buttonName: 'Text',
                        image: 'Image',
                      },
                      title: 'Get the latest updates',
                      subtitle: 'Subscribe to receive alerts when new items are published on this section (press release or news).',
                      buttonName: 'Subscribe',
                      image: {
                        main: {
                          dimensions: {
                            width: 600,
                            height: 600,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/bd8a639ecaac1522c43215bbe8489480753aeb3d_bg.jpg',
                        },
                        views: {
                          thumbnails: {
                            dimensions: {
                              width: 300,
                              height: 300,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d38e6cbf26a4ee409146349f91443c6a9f5a283d_bg.jpg',
                          },
                        },
                      },
                    },
                  },
                  {
                    sliceType: 'contacts',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {
                            contact: 'Link.document',
                          },
                          contact: {
                            id: 'Xr1IAREAACkAp_4a',
                            type: 'contact',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            contact: 'Link.document',
                          },
                          contact: {
                            id: 'XlaHlxMAACoAdn52',
                            type: 'contact',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            contact: 'Link.document',
                          },
                          contact: {
                            id: 'Xle9kBMAACoAe9Ym',
                            type: 'contact',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            contact: 'Link.document',
                          },
                          contact: {
                            id: 'XsJnYREAACgAvp1-',
                            type: 'contact',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        link: 'Link.document',
                        linkName: 'Text',
                      },
                      title: 'Contacts',
                      link: {
                        id: 'WFgN3yAAANHE5JU-',
                        type: 'page-v2',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      linkName: 'Contact us',
                    },
                  },
                ],
                url: '/en/press',
                url_en: '/en/press',
                url_fr: '/fr/presse',
                prismic: {
                  creationDate: '2020-06-10T07:24:51+0000',
                  updateDate: '2020-06-10T12:48:43+0000',
                },
              },
              backLabel: 'Press',
              filtersRef: [{}],
              url: '/en/press/press-releases',
              url_en: '/en/press/press-releases',
              url_fr: '/fr/presse/communiques-de-presse',
              prismic: {
                creationDate: null,
                updateDate: '2020-06-10T07:26:17+0000',
              },
            },
            title: '1Q20 Activity Indicators: AXA performed well in the 1Q20',
            titleLink: {
              type: 'press-release',
              _tags: [],
              id: 'XrF6sREAACcAc93j',
              uid: null,
              slug: '1q20-activity-indicators',
              slug_en: '1q20-activity-indicators',
              slug_fr: 'indicateurs-activite-t1-2020',
              seoDescription:
                '"The Group performed well in the first quarter of 2020,” said Thomas Buberl, CEO of AXA. “Revenues were up 4%, once again with growth across all lines of business and geographies, notably supported by a strong pricing environment in P&C Commercial lines.”',
              tweet: '#AXA 1Q20 Activity indicators',
              sharingDescription: '#AXA 1Q20 Activity indicators',
              title: '1Q20 Activity indicators',
              date: '2020-05-05T15:45:00+0000',
              document: {
                file: {
                  name: 'AXA_PR_20200505.pdf',
                  kind: 'document',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fc52af931-d980-4306-9076-f45852f31ba4_axa_pr_20200505.pdf',
                  size: '467702',
                },
                target: 'file',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fc52af931-d980-4306-9076-f45852f31ba4_axa_pr_20200505.pdf',
              },
              body: [
                {
                  sliceType: 'highlight',
                  sliceLabel: null,
                  value: [
                    {
                      text: [
                        {
                          type: 'list-item',
                          text: 'Total gross revenues* +4% in 1Q20, with growth across all business lines and geographies',
                          spans: [
                            {
                              start: 0,
                              end: 33,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'list-item',
                          text: 'Resilient Solvency II ratio** at 182%, as at March 31, 2020',
                          spans: [
                            {
                              start: 0,
                              end: 37,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'list-item',
                          text: 'Debt Gearing below 28%***, following €1.3bn subordinated debt repayment in April',
                          spans: [
                            {
                              start: 0,
                              end: 25,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'list-item',
                          text: 'Covid-19: AXA taking strong actions to support employees, clients and the communities in which it operates; expecting a slowdown in revenues; too early for precise earnings guidance',
                          spans: [
                            {
                              start: 0,
                              end: 8,
                              type: 'strong',
                            },
                          ],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'long-quote',
                  sliceLabel: null,
                  value: [
                    {
                      author: {
                        type: 'person',
                        _tags: ['Health insurance', 'Team'],
                        id: 'Vhe9iRwAABJWde4I',
                        uid: null,
                        _meta: {
                          avatar: 'Image',
                          lastname: 'Text',
                          lastname_en: 'Text',
                          lastname_fr: 'Text',
                          firstname: 'Text',
                          firstname_en: 'Text',
                          firstname_fr: 'Text',
                          slug: 'Text',
                          slug_en: 'Text',
                          slug_fr: 'Text',
                          seoDescription: 'Text',
                          seoDescription_en: 'Text',
                          seoDescription_fr: 'Text',
                          sharingImage: 'Image',
                          role: 'Text',
                          role_en: 'Text',
                          role_fr: 'Text',
                          shortRole: 'Text',
                          shortRole_en: 'Text',
                          shortRole_fr: 'Text',
                          organizationLink: 'Group',
                          twitter: 'Text',
                          twitter_en: 'Text',
                          twitter_fr: 'Text',
                          linkedin: 'Text',
                          linkedin_en: 'Text',
                          linkedin_fr: 'Text',
                          birthdate: 'Date',
                          nationality: 'Text',
                          nationality_en: 'Text',
                          nationality_fr: 'Text',
                          content: 'SliceZone',
                        },
                        avatar: {
                          main: {
                            dimensions: {
                              width: 100,
                              height: 100,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/2a6c3ce22017732579a2b6ce7cc1a5ee246e6816_thomas-buberl.png',
                          },
                          views: {},
                        },
                        lastname: 'Buberl',
                        firstname: 'Thomas',
                        slug: 'thomas-buberl',
                        slug_en: 'thomas-buberl',
                        slug_fr: 'thomas-buberl',
                        seoDescription: 'Biography of Thomas Buberl',
                        sharingImage: {
                          main: {
                            dimensions: {
                              width: 1200,
                              height: 630,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/9c25e575e30c174bc7f0850a9fb99c95f87d04c5_thomas-buberl.png',
                          },
                          views: {
                            twitter: {
                              dimensions: {
                                width: 120,
                                height: 120,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/26db25fe1a9ae123a3fc7adc244f1e38e4991bc5_thomas-buberl.png',
                            },
                            facebook: {
                              dimensions: {
                                width: 600,
                                height: 315,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f63a3b129c84789edf74f7df050d9fdb526c8c25_thomas-buberl.png',
                            },
                            linkedin: {
                              dimensions: {
                                width: 180,
                                height: 110,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/610dab8b7ac3a328408f2f13de2eafce00862b8a_thomas-buberl.png',
                            },
                          },
                        },
                        role: 'Chief Executive Officer of AXA',
                        shortRole: 'Chief Executive Officer of AXA',
                        organizationLink: [
                          {
                            _meta: {
                              organizationChart: 'Link.document',
                              organizationRanking: 'Number',
                            },
                            organizationChart: {
                              id: 'VidrvBwAAPEhicwJ',
                              type: 'organization-chart',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            organizationRanking: 1,
                          },
                          {
                            _meta: {
                              organizationChart: 'Link.document',
                              organizationRanking: 'Number',
                            },
                            organizationChart: {
                              id: 'Ve2VAh4AAABIP2Fd',
                              type: 'organization-chart',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            organizationRanking: 2,
                          },
                        ],
                        twitter: 'https://twitter.com/thomasbuberl',
                        linkedin: 'https://www.linkedin.com/in/thomas-buberl-13a30b61/?ppe=1',
                        birthdate: '1973-03-24',
                        nationality: 'German and Swiss nationalities',
                        content: [
                          {
                            sliceType: 'paragraph',
                            sliceLabel: null,
                            _meta: {
                              value: 'Group',
                            },
                            value: [
                              {
                                _meta: {
                                  text: 'StructuredText',
                                },
                                text: [
                                  {
                                    type: 'heading2',
                                    text: 'Directorship and number of AXA shares',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: "Appointed on April 25, 2018 - Term expires at the 2022 Shareholders' Meeting",
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'First appointment on September 1, 2016',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Number of AXA shares held on December 31, 2019: 320,305',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading3',
                                    text: 'On April 28, 2020',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Expertise and experience',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Mr. Thomas Buberl holds a Master of Economics degree from WHU Koblenz (Germany), a MBA from Lancaster University (UK) and a Ph.D. in Economics from the University of St Gallen (Switzerland). In 2008 he was nominated as a Young Global Leader by the World Economic Forum. From 2000 to 2005, Mr. Thomas Buberl worked at the Boston Consulting Group as a consultant for the banking & insurance sector in Germany and abroad. From 2005 to 2008, he had worked for the Winterthur Group as member of the Management Board of Winterthur in Switzerland, first as Chief Operating Officer and then as Chief Marketing and Distribution Officer. Then, he joined Zurich Financial Services where he had been Chief Executive Officer for Switzerland. From 2012 to April 2016, he was Chief Executive Officer of AXA Konzern AG (Germany). In 2012, he has been member of the AXA Executive Committee. In March 2015, he became Chief Executive Officer of the Global Business Line for the Health Business and joined the AXA Management Committee. In January 2016, Mr. Thomas Buberl was also appointed Chief Executive Officer of the global business line Life & Savings. From March 21, 2016 to August 31, 2016, Mr. Thomas Buberl was Deputy Chief Executive Officer (Directeur Général Adjoint ) of AXA. Since September 1, 2016, Mr. Thomas Buberl has been Chief Executive Officer and director of AXA.',
                                    spans: [
                                      {
                                        start: 1232,
                                        end: 1258,
                                        type: 'em',
                                      },
                                    ],
                                  },
                                  {
                                    type: 'heading3',
                                    text: '',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held within the AXA Group',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director and Chief Executive Officer: AXA',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held outside the AXA Group (1)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director or member of the Supervisory Board: Bertelsmann SE & Co. KGaA (Germany), IBM (United States)',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'Directorships held during the last five years',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Management Board: AXA Konzern AG (Germany), AXA Krankenversicherung AG (Germany), AXA Lebensversicherung AG (Germany), AXA Versicherung AG (Germany), DBV Deutsche Beamtenversicherung AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Board of Directors: AXA Equitable Holdings, Inc. (United States), AXA Financial, Inc. (United States), AXA Leben AG (Switzerland), AXA Versicherungen AG (Switzerland), XL Group Ltd (Bermuda)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Chairman of the Supervisory Board: AXA Konzern AG (Germany), AXA Krankenversicherung AG (Germany), AXA Lebensversicherung AG (Germany), AXA Versicherung AG (Germany), Deutsche Ärzteversicherung AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Deputy Chairman of the Supervisory Board: Roland Rechtsschutz-Versicherungs-AG (Germany)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Managing Director and Chief Executive Officer: Vinci B.V. (the Netherlands)',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: 'Director or member of the Management Committee or member of the Supervisory Board: AXA ASIA (SAS), AXA ART Versicherung AG (Germany), AXA Equitable Holdings, Inc. (United States), AXA Equitable Life Insurance Company (United States), AXA Life Insurance Co. Ltd (Japan), MONY Life Insurance Company of America (United States), Tertia GmbH (Germany).',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: '',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: "(1) Mr. Thomas Buberl requested the Board of Directors' approval before accepting new directorships in companies outside the AXA Group.",
                                    spans: [],
                                  },
                                ],
                              },
                            ],
                          },
                        ],
                        url: '/en/about-us/profile/thomas-buberl',
                        url_en: '/en/about-us/profile/thomas-buberl',
                        url_fr: '/fr/a-propos-d-axa/profil/thomas-buberl',
                        prismic: {
                          creationDate: null,
                          updateDate: '2020-05-20T15:55:56+0000',
                        },
                      },
                      quote: [
                        {
                          type: 'paragraph',
                          text: 'The Group performed well in the first quarter of 2020. Revenues were up 4%, once again with growth across all lines of business and geographies, notably supported by a strong pricing environment in P&C Commercial lines.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'AXA’s balance sheet remains resilient in these volatile market conditions, with a Solvency II ratio at 182%, and after the repayment of Euro 1.3 billion subordinated debt in April, AXA’s debt gearing was reduced to below 28%.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'The Covid-19 crisis has created unprecedented health, economic and financial challenges. AXA’s priority has been to protect the safety of our 160,000 employees and partners and allow them, as well as our distributors, to continue providing undisrupted services to our 108 million customers. Exceptional measures have been implemented to help our most impacted clients, particularly SMEs.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'AXA has also leveraged its medical networks and teleconsulting services for its clients while supporting medical responses in the regions in which it operates. We have contributed to solidarity funds to support healthcare professionals, research, affected companies, and economic recovery. AXA has initiated discussions with peers and public authorities to better insure future health risks.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Although Covid-19 related claims notified in March were limited and the precise implications of the crisis remain uncertain at this stage, we believe that the effects of the Covid-19 crisis will have a material impact on our earnings in 2020.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'We are confident in our strategy and its execution, and the need for enhanced insurance coverage in our preferred segments confirms our growth potential post-crisis. I would particularly like to express my gratitude to all AXA colleagues and partners for their unwavering commitment during this crisis, and their support as we prepare for a safe and progressive end to global lockdowns.',
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'paragraph',
                  sliceLabel: null,
                  value: [
                    {
                      text: [
                        {
                          type: 'heading6',
                          text: '*Change in gross revenues is on a comparable basis (constant forex, scope and methodology). On a reported basis, total gross revenues declined by 9% in 1Q20, mainly driven by the deconsolidation of Equitable Holdings, Inc. and the transformation of the Swiss Group Life business.',
                          spans: [],
                        },
                        {
                          type: 'heading6',
                          text: '**The Solvency II ratio is estimated primarily using AXA’s internal model calibrated based on an adverse 1/200 years shock. It also includes a theoretical amount for dividends accrued for the first three months of 2020, based on the full year dividend proposed by the Board to be paid in 2020 for FY19. Dividends are proposed by the Board, at its discretion based on a variety of factors described in AXA’s 2019 Universal Registration Document, and then submitted to AXA’s shareholders for approval. This estimate should not be considered in any way to be an indication of the actual dividend amount, if any, for the 2019 or the 2020 financial years. For further information on AXA’s internal model and Solvency II disclosures, please refer to AXA Group’s SFCR as of December 31, 2018, available on AXA’s website (www.axa.com).\nIn compliance with the decision from AXA’s lead supervisor (the ACPR) from January 1, 2019, entities that were part of the XL Group (“XL entities”) have been fully consolidated for Solvency II purposes (as per the consolidation-based method set forth in the Solvency II Directive) and their contribution to the Group’s solvency capital requirement has been calculated using the Solvency II standard formula. Subject to the prior approval of the ACPR, the Group intends to extend its Internal Model to XL entities as soon as December 31, 2020.',
                          spans: [],
                        },
                        {
                          type: 'heading6',
                          text: '***Including only the impact of Euro 1.3 billion subordinated debt repayment in April 2020 on AXA’s Debt Gearing as of December 31, 2019. Debt Gearing is a non-GAAP financial measure, or alternative performance measure (“APM”), defined in the Glossary set forth in Appendix V of AXA’s 2019 Universal Registration Document (pp. 471-475). The calculation methodology of the Debt Gearing is set out on page 47 of AXA’s 2019 Universal Registration Document.',
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'documents',
                  sliceLabel: null,
                  value: [
                    {
                      target: {
                        type: 'earnings-page',
                        _tags: [],
                        id: 'Vsb-lCMAACQAVqWP',
                        uid: null,
                        _meta: {
                          slug: 'Text',
                          slug_en: 'Text',
                          slug_fr: 'Text',
                          seoDescription: 'Text',
                          seoDescription_en: 'Text',
                          seoDescription_fr: 'Text',
                          title: 'Text',
                          title_en: 'Text',
                          title_fr: 'Text',
                          bannerStyle: 'Select',
                          bannerStyle_en: 'Select',
                          bannerStyle_fr: 'Select',
                          bannerTitle: 'Text',
                          bannerTitle_en: 'Text',
                          bannerTitle_fr: 'Text',
                          bannerSubtitle: 'Text',
                          bannerSubtitle_en: 'Text',
                          bannerSubtitle_fr: 'Text',
                          presentationContent: 'StructuredText',
                          tableResults: 'Group',
                          attachment: 'Group',
                          contacts: 'Group',
                        },
                        slug: 'earnings-presentation',
                        slug_en: 'earnings-presentation',
                        slug_fr: 'presentations-des-resultats',
                        seoDescription: 'Latest earnings of the AXA Group',
                        title: 'Earnings',
                        bannerStyle: 'Light banner',
                        bannerTitle: 'Earnings Presentations kssjospkolAXAcom',
                        bannerSubtitle: 'Access the AXA Group’s earnings-related financial information : the 1Q and 9M activity indicators but also the half-year and annual results',
                        presentationContent: [
                          {
                            type: 'paragraph',
                            text: 'AXA has published its 1Q 2016 Activity Indicators on Tuesday, May 3rd, 2016 at 5.45pm CET / 4.45pm GMT. kssjospkolAXAcom',
                            spans: [],
                          },
                        ],
                        tableResults: [
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'XG0xgxAAACgAPMBR',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'WQiVGw8AAPdYM3As',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'Vx8rzCMAACIAZoFS',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'VscFJyMAACUAVsqf',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'VscFGiMAACUAVspN',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'VscFCSMAACIAVsnk',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'VscE9CMAACUAVslj',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'VsbzKyMAACMAVmEJ',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'V0QulB4AAB4A8xXR',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'V0RbeR4AAB8A9CCQ',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'V0R7xR4AACAA9OH0',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'V0VtrB4AAB0A-o1p',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'V0WRJR4AAB8A-2B3',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              yearResults: 'Link.document',
                            },
                            yearResults: {
                              id: 'V0WtCh4AAB0A_APP',
                              type: 'earning-results-year',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                        ],
                        attachment: [],
                        contacts: [],
                        url: '/en/investor/earnings-presentation',
                        url_en: '/en/investor/earnings-presentation',
                        url_fr: '/fr/investisseurs/presentations-des-resultats',
                        prismic: {
                          creationDate: '2020-06-11T13:16:08+0000',
                          updateDate: '2020-06-11T13:16:08+0000',
                        },
                      },
                      title: 'Find out all related information',
                    },
                  ],
                },
                {
                  sliceType: 'contacts',
                  sliceLabel: null,
                  value: [
                    {
                      contact: {
                        type: 'contact',
                        _tags: [],
                        id: 'Vl7CqCAAAJEjR7_o',
                        uid: null,
                        _meta: {
                          name: 'Text',
                          name_en: 'Text',
                          name_fr: 'Text',
                          section: 'Text',
                          section_en: 'Text',
                          section_fr: 'Text',
                          phone: 'Text',
                          phone_en: 'Text',
                          phone_fr: 'Text',
                        },
                        name: 'Investor Relations team',
                        section: 'Investor Relations',
                        phone: '+33 1 40 75 48 42',
                        url: '/not-resolved',
                        url_en: '/not-resolved',
                        url_fr: '/not-resolved',
                        prismic: {
                          creationDate: null,
                          updateDate: null,
                        },
                      },
                    },
                    {
                      contact: {
                        type: 'contact',
                        _tags: ['Contact'],
                        id: 'Veh3JR4AAKAAILFL',
                        uid: null,
                        _meta: {
                          name: 'Text',
                          name_en: 'Text',
                          name_fr: 'Text',
                          section: 'Text',
                          section_en: 'Text',
                          section_fr: 'Text',
                          phone: 'Text',
                          phone_en: 'Text',
                          phone_fr: 'Text',
                        },
                        name: 'Axa Media Relations',
                        section: 'Media relations',
                        phone: '+33.1.40.75.46.68',
                        url: '/not-resolved',
                        url_en: '/not-resolved',
                        url_fr: '/not-resolved',
                        prismic: {
                          creationDate: null,
                          updateDate: null,
                        },
                      },
                    },
                  ],
                },
              ],
              url: '/en/press/press-releases/1q20-activity-indicators',
              url_en: '/en/press/press-releases/1q20-activity-indicators',
              url_fr: '/fr/presse/communiques-de-presse/indicateurs-activite-t1-2020',
              prismic: {
                creationDate: '2020-05-05T15:46:27+0000',
                updateDate: '2020-05-05T17:23:40+0000',
              },
            },
            image: {
              main: {
                dimensions: {
                  width: 1920,
                  height: 1080,
                },
                alt: '',
                copyright: '',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/ad58ff3dc3b206894bafe9575b5cb61a2c8a8657_thomas_buberl_press.jpg',
              },
              views: {
                small: {
                  dimensions: {
                    width: 768,
                    height: 432,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/fc897693d7a1630d778670adb143455b42d3ad51_thomas_buberl_press.jpg',
                },
                medium: {
                  dimensions: {
                    width: 970,
                    height: 545,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/bf43878a5ec4ed8eb78b29a195f23d8958fe87d4_thomas_buberl_press.jpg',
                },
              },
            },
          },
          {
            surtitle: "Leader's voice",
            date: 'June 10, 2020',
            surtitleLink: {
              type: 'page-v2',
              _tags: [],
              id: 'Xr1JDhEAACgAqALl',
              uid: null,
              slug: 'leaders-voice',
              slug_en: 'leaders-voice',
              slug_fr: 'parole-de-leaders',
              metaContent: [
                {
                  seoDescription: "Leader's voice",
                  tweet: "Discover a new section which gives voice to #AXA's leaders on news and topics that matters to the Group.",
                  sharingImage: {
                    main: {
                      dimensions: {
                        width: 1200,
                        height: 628,
                      },
                      alt: '',
                      copyright: '',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/ed2a1c1c1b4d7df40cae675357ff6a23d589f4c6_thomas-buberl-hye-2018.jpg',
                    },
                    views: {},
                  },
                  sharingDescription: "Discover our new section which gives voice to #AXA's leaders on news and topics that matter to us.",
                  title: "Leaders' Voice",
                  sectionReferrer: 'Press',
                  summary: "A place which gives voice to AXA's leaders on news and topics that matter to us.",
                },
              ],
              anchor: [],
              body: [
                {
                  sliceType: 'articleThumbnailList',
                  sliceLabel: null,
                  value: {
                    items: [],
                    title: "Leader's voice",
                    highlightedArticle: {
                      type: 'article-v2',
                      _tags: [],
                      id: 'XsQ_VREAACwAxsXv',
                      uid: null,
                      _meta: {
                        slug: 'Text',
                        slug_en: 'Text',
                        slug_fr: 'Text',
                        theme: 'Link.document',
                        theme_en: 'Link.document',
                        theme_fr: 'Link.document',
                        date: 'Timestamp',
                        date_en: 'Timestamp',
                        date_fr: 'Timestamp',
                        typeArticle: 'Select',
                        typeArticle_en: 'Select',
                        typeArticle_fr: 'Select',
                        metaContent: 'Group',
                        author: 'Group',
                        body: 'SliceZone',
                        related_articles: 'Group',
                      },
                      slug: 'alban-risk-covid19',
                      slug_en: 'alban-risk-covid19',
                      slug_fr: 'alban-risque-covid19',
                      theme: {
                        id: 'XqA6xhMAAGKnu7Y2',
                        type: 'theme-v2',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      date: '2020-06-09T22:00:00+0000',
                      typeArticle: 'Press-Magazine',
                      metaContent: [
                        {
                          _meta: {
                            seoDescription: 'Text',
                            tweet: 'Text',
                            sharingImage: 'Image',
                            sharingDescription: 'Text',
                            title: 'Text',
                            summary: 'Text',
                          },
                          seoDescription: 'Covid-19 crisis: a tipping point for the insurance sector?',
                          tweet:
                            '"This crisis may be a tipping point for insurers. It has revealed a transformation in the nature of risks which require strong insurers to absorb the shocks & understand the risks, and @AXA is one of them." Alban de Mailly Nesle, #AXA Chief Risk & Investment Officer.',
                          sharingImage: {
                            main: {
                              dimensions: {
                                width: 1200,
                                height: 628,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/2c2a70941565a75e85e4519e3777076ff341dcc5_alban_1200x628.jpg',
                            },
                            views: {},
                          },
                          sharingDescription:
                            '"This crisis may be a tipping point for insurers. It has revealed a transformation in the nature of risks which require strong insurers to absorb the shocks and @AXA is one of them." Alban de Mailly Nesle, #AXA Chief Risk & Investment Officer.',
                          title: 'Covid-19 crisis: a tipping point for the insurance sector?',
                          summary:
                            'Alban de Mailly Nesle, AXA Chief Risk and Investment Officer, explains why the Covid-19 crisis could be a tipping point for the insurance industry, with long lasting consequences on how insurers anticipate and cover large risks.',
                        },
                      ],
                      author: [
                        {
                          _meta: {},
                        },
                      ],
                      body: [
                        {
                          sliceType: 'cover',
                          sliceLabel: null,
                          _meta: {
                            value: 'NewSlice',
                          },
                          value: {
                            items: [
                              {
                                _meta: {},
                              },
                            ],
                            _meta: {
                              title: 'Text',
                              shortTitle: 'Text',
                              subtitle: 'Text',
                              banner: 'Image',
                            },
                            title: 'Covid-19 crisis: a tipping point for the insurance sector?',
                            shortTitle: 'Covid-19 crisis: a tipping point for the insurance sector?',
                            subtitle:
                              'Alban de Mailly Nesle, AXA Chief Risk and Investment Officer, explains why the Covid-19 crisis could be a tipping point for the industry, with long lasting consequences on how insurers anticipate and cover large risks.',
                            banner: {
                              main: {
                                dimensions: {
                                  width: 1920,
                                  height: 1280,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d76ff975ea6e2d555e270b8e020f8e06416194d2_albanmaillynesle.jpg',
                              },
                              views: {
                                small: {
                                  dimensions: {
                                    width: 768,
                                    height: 576,
                                  },
                                  alt: '',
                                  copyright: '',
                                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d6c16f2545f0623dfc853bddb29b9d368b5995c1_albanmaillynesle.jpg',
                                },
                                medium: {
                                  dimensions: {
                                    width: 970,
                                    height: 576,
                                  },
                                  alt: '',
                                  copyright: '',
                                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/9be321a3863b4a6c7b0ea6a27adb512bf2dd2a43_albanmaillynesle.jpg',
                                },
                              },
                            },
                          },
                        },
                        {
                          sliceType: 'paragraph',
                          sliceLabel: null,
                          _meta: {
                            value: 'Group',
                          },
                          value: [
                            {
                              _meta: {
                                text: 'StructuredText',
                              },
                              text: [
                                {
                                  type: 'paragraph',
                                  text: 'As Director of Risks and Investments, what is your vision of the Covid-19 crisis?',
                                  spans: [
                                    {
                                      start: 0,
                                      end: 81,
                                      type: 'strong',
                                    },
                                  ],
                                },
                                {
                                  type: 'paragraph',
                                  text: 'It\'s a new situation. This crisis is unique. While we often deal with disasters that can be serious but are most often limited in their occurrence and spread, we are witnessing a "total" crisis here: almost all countries are affected simultaneously, with more than half of the world\'s population confined to their homes, and economies at a standstill. \nIt is also a complex crisis. It is a health crisis, it has put our health systems under strain, causing more than 350,000 deaths to date. It is an economic crisis; the shutdown of our economies has sparked one of the worst recessions since WWII. It could become social, or even political, depending on the extent of the shock and the way in which governments respond to it. ',
                                  spans: [],
                                },
                                {
                                  type: 'paragraph',
                                  text: 'Are you surprised by this crisis? ',
                                  spans: [
                                    {
                                      start: 0,
                                      end: 34,
                                      type: 'strong',
                                    },
                                  ],
                                },
                                {
                                  type: 'paragraph',
                                  text: 'What was new was the decision taken by governments to confine their populations, causing our economies to come to a standstill beyond what we could have anticipated. This had not happened in previous pandemics, especially the most recent ones, in the 50s and 60s. We see a greater appreciation in the value of human life, and that is to be welcomed, but it has a huge impact on the economy. \nThis crisis is therefore surprising in its magnitude, but not in its matrix. It illustrates a major new phenomenon that we discussed in our last Future Risk Report: the interconnection of risks. Standardization of lifestyles and globalization now play a key role in the spread of risk. It is a powerful accelerator.\nIt should also be remembered that the world has experienced several epidemic episodes in recent years, even if they did not reach the pandemic stage. After the SARS episode in 2003, we saw companies in Asia asking to insure themselves against this type of risk, even though these contracts remained very rare. All these signals led us to develop a new actuarial model for pandemics, which we deployed before the current crisis began. It proved to be aligned with the reality of the situation. ',
                                  spans: [],
                                },
                                {
                                  type: 'paragraph',
                                  text: 'Can insurers play a role in the face of such risks? ',
                                  spans: [
                                    {
                                      start: 0,
                                      end: 52,
                                      type: 'strong',
                                    },
                                  ],
                                },
                                {
                                  type: 'paragraph',
                                  text: 'Insurers are already doing a lot. Wherever we are present, we are playing a role and honouring contracts, particularly in health and provident insurance. Sometimes we have even gone beyond that, by making exceptional solidarity efforts. AXA has mobilized nearly 400 million euros to help its clients and society. \nThe subject that has been the subject of debate is operating losses. This crisis revealed that this risk is not covered, or very rarely, in the event of a pandemic. The reason is simple: in the event of a pandemic, as in the case of war, everyone is affected at the same time. There can therefore be no risk pooling, which is an essential foundation of insurance. \nBut we can innovate. This is why we have launched, first of all in France, a strategy to bring together the State and private players to set up a mechanism to cover risks linked to pandemics, as is already the case for natural disasters. Only joint action by the public and private sectors, as well as pooling over time, can make it possible to cover such risks. ',
                                  spans: [],
                                },
                                {
                                  type: 'paragraph',
                                  text: 'Will there be a before and after for insurance? ',
                                  spans: [
                                    {
                                      start: 0,
                                      end: 48,
                                      type: 'strong',
                                    },
                                  ],
                                },
                                {
                                  type: 'paragraph',
                                  text: 'This crisis may be a tipping point for insurance. On the one hand, it has revealed the sector’s underestimation of health risks. While major pandemics seemed to be a thing of the past, this incident shows us that the risk is still present and that the "protection gap" remains significant. Moving forward, society will be even more demanding regarding their health. \nOn the other hand, this crisis reveals a transformation in the nature of risks. Pandemics, cyber risk, climate change, the threats are global and complex. They require coordinated responses between countries, with strong insurers to absorb the shocks and experts to understand the risks. AXA is one of these strong players. At the end of the day, this crisis fully affirms our strategic vision of desensitizing the company to financial risks and focusing on large risks and health. ',
                                  spans: [],
                                },
                              ],
                            },
                          ],
                        },
                        {
                          sliceType: 'documents',
                          sliceLabel: null,
                          _meta: {
                            value: 'Group',
                          },
                          value: [
                            {
                              _meta: {
                                attachmentTitle: 'Text',
                                target: 'Link.document',
                              },
                              attachmentTitle: 'Publication',
                              target: {
                                id: 'XabNFBAAACEAh4LL',
                                type: 'publication',
                                target: 'document',
                                isBroken: false,
                                url: '/not-populated',
                              },
                            },
                          ],
                        },
                      ],
                      related_articles: [
                        {
                          _meta: {
                            article: 'Link.document',
                          },
                          article: {
                            id: 'Xr1PlREAACwAqCDD',
                            type: 'article-v2',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                        {
                          _meta: {
                            article: 'Link.document',
                          },
                          article: {
                            id: 'XoRT_xMAAC_mQJdg',
                            type: 'press-release',
                            target: 'document',
                            isBroken: false,
                            url: '/not-populated',
                          },
                        },
                      ],
                      url: '/en/magazine/alban-risk-covid19',
                      url_en: '/en/magazine/alban-risk-covid19',
                      url_fr: '/fr/magazine/alban-risque-covid19',
                      prismic: {
                        creationDate: '2020-06-10T07:25:48+0000',
                        updateDate: '2020-06-10T13:01:47+0000',
                      },
                    },
                    typeArticle: 'Press-Magazine',
                  },
                },
                {
                  sliceType: 'contacts',
                  sliceLabel: null,
                  value: {
                    items: [
                      {
                        contact: {
                          type: 'contact',
                          _tags: [],
                          id: 'XlkbKRMAACcAgd7H',
                          uid: null,
                          _meta: {
                            name: 'Text',
                            name_en: 'Text',
                            name_fr: 'Text',
                            section: 'Text',
                            section_en: 'Text',
                            section_fr: 'Text',
                            email: 'Text',
                            email_en: 'Text',
                            email_fr: 'Text',
                            contactImage: 'Image',
                          },
                          name: 'Minh Duy Tran',
                          section: 'Media Relations Officer',
                          email: 'minhduy.tran@axa.com',
                          contactImage: {
                            main: {
                              dimensions: {
                                width: 1200,
                                height: 1679,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/32412f7fe1c1e3bd31b590b3912e13b34935bf8e_mdt4.jpg',
                            },
                            views: {},
                          },
                          url: '/not-resolved',
                          url_en: '/not-resolved',
                          url_fr: '/not-resolved',
                          prismic: {
                            creationDate: '2020-06-10T07:23:59+0000',
                            updateDate: '2020-06-10T07:23:59+0000',
                          },
                        },
                      },
                    ],
                    title: 'Contact',
                  },
                },
              ],
              url: '/en/page/leaders-voice',
              url_en: '/en/page/leaders-voice',
              url_fr: '/fr/page/parole-de-leaders',
              prismic: {
                creationDate: '2020-06-10T07:26:08+0000',
                updateDate: '2020-06-10T07:26:08+0000',
              },
            },
            title: '"Covid-19: a tipping point for the industry?" by Alban de Mailly Nesle, Group Chief Risk & Investment Officer',
            titleLink: {
              type: 'article-v2',
              _tags: [],
              id: 'XsQ_VREAACwAxsXv',
              uid: null,
              slug: 'alban-risk-covid19',
              slug_en: 'alban-risk-covid19',
              slug_fr: 'alban-risque-covid19',
              theme: {
                type: 'theme-v2',
                _tags: [],
                id: 'XqA6xhMAAGKnu7Y2',
                uid: null,
                _meta: {
                  slug: 'Text',
                  slug_en: 'Text',
                  slug_fr: 'Text',
                  metaContent: 'Group',
                  description: 'StructuredText',
                  highlighted_article: 'Link.document',
                  highlighted_article_en: 'Link.document',
                  highlighted_article_fr: 'Link.document',
                },
                slug: 'covid',
                slug_en: 'covid',
                slug_fr: 'covid',
                metaContent: [
                  {
                    _meta: {
                      title: 'Text',
                    },
                    title: 'Covid-19',
                  },
                ],
                description: [
                  {
                    type: 'paragraph',
                    text: '',
                    spans: [],
                  },
                ],
                highlighted_article: {
                  id: 'Xp_uLBMAADUMumYG',
                  type: 'article-v2',
                  target: 'document',
                  isBroken: false,
                  url: '/not-populated',
                },
                url: '/en/theme/covid',
                url_en: '/en/theme/covid',
                url_fr: '/fr/theme/covid',
                prismic: {
                  creationDate: '2020-04-22T12:39:33+0000',
                  updateDate: '2020-04-22T14:50:45+0000',
                },
              },
              date: '2020-06-09T22:00:00+0000',
              typeArticle: 'Press-Magazine',
              metaContent: [
                {
                  seoDescription: 'Covid-19 crisis: a tipping point for the insurance sector?',
                  tweet:
                    '"This crisis may be a tipping point for insurers. It has revealed a transformation in the nature of risks which require strong insurers to absorb the shocks & understand the risks, and @AXA is one of them." Alban de Mailly Nesle, #AXA Chief Risk & Investment Officer.',
                  sharingImage: {
                    main: {
                      dimensions: {
                        width: 1200,
                        height: 628,
                      },
                      alt: '',
                      copyright: '',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/2c2a70941565a75e85e4519e3777076ff341dcc5_alban_1200x628.jpg',
                    },
                    views: {},
                  },
                  sharingDescription:
                    '"This crisis may be a tipping point for insurers. It has revealed a transformation in the nature of risks which require strong insurers to absorb the shocks and @AXA is one of them." Alban de Mailly Nesle, #AXA Chief Risk & Investment Officer.',
                  title: 'Covid-19 crisis: a tipping point for the insurance sector?',
                  summary:
                    'Alban de Mailly Nesle, AXA Chief Risk and Investment Officer, explains why the Covid-19 crisis could be a tipping point for the insurance industry, with long lasting consequences on how insurers anticipate and cover large risks.',
                },
              ],
              author: [{}],
              body: [
                {
                  sliceType: 'cover',
                  sliceLabel: null,
                  value: {
                    items: [{}],
                    title: 'Covid-19 crisis: a tipping point for the insurance sector?',
                    shortTitle: 'Covid-19 crisis: a tipping point for the insurance sector?',
                    subtitle:
                      'Alban de Mailly Nesle, AXA Chief Risk and Investment Officer, explains why the Covid-19 crisis could be a tipping point for the industry, with long lasting consequences on how insurers anticipate and cover large risks.',
                    banner: {
                      main: {
                        dimensions: {
                          width: 1920,
                          height: 1280,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d76ff975ea6e2d555e270b8e020f8e06416194d2_albanmaillynesle.jpg',
                      },
                      views: {
                        small: {
                          dimensions: {
                            width: 768,
                            height: 576,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d6c16f2545f0623dfc853bddb29b9d368b5995c1_albanmaillynesle.jpg',
                        },
                        medium: {
                          dimensions: {
                            width: 970,
                            height: 576,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/9be321a3863b4a6c7b0ea6a27adb512bf2dd2a43_albanmaillynesle.jpg',
                        },
                      },
                    },
                  },
                },
                {
                  sliceType: 'paragraph',
                  sliceLabel: null,
                  value: [
                    {
                      text: [
                        {
                          type: 'paragraph',
                          text: 'As Director of Risks and Investments, what is your vision of the Covid-19 crisis?',
                          spans: [
                            {
                              start: 0,
                              end: 81,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'It\'s a new situation. This crisis is unique. While we often deal with disasters that can be serious but are most often limited in their occurrence and spread, we are witnessing a "total" crisis here: almost all countries are affected simultaneously, with more than half of the world\'s population confined to their homes, and economies at a standstill. \nIt is also a complex crisis. It is a health crisis, it has put our health systems under strain, causing more than 350,000 deaths to date. It is an economic crisis; the shutdown of our economies has sparked one of the worst recessions since WWII. It could become social, or even political, depending on the extent of the shock and the way in which governments respond to it. ',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Are you surprised by this crisis? ',
                          spans: [
                            {
                              start: 0,
                              end: 34,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'What was new was the decision taken by governments to confine their populations, causing our economies to come to a standstill beyond what we could have anticipated. This had not happened in previous pandemics, especially the most recent ones, in the 50s and 60s. We see a greater appreciation in the value of human life, and that is to be welcomed, but it has a huge impact on the economy. \nThis crisis is therefore surprising in its magnitude, but not in its matrix. It illustrates a major new phenomenon that we discussed in our last Future Risk Report: the interconnection of risks. Standardization of lifestyles and globalization now play a key role in the spread of risk. It is a powerful accelerator.\nIt should also be remembered that the world has experienced several epidemic episodes in recent years, even if they did not reach the pandemic stage. After the SARS episode in 2003, we saw companies in Asia asking to insure themselves against this type of risk, even though these contracts remained very rare. All these signals led us to develop a new actuarial model for pandemics, which we deployed before the current crisis began. It proved to be aligned with the reality of the situation. ',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Can insurers play a role in the face of such risks? ',
                          spans: [
                            {
                              start: 0,
                              end: 52,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'Insurers are already doing a lot. Wherever we are present, we are playing a role and honouring contracts, particularly in health and provident insurance. Sometimes we have even gone beyond that, by making exceptional solidarity efforts. AXA has mobilized nearly 400 million euros to help its clients and society. \nThe subject that has been the subject of debate is operating losses. This crisis revealed that this risk is not covered, or very rarely, in the event of a pandemic. The reason is simple: in the event of a pandemic, as in the case of war, everyone is affected at the same time. There can therefore be no risk pooling, which is an essential foundation of insurance. \nBut we can innovate. This is why we have launched, first of all in France, a strategy to bring together the State and private players to set up a mechanism to cover risks linked to pandemics, as is already the case for natural disasters. Only joint action by the public and private sectors, as well as pooling over time, can make it possible to cover such risks. ',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'Will there be a before and after for insurance? ',
                          spans: [
                            {
                              start: 0,
                              end: 48,
                              type: 'strong',
                            },
                          ],
                        },
                        {
                          type: 'paragraph',
                          text: 'This crisis may be a tipping point for insurance. On the one hand, it has revealed the sector’s underestimation of health risks. While major pandemics seemed to be a thing of the past, this incident shows us that the risk is still present and that the "protection gap" remains significant. Moving forward, society will be even more demanding regarding their health. \nOn the other hand, this crisis reveals a transformation in the nature of risks. Pandemics, cyber risk, climate change, the threats are global and complex. They require coordinated responses between countries, with strong insurers to absorb the shocks and experts to understand the risks. AXA is one of these strong players. At the end of the day, this crisis fully affirms our strategic vision of desensitizing the company to financial risks and focusing on large risks and health. ',
                          spans: [],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'documents',
                  sliceLabel: null,
                  value: [
                    {
                      attachmentTitle: 'Publication',
                      target: {
                        type: 'publication',
                        _tags: [],
                        id: 'XabNFBAAACEAh4LL',
                        uid: null,
                        _meta: {
                          slug: 'Text',
                          slug_en: 'Text',
                          slug_fr: 'Text',
                          seoDescription: 'Text',
                          seoDescription_en: 'Text',
                          seoDescription_fr: 'Text',
                          sharingImage: 'Image',
                          sharingDescription: 'Text',
                          sharingDescription_en: 'Text',
                          sharingDescription_fr: 'Text',
                          topic: 'Link.document',
                          topic_en: 'Link.document',
                          topic_fr: 'Link.document',
                          title: 'Text',
                          title_en: 'Text',
                          title_fr: 'Text',
                          date: 'Date',
                          cover: 'Image',
                          document: 'Link.file',
                          documentTitle: 'Text',
                          documentTitle_en: 'Text',
                          documentTitle_fr: 'Text',
                        },
                        slug: 'future-risks-report-2019',
                        slug_en: 'future-risks-report-2019',
                        slug_fr: 'rapport-risques-futurs-2019',
                        seoDescription:
                          'AXA & Eurasia Group Future Risks Report focuses on defining, identifying and anticipating emerging risks. It is meant to ensure that all new, evolving and potentially disruptive risks are firmly on the AXA Group’s radar. The report finds that the main risks in the next five to ten years will relate to climate change, technology and geopolitical instability.',
                        sharingImage: {
                          main: {
                            dimensions: {
                              width: 1200,
                              height: 630,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/0c4187f2d9d8eaaa2c77b14abb20ad1d2fffb678_cover-video-er-2019.jpg',
                          },
                          views: {},
                        },
                        sharingDescription:
                          'AXA & Eurasia Group Future Risks Report focuses on defining, identifying and anticipating emerging risks. It is meant to ensure that all new, evolving and potentially disruptive risks are firmly on the AXA Group’s radar. The report finds that the main risks in the next five to ten years will relate to climate change, technology and geopolitical instability.',
                        topic: {
                          id: 'XkUd9hMAACkAKa0S',
                          type: 'publication-topic',
                          target: 'document',
                          isBroken: false,
                          url: '/not-populated',
                        },
                        title: 'AXA & Eurasia Group Future Risks Report',
                        date: '2019-10-16',
                        cover: {
                          main: {
                            dimensions: {
                              width: 400,
                              height: 517,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/7c230df89899a144b9b688f61f64366cc0299001_cover-report-publication.jpg',
                          },
                          views: {},
                        },
                        document: {
                          file: {
                            name: '1910-15 Future Risks Report final.pdf',
                            kind: 'document',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F744a1c88-b1a7-4103-a831-a84f72578a0f_1910-15+future+risks+report+final.pdf',
                            size: '7173003',
                          },
                          target: 'file',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F744a1c88-b1a7-4103-a831-a84f72578a0f_1910-15+future+risks+report+final.pdf',
                        },
                        documentTitle: 'PDF Document',
                        url: '/en/press/publications/future-risks-report-2019',
                        url_en: '/en/press/publications/future-risks-report-2019',
                        url_fr: '/fr/presse/publications/rapport-risques-futurs-2019',
                        prismic: {
                          creationDate: '2019-10-16T10:21:32+0000',
                          updateDate: '2020-02-13T10:03:19+0000',
                        },
                      },
                    },
                  ],
                },
              ],
              related_articles: [
                {
                  article: {
                    type: 'article-v2',
                    _tags: [],
                    id: 'Xr1PlREAACwAqCDD',
                    uid: null,
                    _meta: {
                      slug: 'Text',
                      slug_en: 'Text',
                      slug_fr: 'Text',
                      theme: 'Link.document',
                      theme_en: 'Link.document',
                      theme_fr: 'Link.document',
                      date: 'Timestamp',
                      date_en: 'Timestamp',
                      date_fr: 'Timestamp',
                      typeArticle: 'Select',
                      typeArticle_en: 'Select',
                      typeArticle_fr: 'Select',
                      metaContent: 'Group',
                      author: 'Group',
                      body: 'SliceZone',
                      related_articles: 'Group',
                    },
                    slug: 'gilbert-chahine-axa-accor',
                    slug_en: 'gilbert-chahine-axa-accor',
                    slug_fr: 'gilbert-chahine-axa-accor',
                    theme: {
                      id: 'XqA6xhMAAGKnu7Y2',
                      type: 'theme-v2',
                      target: 'document',
                      isBroken: false,
                      url: '/not-populated',
                    },
                    date: '2020-06-09T22:00:00+0000',
                    typeArticle: 'Press-Magazine',
                    metaContent: [
                      {
                        _meta: {
                          seoDescription: 'Text',
                          tweet: 'Text',
                          sharingImage: 'Image',
                          sharingDescription: 'Text',
                          title: 'Text',
                          summary: 'Text',
                        },
                        seoDescription: 'This health crisis reaffirmed our initial intuition was the right one',
                        tweet:
                          'Gilbert Chahine, CEO of @AXAPartners, sheds light on how @AXA leverages its expertise to assist @Accor’s customers through offering free medical support across 5,000 hotels worldwide.',
                        sharingImage: {
                          main: {
                            dimensions: {
                              width: 1200,
                              height: 628,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/b96d13a35e6cb4812d3c1c3c1220369ef51804dd_bd-chahine-gilbert-010-hero.jpg',
                          },
                          views: {},
                        },
                        sharingDescription:
                          'Gilbert Chahine, CEO of @AXAPartners, sheds light on how @AXA leverages its expertise to assist @Accor’s customers through offering free medical support across 5,000 hotels worldwide.',
                        title: '"This health crisis reaffirmed our initial intuition was the right one"',
                        summary:
                          'Starting July, guests of the Accor’s hotels will have access to a free of charge medical support provided by AXA Partners. Gilbert Chahine, CEO of AXA Partners, tells us more about the outlines of this partnership.',
                      },
                    ],
                    author: [
                      {
                        _meta: {},
                      },
                    ],
                    body: [
                      {
                        sliceType: 'cover',
                        sliceLabel: null,
                        _meta: {
                          value: 'NewSlice',
                        },
                        value: {
                          items: [
                            {
                              _meta: {},
                            },
                          ],
                          _meta: {
                            title: 'Text',
                            shortTitle: 'Text',
                            subtitle: 'Text',
                            banner: 'Image',
                          },
                          title: 'AXA & Accor: "This health crisis reaffirmed our initial intuition was the right one"',
                          shortTitle: 'AXA & Accor: "This health crisis reaffirmed our initial intuition was the right one"',
                          subtitle:
                            'Starting July, guests of the Accor’s hotels will have access to a free of charge medical support provided by AXA Partners. Gilbert Chahine, CEO of AXA Partners, tells us more about the outlines of this partnership.',
                          banner: {
                            main: {
                              dimensions: {
                                width: 1920,
                                height: 1280,
                              },
                              alt: '',
                              copyright: '',
                              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/61c8ae5e69d01bbd36c2a36402015e9fb4f36168_bd-chahine-gilbert-010-hero.jpg',
                            },
                            views: {
                              medium: {
                                dimensions: {
                                  width: 970,
                                  height: 576,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/6e6163fdaade0d0f7e88d0d39e7756c7bcbef5e1_bd-chahine-gilbert-010-hero.jpg',
                              },
                              small: {
                                dimensions: {
                                  width: 768,
                                  height: 576,
                                },
                                alt: '',
                                copyright: '',
                                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/30387b79a5316ce2c7a7e9f1402042fdb3dd377a_bd-chahine-gilbert-010-hero.jpg',
                              },
                            },
                          },
                        },
                      },
                      {
                        sliceType: 'paragraph',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              text: 'StructuredText',
                            },
                            text: [
                              {
                                type: 'paragraph',
                                text: 'Why does Accor partner with AXA?',
                                spans: [
                                  {
                                    start: 0,
                                    end: 32,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'AXA brings its ability to provide innovative services and assistance to Accor’s customers, whether in the event of a major crisis, which we are already doing in certain countries, or more simply in the event of an accident, incident or a specific need on the part of customers during their stay at an Accor hotel. We are offering them worldwide access to the highest level of care, leveraging the extensive medical network, expertise and medical solutions we have built at AXA Partners with more than 200 in-house doctors and nurses and over 40,000 medical providers worldwide.',
                                spans: [
                                  {
                                    start: 473,
                                    end: 486,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'What services will be offered and who can benefit from them?',
                                spans: [
                                  {
                                    start: 0,
                                    end: 60,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: "As soon as July, all Accor guests will have access, at any time and free of charge, to AXA Partners' medical network, as well as to medical teleconsultations, around the world. Concretely, our API-integrated interface to Accor’s systems allows their concierge teams to easily find and recommend the most appropriate and nearest physician or hospital for their customers, certified and vetted by our teams. Customers can also opt for a teleconsultation from their room with an English-speaking certified practitioner. This service will be quickly extended to 5 additional languages and will be digitally accessible through “All”, Accor’s application dedicated to its VIP customers.",
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'Has the Covid-19 crisis accelerated the implementation of this partnership?',
                                spans: [
                                  {
                                    start: 0,
                                    end: 75,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'Our discussions with Accor started back in 2019 to explore various opportunities and brainstorm together on ways to partner, given our shared vision of offering the best services to our customers. Interestingly, in our initial plan we were already developing solutions to provide health services and protection to customers during their mobility. The recent coronavirus health crisis reaffirmed that our initial intuition was the right one and meant that we should accelerate the launch date given the relevance of the services in order to expand people’s access to our healthcare expertise and solutions via the Accor networks worldwide.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'How is this in line with AXA’s global strategy?',
                                spans: [
                                  {
                                    start: 0,
                                    end: 47,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'Health is a key area of growth in AXA’s Ambition 2020 plan, and this partnership is a perfect example of how we are extending our Payer-to-Partner strategy by offering innovative health solutions to support travelers in these ever-changing times. With Accor we have also found the perfect partner to tackle broader questions on the future of mobility and services within the hospitality industry. So, the partnership is likely to grow to potentially include new products, services and insurance coverage in the long term.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'How has AXA Partners become a leader in telemedicine services over the past years? ',
                                spans: [
                                  {
                                    start: 0,
                                    end: 83,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'AXA Partners is one of the pioneers in teleconsultation, providing this solution to our customers starting in 2015. The pandemic has accelerated demand for these types of online services among other healthcare solutions we offer. Over the last few months we have seen volumes 3-4 times higher, with over 16,000 requests in France alone. What is impressive is that our teams have been able to manage the higher volume to support our customers during this time with consistent service and quality. In some markets, such as Belgium, we have even opened this service to the general public for free.',
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        sliceType: 'documents',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              attachmentTitle: 'Text',
                              target: 'Link.document',
                              title: 'Text',
                            },
                            attachmentTitle: 'Press release',
                            target: {
                              id: 'Xr4xwhEAAC4ArAYv',
                              type: 'press-release',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            title: 'AXA and Accor launch a strategic partnership',
                          },
                        ],
                      },
                    ],
                    related_articles: [
                      {
                        _meta: {
                          article: 'Link.document',
                        },
                        article: {
                          id: 'XsQ_VREAACwAxsXv',
                          type: 'article-v2',
                          target: 'document',
                          isBroken: false,
                          url: '/not-populated',
                        },
                      },
                    ],
                    url: '/en/magazine/gilbert-chahine-axa-accor',
                    url_en: '/en/magazine/gilbert-chahine-axa-accor',
                    url_fr: '/fr/magazine/gilbert-chahine-axa-accor',
                    prismic: {
                      creationDate: '2020-06-10T07:25:48+0000',
                      updateDate: '2020-06-10T13:04:24+0000',
                    },
                  },
                },
                {
                  article: {
                    type: 'press-release',
                    _tags: [],
                    id: 'XoRT_xMAAC_mQJdg',
                    uid: null,
                    _meta: {
                      slug: 'Text',
                      slug_en: 'Text',
                      slug_fr: 'Text',
                      seoDescription: 'Text',
                      seoDescription_en: 'Text',
                      seoDescription_fr: 'Text',
                      tweet: 'Text',
                      tweet_en: 'Text',
                      tweet_fr: 'Text',
                      sharingDescription: 'Text',
                      sharingDescription_en: 'Text',
                      sharingDescription_fr: 'Text',
                      title: 'Text',
                      title_en: 'Text',
                      title_fr: 'Text',
                      date: 'Timestamp',
                      date_en: 'Timestamp',
                      date_fr: 'Timestamp',
                      document: 'Link.file',
                      documentTitle: 'Text',
                      documentTitle_en: 'Text',
                      documentTitle_fr: 'Text',
                      body: 'SliceZone',
                    },
                    slug: 'covid-19-axa-strengthens-its-commitments-to-tackle-an-unprecedented-health-economic-and-social-challenge',
                    slug_en: 'covid-19-axa-strengthens-its-commitments-to-tackle-an-unprecedented-health-economic-and-social-challenge',
                    slug_fr: 'covid-19-axa-renforce-ses-engagements-pour-repondre-a-un-defi-sanitaire-economique-et-social-inedit',
                    seoDescription:
                      'As the COVID-19 crisis continues to spread globally, AXA today announces the strengthening of its action plan to tackle the health, economic and social emergency.',
                    tweet: 'Covid-19 #AXA strengthens its commitments to tackle an unprecedented health, economic and social challenge',
                    sharingDescription:
                      'As the COVID-19 crisis continues to spread globally, AXA today announces the strengthening of its action plan to tackle the health, economic and social emergency.',
                    title: 'COVID-19: AXA strengthens its commitments to tackle an unprecedented health, economic and social challenge',
                    date: '2020-04-01T13:30:00+0000',
                    document: {
                      file: {
                        name: '2020-04-01 - COVID-19 - AXA strengthens its commitments.pdf',
                        kind: 'document',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fead2164b-729b-444c-903e-692aeccb08be_2020-04-01+-+covid-19+-+axa+strengthens+its+commitments.pdf',
                        size: '332010',
                      },
                      target: 'file',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fead2164b-729b-444c-903e-692aeccb08be_2020-04-01+-+covid-19+-+axa+strengthens+its+commitments.pdf',
                    },
                    documentTitle: 'PDF Format',
                    body: [
                      {
                        sliceType: 'paragraph',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              text: 'StructuredText',
                            },
                            text: [
                              {
                                type: 'paragraph',
                                text: 'As the COVID-19 crisis continues to spread globally, AXA today announces the strengthening of its action plan to tackle the health, economic and social emergency.',
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        sliceType: 'long-quote',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              author: 'Link.document',
                              quote: 'StructuredText',
                            },
                            author: {
                              id: 'Vhe9iRwAABJWde4I',
                              type: 'person',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            quote: [
                              {
                                type: 'paragraph',
                                text: 'The world is going through a crisis that will stand in collective memory. In an unstable environment, AXA has been fully mobilized since the outbreak of the pandemic to respond to two challenges: the health emergency, by protecting its employees and clients, and the economic and social emergency, by ensuring the continuity of a business that is essential to society. In line with our mission, and consistent with the actions taken by public authorities around the world, we are announcing today new commitments to reinforce the impact of initiatives already underway',
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        sliceType: 'paragraph',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              text: 'StructuredText',
                            },
                            text: [
                              {
                                type: 'list-item',
                                text: 'Responding to the economic and social emergency',
                                spans: [
                                  {
                                    start: 0,
                                    end: 47,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'AXA’s 160,000 employees and partners have been available and fully operational, notably thanks to remote working tools, from the start of the crisis to meet client needs and continue to play their role in the economy.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'Jobs maintained, without resorting to short-time working',
                                spans: [
                                  {
                                    start: 0,
                                    end: 56,
                                    type: 'em',
                                  },
                                  {
                                    start: 0,
                                    end: 56,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'AXA announces today that the crisis will have no impact on employment or on the remuneration of employees during the confinement period; AXA will not use temporary unemployment. The Group also undertakes not to defer any social security or tax payments in France during the period.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'AXA is a Group that has its social responsibility at heart and wishes the financial efforts of public authorities to be primarily directed towards the most vulnerable individuals and businesses.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'Exceptional measures for our most affected customers',
                                spans: [
                                  {
                                    start: 0,
                                    end: 52,
                                    type: 'em',
                                  },
                                  {
                                    start: 0,
                                    end: 52,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'These announcements come in addition to exceptional measures that have already been taken to provide flexibility to business customers, particularly SMEs.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'In several countries, including France, the Group will continue to insure businesses even in the event of late payment due to the pandemic, for the duration of the containment period, and will ensure prompt payment to all suppliers to enable them to maintain the cash and liquidity needed to overcome the crisis.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'Euro 37 million for solidarity funds',
                                spans: [
                                  {
                                    start: 0,
                                    end: 36,
                                    type: 'em',
                                  },
                                  {
                                    start: 0,
                                    end: 36,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'AXA will also be the leading contributor, with Euro 27 million, to the solidarity effort coordinated by the Fédération Française de l’Assurance (FFA). In total Euro 200 million will be contributed to the solidarity fund set up by the French government for small businesses and the self-employed.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'This is in addition to AXA partner association AGIPI’s creation of the “AGIPI Covid 19 Solidarity Fund”, endowed with Euro 10 million to support clients experiencing economic difficulties.',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Responding to the health emergency',
                                spans: [
                                  {
                                    start: 0,
                                    end: 34,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'In response to the health emergency, as a major international healthcare company, AXA is committed to directly helping its employees and clients, while supporting medical actions in the regions in which it operates. AXA has extended coverage and services to healthcare professionals in several countries and leveraged its own medical networks and teleconsulting services to contribute to the healthcare effort. Finally, the Group has taken full action to support and compensate its customers affected by the virus.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: '2 million masks distributed as part of an emergency plan to support healthcare professionals',
                                spans: [
                                  {
                                    start: 0,
                                    end: 92,
                                    type: 'em',
                                  },
                                  {
                                    start: 0,
                                    end: 92,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'To strengthen its support for healthcare professionals on the frontline against the virus, AXA announced today that it will provide 2 million masks to help healthcare workers. The first 350,000, which will be sent out in the coming days, and distributed to French hospitals, are much-needed FFP2 masks. AXA France has set up psychological support resources for healthcare workers.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'Support will also be provided to the AP-HP (Assistance Publique-Hôpitaux de Paris), the public hospital system of the city of Paris and the Ile-de-France region. AXA will donate 20,000 meals to the AP-HP care community for lunch or dinner at home.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'These solidarity measures for health professionals come in addition to donations already made to hospitals and intensive care units in several countries. AXA is also supporting intensive care units through a partnership with the 101 Fund, a network of 1200 intensive care centers in over 60 countries, that aims to share real-time information from each unit to accelerate the improvement of therapeutic protocols. This funding will also make it possible to set up accelerated training for caregivers in order to increase the staffing capacity of these units.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'Euro 5 million to fund research on infectious diseases, including COVID-19',
                                spans: [
                                  {
                                    start: 0,
                                    end: 74,
                                    type: 'em',
                                  },
                                  {
                                    start: 0,
                                    end: 74,
                                    type: 'strong',
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'Finally, AXA Research Fund, which has made a steadfast commitment over the years to support research on infectious diseases and pandemics (35 projects from leading institutions worldwide for a total of Euro 7.4 million), has decided to mobilize an additional Euro 5 million for the development of responses to infectious diseases and COVID-19, including the implementation of post-crisis solutions.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: "AXA also supports the creation of the Institut Pasteur's COVID-19 Task Force and the OpenCOVID-19 initiative launched by Just One Giant Lab (JOGL), an open-source research platform aimed at providing low-cost emergency solutions to respond to the pandemic, with a particular focus on low-income countries.",
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        sliceType: 'long-quote',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              author: 'Link.document',
                              quote: 'StructuredText',
                            },
                            author: {
                              id: 'Vhe9iRwAABJWde4I',
                              type: 'person',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            quote: [
                              {
                                type: 'paragraph',
                                text: 'I would like to thank all of our employees and partners who, thanks to their actions and commitments, enable AXA to fulfill all of its operations in an unprecedented context and to provide valuable assistance to those who are fighting the virus on the frontline. More than ever, this crisis confirms what the Group has always worked for: protecting what matters most to society',
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        sliceType: 'contacts',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              contact: 'Link.document',
                            },
                            contact: {
                              id: 'Vl7CqCAAAJEjR7_o',
                              type: 'contact',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              contact: 'Link.document',
                            },
                            contact: {
                              id: 'Veh3JR4AAKAAILFL',
                              type: 'contact',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                        ],
                      },
                    ],
                    url: '/en/press/press-releases/covid-19-axa-strengthens-its-commitments-to-tackle-an-unprecedented-health-economic-and-social-challenge',
                    url_en: '/en/press/press-releases/covid-19-axa-strengthens-its-commitments-to-tackle-an-unprecedented-health-economic-and-social-challenge',
                    url_fr: '/fr/presse/communiques-de-presse/covid-19-axa-renforce-ses-engagements-pour-repondre-a-un-defi-sanitaire-economique-et-social-inedit',
                    prismic: {
                      creationDate: '2020-04-01T13:30:20+0000',
                      updateDate: '2020-04-01T14:19:07+0000',
                    },
                  },
                },
              ],
              url: '/en/magazine/alban-risk-covid19',
              url_en: '/en/magazine/alban-risk-covid19',
              url_fr: '/fr/magazine/alban-risque-covid19',
              prismic: {
                creationDate: '2020-06-10T07:25:48+0000',
                updateDate: '2020-06-10T13:01:47+0000',
              },
            },
            image: {
              main: {
                dimensions: {
                  width: 1920,
                  height: 1080,
                },
                alt: '',
                copyright: '',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/16f387436a2c4cabb34bd9edecca90b36bae3b5f_alban_1200x628.jpg',
              },
              views: {
                medium: {
                  dimensions: {
                    width: 970,
                    height: 545,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/52c6edf34754960a8579ce88663b59315d69fdc2_alban_1200x628.jpg',
                },
                small: {
                  dimensions: {
                    width: 768,
                    height: 432,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/24f394a801e6b60d490d273028b6b3832593c170_alban_1200x628.jpg',
                },
              },
            },
          },
        ],
        title: 'Top of mind',
        item1title: 'AXA and Accor: offering unique medical assistance in hotels',
        item1subtitle: 'AXA and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
        item1primaryButtonName: 'Press release',
        item1primaryButtonLink: {
          type: 'press-release',
          _tags: [],
          id: 'Xr4xwhEAAC4ArAYv',
          uid: null,
          slug: 'axa-and-accor-launch-a-strategic-partnership-to-offer-unique-medical-assistance-in-hotels-worldwide',
          slug_en: 'axa-and-accor-launch-a-strategic-partnership-to-offer-unique-medical-assistance-in-hotels-worldwide',
          slug_fr: 'axa-et-accor-lancent-un-partenariat-strategique-afin-d-offrir-une-assistance-medicale-inegalee-dans-les-hotels-du-monde-entier',
          seoDescription:
            'AXA, a global leader in insurance, and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
          tweet: '#AXA and Accor launch a strategic partnership to offer unique medical assistance in hotels worldwide',
          sharingDescription:
            'AXA, a global leader in insurance, and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
          title: 'AXA and Accor launch a strategic partnership to offer unique medical assistance in hotels worldwide',
          date: '2020-05-15T06:45:00+0000',
          document: {
            file: {
              name: '2020-05-15 - AXA and Accor launch a strategic partnership.pdf',
              kind: 'document',
              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fbb4054ec-9dd9-40ad-aa4d-a383161fe5c7_2020-05-15+-+axa+and+accor+launch+a+strategic+partnership.pdf',
              size: '334566',
            },
            target: 'file',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fbb4054ec-9dd9-40ad-aa4d-a383161fe5c7_2020-05-15+-+axa+and+accor+launch+a+strategic+partnership.pdf',
          },
          documentTitle: 'PDF Format',
          body: [
            {
              sliceType: 'paragraph',
              sliceLabel: null,
              value: [
                {
                  text: [
                    {
                      type: 'paragraph',
                      text: 'AXA, a global leader in insurance, and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
                      spans: [],
                    },
                    {
                      type: 'paragraph',
                      text: 'As soon as July 2020, this partnership will enable Accor guests to benefit from the highest level of care thanks to the expert medical solutions of AXA Partners, AXA’s international entity specialized in assistance services, travel insurance and credit protection.',
                      spans: [],
                    },
                    {
                      type: 'paragraph',
                      text: 'First and foremost, Accor guests will benefit from AXA’s most recent advances in telemedicine through free access to medical teleconsultations. Guests will also get access to AXA’s extensive medical networks with tens of thousands of vetted medical professionals. This will allow hotels to make the most relevant referrals (eg language, speciality, etc..) to their guests in the 110 destinations where Accor is present.',
                      spans: [],
                    },
                    {
                      type: 'paragraph',
                      text: 'As Accor prepares for the post COVID-19 rebound, this unique medical service complements its overall global recovery plan and is included in the enhanced health and prevention protocols that Accor has put in place notably through its ALLSAFE Cleanliness label in anticipation of the progressive reopening of its hotels across the different regions.',
                      spans: [
                        {
                          start: 234,
                          end: 253,
                          type: 'hyperlink',
                          data: {
                            type: 'Link.web',
                            value: {
                              url: 'https://group.accor.com/en/Actualites/2020/05/allsafe-cleanliness-prevention-label',
                            },
                          },
                        },
                      ],
                    },
                    {
                      type: 'paragraph',
                      text: 'For AXA, this partnership is a unique occasion to strengthen its payer to partner strategy, which aims to provide innovative services to its customers, notably in health, one of its areas of growth in its Ambition 2020 plan.',
                      spans: [],
                    },
                  ],
                },
              ],
            },
            {
              sliceType: 'long-quote',
              sliceLabel: null,
              value: [
                {
                  authorName: 'Sébastien Bazin',
                  authorRole: 'Chairman and CEO of Accor',
                  quote: [
                    {
                      type: 'paragraph',
                      text: 'Welcoming, safeguarding and taking care of others is at the very heart of what we do and who we are as hoteliers. This distinctive partnership with AXA which we have been working on for several months makes even more sense in today’s context. In an increasingly complex environment, our 300.000 team members on the ground will be able to assist our guests and ensure their safety during their stays, turning our hotels into shelters. This initiative combined with our ALLSAFE enhanced hygiene protocols, will be key to rediscover the Love of Travel in the 5000 Accor properties around the world.',
                      spans: [],
                    },
                  ],
                },
              ],
            },
            {
              sliceType: 'long-quote',
              sliceLabel: null,
              value: [
                {
                  author: {
                    type: 'person',
                    _tags: ['Health insurance', 'Team'],
                    id: 'Vhe9iRwAABJWde4I',
                    uid: null,
                    _meta: {
                      avatar: 'Image',
                      lastname: 'Text',
                      lastname_en: 'Text',
                      lastname_fr: 'Text',
                      firstname: 'Text',
                      firstname_en: 'Text',
                      firstname_fr: 'Text',
                      slug: 'Text',
                      slug_en: 'Text',
                      slug_fr: 'Text',
                      seoDescription: 'Text',
                      seoDescription_en: 'Text',
                      seoDescription_fr: 'Text',
                      sharingImage: 'Image',
                      role: 'Text',
                      role_en: 'Text',
                      role_fr: 'Text',
                      shortRole: 'Text',
                      shortRole_en: 'Text',
                      shortRole_fr: 'Text',
                      organizationLink: 'Group',
                      twitter: 'Text',
                      twitter_en: 'Text',
                      twitter_fr: 'Text',
                      linkedin: 'Text',
                      linkedin_en: 'Text',
                      linkedin_fr: 'Text',
                      birthdate: 'Date',
                      nationality: 'Text',
                      nationality_en: 'Text',
                      nationality_fr: 'Text',
                      content: 'SliceZone',
                    },
                    avatar: {
                      main: {
                        dimensions: {
                          width: 100,
                          height: 100,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/2a6c3ce22017732579a2b6ce7cc1a5ee246e6816_thomas-buberl.png',
                      },
                      views: {},
                    },
                    lastname: 'Buberl',
                    firstname: 'Thomas',
                    slug: 'thomas-buberl',
                    slug_en: 'thomas-buberl',
                    slug_fr: 'thomas-buberl',
                    seoDescription: 'Biography of Thomas Buberl',
                    sharingImage: {
                      main: {
                        dimensions: {
                          width: 1200,
                          height: 630,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/9c25e575e30c174bc7f0850a9fb99c95f87d04c5_thomas-buberl.png',
                      },
                      views: {
                        twitter: {
                          dimensions: {
                            width: 120,
                            height: 120,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/26db25fe1a9ae123a3fc7adc244f1e38e4991bc5_thomas-buberl.png',
                        },
                        facebook: {
                          dimensions: {
                            width: 600,
                            height: 315,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f63a3b129c84789edf74f7df050d9fdb526c8c25_thomas-buberl.png',
                        },
                        linkedin: {
                          dimensions: {
                            width: 180,
                            height: 110,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/610dab8b7ac3a328408f2f13de2eafce00862b8a_thomas-buberl.png',
                        },
                      },
                    },
                    role: 'Chief Executive Officer of AXA',
                    shortRole: 'Chief Executive Officer of AXA',
                    organizationLink: [
                      {
                        _meta: {
                          organizationChart: 'Link.document',
                          organizationRanking: 'Number',
                        },
                        organizationChart: {
                          id: 'VidrvBwAAPEhicwJ',
                          type: 'organization-chart',
                          target: 'document',
                          isBroken: false,
                          url: '/not-populated',
                        },
                        organizationRanking: 1,
                      },
                      {
                        _meta: {
                          organizationChart: 'Link.document',
                          organizationRanking: 'Number',
                        },
                        organizationChart: {
                          id: 'Ve2VAh4AAABIP2Fd',
                          type: 'organization-chart',
                          target: 'document',
                          isBroken: false,
                          url: '/not-populated',
                        },
                        organizationRanking: 2,
                      },
                    ],
                    twitter: 'https://twitter.com/thomasbuberl',
                    linkedin: 'https://www.linkedin.com/in/thomas-buberl-13a30b61/?ppe=1',
                    birthdate: '1973-03-24',
                    nationality: 'German and Swiss nationalities',
                    content: [
                      {
                        sliceType: 'paragraph',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              text: 'StructuredText',
                            },
                            text: [
                              {
                                type: 'heading2',
                                text: 'Directorship and number of AXA shares',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: "Appointed on April 25, 2018 - Term expires at the 2022 Shareholders' Meeting",
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'First appointment on September 1, 2016',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Number of AXA shares held on December 31, 2019: 320,305',
                                spans: [],
                              },
                              {
                                type: 'heading3',
                                text: 'On April 28, 2020',
                                spans: [],
                              },
                              {
                                type: 'heading2',
                                text: 'Expertise and experience',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'Mr. Thomas Buberl holds a Master of Economics degree from WHU Koblenz (Germany), a MBA from Lancaster University (UK) and a Ph.D. in Economics from the University of St Gallen (Switzerland). In 2008 he was nominated as a Young Global Leader by the World Economic Forum. From 2000 to 2005, Mr. Thomas Buberl worked at the Boston Consulting Group as a consultant for the banking & insurance sector in Germany and abroad. From 2005 to 2008, he had worked for the Winterthur Group as member of the Management Board of Winterthur in Switzerland, first as Chief Operating Officer and then as Chief Marketing and Distribution Officer. Then, he joined Zurich Financial Services where he had been Chief Executive Officer for Switzerland. From 2012 to April 2016, he was Chief Executive Officer of AXA Konzern AG (Germany). In 2012, he has been member of the AXA Executive Committee. In March 2015, he became Chief Executive Officer of the Global Business Line for the Health Business and joined the AXA Management Committee. In January 2016, Mr. Thomas Buberl was also appointed Chief Executive Officer of the global business line Life & Savings. From March 21, 2016 to August 31, 2016, Mr. Thomas Buberl was Deputy Chief Executive Officer (Directeur Général Adjoint ) of AXA. Since September 1, 2016, Mr. Thomas Buberl has been Chief Executive Officer and director of AXA.',
                                spans: [
                                  {
                                    start: 1232,
                                    end: 1258,
                                    type: 'em',
                                  },
                                ],
                              },
                              {
                                type: 'heading3',
                                text: '',
                                spans: [],
                              },
                              {
                                type: 'heading2',
                                text: 'Directorships held within the AXA Group',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Director and Chief Executive Officer: AXA',
                                spans: [],
                              },
                              {
                                type: 'heading2',
                                text: 'Directorships held outside the AXA Group (1)',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Director or member of the Supervisory Board: Bertelsmann SE & Co. KGaA (Germany), IBM (United States)',
                                spans: [],
                              },
                              {
                                type: 'heading2',
                                text: 'Directorships held during the last five years',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Chairman of the Management Board: AXA Konzern AG (Germany), AXA Krankenversicherung AG (Germany), AXA Lebensversicherung AG (Germany), AXA Versicherung AG (Germany), DBV Deutsche Beamtenversicherung AG (Germany)',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Chairman of the Board of Directors: AXA Equitable Holdings, Inc. (United States), AXA Financial, Inc. (United States), AXA Leben AG (Switzerland), AXA Versicherungen AG (Switzerland), XL Group Ltd (Bermuda)',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Chairman of the Supervisory Board: AXA Konzern AG (Germany), AXA Krankenversicherung AG (Germany), AXA Lebensversicherung AG (Germany), AXA Versicherung AG (Germany), Deutsche Ärzteversicherung AG (Germany)',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Deputy Chairman of the Supervisory Board: Roland Rechtsschutz-Versicherungs-AG (Germany)',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Managing Director and Chief Executive Officer: Vinci B.V. (the Netherlands)',
                                spans: [],
                              },
                              {
                                type: 'list-item',
                                text: 'Director or member of the Management Committee or member of the Supervisory Board: AXA ASIA (SAS), AXA ART Versicherung AG (Germany), AXA Equitable Holdings, Inc. (United States), AXA Equitable Life Insurance Company (United States), AXA Life Insurance Co. Ltd (Japan), MONY Life Insurance Company of America (United States), Tertia GmbH (Germany).',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: '',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: "(1) Mr. Thomas Buberl requested the Board of Directors' approval before accepting new directorships in companies outside the AXA Group.",
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                    ],
                    url: '/en/about-us/profile/thomas-buberl',
                    url_en: '/en/about-us/profile/thomas-buberl',
                    url_fr: '/fr/a-propos-d-axa/profil/thomas-buberl',
                    prismic: {
                      creationDate: null,
                      updateDate: '2020-05-20T15:55:56+0000',
                    },
                  },
                  quote: [
                    {
                      type: 'paragraph',
                      text: 'AXA’s ambition is to move from a payer to a partner with its customers, notably by providing them with innovative solutions in health. This is why AXA has become over the last year a world leader in telemedicine solutions. Partnering with Accor, a worldwide leader in hospitality, is a unique opportunity to enlarge people’s access to our healthcare expertise and solutions. As we are facing an unprecedented health crisis with Covid-19, this ambition has never been more relevant.',
                      spans: [],
                    },
                  ],
                },
              ],
            },
            {
              sliceType: 'contacts',
              sliceLabel: null,
              value: [
                {
                  contact: {
                    type: 'contact',
                    _tags: [],
                    id: 'Vl7CqCAAAJEjR7_o',
                    uid: null,
                    _meta: {
                      name: 'Text',
                      name_en: 'Text',
                      name_fr: 'Text',
                      section: 'Text',
                      section_en: 'Text',
                      section_fr: 'Text',
                      phone: 'Text',
                      phone_en: 'Text',
                      phone_fr: 'Text',
                    },
                    name: 'Investor Relations team',
                    section: 'Investor Relations',
                    phone: '+33 1 40 75 48 42',
                    url: '/not-resolved',
                    url_en: '/not-resolved',
                    url_fr: '/not-resolved',
                    prismic: {
                      creationDate: null,
                      updateDate: null,
                    },
                  },
                },
                {
                  contact: {
                    type: 'contact',
                    _tags: ['Contact'],
                    id: 'Veh3JR4AAKAAILFL',
                    uid: null,
                    _meta: {
                      name: 'Text',
                      name_en: 'Text',
                      name_fr: 'Text',
                      section: 'Text',
                      section_en: 'Text',
                      section_fr: 'Text',
                      phone: 'Text',
                      phone_en: 'Text',
                      phone_fr: 'Text',
                    },
                    name: 'Axa Media Relations',
                    section: 'Media relations',
                    phone: '+33.1.40.75.46.68',
                    url: '/not-resolved',
                    url_en: '/not-resolved',
                    url_fr: '/not-resolved',
                    prismic: {
                      creationDate: null,
                      updateDate: null,
                    },
                  },
                },
              ],
            },
          ],
          url: '/en/press/press-releases/axa-and-accor-launch-a-strategic-partnership-to-offer-unique-medical-assistance-in-hotels-worldwide',
          url_en: '/en/press/press-releases/axa-and-accor-launch-a-strategic-partnership-to-offer-unique-medical-assistance-in-hotels-worldwide',
          url_fr: '/fr/presse/communiques-de-presse/axa-et-accor-lancent-un-partenariat-strategique-afin-d-offrir-une-assistance-medicale-inegalee-dans-les-hotels-du-monde-entier',
          prismic: {
            creationDate: '2020-05-15T06:45:12+0000',
            updateDate: '2020-05-15T06:45:12+0000',
          },
        },
        item1secondaryButtonName: 'Interview with Gilbert Chahine, CEO of AXA Partners',
        item1secondaryButtonLink: {
          type: 'article-v2',
          _tags: [],
          id: 'Xr1PlREAACwAqCDD',
          uid: null,
          slug: 'gilbert-chahine-axa-accor',
          slug_en: 'gilbert-chahine-axa-accor',
          slug_fr: 'gilbert-chahine-axa-accor',
          theme: {
            type: 'theme-v2',
            _tags: [],
            id: 'XqA6xhMAAGKnu7Y2',
            uid: null,
            _meta: {
              slug: 'Text',
              slug_en: 'Text',
              slug_fr: 'Text',
              metaContent: 'Group',
              description: 'StructuredText',
              highlighted_article: 'Link.document',
              highlighted_article_en: 'Link.document',
              highlighted_article_fr: 'Link.document',
            },
            slug: 'covid',
            slug_en: 'covid',
            slug_fr: 'covid',
            metaContent: [
              {
                _meta: {
                  title: 'Text',
                },
                title: 'Covid-19',
              },
            ],
            description: [
              {
                type: 'paragraph',
                text: '',
                spans: [],
              },
            ],
            highlighted_article: {
              id: 'Xp_uLBMAADUMumYG',
              type: 'article-v2',
              target: 'document',
              isBroken: false,
              url: '/not-populated',
            },
            url: '/en/theme/covid',
            url_en: '/en/theme/covid',
            url_fr: '/fr/theme/covid',
            prismic: {
              creationDate: '2020-04-22T12:39:33+0000',
              updateDate: '2020-04-22T14:50:45+0000',
            },
          },
          date: '2020-06-09T22:00:00+0000',
          typeArticle: 'Press-Magazine',
          metaContent: [
            {
              seoDescription: 'This health crisis reaffirmed our initial intuition was the right one',
              tweet:
                'Gilbert Chahine, CEO of @AXAPartners, sheds light on how @AXA leverages its expertise to assist @Accor’s customers through offering free medical support across 5,000 hotels worldwide.',
              sharingImage: {
                main: {
                  dimensions: {
                    width: 1200,
                    height: 628,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/b96d13a35e6cb4812d3c1c3c1220369ef51804dd_bd-chahine-gilbert-010-hero.jpg',
                },
                views: {},
              },
              sharingDescription:
                'Gilbert Chahine, CEO of @AXAPartners, sheds light on how @AXA leverages its expertise to assist @Accor’s customers through offering free medical support across 5,000 hotels worldwide.',
              title: '"This health crisis reaffirmed our initial intuition was the right one"',
              summary:
                'Starting July, guests of the Accor’s hotels will have access to a free of charge medical support provided by AXA Partners. Gilbert Chahine, CEO of AXA Partners, tells us more about the outlines of this partnership.',
            },
          ],
          author: [{}],
          body: [
            {
              sliceType: 'cover',
              sliceLabel: null,
              value: {
                items: [{}],
                title: 'AXA & Accor: "This health crisis reaffirmed our initial intuition was the right one"',
                shortTitle: 'AXA & Accor: "This health crisis reaffirmed our initial intuition was the right one"',
                subtitle:
                  'Starting July, guests of the Accor’s hotels will have access to a free of charge medical support provided by AXA Partners. Gilbert Chahine, CEO of AXA Partners, tells us more about the outlines of this partnership.',
                banner: {
                  main: {
                    dimensions: {
                      width: 1920,
                      height: 1280,
                    },
                    alt: '',
                    copyright: '',
                    url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/61c8ae5e69d01bbd36c2a36402015e9fb4f36168_bd-chahine-gilbert-010-hero.jpg',
                  },
                  views: {
                    medium: {
                      dimensions: {
                        width: 970,
                        height: 576,
                      },
                      alt: '',
                      copyright: '',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/6e6163fdaade0d0f7e88d0d39e7756c7bcbef5e1_bd-chahine-gilbert-010-hero.jpg',
                    },
                    small: {
                      dimensions: {
                        width: 768,
                        height: 576,
                      },
                      alt: '',
                      copyright: '',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/30387b79a5316ce2c7a7e9f1402042fdb3dd377a_bd-chahine-gilbert-010-hero.jpg',
                    },
                  },
                },
              },
            },
            {
              sliceType: 'paragraph',
              sliceLabel: null,
              value: [
                {
                  text: [
                    {
                      type: 'paragraph',
                      text: 'Why does Accor partner with AXA?',
                      spans: [
                        {
                          start: 0,
                          end: 32,
                          type: 'strong',
                        },
                      ],
                    },
                    {
                      type: 'paragraph',
                      text: 'AXA brings its ability to provide innovative services and assistance to Accor’s customers, whether in the event of a major crisis, which we are already doing in certain countries, or more simply in the event of an accident, incident or a specific need on the part of customers during their stay at an Accor hotel. We are offering them worldwide access to the highest level of care, leveraging the extensive medical network, expertise and medical solutions we have built at AXA Partners with more than 200 in-house doctors and nurses and over 40,000 medical providers worldwide.',
                      spans: [
                        {
                          start: 473,
                          end: 486,
                          type: 'strong',
                        },
                      ],
                    },
                    {
                      type: 'paragraph',
                      text: 'What services will be offered and who can benefit from them?',
                      spans: [
                        {
                          start: 0,
                          end: 60,
                          type: 'strong',
                        },
                      ],
                    },
                    {
                      type: 'paragraph',
                      text: "As soon as July, all Accor guests will have access, at any time and free of charge, to AXA Partners' medical network, as well as to medical teleconsultations, around the world. Concretely, our API-integrated interface to Accor’s systems allows their concierge teams to easily find and recommend the most appropriate and nearest physician or hospital for their customers, certified and vetted by our teams. Customers can also opt for a teleconsultation from their room with an English-speaking certified practitioner. This service will be quickly extended to 5 additional languages and will be digitally accessible through “All”, Accor’s application dedicated to its VIP customers.",
                      spans: [],
                    },
                    {
                      type: 'paragraph',
                      text: 'Has the Covid-19 crisis accelerated the implementation of this partnership?',
                      spans: [
                        {
                          start: 0,
                          end: 75,
                          type: 'strong',
                        },
                      ],
                    },
                    {
                      type: 'paragraph',
                      text: 'Our discussions with Accor started back in 2019 to explore various opportunities and brainstorm together on ways to partner, given our shared vision of offering the best services to our customers. Interestingly, in our initial plan we were already developing solutions to provide health services and protection to customers during their mobility. The recent coronavirus health crisis reaffirmed that our initial intuition was the right one and meant that we should accelerate the launch date given the relevance of the services in order to expand people’s access to our healthcare expertise and solutions via the Accor networks worldwide.',
                      spans: [],
                    },
                    {
                      type: 'paragraph',
                      text: 'How is this in line with AXA’s global strategy?',
                      spans: [
                        {
                          start: 0,
                          end: 47,
                          type: 'strong',
                        },
                      ],
                    },
                    {
                      type: 'paragraph',
                      text: 'Health is a key area of growth in AXA’s Ambition 2020 plan, and this partnership is a perfect example of how we are extending our Payer-to-Partner strategy by offering innovative health solutions to support travelers in these ever-changing times. With Accor we have also found the perfect partner to tackle broader questions on the future of mobility and services within the hospitality industry. So, the partnership is likely to grow to potentially include new products, services and insurance coverage in the long term.',
                      spans: [],
                    },
                    {
                      type: 'paragraph',
                      text: 'How has AXA Partners become a leader in telemedicine services over the past years? ',
                      spans: [
                        {
                          start: 0,
                          end: 83,
                          type: 'strong',
                        },
                      ],
                    },
                    {
                      type: 'paragraph',
                      text: 'AXA Partners is one of the pioneers in teleconsultation, providing this solution to our customers starting in 2015. The pandemic has accelerated demand for these types of online services among other healthcare solutions we offer. Over the last few months we have seen volumes 3-4 times higher, with over 16,000 requests in France alone. What is impressive is that our teams have been able to manage the higher volume to support our customers during this time with consistent service and quality. In some markets, such as Belgium, we have even opened this service to the general public for free.',
                      spans: [],
                    },
                  ],
                },
              ],
            },
            {
              sliceType: 'documents',
              sliceLabel: null,
              value: [
                {
                  attachmentTitle: 'Press release',
                  target: {
                    type: 'press-release',
                    _tags: [],
                    id: 'Xr4xwhEAAC4ArAYv',
                    uid: null,
                    _meta: {
                      slug: 'Text',
                      slug_en: 'Text',
                      slug_fr: 'Text',
                      seoDescription: 'Text',
                      seoDescription_en: 'Text',
                      seoDescription_fr: 'Text',
                      tweet: 'Text',
                      tweet_en: 'Text',
                      tweet_fr: 'Text',
                      sharingDescription: 'Text',
                      sharingDescription_en: 'Text',
                      sharingDescription_fr: 'Text',
                      title: 'Text',
                      title_en: 'Text',
                      title_fr: 'Text',
                      date: 'Timestamp',
                      date_en: 'Timestamp',
                      date_fr: 'Timestamp',
                      document: 'Link.file',
                      documentTitle: 'Text',
                      documentTitle_en: 'Text',
                      documentTitle_fr: 'Text',
                      body: 'SliceZone',
                    },
                    slug: 'axa-and-accor-launch-a-strategic-partnership-to-offer-unique-medical-assistance-in-hotels-worldwide',
                    slug_en: 'axa-and-accor-launch-a-strategic-partnership-to-offer-unique-medical-assistance-in-hotels-worldwide',
                    slug_fr: 'axa-et-accor-lancent-un-partenariat-strategique-afin-d-offrir-une-assistance-medicale-inegalee-dans-les-hotels-du-monde-entier',
                    seoDescription:
                      'AXA, a global leader in insurance, and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
                    tweet: '#AXA and Accor launch a strategic partnership to offer unique medical assistance in hotels worldwide',
                    sharingDescription:
                      'AXA, a global leader in insurance, and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
                    title: 'AXA and Accor launch a strategic partnership to offer unique medical assistance in hotels worldwide',
                    date: '2020-05-15T06:45:00+0000',
                    document: {
                      file: {
                        name: '2020-05-15 - AXA and Accor launch a strategic partnership.pdf',
                        kind: 'document',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fbb4054ec-9dd9-40ad-aa4d-a383161fe5c7_2020-05-15+-+axa+and+accor+launch+a+strategic+partnership.pdf',
                        size: '334566',
                      },
                      target: 'file',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fbb4054ec-9dd9-40ad-aa4d-a383161fe5c7_2020-05-15+-+axa+and+accor+launch+a+strategic+partnership.pdf',
                    },
                    documentTitle: 'PDF Format',
                    body: [
                      {
                        sliceType: 'paragraph',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              text: 'StructuredText',
                            },
                            text: [
                              {
                                type: 'paragraph',
                                text: 'AXA, a global leader in insurance, and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'As soon as July 2020, this partnership will enable Accor guests to benefit from the highest level of care thanks to the expert medical solutions of AXA Partners, AXA’s international entity specialized in assistance services, travel insurance and credit protection.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'First and foremost, Accor guests will benefit from AXA’s most recent advances in telemedicine through free access to medical teleconsultations. Guests will also get access to AXA’s extensive medical networks with tens of thousands of vetted medical professionals. This will allow hotels to make the most relevant referrals (eg language, speciality, etc..) to their guests in the 110 destinations where Accor is present.',
                                spans: [],
                              },
                              {
                                type: 'paragraph',
                                text: 'As Accor prepares for the post COVID-19 rebound, this unique medical service complements its overall global recovery plan and is included in the enhanced health and prevention protocols that Accor has put in place notably through its ALLSAFE Cleanliness label in anticipation of the progressive reopening of its hotels across the different regions.',
                                spans: [
                                  {
                                    start: 234,
                                    end: 253,
                                    type: 'hyperlink',
                                    data: {
                                      type: 'Link.web',
                                      value: {
                                        url: 'https://group.accor.com/en/Actualites/2020/05/allsafe-cleanliness-prevention-label',
                                      },
                                    },
                                  },
                                ],
                              },
                              {
                                type: 'paragraph',
                                text: 'For AXA, this partnership is a unique occasion to strengthen its payer to partner strategy, which aims to provide innovative services to its customers, notably in health, one of its areas of growth in its Ambition 2020 plan.',
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        sliceType: 'long-quote',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              authorName: 'Text',
                              authorRole: 'Text',
                              quote: 'StructuredText',
                            },
                            authorName: 'Sébastien Bazin',
                            authorRole: 'Chairman and CEO of Accor',
                            quote: [
                              {
                                type: 'paragraph',
                                text: 'Welcoming, safeguarding and taking care of others is at the very heart of what we do and who we are as hoteliers. This distinctive partnership with AXA which we have been working on for several months makes even more sense in today’s context. In an increasingly complex environment, our 300.000 team members on the ground will be able to assist our guests and ensure their safety during their stays, turning our hotels into shelters. This initiative combined with our ALLSAFE enhanced hygiene protocols, will be key to rediscover the Love of Travel in the 5000 Accor properties around the world.',
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        sliceType: 'long-quote',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              author: 'Link.document',
                              quote: 'StructuredText',
                            },
                            author: {
                              id: 'Vhe9iRwAABJWde4I',
                              type: 'person',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                            quote: [
                              {
                                type: 'paragraph',
                                text: 'AXA’s ambition is to move from a payer to a partner with its customers, notably by providing them with innovative solutions in health. This is why AXA has become over the last year a world leader in telemedicine solutions. Partnering with Accor, a worldwide leader in hospitality, is a unique opportunity to enlarge people’s access to our healthcare expertise and solutions. As we are facing an unprecedented health crisis with Covid-19, this ambition has never been more relevant.',
                                spans: [],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        sliceType: 'contacts',
                        sliceLabel: null,
                        _meta: {
                          value: 'Group',
                        },
                        value: [
                          {
                            _meta: {
                              contact: 'Link.document',
                            },
                            contact: {
                              id: 'Vl7CqCAAAJEjR7_o',
                              type: 'contact',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                          {
                            _meta: {
                              contact: 'Link.document',
                            },
                            contact: {
                              id: 'Veh3JR4AAKAAILFL',
                              type: 'contact',
                              target: 'document',
                              isBroken: false,
                              url: '/not-populated',
                            },
                          },
                        ],
                      },
                    ],
                    url: '/en/press/press-releases/axa-and-accor-launch-a-strategic-partnership-to-offer-unique-medical-assistance-in-hotels-worldwide',
                    url_en: '/en/press/press-releases/axa-and-accor-launch-a-strategic-partnership-to-offer-unique-medical-assistance-in-hotels-worldwide',
                    url_fr: '/fr/presse/communiques-de-presse/axa-et-accor-lancent-un-partenariat-strategique-afin-d-offrir-une-assistance-medicale-inegalee-dans-les-hotels-du-monde-entier',
                    prismic: {
                      creationDate: '2020-05-15T06:45:12+0000',
                      updateDate: '2020-05-15T06:45:12+0000',
                    },
                  },
                  title: 'AXA and Accor launch a strategic partnership',
                },
              ],
            },
          ],
          related_articles: [
            {
              article: {
                type: 'article-v2',
                _tags: [],
                id: 'XsQ_VREAACwAxsXv',
                uid: null,
                _meta: {
                  slug: 'Text',
                  slug_en: 'Text',
                  slug_fr: 'Text',
                  theme: 'Link.document',
                  theme_en: 'Link.document',
                  theme_fr: 'Link.document',
                  date: 'Timestamp',
                  date_en: 'Timestamp',
                  date_fr: 'Timestamp',
                  typeArticle: 'Select',
                  typeArticle_en: 'Select',
                  typeArticle_fr: 'Select',
                  metaContent: 'Group',
                  author: 'Group',
                  body: 'SliceZone',
                  related_articles: 'Group',
                },
                slug: 'alban-risk-covid19',
                slug_en: 'alban-risk-covid19',
                slug_fr: 'alban-risque-covid19',
                theme: {
                  id: 'XqA6xhMAAGKnu7Y2',
                  type: 'theme-v2',
                  target: 'document',
                  isBroken: false,
                  url: '/not-populated',
                },
                date: '2020-06-09T22:00:00+0000',
                typeArticle: 'Press-Magazine',
                metaContent: [
                  {
                    _meta: {
                      seoDescription: 'Text',
                      tweet: 'Text',
                      sharingImage: 'Image',
                      sharingDescription: 'Text',
                      title: 'Text',
                      summary: 'Text',
                    },
                    seoDescription: 'Covid-19 crisis: a tipping point for the insurance sector?',
                    tweet:
                      '"This crisis may be a tipping point for insurers. It has revealed a transformation in the nature of risks which require strong insurers to absorb the shocks & understand the risks, and @AXA is one of them." Alban de Mailly Nesle, #AXA Chief Risk & Investment Officer.',
                    sharingImage: {
                      main: {
                        dimensions: {
                          width: 1200,
                          height: 628,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/2c2a70941565a75e85e4519e3777076ff341dcc5_alban_1200x628.jpg',
                      },
                      views: {},
                    },
                    sharingDescription:
                      '"This crisis may be a tipping point for insurers. It has revealed a transformation in the nature of risks which require strong insurers to absorb the shocks and @AXA is one of them." Alban de Mailly Nesle, #AXA Chief Risk & Investment Officer.',
                    title: 'Covid-19 crisis: a tipping point for the insurance sector?',
                    summary:
                      'Alban de Mailly Nesle, AXA Chief Risk and Investment Officer, explains why the Covid-19 crisis could be a tipping point for the insurance industry, with long lasting consequences on how insurers anticipate and cover large risks.',
                  },
                ],
                author: [
                  {
                    _meta: {},
                  },
                ],
                body: [
                  {
                    sliceType: 'cover',
                    sliceLabel: null,
                    _meta: {
                      value: 'NewSlice',
                    },
                    value: {
                      items: [
                        {
                          _meta: {},
                        },
                      ],
                      _meta: {
                        title: 'Text',
                        shortTitle: 'Text',
                        subtitle: 'Text',
                        banner: 'Image',
                      },
                      title: 'Covid-19 crisis: a tipping point for the insurance sector?',
                      shortTitle: 'Covid-19 crisis: a tipping point for the insurance sector?',
                      subtitle:
                        'Alban de Mailly Nesle, AXA Chief Risk and Investment Officer, explains why the Covid-19 crisis could be a tipping point for the industry, with long lasting consequences on how insurers anticipate and cover large risks.',
                      banner: {
                        main: {
                          dimensions: {
                            width: 1920,
                            height: 1280,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d76ff975ea6e2d555e270b8e020f8e06416194d2_albanmaillynesle.jpg',
                        },
                        views: {
                          small: {
                            dimensions: {
                              width: 768,
                              height: 576,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d6c16f2545f0623dfc853bddb29b9d368b5995c1_albanmaillynesle.jpg',
                          },
                          medium: {
                            dimensions: {
                              width: 970,
                              height: 576,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/9be321a3863b4a6c7b0ea6a27adb512bf2dd2a43_albanmaillynesle.jpg',
                          },
                        },
                      },
                    },
                  },
                  {
                    sliceType: 'paragraph',
                    sliceLabel: null,
                    _meta: {
                      value: 'Group',
                    },
                    value: [
                      {
                        _meta: {
                          text: 'StructuredText',
                        },
                        text: [
                          {
                            type: 'paragraph',
                            text: 'As Director of Risks and Investments, what is your vision of the Covid-19 crisis?',
                            spans: [
                              {
                                start: 0,
                                end: 81,
                                type: 'strong',
                              },
                            ],
                          },
                          {
                            type: 'paragraph',
                            text: 'It\'s a new situation. This crisis is unique. While we often deal with disasters that can be serious but are most often limited in their occurrence and spread, we are witnessing a "total" crisis here: almost all countries are affected simultaneously, with more than half of the world\'s population confined to their homes, and economies at a standstill. \nIt is also a complex crisis. It is a health crisis, it has put our health systems under strain, causing more than 350,000 deaths to date. It is an economic crisis; the shutdown of our economies has sparked one of the worst recessions since WWII. It could become social, or even political, depending on the extent of the shock and the way in which governments respond to it. ',
                            spans: [],
                          },
                          {
                            type: 'paragraph',
                            text: 'Are you surprised by this crisis? ',
                            spans: [
                              {
                                start: 0,
                                end: 34,
                                type: 'strong',
                              },
                            ],
                          },
                          {
                            type: 'paragraph',
                            text: 'What was new was the decision taken by governments to confine their populations, causing our economies to come to a standstill beyond what we could have anticipated. This had not happened in previous pandemics, especially the most recent ones, in the 50s and 60s. We see a greater appreciation in the value of human life, and that is to be welcomed, but it has a huge impact on the economy. \nThis crisis is therefore surprising in its magnitude, but not in its matrix. It illustrates a major new phenomenon that we discussed in our last Future Risk Report: the interconnection of risks. Standardization of lifestyles and globalization now play a key role in the spread of risk. It is a powerful accelerator.\nIt should also be remembered that the world has experienced several epidemic episodes in recent years, even if they did not reach the pandemic stage. After the SARS episode in 2003, we saw companies in Asia asking to insure themselves against this type of risk, even though these contracts remained very rare. All these signals led us to develop a new actuarial model for pandemics, which we deployed before the current crisis began. It proved to be aligned with the reality of the situation. ',
                            spans: [],
                          },
                          {
                            type: 'paragraph',
                            text: 'Can insurers play a role in the face of such risks? ',
                            spans: [
                              {
                                start: 0,
                                end: 52,
                                type: 'strong',
                              },
                            ],
                          },
                          {
                            type: 'paragraph',
                            text: 'Insurers are already doing a lot. Wherever we are present, we are playing a role and honouring contracts, particularly in health and provident insurance. Sometimes we have even gone beyond that, by making exceptional solidarity efforts. AXA has mobilized nearly 400 million euros to help its clients and society. \nThe subject that has been the subject of debate is operating losses. This crisis revealed that this risk is not covered, or very rarely, in the event of a pandemic. The reason is simple: in the event of a pandemic, as in the case of war, everyone is affected at the same time. There can therefore be no risk pooling, which is an essential foundation of insurance. \nBut we can innovate. This is why we have launched, first of all in France, a strategy to bring together the State and private players to set up a mechanism to cover risks linked to pandemics, as is already the case for natural disasters. Only joint action by the public and private sectors, as well as pooling over time, can make it possible to cover such risks. ',
                            spans: [],
                          },
                          {
                            type: 'paragraph',
                            text: 'Will there be a before and after for insurance? ',
                            spans: [
                              {
                                start: 0,
                                end: 48,
                                type: 'strong',
                              },
                            ],
                          },
                          {
                            type: 'paragraph',
                            text: 'This crisis may be a tipping point for insurance. On the one hand, it has revealed the sector’s underestimation of health risks. While major pandemics seemed to be a thing of the past, this incident shows us that the risk is still present and that the "protection gap" remains significant. Moving forward, society will be even more demanding regarding their health. \nOn the other hand, this crisis reveals a transformation in the nature of risks. Pandemics, cyber risk, climate change, the threats are global and complex. They require coordinated responses between countries, with strong insurers to absorb the shocks and experts to understand the risks. AXA is one of these strong players. At the end of the day, this crisis fully affirms our strategic vision of desensitizing the company to financial risks and focusing on large risks and health. ',
                            spans: [],
                          },
                        ],
                      },
                    ],
                  },
                  {
                    sliceType: 'documents',
                    sliceLabel: null,
                    _meta: {
                      value: 'Group',
                    },
                    value: [
                      {
                        _meta: {
                          attachmentTitle: 'Text',
                          target: 'Link.document',
                        },
                        attachmentTitle: 'Publication',
                        target: {
                          id: 'XabNFBAAACEAh4LL',
                          type: 'publication',
                          target: 'document',
                          isBroken: false,
                          url: '/not-populated',
                        },
                      },
                    ],
                  },
                ],
                related_articles: [
                  {
                    _meta: {
                      article: 'Link.document',
                    },
                    article: {
                      id: 'Xr1PlREAACwAqCDD',
                      type: 'article-v2',
                      target: 'document',
                      isBroken: false,
                      url: '/not-populated',
                    },
                  },
                  {
                    _meta: {
                      article: 'Link.document',
                    },
                    article: {
                      id: 'XoRT_xMAAC_mQJdg',
                      type: 'press-release',
                      target: 'document',
                      isBroken: false,
                      url: '/not-populated',
                    },
                  },
                ],
                url: '/en/magazine/alban-risk-covid19',
                url_en: '/en/magazine/alban-risk-covid19',
                url_fr: '/fr/magazine/alban-risque-covid19',
                prismic: {
                  creationDate: '2020-06-10T07:25:48+0000',
                  updateDate: '2020-06-10T13:01:47+0000',
                },
              },
            },
          ],
          url: '/en/magazine/gilbert-chahine-axa-accor',
          url_en: '/en/magazine/gilbert-chahine-axa-accor',
          url_fr: '/fr/magazine/gilbert-chahine-axa-accor',
          prismic: {
            creationDate: '2020-06-10T07:25:48+0000',
            updateDate: '2020-06-10T13:04:24+0000',
          },
        },
        item1Image: {
          main: {
            dimensions: {
              width: 1920,
              height: 1080,
            },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/a4b1f276af4bb36df037f209a0a5bcbd42c1e7f4_eydztsux0amghms.jpg',
          },
          views: {
            small: {
              dimensions: {
                width: 768,
                height: 432,
              },
              alt: '',
              copyright: '',
              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/dcb56d0109655c04b4c624e8310e7b89adbde0b8_eydztsux0amghms.jpg',
            },
            medium: {
              dimensions: {
                width: 970,
                height: 545,
              },
              alt: '',
              copyright: '',
              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/3addee3fdf6c725a19ec567b06b53b52ef6b1b38_eydztsux0amghms.jpg',
            },
          },
        },
      },
    },
    {
      sliceType: 'publications',
      sliceLabel: null,
      value: {
        items: [
          {
            publication: {
              type: 'publication',
              _tags: [],
              id: 'XL8ZPxEAACAA0FxN',
              uid: null,
              slug: 'axa-essentials-2019',
              slug_en: 'axa-essentials-2019',
              slug_fr: 'axa-en-bref-2019',
              topic: {
                type: 'publication-topic',
                _tags: [],
                id: 'XkUdWhMAAC4AKao2',
                uid: null,
                _meta: {
                  title: 'Text',
                  title_en: 'Text',
                  title_fr: 'Text',
                },
                title: 'Reference Documents',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: '2020-02-13T10:01:43+0000',
                  updateDate: '2020-02-13T10:49:39+0000',
                },
              },
              title: 'AXA Essentials, 2019 edition',
              date: '2019-04-24',
              cover: {
                main: {
                  dimensions: {
                    width: 400,
                    height: 565,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/b302bccede0ad5357f3eb41a5ee3d937958bb9fb.jpg',
                },
                views: {},
              },
              document: {
                file: {
                  name: 'axa-essentials-2019-accessible.pdf',
                  kind: 'document',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F39720ff6-b2c6-4854-82a2-3b4e665c54e7_axa-essentials-2019-accessible.pdf',
                  size: '2471617',
                },
                target: 'file',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F39720ff6-b2c6-4854-82a2-3b4e665c54e7_axa-essentials-2019-accessible.pdf',
              },
              documentTitle: 'PDF Accessible Document',
              body: [],
              url: '/en/press/publications/axa-essentials-2019',
              url_en: '/en/press/publications/axa-essentials-2019',
              url_fr: '/fr/presse/publications/axa-en-bref-2019',
              prismic: {
                creationDate: '2019-04-24T05:02:09+0000',
                updateDate: '2020-02-13T10:04:55+0000',
              },
            },
          },
          {
            publication: {
              type: 'publication',
              _tags: [],
              id: 'XsKDLxEAAC4AvxjU',
              uid: null,
              slug: 'full-year-earnings-2019-press',
              slug_en: 'full-year-earnings-2019-press',
              slug_fr: 'resultats-annuels-2019-presse',
              seoDescription: 'Full Year Earnings 2019, Press Presentation',
              tweet: 'Access #AXA full year earnings 2019 press presentation',
              sharingImage: {
                main: {
                  dimensions: {
                    width: 1200,
                    height: 630,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/1b42701aab9f6b7b36fdcbdf9656d0698c490aa9_fy2019.jpg',
                },
                views: {},
              },
              sharingDescription: 'Full Year Earnings 2019, Press Presentation',
              topic: {
                type: 'publication-topic',
                _tags: [],
                id: 'VmWxthwAAB4BUCHy',
                uid: null,
                _meta: {
                  title: 'Text',
                  title_en: 'Text',
                  title_fr: 'Text',
                },
                title: 'Earnings & Results',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: '2020-02-13T09:58:26+0000',
                },
              },
              title: 'Full Year Earnings 2019, Press Presentation',
              date: '2020-02-20',
              cover: {
                main: {
                  dimensions: {
                    width: 400,
                    height: 581,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/94621628e7326ca62fd158159ff3aabec4f14233_fy2019.jpg',
                },
                views: {},
              },
              document: {
                file: {
                  name: 'AXA_Full_Year_Results_2019_Press.pdf',
                  kind: 'document',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F55f34bcb-4b0a-4b51-ae00-d3895c9bd83d_axa_full_year_results_2019_press.pdf',
                  size: '1246914',
                },
                target: 'file',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F55f34bcb-4b0a-4b51-ae00-d3895c9bd83d_axa_full_year_results_2019_press.pdf',
              },
              documentTitle: 'Full Year Earnings 2019 - Press Presentation',
              description: [
                {
                  type: 'paragraph',
                  text: 'Full Year Earnings 2019 - Press Presentation',
                  spans: [],
                },
              ],
              url: '/en/press/publications/full-year-earnings-2019-press',
              url_en: '/en/press/publications/full-year-earnings-2019-press',
              url_fr: '/fr/presse/publications/resultats-annuels-2019-presse',
              prismic: {
                creationDate: '2020-06-10T07:26:46+0000',
                updateDate: '2020-06-10T07:26:46+0000',
              },
            },
          },
          {
            publication: {
              type: 'publication',
              _tags: [],
              id: 'XnOiuRMAACwA9uJB',
              uid: null,
              slug: '2019-annual-report',
              slug_en: '2019-annual-report',
              slug_fr: 'rapport-annuel-2019',
              seoDescription: '2019 Annual Report',
              tweet: '#AXA 2019 Annual Report',
              sharingDescription: '2019 Annual Report',
              topic: {
                type: 'publication-topic',
                _tags: [],
                id: 'XkUdWhMAAC4AKao2',
                uid: null,
                _meta: {
                  title: 'Text',
                  title_en: 'Text',
                  title_fr: 'Text',
                },
                title: 'Reference Documents',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: '2020-02-13T10:01:43+0000',
                  updateDate: '2020-02-13T10:49:39+0000',
                },
              },
              title: '2019 Annual Report',
              date: '2020-03-19',
              cover: {
                main: {
                  dimensions: {
                    width: 400,
                    height: 572,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/b1fedce3392b47ac11b3fe7e65ac68f7e55025ec_urd19en.jpg',
                },
                views: {},
              },
              document: {
                file: {
                  name: 'AXA-URD2019-EN-accessible.pdf',
                  kind: 'document',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fe4fb6b8b-ed94-4cfa-b954-356f3a4835ac_axa-urd2019-en-accessible.pdf',
                  size: '4407333',
                },
                target: 'file',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fe4fb6b8b-ed94-4cfa-b954-356f3a4835ac_axa-urd2019-en-accessible.pdf',
              },
              documentTitle: 'Accessible PDF document',
              body: [],
              url: '/en/press/publications/2019-annual-report',
              url_en: '/en/press/publications/2019-annual-report',
              url_fr: '/fr/presse/publications/rapport-annuel-2019',
              prismic: {
                creationDate: '2020-03-19T17:13:04+0000',
                updateDate: '2020-04-21T15:28:53+0000',
              },
            },
          },
          {
            publication: {
              type: 'publication',
              _tags: [],
              id: 'XTHfNREAACEAyaC0',
              uid: null,
              slug: '2019-climate-report',
              slug_en: '2019-climate-report',
              slug_fr: 'rapport-climat-2019',
              seoDescription: '2019 Climate Report, in line with France’s Article 173 and recommendations from the Task Force on Climate-related Financial Disclosures.',
              sharingDescription: '2019 Climate Report, In line with France’s Article 173 and recommendations from the Task Force on Climate-related Financial Disclosures.',
              topic: {
                type: 'publication-topic',
                _tags: [],
                id: 'XkUeEBMAACkAKa2T',
                uid: null,
                _meta: {
                  title: 'Text',
                  title_en: 'Text',
                  title_fr: 'Text',
                },
                title: 'Corporate & Social Responsibility',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: '2020-02-13T10:01:29+0000',
                  updateDate: '2020-02-13T10:54:45+0000',
                },
              },
              title: '2019 Climate Report',
              date: '2019-07-22',
              cover: {
                main: {
                  dimensions: {
                    width: 400,
                    height: 553,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/dd1d526d9265b336cfdd09de72da1d512eeeb7e2_climate-report.jpg',
                },
                views: {},
              },
              document: {
                file: {
                  name: 'axa2019_ra_en_climate_report_2.pdf',
                  kind: 'document',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F667045c2-cc3c-4f65-a888-18753c463d9c_axa2019_ra_en_climate_report_2.pdf',
                  size: '5539292',
                },
                target: 'file',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2F667045c2-cc3c-4f65-a888-18753c463d9c_axa2019_ra_en_climate_report_2.pdf',
              },
              documentTitle: 'PDF Document',
              description: [
                {
                  type: 'paragraph',
                  text: 'In line with France’s Article 173 and recommendations from the Task Force on Climate-related Financial Disclosures.',
                  spans: [],
                },
              ],
              nameLink: 'Read the news',
              body: [
                {
                  sliceType: 'paragraph',
                  sliceLabel: null,
                  value: [
                    {
                      text: [
                        {
                          type: 'paragraph',
                          text: 'The science is clear : the Earth is warming at an unprecedented rate and carbon emissions are the main cause. The Paris Agreement’s call for “making finance flows consistent” with a low carbon economy also requires understanding the “climate dynamics” of our investments. This concept - striving to align investments with the “2°C” trajectory that science and the Paris Agreement are calling for - forms the core of the TCFD guidelines.',
                          spans: [],
                        },
                        {
                          type: 'paragraph',
                          text: 'This report, building on our first two Climate reports, presents our most advanced efforts in this area. It seeks to model both the impact that climate-related risks may have on our investments (what we have termed the “cost of climate”, expressed in financial terms) and conversely the impact that our investments (ie. the businesses and governments we finance) may have on the climate (what we have called here the “warming potential”, expressed in “temperature”).',
                          spans: [
                            {
                              start: 123,
                              end: 128,
                              type: 'em',
                            },
                          ],
                        },
                      ],
                    },
                  ],
                },
                {
                  sliceType: 'documents',
                  sliceLabel: null,
                  value: [
                    {
                      target: {
                        id: 'XTVoNhEAAB8A2S5Z',
                        type: 'article',
                        target: 'document',
                        isBroken: true,
                        url: '/broken',
                      },
                      title: 'Read the news',
                      label: 'on axa.com',
                    },
                  ],
                },
              ],
              url: '/en/press/publications/2019-climate-report',
              url_en: '/en/press/publications/2019-climate-report',
              url_fr: '/fr/presse/publications/rapport-climat-2019',
              prismic: {
                creationDate: '2019-07-22T10:18:53+0000',
                updateDate: '2020-02-13T10:03:35+0000',
              },
            },
          },
        ],
        title: 'Key publications',
        link: {
          type: 'repository',
          _tags: [],
          id: 'VjtzaRwAAK3xMcBC',
          uid: 'repository-publications',
          slug: 'publications',
          slug_en: 'publications',
          slug_fr: 'publications',
          seoDescription: 'Find out all publications.',
          maskType: 'publication',
          title: 'Publications',
          backLink: {
            type: 'page-v2',
            _tags: ['rédaction', 'actualites'],
            id: 'Xrul9BEAACoAoLul',
            uid: null,
            _meta: {
              slug: 'Text',
              slug_en: 'Text',
              slug_fr: 'Text',
              metaContent: 'Group',
              anchor: 'Group',
              sectionName: 'Text',
              sectionName_en: 'Text',
              sectionName_fr: 'Text',
              body: 'SliceZone',
            },
            slug: 'press',
            slug_en: 'press',
            slug_fr: 'presse',
            metaContent: [
              {
                _meta: {
                  seoDescription: 'Text',
                  tweet: 'Text',
                  sharingImage: 'Image',
                  sharingDescription: 'Text',
                  title: 'Text',
                  sectionReferrer: 'Select',
                  summary: 'Text',
                  summaryStructured: 'StructuredText',
                },
                seoDescription: 'Press',
                tweet: 'Discover an entirely dedicated section to journalists on the #AXA corporate website.',
                sharingImage: {
                  main: {
                    dimensions: {
                      width: 1200,
                      height: 628,
                    },
                    alt: '',
                    copyright: '',
                    url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/98b2ab644f3cccaf0f5651575f7b022d9d0686a2_170223axa_resultats-annuels238.jpeg',
                  },
                  views: {},
                },
                sharingDescription: 'Discover an entirely dedicated section to journalists on the #AXA corporate website.',
                title: 'Home Press',
                sectionReferrer: 'Press',
                summary:
                  "This section gives you access to content and services primarily designed to meet the journalist's needs. Read our latest press releases along with exclusive interviews of our leaders.",
                summaryStructured: [
                  {
                    type: 'paragraph',
                    text: '',
                    spans: [],
                  },
                ],
              },
            ],
            anchor: [],
            sectionName: 'June 3, 2020',
            body: [
              {
                sliceType: 'cover',
                sliceLabel: null,
                _meta: {
                  value: 'NewSlice',
                },
                value: {
                  items: [
                    {
                      _meta: {
                        bannerButtonName: 'Text',
                        bannerButtonLink: 'Link.document',
                      },
                      bannerButtonName: 'Press release',
                      bannerButtonLink: {
                        id: 'XtZ8oxIAACsArCAY',
                        type: 'press-release',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                  ],
                  _meta: {
                    title: 'Text',
                    shortTitle: 'Text',
                    subtitle: 'Text',
                    banner: 'Image',
                  },
                  title: 'Decision of the Board of Directors in respect of AXA’s dividend proposal',
                  shortTitle: 'Decision of the Board of Directors in respect of AXA’s dividend proposal',
                  subtitle:
                    'From the very beginning of the Covid-19 crisis, AXA’s priority has been to act responsibly towards its employees and customers. The Board of Directors’ decision to reduce the proposed dividend demonstrates the same sense of responsibility towards AXA’s shareholders, while adopting a prudent approach in the current environment.',
                  banner: {
                    main: {
                      dimensions: {
                        width: 1920,
                        height: 1280,
                      },
                      alt: '',
                      copyright: '',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d4e7a8f47573c9af185bc1f78f81314ccdcf26e1_thomas_buberl_press.jpg',
                    },
                    views: {
                      medium: {
                        dimensions: {
                          width: 970,
                          height: 576,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f6f60cf9a8663e592d06f75099921d22df444a43_thomas_buberl_press.jpg',
                      },
                      small: {
                        dimensions: {
                          width: 768,
                          height: 576,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/81d2f096f57601637632c160b1d7f9997004cb2a_thomas_buberl_press.jpg',
                      },
                    },
                  },
                },
              },
              {
                sliceType: 'spotLight',
                sliceLabel: null,
                _meta: {
                  value: 'NewSlice',
                },
                value: {
                  items: [
                    {
                      _meta: {
                        surtitle: 'Text',
                        date: 'Text',
                        surtitleLink: 'Link.document',
                        title: 'Text',
                        titleLink: 'Link.document',
                        image: 'Image',
                      },
                      surtitle: 'Press release',
                      date: 'April 1, 2020',
                      surtitleLink: {
                        id: 'VjtzFhwAAK3xMb6G',
                        type: 'repository',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      title: 'AXA strengthens its commitments to tackle an unprecedented health, economic and social challenge',
                      titleLink: {
                        id: 'XoRT_xMAAC_mQJdg',
                        type: 'press-release',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      image: {
                        main: {
                          dimensions: {
                            width: 1920,
                            height: 1080,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/e50e7e8957e28501e47901c9c73123ed936b24f0_covid19.jpg',
                        },
                        views: {
                          small: {
                            dimensions: {
                              width: 768,
                              height: 432,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f3d28a069ff38f1784d8e1bfb8d939d348f633e6_covid19.jpg',
                          },
                          medium: {
                            dimensions: {
                              width: 970,
                              height: 545,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/6680193200995b13f65d9c8f130a2677d8a4b120_covid19.jpg',
                          },
                        },
                      },
                    },
                    {
                      _meta: {
                        surtitle: 'Text',
                        date: 'Text',
                        surtitleLink: 'Link.document',
                        title: 'Text',
                        titleLink: 'Link.document',
                        image: 'Image',
                      },
                      surtitle: 'Press release',
                      date: 'May 5, 2020',
                      surtitleLink: {
                        id: 'VjtzFhwAAK3xMb6G',
                        type: 'repository',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      title: '1Q20 Activity Indicators: AXA performed well in the 1Q20',
                      titleLink: {
                        id: 'XrF6sREAACcAc93j',
                        type: 'press-release',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      image: {
                        main: {
                          dimensions: {
                            width: 1920,
                            height: 1080,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/ad58ff3dc3b206894bafe9575b5cb61a2c8a8657_thomas_buberl_press.jpg',
                        },
                        views: {
                          small: {
                            dimensions: {
                              width: 768,
                              height: 432,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/fc897693d7a1630d778670adb143455b42d3ad51_thomas_buberl_press.jpg',
                          },
                          medium: {
                            dimensions: {
                              width: 970,
                              height: 545,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/bf43878a5ec4ed8eb78b29a195f23d8958fe87d4_thomas_buberl_press.jpg',
                          },
                        },
                      },
                    },
                    {
                      _meta: {
                        surtitle: 'Text',
                        date: 'Text',
                        surtitleLink: 'Link.document',
                        title: 'Text',
                        titleLink: 'Link.document',
                        image: 'Image',
                      },
                      surtitle: "Leader's voice",
                      date: 'June 10, 2020',
                      surtitleLink: {
                        id: 'Xr1JDhEAACgAqALl',
                        type: 'page-v2',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      title: '"Covid-19: a tipping point for the industry?" by Alban de Mailly Nesle, Group Chief Risk & Investment Officer',
                      titleLink: {
                        id: 'XsQ_VREAACwAxsXv',
                        type: 'article-v2',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                      image: {
                        main: {
                          dimensions: {
                            width: 1920,
                            height: 1080,
                          },
                          alt: '',
                          copyright: '',
                          url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/16f387436a2c4cabb34bd9edecca90b36bae3b5f_alban_1200x628.jpg',
                        },
                        views: {
                          medium: {
                            dimensions: {
                              width: 970,
                              height: 545,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/52c6edf34754960a8579ce88663b59315d69fdc2_alban_1200x628.jpg',
                          },
                          small: {
                            dimensions: {
                              width: 768,
                              height: 432,
                            },
                            alt: '',
                            copyright: '',
                            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/24f394a801e6b60d490d273028b6b3832593c170_alban_1200x628.jpg',
                          },
                        },
                      },
                    },
                  ],
                  _meta: {
                    title: 'Text',
                    item1title: 'Text',
                    item1subtitle: 'Text',
                    item1primaryButtonName: 'Text',
                    item1primaryButtonLink: 'Link.document',
                    item1secondaryButtonName: 'Text',
                    item1secondaryButtonLink: 'Link.document',
                    item1Image: 'Image',
                  },
                  title: 'Top of mind',
                  item1title: 'AXA and Accor: offering unique medical assistance in hotels',
                  item1subtitle:
                    'AXA and Accor, a global hospitality leader, announce an innovative strategic partnership to provide medical support to guests across the 5000 Accor hotels worldwide.',
                  item1primaryButtonName: 'Press release',
                  item1primaryButtonLink: {
                    id: 'Xr4xwhEAAC4ArAYv',
                    type: 'press-release',
                    target: 'document',
                    isBroken: false,
                    url: '/not-populated',
                  },
                  item1secondaryButtonName: 'Interview with Gilbert Chahine, CEO of AXA Partners',
                  item1secondaryButtonLink: {
                    id: 'Xr1PlREAACwAqCDD',
                    type: 'article-v2',
                    target: 'document',
                    isBroken: false,
                    url: '/not-populated',
                  },
                  item1Image: {
                    main: {
                      dimensions: {
                        width: 1920,
                        height: 1080,
                      },
                      alt: '',
                      copyright: '',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/a4b1f276af4bb36df037f209a0a5bcbd42c1e7f4_eydztsux0amghms.jpg',
                    },
                    views: {
                      small: {
                        dimensions: {
                          width: 768,
                          height: 432,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/dcb56d0109655c04b4c624e8310e7b89adbde0b8_eydztsux0amghms.jpg',
                      },
                      medium: {
                        dimensions: {
                          width: 970,
                          height: 545,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/3addee3fdf6c725a19ec567b06b53b52ef6b1b38_eydztsux0amghms.jpg',
                      },
                    },
                  },
                },
              },
              {
                sliceType: 'publications',
                sliceLabel: null,
                _meta: {
                  value: 'NewSlice',
                },
                value: {
                  items: [
                    {
                      _meta: {
                        publication: 'Link.document',
                      },
                      publication: {
                        id: 'XL8ZPxEAACAA0FxN',
                        type: 'publication',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                    {
                      _meta: {
                        publication: 'Link.document',
                      },
                      publication: {
                        id: 'XsKDLxEAAC4AvxjU',
                        type: 'publication',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                    {
                      _meta: {
                        publication: 'Link.document',
                      },
                      publication: {
                        id: 'XnOiuRMAACwA9uJB',
                        type: 'publication',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                    {
                      _meta: {
                        publication: 'Link.document',
                      },
                      publication: {
                        id: 'XTHfNREAACEAyaC0',
                        type: 'publication',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                  ],
                  _meta: {
                    title: 'Text',
                    link: 'Link.document',
                    linkName: 'Text',
                  },
                  title: 'Key publications',
                  link: {
                    id: 'VjtzaRwAAK3xMcBC',
                    type: 'repository',
                    target: 'document',
                    isBroken: false,
                    url: '/not-populated',
                  },
                  linkName: 'All publications',
                },
              },
              {
                sliceType: 'calendar',
                sliceLabel: null,
                _meta: {
                  value: 'NewSlice',
                },
                value: {
                  items: [
                    {
                      _meta: {
                        audience: 'Link.document',
                      },
                      audience: {
                        id: 'VkzBQB8AAEc90sZm',
                        type: 'audience',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                    {
                      _meta: {
                        audience: 'Link.document',
                      },
                      audience: {
                        id: 'Vpz3WhsAADWYyOec',
                        type: 'audience',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                  ],
                  _meta: {
                    title: 'Text',
                    subtitleNoEvent: 'Text',
                    calendarLink: 'Link.document',
                    calendarLinkName: 'Text',
                  },
                  title: 'Upcoming events',
                  subtitleNoEvent: 'No events',
                  calendarLink: {
                    id: 'VkRz1h8AAFBAOKQy',
                    type: 'repository',
                    target: 'document',
                    isBroken: false,
                    url: '/not-populated',
                  },
                  calendarLinkName: 'All events',
                },
              },
              {
                sliceType: 'newsletterBlock',
                sliceLabel: null,
                _meta: {
                  value: 'NewSlice',
                },
                value: {
                  items: [],
                  _meta: {
                    title: 'Text',
                    subtitle: 'Text',
                    buttonName: 'Text',
                    image: 'Image',
                  },
                  title: 'Get the latest updates',
                  subtitle: 'Subscribe to receive alerts when new items are published on this section (press release or news).',
                  buttonName: 'Subscribe',
                  image: {
                    main: {
                      dimensions: {
                        width: 600,
                        height: 600,
                      },
                      alt: '',
                      copyright: '',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/bd8a639ecaac1522c43215bbe8489480753aeb3d_bg.jpg',
                    },
                    views: {
                      thumbnails: {
                        dimensions: {
                          width: 300,
                          height: 300,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d38e6cbf26a4ee409146349f91443c6a9f5a283d_bg.jpg',
                      },
                    },
                  },
                },
              },
              {
                sliceType: 'contacts',
                sliceLabel: null,
                _meta: {
                  value: 'NewSlice',
                },
                value: {
                  items: [
                    {
                      _meta: {
                        contact: 'Link.document',
                      },
                      contact: {
                        id: 'Xr1IAREAACkAp_4a',
                        type: 'contact',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                    {
                      _meta: {
                        contact: 'Link.document',
                      },
                      contact: {
                        id: 'XlaHlxMAACoAdn52',
                        type: 'contact',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                    {
                      _meta: {
                        contact: 'Link.document',
                      },
                      contact: {
                        id: 'Xle9kBMAACoAe9Ym',
                        type: 'contact',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                    {
                      _meta: {
                        contact: 'Link.document',
                      },
                      contact: {
                        id: 'XsJnYREAACgAvp1-',
                        type: 'contact',
                        target: 'document',
                        isBroken: false,
                        url: '/not-populated',
                      },
                    },
                  ],
                  _meta: {
                    title: 'Text',
                    link: 'Link.document',
                    linkName: 'Text',
                  },
                  title: 'Contacts',
                  link: {
                    id: 'WFgN3yAAANHE5JU-',
                    type: 'page-v2',
                    target: 'document',
                    isBroken: false,
                    url: '/not-populated',
                  },
                  linkName: 'Contact us',
                },
              },
            ],
            url: '/en/press',
            url_en: '/en/press',
            url_fr: '/fr/presse',
            prismic: {
              creationDate: '2020-06-10T07:24:51+0000',
              updateDate: '2020-06-10T12:48:43+0000',
            },
          },
          backLabel: 'Press',
          filtersRef: [{}],
          url: '/en/press/publications',
          url_en: '/en/press/publications',
          url_fr: '/fr/presse/publications',
          prismic: {
            creationDate: null,
            updateDate: '2020-06-10T07:24:51+0000',
          },
        },
        linkName: 'All publications',
      },
    },
    {
      sliceType: 'calendar',
      sliceLabel: null,
      value: {
        items: [
          {
            audience: {
              type: 'audience',
              _tags: [],
              id: 'VkzBQB8AAEc90sZm',
              uid: null,
              name: "Shareholders' Meeting",
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: null,
                updateDate: null,
              },
            },
          },
          {
            audience: {
              type: 'audience',
              _tags: [],
              id: 'Vpz3WhsAADWYyOec',
              uid: null,
              name: 'Earnings and Results',
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: null,
                updateDate: null,
              },
            },
          },
          {
            audience: {
              type: 'audience',
              _tags: [],
              id: 'WBCuDh4AANkf7LcA',
              uid: null,
              name: 'qa-event-type03',
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: '2020-06-11T13:16:08+0000',
                updateDate: '2020-06-11T13:16:08+0000',
              },
            },
          },
          {
            audience: {
              type: 'audience',
              _tags: [],
              id: 'WBCxuR4AACAA7M0n',
              uid: null,
              name: 'qa-newsroom-test',
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: '2020-06-11T13:16:08+0000',
                updateDate: '2020-06-11T13:16:08+0000',
              },
            },
          },
          {
            audience: {
              type: 'audience',
              _tags: [],
              id: 'WpzPrg8AADlr-SVX',
              uid: null,
              name: 'Financing',
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: '2018-03-05T06:02:10+0000',
                updateDate: '2018-03-05T06:02:10+0000',
              },
            },
          },
          {
            audience: {
              type: 'audience',
              _tags: [],
              id: 'V_tT7h4AAB4AbRtO',
              uid: null,
              name: 'Innovation',
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: null,
                updateDate: '2019-04-12T15:10:35+0000',
              },
            },
          },
          {
            audience: {
              type: 'audience',
              _tags: [],
              id: 'XuHatBIAACsA3kP0',
              uid: null,
              name: 'Climate',
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: '2020-06-11T07:18:22+0000',
                updateDate: '2020-06-11T07:18:22+0000',
              },
            },
          },
        ],
        title: 'Upcoming events',
        subtitleNoEvent: 'No events',
        calendarLink: {
          type: 'repository',
          _tags: [],
          id: 'VkRz1h8AAFBAOKQy',
          uid: 'repository-events',
          slug: 'events',
          slug_en: 'events',
          slug_fr: 'evenements',
          seoDescription: 'Events and conferencees',
          maskType: 'event',
          title: 'Events',
          backLink: {
            id: 'VgAogBwAAIhKi3dI',
            type: 'news-and-media',
            target: 'document',
            isBroken: true,
            url: '/broken',
          },
          backLabel: 'Press',
          filtersRefTitle: 'Event type',
          filtersRef: [
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'VmGBbxsAAMkh9JZ7',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: "Brokers' Conferences",
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: null,
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'Vie1RxwAAPEhi6gw',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'Candidates',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: null,
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'V_tT7h4AAB4AbRtO',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'Innovation',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: '2019-04-12T15:10:35+0000',
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'Vpz3WhsAADWYyOec',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'Earnings and Results',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: null,
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'Vie0GhwAAPEhi6Fi',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'Individual Shareholders',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: null,
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'Vie0NBwAAPEhi6Hu',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'Investor Days',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: null,
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'Vie0mhwAAPEhi6Qy',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'Press',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: null,
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'VkzBQB8AAEc90sZm',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: "Shareholders' Meeting",
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: null,
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'V35Nmx4AAB0Agv4d',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'AXA Stakeholder Advisory Panel',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: null,
                  updateDate: null,
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'WBCuDh4AANkf7LcA',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'qa-event-type03',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: '2020-06-11T13:16:08+0000',
                  updateDate: '2020-06-11T13:16:08+0000',
                },
              },
            },
            {
              ref: {
                type: 'audience',
                _tags: [],
                id: 'WBCxuR4AACAA7M0n',
                uid: null,
                _meta: {
                  name: 'Text',
                  name_en: 'Text',
                  name_fr: 'Text',
                },
                name: 'qa-newsroom-test',
                url: '/not-resolved',
                url_en: '/not-resolved',
                url_fr: '/not-resolved',
                prismic: {
                  creationDate: '2020-06-11T13:16:08+0000',
                  updateDate: '2020-06-11T13:16:08+0000',
                },
              },
            },
          ],
          url: '/en/press/events',
          url_en: '/en/press/events',
          url_fr: '/fr/presse/evenements',
          prismic: {
            creationDate: '2020-06-11T13:16:08+0000',
            updateDate: '2020-06-11T13:16:08+0000',
          },
        },
        calendarLinkName: 'All events',
      },
    },
    {
      sliceType: 'newsletterBlock',
      sliceLabel: null,
      value: {
        items: [],
        title: 'Get the latest updates',
        subtitle: 'Subscribe to receive alerts when new items are published on this section (press release or news).',
        buttonName: 'Subscribe',
        image: {
          main: {
            dimensions: {
              width: 600,
              height: 600,
            },
            alt: '',
            copyright: '',
            url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/bd8a639ecaac1522c43215bbe8489480753aeb3d_bg.jpg',
          },
          views: {
            thumbnails: {
              dimensions: {
                width: 300,
                height: 300,
              },
              alt: '',
              copyright: '',
              url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/d38e6cbf26a4ee409146349f91443c6a9f5a283d_bg.jpg',
            },
          },
        },
      },
    },
    {
      sliceType: 'contacts',
      sliceLabel: null,
      value: {
        items: [
          {
            contact: {
              type: 'contact',
              _tags: [],
              id: 'Xr1IAREAACkAp_4a',
              uid: null,
              name: 'Julien Parot',
              section: 'Head of Media Relations & Reputation',
              email: 'julien.parot@axa.com',
              contactImage: {
                main: {
                  dimensions: {
                    width: 600,
                    height: 400,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f4679c5261b6c15048a845ababe98175521a3524_01.jpg',
                },
                views: {},
              },
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: '2020-06-10T07:24:34+0000',
                updateDate: '2020-06-10T07:24:34+0000',
              },
            },
          },
          {
            contact: {
              type: 'contact',
              _tags: [],
              id: 'XlaHlxMAACoAdn52',
              uid: null,
              name: 'Farah El Mamoune',
              section: 'Media Relations Officer',
              email: 'farah.elmamoune@axa.com',
              contactImage: {
                main: {
                  dimensions: {
                    width: 738,
                    height: 498,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/b90aa0971b56f97998911450fed7f55e609cdadb_img_0538.jpg',
                },
                views: {},
              },
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: '2020-05-14T13:28:15+0000',
                updateDate: '2020-06-10T07:24:11+0000',
              },
            },
          },
          {
            contact: {
              type: 'contact',
              _tags: ['photo'],
              id: 'Xle9kBMAACoAe9Ym',
              uid: null,
              name: 'Jonathan Deslandes',
              section: 'Media Relations Officer',
              email: 'jonathan.deslandes@axa.com',
              contactImage: {
                main: {
                  dimensions: {
                    width: 1200,
                    height: 1165,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/0f863f2ecc5d1d937dd1de79fc4f75d28fdf12ab_jd.jpg',
                },
                views: {},
              },
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: '2020-06-10T07:24:23+0000',
                updateDate: '2020-06-10T07:24:23+0000',
              },
            },
          },
          {
            contact: {
              type: 'contact',
              _tags: [],
              id: 'XsJnYREAACgAvp1-',
              uid: null,
              name: 'Sarah Andersen',
              section: 'Media Relations Officer',
              email: 'sarah.andersen@axa.com',
              contactImage: {
                main: {
                  dimensions: {
                    width: 577,
                    height: 582,
                  },
                  alt: '',
                  copyright: '',
                  url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/be1df46c31db75d6cd742841a96caf09e74aa659_sarahandersen2-copie.png',
                },
                views: {},
              },
              url: '/not-resolved',
              url_en: '/not-resolved',
              url_fr: '/not-resolved',
              prismic: {
                creationDate: '2020-06-10T07:23:48+0000',
                updateDate: '2020-06-10T07:23:48+0000',
              },
            },
          },
        ],
        title: 'Contacts',
        link: {
          type: 'page-v2',
          _tags: [],
          id: 'WFgN3yAAANHE5JU-',
          uid: null,
          slug: 'page-v2',
          slug_en: 'page-v2',
          slug_fr: 'contacts-groupe-axa',
          seoDescription:
            'Looking for information about your contracts, products or services? You should get in touch directly with the AXA entity located in your country. You will find the contact details of all Group companies in the "AXA in the world" section.',
          title: 'Contact',
          legalInformation: [
            {
              type: 'heading6',
              text: 'Test1Protection of personal information ou should get in touch directly with the AXA entity located in your country. You will find the contact details of all Group companies in the "AXA in the world" section.ou should get in touch directly with the AXA entity located in your country. You will find the contact details of all Group companies in the "AXA in the world" section.ou should get in touch directly with the AXA entity located in your country. You will find the contact details of all Group companies in the "AXA in the world" section.\nVisit the Legal information section.',
              spans: [
                {
                  start: 181,
                  end: 199,
                  type: 'hyperlink',
                  data: {
                    type: 'Link.web',
                    value: {
                      url: 'https://www.axa.com/en/about-us/axa-world-map',
                    },
                  },
                },
                {
                  start: 349,
                  end: 367,
                  type: 'hyperlink',
                  data: {
                    type: 'Link.web',
                    value: {
                      url: 'https://www.axa.com/en/about-us/axa-world-map',
                    },
                  },
                },
                {
                  start: 517,
                  end: 535,
                  type: 'hyperlink',
                  data: {
                    type: 'Link.web',
                    value: {
                      url: 'https://www.axa.com/en/about-us/axa-world-map',
                    },
                  },
                },
                {
                  start: 544,
                  end: 581,
                  type: 'hyperlink',
                  data: {
                    type: 'Link.document',
                    value: {
                      document: {
                        type: 'page',
                        _tags: [],
                        id: 'VktpWR8AACAAywHa',
                        uid: null,
                        _meta: {
                          slug: 'Text',
                          slug_en: 'Text',
                          slug_fr: 'Text',
                          title: 'Text',
                          title_en: 'Text',
                          title_fr: 'Text',
                          sectionReferrer: 'Select',
                          sectionReferrer_en: 'Select',
                          sectionReferrer_fr: 'Select',
                          summary: 'Text',
                          summary_en: 'Text',
                          summary_fr: 'Text',
                          sectionName: 'Text',
                          sectionName_en: 'Text',
                          sectionName_fr: 'Text',
                          anchorToggle: 'Select',
                          anchorToggle_en: 'Select',
                          anchorToggle_fr: 'Select',
                          anchors: 'Group',
                          bodyGenericPage: 'SliceZone',
                        },
                        slug: 'Legal-Information-20190731',
                        slug_en: 'Legal-Information-20190731',
                        slug_fr: 'mentions-legales-20190731',
                        title: 'Legal information / Terms of use',
                        sectionReferrer: 'About us',
                        summary: 'Please read carefully the following terms of use, which apply to all visitors of the website www.axa.com (the "Website") and which you agree to comply with.',
                        sectionName: 'Legal  information',
                        anchorToggle: 'No',
                        anchors: [
                          {
                            _meta: {},
                          },
                        ],
                        bodyGenericPage: [
                          {
                            sliceType: 'paragraph',
                            sliceLabel: null,
                            _meta: {
                              value: 'Group',
                            },
                            value: [
                              {
                                _meta: {
                                  text: 'StructuredText',
                                },
                                text: [
                                  {
                                    type: 'paragraph',
                                    text: 'Date of the last update : 07/31/2019',
                                    spans: [],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '06/19/2019 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'XUGv8BEAAB4AD0FY',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20190619',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '04/24/2019 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'XQtEHBEAAB8AH6sX',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20190424',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '04/10/2019 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'XMCZXBEAACAA1vqV',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20190410',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '02/20/2019 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'XK2pWRAAACAAkowo',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20190220',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '12/13/2018 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'XG591xAAACgAQn1z',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20181213',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '12/03/2018 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'XBN-ShIAACwAewPn',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20181203',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '08/13/2018 version ',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'XAUAKhAAACgArrWl',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20180813',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '08/01/2018 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'W3FVnxAAAJSR578w',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20180801',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '06/28/2018 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'W2H2JREAAI-Fit9T',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20180628',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '02/21/2018 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'WzTRKhAAAOOdDo4E',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20180221',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '12/14/2017 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'Wo2arg8AAEUMtkDz',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20171214',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '12/01/2017 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'WjPzKRIAAEnYzkHR',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20171201',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '08/02/2017 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'WiUltBIAAE5EjSP6',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20170802',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '06/21/2017 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'WYLKphEAAI0Abg-M',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20170621',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '02/22/2017 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'WUuJqhAAALZVrqDA',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20170222',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '08/03/2016 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'WEU6aSAAANHEdIpB',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20160803',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '06/17/2016 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'V6G4Mx4AAB4AVod1',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20160617',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '03/16/2016 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'V2P8kB4AACAA5dnw',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20160316',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '02/24/2016 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'Vuq7vCMAACUALNG-',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20160224',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'list-item',
                                    text: '12/17/2015 version',
                                    spans: [
                                      {
                                        start: 0,
                                        end: 18,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'Vs8HMSMAACIAhrJU',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'legal-information-20151217',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: '',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'ACCEPTANCE OF THE TERMS OF USE ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA reserves the right to add to, modify or remove and more generally update at any time, all or part of these terms of use. AXA will inform each visitor of the Website (a «User») about the modifications made to the present terms of use. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'If the User does not respect these terms of use and if AXA does not immediately react, this does not mean that AXA waives its rights to act subsequently. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'LEGAL INFORMATION',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading3',
                                    text: 'The Website editor ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA\n25, avenue Matignon\nFR - 75008 Paris\nTelephone: +33 (0) 1 40 75 57 00 ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Number of V.A.T: FR 50 572 093 920',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA is a “société anonyme” with registered capital of: €5,530,263,916.61 (at July 31, 2019), registered in the Paris Trade and Companies Register under the number 572.093.920 and represented by Thomas Buberl –  Chief Executive Officer. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: '(« AXA »)',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading3',
                                    text: 'Publication Director ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Thomas Buberl – Chief Executive Officer.',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading3',
                                    text: 'Web hosting',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA Technology Services SAS \n76, route de la Demi-lune\nFR - 92057 Paris La Défense Cedex\nTelephone: + 33 (0) 1 55 67 20 00',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA Technology Services SAS is registered in the Nanterre Trade and Companies Register under the number 399.214.287 ',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'ACCESS ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The Website is an information website published in English and French, intended both for AXA customers and non-customers.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The information contained on the Website is given strictly for informative purposes and does not entail any legal commitment or implicit or explicit contractual agreement on the part of AXA, which also reserves the right to modify its characteristics at any time. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Access to any products and services presented on the Website may be subject to legal or regulatory restrictions for certain persons or in certain countries. None of the products and/or services will be supplied by AXA or any entity of the AXA Group (« AXA Group ») to a person if the law applicable to him/her prohibits it. However, it is up to all persons concerned to check beforehand with their usual legal advisors that their legal and fiscal status permits them to subscribe to the products and/or services presented on the Website. AXA declines all responsibility in case of violation of these restrictions by any person. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Access to the Website is free of charge. However, the costs of access and use of the telecommunications network shall be borne by the User, according to the terms stipulated by his/her Internet access provider and his/her telecom operator. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'USER ACCOUNT ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Some features on the Website may require the creation of a User account. The User has the entire responsibility of maintaining the confidentiality of his/her account information, especially his/her password and of all the operations carried out with the account. He/she is responsible for his/her own activity carried out using his/her account or through it. He/she shall not use the same password for third-party applications.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User is not allowed to use the account of any other person without such account holder’s permission.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User undertakes to immediately notify AXA in case of non authorised use of his/her account or of his/her password or any breach of security. He/she may be held responsible for the damages suffered by AXA or any other User due to the use, caused by his/her own intent or negligence, of his/her AXA login, his/her password or his/her account, by another person. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'PRIVACY POLICY',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'For any further information concerning the processing of Personal Data realised by the Website, please refer to the Privacy Policy and the Cookie Policy.',
                                    spans: [
                                      {
                                        start: 116,
                                        end: 130,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'W_LDkhAAADatIjw0',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'privacy-policy',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                      {
                                        start: 139,
                                        end: 152,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'W2G73xEAABx9id25',
                                              type: 'page',
                                              tags: [],
                                              lang: 'en-us',
                                              slug: 'cookie-policy',
                                            },
                                            isBroken: false,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'HYPERTEXT LINKS',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The creation of hypertext links to the Website is subject to the explicit prior approval of AXA.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The Website can contain hypertext links to other sites. The existence of hypertext links between the Website and third party sites means in no way that AXA approves the content of that site or the use which may be made, and may not, under any circumstances, incur AXA’s responsibility. The User visits the other sites at his/her own risks and under his/her responsibility.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA does not accept any responsibility for any third party website linked to or from this website.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'It is to be recalled that delays, omissions or inaccuracies are liable to occur because of the electronic transmission system.',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'COPYRIGHT LAW',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'All the elements of the Website , individually and as a whole, are governed by applicable legislation on intellectual property, copyright law, trademark law. The same applies to the form of the Website (tree view, layout, design, conviviality…), as well as to its content (trademark, texts, images, illustrations, music, sounds…). These elements are the exclusive property of AXA or are licensed to AXA, and AXA is the sole authorized user of such elements. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Any other complete or partial reproduction, representation or communication of the pages, the data and any other element constituting the Website, by any process and on any support, as well as their modification, is prohibited, with the exception of prior and written authorization of AXA.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: '“AXA” is a registered trademark. The trademarks, service marks and logos appearing in AXA information services and/or on any other AXA Group entities’ website are the property of the AXA Group entity in question. It is strictly forbidden to use or reproduce the name “AXA” and/or its logos, used alone or combined, in any capacity whatsoever, without AXA’s prior written agreement. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The non-compliance with such prohibition constitutes an infringement which can result in civil and criminal liability.',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'USE OF THE WEBSITE',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User may not use the Website or its content for an improper purpose or a purpose forbidden by these terms of use, nor encourage any illegal activity, or other activity violating AXA’s rights or third parties’ rights.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User is not allowed to use mechanisms, programmes, algorithms or other automatic methods to access, obtain, copy or supervise any part of the Website, nor reproduce or bypass the navigation structure or the presentation of the Website in order to obtain data, documents or information. The User can only extract and/or re-use data, documents or information from the Website when this has been expressly authorized. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User must not attempt to access unlawfully to any section or functionality of the Website, nor to any other system or connected network to the Website, nor to the services proposed on the Website, by hacking or using any other illegitimate means. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User must not try to analyse or test the vulnerability of the Website or any connected network to the Website, nor violate the security and authentication measures put in place by the Website or the networks connected to the Website. The User is not authorized to question or trace information about other Users, or clients of the AXA Group, especially all Users’ accounts which are not his/her own, or set up at his/her initiative, nor to exploit the Website or the services or the information made available on the Website, in any manner, for the purpose of revealing such information, especially personal identification information or the information other than his/her own information, as they appear on the Website.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: "The User agrees to take no action imposing an undue or unreasonable burden on the Website's infrastructure, or systems or AXA’s networks, or any network connected to the Website or to AXA.",
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User agrees not to use any mechanism or software to interfere or try to interfere with the proper function of the Website or with any transaction conducted on the Website or with any use of the Website by any other person.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User must not try to infringe the headers or manipulate the identifying information in any manner, to mask the origin of the message or of an information sent to AXA using the Website, or a service offered by the Website. The User must not claim to be or represent someone else, nor pretend to be another natural or legal person.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA reserves the right at any time to modify or suspend temporarily or permanently the use of this Website and may not be held responsible for these changes, suspension or interruptions. Also, AXA declines all responsibility for the dysfunctions or interruptions during the use of the Website due to power failure, defection on telephone lines and/or internet or any other damaging event out of its control. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'TECHNICAL INFORMATION',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA may not be held responsible for events out of its control and the potential damages suffered by the technical environment of the User and notably, his/her computers, software, network equipment or any other material to use the Website and/or information contained in it.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The confidentiality of correspondence is not guaranteed on the network and it is up to each User in particular to take all appropriate steps to protect his/her own data and/or software against contamination by any viruses circulating on the Internet. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The User agrees to compensate and release AXA from all responsibility regarding losses or complaints from third parties, due to or in relation to the use made by such User of the Website.',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'COOKIES',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Cookies are used on the Website in order to constantly improve the Website and to respond effectively to consumers expectations.',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'All information about cookies and disabling of cookies is available in the Cookies Policy. ',
                                    spans: [
                                      {
                                        start: 75,
                                        end: 89,
                                        type: 'hyperlink',
                                        data: {
                                          type: 'Link.document',
                                          value: {
                                            document: {
                                              id: 'VkTLwB8AAJBROq0f',
                                              type: 'cookie-page',
                                              tags: [],
                                              lang: null,
                                              slug: '-',
                                            },
                                            isBroken: true,
                                          },
                                        },
                                      },
                                    ],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'ABSENCE OF GUARANTEE',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'AXA endeavours to keep this Website up to date. However, AXA guarantees neither the accuracy nor the completeness of any information presented. ',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Besides, to the extent permitted by applicable law, AXA may in no case be held responsible for any indirect loss, for whatever cause, origins, natures or consequences, resulting from a visit to the Website or associated with such a visit, particularly, and without limitation, for any loss of profits, interruption of activities or loss of software or data.',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'JURISDICTION AND APPLICABLE LAW',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'The Website and its content are governed by French law subject to provisions that cannot be derogated from by agreement by virtue of the law applicable to the User. All disputes in relation to the Website shall be subject to French courts.',
                                    spans: [],
                                  },
                                  {
                                    type: 'heading2',
                                    text: 'PHOTO CREDITS',
                                    spans: [],
                                  },
                                  {
                                    type: 'paragraph',
                                    text: 'Patrick Messina, Franck Dunouau, SeignetteLafontan.com, Raphael Fournier, Antoine Doyen, Stephen Dock, Jean-Lionel Dias, Mat Be, Benoit Paillé, Romuald Meigneux, GettyImage, IStockPhoto, Jean Philippe Robin, Raphael Dautigny, Eric Avena, Leonard Misonne, PhotoNonStop, Agence photographique du musée Rodin - Pauline Hisbacq, Pascal Michelet, Eleanor Goodey, Patrick Brown, Stephen Laemlin, Pierre-Lucet Penato, Mint Images, Musée des Beaux-Arts de Lyon, Shutterstock, Thomas Coex/CARE, CARE, Philippe Fuzeau / musée du Louvre, Maskot, Benjamin Boccas, Manuel Meszarovits, Andy Mac Photography, Spanish Paralympics Comittee, Fundación AXA, AXA Seguros, Fotolia, FSB Task Force on Climate-related Financial Disclosures, Ana Solorzano/CARE, Ian Teh, UNICEF/UNI178926/Ramos, Miles Sabin, OxF2, Philippe Dureuil, odanielgp, Java User Group Belgium, American Telephone and Telegraph Company, Stig Nygaard, MjZ Photography, UN Photo/Rick Bajornas, Sean Dreilinger – Durak.org, Šarūnas Burdulis, Abbie-Trayler-Smith_Panos, Ars Electronica, Musée du Louvre, Guillaume Pagnard',
                                    spans: [],
                                  },
                                ],
                              },
                            ],
                          },
                        ],
                        url: '/en/about-us/Legal-Information-20190731',
                        url_en: '/en/about-us/Legal-Information-20190731',
                        url_fr: '/fr/a-propos-d-axa/mentions-legales-20190731',
                        prismic: {
                          creationDate: null,
                          updateDate: '2020-04-23T07:52:22+0000',
                        },
                      },
                      isBroken: false,
                    },
                  },
                },
              ],
            },
          ],
          url: '/en/about-us/axa-contacts',
          url_en: '/en/about-us/axa-contacts',
          url_fr: '/fr/a-propos-d-axa/contacts-groupe-axa',
          prismic: {
            creationDate: '2017-09-07T09:00:35+0000',
            updateDate: '2020-06-11T13:16:08+0000',
          },
        },
        linkName: 'Contact us',
      },
    },
  ],
  url: '/en/page/qa-landing-press',
  url_en: '/en/page/qa-landing-press',
  url_fr: '/fr/page/qa-landing-press',
  prismic: {
    creationDate: '2020-06-11T13:16:08+0000',
    updateDate: '2020-06-11T13:16:08+0000',
  },
}

import simpleCardDeck from '../../organisms/Slices/SimpleCardDeck/SimpleCardDeck.types'
import iconTextBlock from '../../organisms/Slices/IconTextBlock/IconTextBlock.types'
import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import cover from '../../organisms/Slices/Cover/Cover.types'
import coverTextOnly from '../../organisms/Slices/CoverTextOnly/CoverTextOnly.types'
import coverColorBackground from '../../organisms/Slices/CoverColorBackground/CoverColorBackground.types'
import { getPublications } from '../../organisms/Slices/Publications/Publications.types'
import contacts from '../../organisms/Slices/Contacts/Contacts.types'
import newsletterBlock from '../../organisms/Slices/NewsletterBlock/NewsletterBlock.types'
import spotLight from '../../organisms/Slices/Spotlight/Spotlight.types'
import calendar from '../../organisms/Slices/Calendar/Calendar.types'
import earnings from '../../organisms/Slices/Earnings/Earnings.types'
import articleThumbnailList from '../../organisms/Slices/ArticleThumbnailList/ArticleThumbnailList.types'
import articleSeries from '../../organisms/Slices/ArticleSeries/ArticleSeries.types'
import stickyThemeMenu from '../../organisms/Slices/StickyThemeMenu/StickyThemeMenu.types'
import textWithThumbnail from '../../organisms/Slices/TextWithThumbnail/TextWithThumbnail.types'
import spotlightNews from '../../organisms/Slices/SpotlightNews/SpotlightNews.types'
import { ctaBlockSlice } from '../../organisms/Slices/CtaBlock/CtaBlock.types'
import ctaDoubleBlock from '../../organisms/Slices/CtaDoubleBlock/CtaDoubleBlock.types'
import titleWithSubtitle from '../../organisms/Slices/TitleWithSubtitle/TitleWithSubtitle.types'
import cardsBlock from '../../organisms/Slices/CardsBlock/CardsBlock.types'
import videoEmbedded from '../../organisms/Slices/VideoEmbedded/VideoEmbedded.types'
import longQuote from '../../organisms/Slices/LongQuote/LongQuote.types'
import highlight from '../../organisms/Slices/Highlight/Highlight.types'
import contactUsBlock from '../../organisms/Slices/ContactUsBlock/ContactUsBlock.types'
import newsletterFormBlock from '../../organisms/Slices/NewsletterFormBlock/NewsletterFormBlock.types'
import paragraph from '../../organisms/Slices/Paragraph/Paragraph.types'
import doubleImage from '../../organisms/Slices/DoubleImage/DoubleImage.types'
import singleImage from '../../organisms/Slices/SingleImage/SingleImage.types'
import iframeBlock from '../../organisms/Slices/IframeBlock/IframeBlock.types'
import anchorBlock from '../../organisms/Slices/AnchorBlock/AnchorBlock.types'
import tweets from '../../organisms/Slices/Tweets/Tweets.types'
import breakpointsImages from '../../organisms/Slices/BreakpointsImages/BreakpointsImages.types'
import horizontalChart from '../../organisms/Slices/HorizontalChart/HorizontalChart.types'
import teamContacts from '../../organisms/Slices/TeamContacts/TeamContacts.types'
import iframeFullWidth from '../../organisms/Slices/IframeFullWidth/IframeFullWidth.types'
import { thumbnailGallery } from '../../organisms/Slices/ThumbnailGallery/ThumbnailGallery.types'
import asideGroup from '../../organisms/Slices/AsideGroup/AsideGroup.types'
import documents from '../../organisms/Slices/Documents/Documents.types'
import spotlightIllustration from '../../organisms/Slices/SpotlightIllustration/SpotlightIllustration.types'
import carousel from '../../organisms/Slices/Carousel/Carousel.types'
import threeFiguresSlice from '../../organisms/Slices/ThreeFigures/ThreeFigures.types'
import twoFiguresSlice from '../../organisms/Slices/TwoFigures/TwoFigures.types'
import tableBlockSlice from '../../organisms/Slices/TableBlock/TableBlock.types'
import paragraphRelatedContent from '../../organisms/Slices/ParagraphRelatedContent/ParagraphRelatedContent.types'
import suggestedNewsletter from '../../organisms/Slices/SuggestedNewsletter/SuggestedNewsletter.types'
import lineChart from '../../organisms/Slices/LineChart/LineChart.types'
import pieChart from '../../organisms/Slices/PieChart/PieChart.types'
import contactList from '../../organisms/Slices/ContactList/ContactList.types'
import pressReleaseList from '../../organisms/Slices/PressReleaseList/PressReleaseList.types'

export default {
  $slug: {
    type: 'Text',
    fieldset: 'Slug',
    config: {
      placeholder: 'Slug',
      label: 'Slug',
      useAsTitle: true,
    },
  },
  ...getMetaContent(),
  $restriction: {
    type: 'Link',
    fieldset: 'Restriction',
    config: {
      placeholder: 'Reference',
      select: 'document',
      masks: ['restriction'],
    },
  },
  $sectionName: {
    type: 'Text',
    config: {
      placeholder: 'Your section name',
      label: 'Section name',
    },
  },
  $maskType: {
    type: 'Text',
    fieldset: 'Configuration (Do not touch this part)',
    config: {
      placeholder: 'Config ID',
    },
  },
  $body: {
    type: 'Slices',
    fieldset: 'Content',
    config: {
      choices: {
        anchorBlock,
        ...cardsBlock,
        ...carousel,
        ...spotlightNews,
        ...titleWithSubtitle,
        ...simpleCardDeck,
        ...iconTextBlock,
        ...cover,
        ...coverTextOnly,
        ...coverColorBackground,
        ...getPublications({ asSlice: true, withAnchor: true }),
        ...contacts,
        ...newsletterBlock,
        ...spotLight,
        ...calendar,
        ...earnings,
        ...articleSeries,
        ...articleThumbnailList,
        ...stickyThemeMenu,
        ...textWithThumbnail,
        ...ctaBlockSlice,
        ...ctaDoubleBlock,
        ...videoEmbedded,
        ...longQuote,
        ...highlight,
        ...contactUsBlock,
        ...paragraph,
        ...doubleImage,
        ...newsletterFormBlock,
        ...singleImage,
        ...iframeBlock,
        ...tweets,
        ...breakpointsImages,
        ...horizontalChart,
        ...teamContacts,
        ...iframeFullWidth,
        ...thumbnailGallery,
        ...asideGroup,
        ...documents,
        ...spotlightIllustration,
        ...threeFiguresSlice,
        ...twoFiguresSlice,
        ...suggestedNewsletter,
        ...paragraphRelatedContent,
        ...tableBlockSlice,
        ...lineChart,
        ...pieChart,
        ...contactList,
        ...pressReleaseList,
      },
    },
  },
}

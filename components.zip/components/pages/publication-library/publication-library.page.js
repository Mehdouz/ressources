import React from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Library from '@axacom-client/components/molecules/Library/Library'
import { LibraryContext, useLibrary } from '@axacom-client/store/LibraryContext'
import Head from 'next/head'

export default function PublicationLibraryPage({ title, filters, filterTitle }) {
  const { i18n } = useGlobalContext()
  const labelOlder = i18n.t('library.older')
  const labelLatest = i18n.t('publications.library.latest')

  let years = []
  let currentYear = new Date().getFullYear()

  for (let i = 0; i < 6; i++) {
    years.push({
      value: i === 5 ? 'before_' + (currentYear - i).toString() : (currentYear - i).toString(),
      date: i === 5 ? labelOlder : (currentYear - i).toString(),
    })
  }

  const yearFilters = [
    {
      date: labelLatest,
      value: 'past',
    },
    ...years,
  ]

  const defaultState = useLibrary({
    type: 'publications',
    apiUrl: '/_api/publications',
    apiUrlFilterLabel: 'topics[topic]',
    year: 'past',
    filterLabel: filterTitle,
    filters,
    yearFilters,
  })

  return (
    <>
      <Head>
        <title>{title}</title>
      </Head>
      <LibraryContext.Provider value={defaultState}>
        <Library title={title} />
      </LibraryContext.Provider>
    </>
  )
}

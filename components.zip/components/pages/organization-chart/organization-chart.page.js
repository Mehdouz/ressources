import React from 'react'
import styled from 'styled-components'
import log from '@axacom-client/logger'
import axacomClient from '@axacom-client/clients/axacom'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import Documents from '@axacom-client/components/organisms/Slices/Documents/Documents'
import ContactList from '@axacom-client/components/organisms/Slices/ContactList/ContactList'
import LightBanner from '@axacom-client/components/organisms/LightBanner/LightBanner'
import media from '@axacom-client/base/style/media'
import { media as mediaQueries } from '@axacom-client/base/style/variables'
import { Container } from '@axacom-client/components/atoms/ResponsiveContainer/ResponsiveContainer.style'
import OrganizationList from '@axacom-client/components/organisms/OrganizationList/OrganizationList'
import CtaBlock from '@axacom-client/components/organisms/Slices/CtaBlock/CtaBlock'

const PictureContainer = styled.div`
  width: 100%;
  height: 300px;
  margin-bottom: 32px;

  ${media.tablet`
    height: 420px;
  `}

  ${media.desktop`
    height: 500px;
    margin-top: 50px;
    margin-bottom: 60px;
  `}

  ${media.desktopLarge`
    margin-top: 60px;
    margin-bottom: 80px;
  `}
`

export default function OrganizationChart({
  persons,
  banner,
  breadcrumb,
  title,
  summary,
  attachment,
  attachmentTitle,
  contacts,
  personsDescription,
  personsTitle,
  ctaImage,
  ctaTitle,
  ctaSubtitle,
  ctaUrl,
  ctaUrlTitle,
}) {
  const { i18n } = useGlobalContext()

  const hasContacts = (() => {
    if (contacts.length > 0) {
      if (Object.keys(contacts[0]).length > 0) return true
      return false
    }
    return false
  })()

  const hasDocuments = (() => {
    if (attachment.length > 0) {
      if (Object.keys(attachment[0]).length > 0) return true
      return false
    }
    return false
  })()

  return (
    <>
      <LightBanner title={breadcrumb ? breadcrumb : i18n.t('organizationChartBanner.title')} bannerTitle={title} bannerSubtitle={summary} />
      {banner?.main?.url && (
        <Container>
          <PictureContainer>
            <picture>
              <source media={`(max-width: ${mediaQueries.phoneMax}px)`} srcSet={banner?.views?.small?.url} />
              <source media={`(max-width: ${mediaQueries.desktopMin}px)`} srcSet={banner?.views?.medium?.url} />
              <img data-testid="OrganizationChart__Image" style={{ objectFit: 'cover', width: '100%', height: '100%' }} src={banner?.main?.url} alt={banner?.main?.alt} />
            </picture>
          </PictureContainer>
        </Container>
      )}
      <OrganizationList title={personsTitle} description={personsDescription} persons={persons} />
      {(ctaTitle || ctaSubtitle) && <CtaBlock externalCtaImage={ctaImage} ctaTitle={ctaTitle} ctaSubTitle={ctaSubtitle} ctalUrl={ctaUrl} ctaUrlTitle={ctaUrlTitle} />}
      {hasDocuments && <Documents blockTitle={attachmentTitle} items={attachment} />}
      {hasContacts && <ContactList items={contacts} />}
    </>
  )
}

export const getOrganizationChartProcData = async ({ language, id, slug, translation, sectionReferrer }) => {
  log.debug('[Organization chart] getInitialProps')

  const document = (await axacomClient().get('/_api/documents/organization-chart', { params: { language, id, slug, translation, sectionReferrer } })).data
  const persons = (await axacomClient().get('/_api/persons', { params: { language, chartId: document.id } })).data

  function sortByOrganizationRanking(arr) {
    return arr.sort((a, b) => {
      const aRanking = (a.organizationLink.find((org) => org.organizationChart && org.organizationChart.id === document.id) || {}).organizationRanking || false
      const bRanking = (b.organizationLink.find((org) => org.organizationChart && org.organizationChart.id === document.id) || {}).organizationRanking || false

      if (aRanking !== false && bRanking === false) return -1
      if (aRanking === false && bRanking !== false) return 1
      if (aRanking < bRanking) return -1
      if (aRanking > bRanking) return 1
      return 0
    })
  }

  document.persons = sortByOrganizationRanking(persons)

  return document
}

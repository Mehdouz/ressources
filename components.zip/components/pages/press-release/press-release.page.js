import React from 'react'
import log from '@axacom-client/logger'
import axacomClient from '@axacom-client/clients/axacom'
import PressReleaseHeader from '@axacom-client/components/organisms/PressReleaseHeader/PressReleaseHeader'
import * as components from '@axacom-client/components/organisms/Slices'
import { ErrorSliceBoundary } from '@axacom-client/components/organisms/Error/Error'
import { camelCase } from 'lodash/string'

export default function PressRelease({ title, body, document, date }) {
  return (
    <>
      <PressReleaseHeader title={title} document={document} date={date} />
      {body &&
        body.map((slice, index) => {
          const Component = components[camelCase(slice.sliceType)]
          if (Component)
            return (
              <ErrorSliceBoundary sliceType={slice.sliceType} key={index}>
                <Component {...slice.value} />
              </ErrorSliceBoundary>
            )
        })}
    </>
  )
}

export const getPressReleaseProcData = async ({ language, slug }) => {
  log.debug('[PressRelease] getInitialProps')

  const document = (await axacomClient().get(`/_api/press-releases/${slug}`, { params: { language } })).data

  return document
}

import highlight from '../../organisms/Slices/Highlight/Highlight.types'
import longQuote from '../../organisms/Slices/LongQuote/LongQuote.types'
import paragraph from '../../organisms/Slices/Paragraph/Paragraph.types'
import videoEmbedded from '../../organisms/Slices/VideoEmbedded/VideoEmbedded.types'
import documents from '../../organisms/Slices/Documents/Documents.types'
import contactList from '../../organisms/Slices/ContactList/ContactList.types'

export default {
  $slug: {
    type: 'Text',
    fieldset: 'SEO',
    config: {
      placeholder: 'Slug',
      label: 'Slug',
      useAsTitle: true,
    },
  },
  $seoDescription: {
    type: 'Text',
    config: {
      label: 'SEO Description',
      placeholder: 'SEO Description',
    },
  },
  $tweet: {
    type: 'Text',
    fieldset: 'Social network sharing',
    config: {
      placeholder: 'Tweet',
      label: 'Tweet',
    },
  },
  $sharingImage: {
    type: 'Image',
    config: {
      placeholder: 'Sharing image',
      constraint: {
        width: 1200,
        height: 630,
      },
    },
  },
  $sharingDescription: {
    type: 'Text',
    config: {
      placeholder: 'Sharing Description',
      label: 'Sharing Description',
    },
  },
  $title: {
    type: 'Text',
    fieldset: 'Main info of your page',
    config: {
      placeholder: 'Your title',
      label: 'Title',
    },
  },
  date_en: {
    type: 'Timestamp',
    config: {
      label: 'Date',
    },
  },
  $document: {
    type: 'Link',
    fieldset: 'Document',
    config: {
      select: 'media',
      placeholder: 'Document',
    },
  },
  $documentTitle: {
    type: 'Text',
    config: {
      placeholder: 'Document title',
    },
  },
  $body: {
    type: 'Slices',
    fieldset: 'Body',
    config: {
      choices: {
        ...paragraph,
        ...highlight,
        ...videoEmbedded,
        ...longQuote,
        ...documents,
        ...contactList,
      },
    },
  },
}

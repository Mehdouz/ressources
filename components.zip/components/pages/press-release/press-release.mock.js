export default {
  type: 'press-release',
  _tags: [],
  id: 'XtZ8oxIAACsArCAY',
  uid: null,
  slug: 'decision-of-the-board-of-directors-in-respect-of-axa-dividend-proposal-for-2019',
  slug_en: 'decision-of-the-board-of-directors-in-respect-of-axa-dividend-proposal-for-2019',
  slug_fr: 'decision-du-conseil-administration-relative-au-versement-du-dividende-pour-exercice-2019',
  seoDescription:
    'Following recent communications from the European Insurance and Occupational Pensions Authority (“EIOPA”) and the Autorité de Contrôle Prudentiel et de Résolution (“ACPR”), relating to the adoption of a prudent approach towards dividend distributions during the Covid-19 pandemic, AXA’s Board of Directors, at its meeting on June 2nd, decided to reduce its dividend proposal from Euro 1.43 per share to Euro 0.73 per share.',
  tweet: 'Decision of the Board of Directors in respect of #AXA dividend proposal for 2019',
  sharingDescription: 'Decision of the Board of Directors in respect of #AXA dividend proposal for 2019',
  title: 'Decision of the Board of Directors in respect of AXA’s dividend proposal for 2019',
  date: '2020-06-03T05:00:00+0000',
  document: {
    file: {
      name: 'AXA_PR_20200603.pdf',
      kind: 'document',
      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fcc159dd2-55a7-402e-906f-2bfacb64c7b3_axa_pr_20200603.pdf',
      size: '280143',
    },
    target: 'file',
    url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com%2Fcc159dd2-55a7-402e-906f-2bfacb64c7b3_axa_pr_20200603.pdf',
  },
  body: [
    {
      sliceType: 'paragraph',
      sliceLabel: null,
      value: [
        {
          text: [
            {
              type: 'paragraph',
              text: 'Following recent communications from the European Insurance and Occupational Pensions Authority (“EIOPA”) and the Autorité de Contrôle Prudentiel et de Résolution (“ACPR”), relating to the adoption of a prudent approach towards dividend distributions during the Covid-19 pandemic, AXA’s Board of Directors, at its meeting on June 2nd, decided to reduce its dividend proposal from Euro 1.43 per share to Euro 0.73 per share. This proposal is subject to approval by shareholders at AXA’s Annual General Meeting on June 30, 2020. The dividend is expected to be paid on July 9, 2020 with an ex-dividend date of July 7, 2020.',
              spans: [
                {
                  start: 114,
                  end: 162,
                  type: 'em',
                },
              ],
            },
            {
              type: 'paragraph',
              text: 'The Board may consider proposing an additional payment to shareholders in 4Q 2020, up to Euro 0.70 per share*, as an exceptional distribution of reserves, subject to favorable market and regulatory conditions at that time. In the event that the Board decides to propose an additional payment, the proposal would then be subject to approval by shareholders at an adhoc General Meeting.',
              spans: [],
            },
          ],
        },
      ],
    },
    {
      sliceType: 'long-quote',
      sliceLabel: null,
      value: [
        {
          author: {
            type: 'person',
            _tags: ['Finance &Strategy', 'Team'],
            id: 'ViDH8BkAABkABS2w',
            uid: null,
            avatar: {
              main: {
                dimensions: {
                  width: 100,
                  height: 100,
                },
                alt: '',
                copyright: '',
                url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/4a3678db1d8bbd436739e4bbffc69bbbdd8c9661_duverne_100.jpg',
              },
              views: {},
            },
            lastname: 'Duverne',
            firstname: 'Denis',
            slug: 'denis-duverne',
            slug_en: 'denis-duverne',
            slug_fr: 'denis-duverne',
            seoDescription: 'Biography of Denis Duverne',
            role: 'Chairman of the Board of Directors of AXA',
            shortRole: 'Chairman of the Board of Directors of AXA',
            organizationLink: [
              {
                organizationChart: {
                  type: 'organization-chart',
                  _tags: [],
                  id: 'Ve2VAh4AAABIP2Fd',
                  uid: null,
                  _meta: {
                    slug: 'Text',
                    slug_en: 'Text',
                    slug_fr: 'Text',
                    seoDescription: 'Text',
                    seoDescription_en: 'Text',
                    seoDescription_fr: 'Text',
                    title: 'Text',
                    title_en: 'Text',
                    title_fr: 'Text',
                    breadcrumb: 'Text',
                    breadcrumb_en: 'Text',
                    breadcrumb_fr: 'Text',
                    summary: 'Text',
                    summary_en: 'Text',
                    summary_fr: 'Text',
                    banner: 'Image',
                    personsDescription: 'Text',
                    personsDescription_en: 'Text',
                    personsDescription_fr: 'Text',
                    eventAudience: 'Group',
                    attachment: 'Group',
                    contacts: 'Group',
                  },
                  slug: 'members-board-of-directors',
                  slug_en: 'members-board-of-directors',
                  slug_fr: 'membres-conseil-administration',
                  seoDescription: 'Meet the members of our Board of Directors and find out more about their directorship, experience and expertise.',
                  title: 'Members of the Board of Directors',
                  breadcrumb: 'About AXA',
                  summary: 'Meet the members of our Board of Directors and find out more about their directorship, experience and expertise.',
                  banner: {
                    main: {
                      dimensions: {
                        width: 1920,
                        height: 1280,
                      },
                      alt: '',
                      copyright: '',
                      url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/94fa00b4d1658c8ee5fd89dc2ef90b06b250ac77_imm1.jpg',
                    },
                    views: {
                      medium: {
                        dimensions: {
                          width: 970,
                          height: 545,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f71708a6efef39a54dc96f03087ab6b33b1e1008_imm1.jpg',
                      },
                      small: {
                        dimensions: {
                          width: 768,
                          height: 432,
                        },
                        alt: '',
                        copyright: '',
                        url: 'https://www-axa-com.cdn.axa-contento-118412.eu/www-axa-com/f221a231245f3d5f3a9349e2fb44793946c013bd_imm1.jpg',
                      },
                    },
                  },
                  personsDescription: 'Composition of the Board of Directors on May 13, 2020',
                  eventAudience: [],
                  attachment: [],
                  contacts: [],
                  url: '/en/about-us/commitee/members-board-of-directors',
                  url_en: '/en/about-us/commitee/members-board-of-directors',
                  url_fr: '/fr/a-propos-d-axa/instance-gouvernance/membres-conseil-administration',
                  prismic: {
                    creationDate: null,
                    updateDate: '2020-05-15T07:59:14+0000',
                  },
                },
                organizationRanking: 1,
              },
            ],
            linkedin: 'https://www.linkedin.com/in/denis-duverne-76b03784',
            birthdate: '1953-10-31',
            nationality: 'French nationality',
            content: [
              {
                sliceType: 'paragraph',
                sliceLabel: null,
                value: [
                  {
                    text: [
                      {
                        type: 'heading2',
                        text: 'Directorship and number of AXA shares',
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: "Appointed on April 25, 2018 - Term expires at the 2022 Shareholders' Meeting",
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: 'First appointment on April 29, 2010',
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: 'Number of AXA shares / ADS AXA held on December 31, 2018: 1,595,071',
                        spans: [],
                      },
                      {
                        type: 'heading3',
                        text: 'On December 31, 2019',
                        spans: [],
                      },
                      {
                        type: 'heading2',
                        text: 'Expertise and experience',
                        spans: [],
                      },
                      {
                        type: 'paragraph',
                        text: 'Mr. Denis Duverne is a graduate of the École des Hautes Études Commerciales (HEC). After graduating from the École Nationale d’Administration (ENA), he started his career in 1979 at the Tax Department of the French Ministry of Finance, and after 2 years as commercial counsellor for the French Consulate General in New York (1984-1986), he became director of the Corporate Taxes Department and then responsible for tax policy within the French Ministry of Finance from 1986 to 1991. In 1991, he was appointed Corporate Secretary of Compagnie Financière IBI. In 1992, he became a member of the Executive Committee of Banque Colbert, in charge of operations. In 1995, Mr. Denis Duverne joined the AXA Group and assumed responsibility for supervision of AXA’s operations in the US and the UK and managed the reorganization of AXA companies in Belgium and the United Kingdom. From February 2003 until December 2009, Mr. Denis Duverne was the Management Board member in charge of Finance, Control and Strategy. From January 2010 until April 2010, Mr. Denis Duverne assumed broader responsibilities as Management Board member in charge of Finance, Strategy and Operations. From April 2010 to August 31, 2016, Mr. Denis Duverne was director and Deputy Chief Executive Off icer of AXA, in charge of Finance, Strategy and Operations. Mid-2014, Mr. Denis Duverne became a member of the Private Sector Advisory Group (PSAG), which brings together international leaders of the private sector whose shared goal is to help developing countries improve their corporate governance, co-founded in 1999 by the World Bank and the Organisation for Economic Cooperation and Development (OECD). Since September 1, 2016, Mr. Denis Duverne has been non-executive Chairman of the Board of Directors of AXA. Since September 2018, he has been Chairman of the Insurance Development Forum (IDF). The IDF is a public-private partnership led by the insurance industry and supported by the World Bank and the United Nations, aiming to enhance the use of insurance to build greater resilience against disasters and to help achieve the United Nations Global 2030 Agenda.',
                        spans: [
                          {
                            start: 39,
                            end: 76,
                            type: 'em',
                          },
                          {
                            start: 109,
                            end: 142,
                            type: 'em',
                          },
                        ],
                      },
                      {
                        type: 'heading3',
                        text: '',
                        spans: [],
                      },
                      {
                        type: 'heading2',
                        text: 'Directorships held within the AXA Group',
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: 'Chairman of the Board of Directors: AXA',
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: 'Chairman: AXA Millésimes (SAS)',
                        spans: [],
                      },
                      {
                        type: 'heading2',
                        text: 'Directorship held outside the AXA Group',
                        spans: [],
                      },
                      {
                        type: 'paragraph',
                        text: 'None',
                        spans: [],
                      },
                      {
                        type: 'heading2',
                        text: 'Directorships held during the last five years',
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: 'Deputy Chief Executive Officer: AXA',
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: 'Chairman & Chief Executive Officer: AXA America Holdings, Inc. (United States)',
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: 'Chairman of the Board of Directors: AXA Holdings Belgium (Belgium), AXA Financial, Inc. (United States)',
                        spans: [],
                      },
                      {
                        type: 'list-item',
                        text: 'Director or member of the Management Committee: AXA ASIA (SAS), AllianceBernstein Corporation (United States), AXA Assicurazioni S.p.A. (Italy), AXA Belgium SA (Belgium), AXA Equitable Life Insurance Company (United States), AXA Italia S.p.A. (Italy), AXA MPS Assicurazioni Danni S.p.A. (Italy), AXA MPS Assicurazioni Vita S.p.A. (Italy), AXA UK plc (United Kingdom), MONY Life Insurance Company (United States), MONY Life Insurance Company of America (United States)',
                        spans: [],
                      },
                    ],
                  },
                ],
              },
            ],
            url: '/en/about-us/profile/denis-duverne',
            url_en: '/en/about-us/profile/denis-duverne',
            url_fr: '/fr/a-propos-d-axa/profil/denis-duverne',
            prismic: {
              creationDate: null,
              updateDate: '2020-05-20T15:54:20+0000',
            },
          },
          quote: [
            {
              type: 'paragraph',
              text: 'From the very beginning of the Covid-19 crisis, AXA’s priority has been to act responsibly towards all its stakeholders.',
              spans: [],
            },
            {
              type: 'paragraph',
              text: 'AXA’s first priority has been to help its customers navigate through this crisis and to protect the safety of its employees, including guaranteeing their full employment for the duration of the confinement period. The Group also continues to support its most impacted customers by taking a range of exceptional measures beyond its contractual obligations, and the wider community by participating in national solidarity efforts including contributions to various public funds. Reflecting the strength of the Group’s balance sheet, AXA has fulfilled these undertakings without requesting any government aid.',
              spans: [],
            },
            {
              type: 'paragraph',
              text: 'The Board of Directors’ decision to reduce the proposed dividend demonstrates the same sense of responsibility towards AXA’s institutional and individual shareholders, while adopting a prudent approach in the current environment.',
              spans: [],
            },
          ],
        },
      ],
    },
    {
      sliceType: 'paragraph',
      sliceLabel: null,
      value: [
        {
          text: [
            {
              type: 'paragraph',
              text: 'During the meeting, AXA’s management also updated the Board on its current best estimate of the impact on 2020 underlying earnings for the Group from claims related to Covid-19. These estimates add further precision to the indications already provided in the 1Q20 disclosure, notably',
              spans: [],
            },
            {
              type: 'list-item',
              text: 'P&C: an overall claims cost of ca. Euro -1.2 billion** post-tax and net of reinsurance. Consistent with indications given in the 1Q20 disclosure, management expects the most material impacts from Business Interruption and Event Cancellation, and to a lesser extent from other lines (e.g. D&O, Liability and Travel), partly offset by reduced claims in some areas, notably from Motor.',
              spans: [],
            },
            {
              type: 'list-item',
              text: 'Life and Health: no material deviation has been observed in current claims experience.',
              spans: [],
            },
            {
              type: 'list-item',
              text: 'Solidarity measures: an overall impact of ca. Euro -0.3 billion** post-tax. This includes extended health and disability coverage to vulnerable customers, most notably in France.',
              spans: [],
            },
            {
              type: 'paragraph',
              text: 'The estimates provided above are based on management’s current assessment and are subject to change depending on the continued evolution of the Covid-19 pandemic and its related impacts. For investment margin, unit-linked and asset management fees, no estimate is provided as the impact will depend on the evolution of financial market conditions through the remainder of the year.',
              spans: [],
            },
            {
              type: 'paragraph',
              text: '',
              spans: [],
            },
            {
              type: 'heading6',
              text: '*This amount will be allocated to “Other reserves” under Shareholders’ Equity in AXA Group’s HY2020 financial statements, and will continue to be deducted in AXA Group’s HY2020 Solvency II ratio.',
              spans: [
                {
                  start: 0,
                  end: 195,
                  type: 'em',
                },
              ],
            },
            {
              type: 'heading6',
              text: '**As a reminder, AXA Group’s Underlying Earnings in 2019 were Euro 6.5 billion',
              spans: [
                {
                  start: 0,
                  end: 78,
                  type: 'em',
                },
              ],
            },
          ],
        },
      ],
    },
    {
      sliceType: 'contacts',
      sliceLabel: null,
      value: [
        {
          contact: {
            type: 'contact',
            _tags: [],
            id: 'Vl7CqCAAAJEjR7_o',
            uid: null,
            name: 'Investor Relations team',
            section: 'Investor Relations',
            phone: '+33 1 40 75 48 42',
            url: '/not-resolved',
            url_en: '/not-resolved',
            url_fr: '/not-resolved',
            prismic: {
              creationDate: null,
              updateDate: null,
            },
          },
        },
        {
          contact: {
            type: 'contact',
            _tags: ['Contact'],
            id: 'Veh3JR4AAKAAILFL',
            uid: null,
            name: 'Axa Media Relations',
            section: 'Media relations',
            phone: '+33.1.40.75.46.68',
            url: '/not-resolved',
            url_en: '/not-resolved',
            url_fr: '/not-resolved',
            prismic: {
              creationDate: null,
              updateDate: null,
            },
          },
        },
      ],
    },
  ],
  url: '/en/press/press-releases/decision-of-the-board-of-directors-in-respect-of-axa-dividend-proposal-for-2019',
  url_en: '/en/press/press-releases/decision-of-the-board-of-directors-in-respect-of-axa-dividend-proposal-for-2019',
  url_fr: '/fr/presse/communiques-de-presse/decision-du-conseil-administration-relative-au-versement-du-dividende-pour-exercice-2019',
  prismic: {
    creationDate: '2020-06-03T05:00:36+0000',
    updateDate: '2020-06-03T14:10:37+0000',
  },
}

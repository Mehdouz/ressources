import React from 'react'
import * as components from '@axacom-client/components/organisms/Slices'
import { ErrorSliceBoundary, RequirementsErrorMessage } from '@axacom-client/components/organisms/Error/Error'
import StoriesStickyHeader from '@axacom-client/components/organisms/StoriesStickyHeader/StoriesStickyHeader'
import log from '@axacom-client/logger'
import { i18n } from '@i18n-axa'
import { getStory } from '@axacom-client/repositories/documents'
import { camelCase } from 'lodash/string'
import { colors } from '@axacom-client/base/style/variables'
import { timeToSentence, wordsReadTime } from '@axacom-client/services/string-service'
import { getBodyAsString } from '@axacom-client/services/document-service'
import axacomClient from '@axacom-client/clients/axacom'
import CoverStory from '@axacom-client/components/organisms/Slices/CoverStory/CoverStory'
import RelatedStories from '@axacom-client/components/organisms/Slices/RelatedStories/RelatedStories'

export default function Stories({ body, color, cover, readTime, hasMissingRequirements, relatedStories, relatedStoriesLink }) {
  const colorTheme = color.toLowerCase()
  const storyColors = colors.stories[colorTheme]

  if (hasMissingRequirements) {
    return <RequirementsErrorMessage />
  }

  return (
    <>
      <StoriesStickyHeader title={cover[0].title} />
      <CoverStory cover={cover[0]} readTime={readTime} />
      {body &&
        body.map((slice, index) => {
          const Component = components[camelCase(slice.sliceType)]
          if (Component)
            return (
              <ErrorSliceBoundary sliceType={slice.sliceType} key={index}>
                <Component {...slice.value} storyColors={storyColors} />
              </ErrorSliceBoundary>
            )
        })}
      <RelatedStories stories={relatedStories} storiesLink={relatedStoriesLink} />
    </>
  )
}

Stories.getInitialProps = async (context) => {
  log.debug('[Stories] getInitialProps')
  const language = (context.req || i18n).language
  const document = await getStory(context.query)

  if (document?.body) {
    // Add readtime
    const wordTime = wordsReadTime(getBodyAsString(document)).wordTime
    document.readTime = timeToSentence(wordTime, language, true)

    // Slice keyFigures if there is more than 3 items and add a boolean to see if its last element
    document.body.forEach((slice) => {
      if (slice.sliceType === 'keyFiguresStory') {
        slice.value.items = slice.value.items.slice(0, 3)

        // Add isLastElement to figure
        slice.value.items.forEach((item, index, figures) => {
          item.isLastElement = index == figures.length - 1
        })
      }
    })

    // Prevent having empty object that can be returned from contribution
    document.relatedStories = document.relatedStories.filter(({ stories }) => !!stories?.id).filter(({ stories }) => stories.id !== document.id)

    const missingItems = 4 - document.relatedStories.length

    if (missingItems <= 0) {
      document.relatedStories = document.relatedStories.slice(0, 4)
    } else {
      // Query 6 last stories (based on stories.date) from prismic
      const stories = (await axacomClient().get('/_api/stories', { params: { size: 6, language } })).data || []

      // Filter to prevent duplicate stories & not having the original document in related stories
      const filteredStories = stories.filter((story) => document.relatedStories.every((contribStory) => story.id !== contribStory.stories.id)).filter((story) => story.id !== document.id)
      const relatedStories = filteredStories.map((story) => ({ stories: story }))

      // Add queried stories from prismic to the original ones from the contribution
      document.relatedStories.push(...relatedStories.slice(0, missingItems))
    }

    // Add readTime to related stories
    document.relatedStories.forEach((relatedStory) => {
      const timeWords = wordsReadTime(getBodyAsString(relatedStory?.stories)).wordTime
      relatedStory.stories.readTime = timeToSentence(timeWords, language, true)
    })
  }

  return document
}

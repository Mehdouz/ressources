import firstContent from '../../organisms/Slices/FirstContents/FirstContents.validation'
import singleImageStory from '../../organisms/Slices/SingleImageStory/SingleImageStory.validation'
import keyFiguresStory from '../../organisms/Slices/KeyFiguresStory/KeyFiguresStory.validation'
import video from '../../organisms/Slices/Video/Video.validation'
import scrollyTelling from '../../organisms/Slices/ScrollyTelling/ScrollyTelling.validation'

export default [
  (document) => {
    return document.date !== null
  },
  (document) => {
    return document.cover[0].image !== undefined && document.cover[0].title !== undefined
  },
  (document) => {
    return document.body.some((slice) => slice.sliceType === 'storyFirstContents')
  },
  ...firstContent,
  ...singleImageStory,
  ...keyFiguresStory,
  ...scrollyTelling,
  ...video,
]

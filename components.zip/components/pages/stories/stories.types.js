import { Select, Group, Image, Text, Slices, Link } from '../../../../tools/prismic/backup-types/generic-type'
import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import FirstContents from '../../organisms/Slices/FirstContents/FirstContents.types'
import SingleImageStory from '../../organisms/Slices/SingleImageStory/SingleImageStory.types'
import KeyFiguresStory from '../../organisms/Slices/KeyFiguresStory/KeyFiguresStory.types'
import Video from '../../organisms/Slices/Video/Video.types'
import Documents from '../../organisms/Slices/Documents/Documents.types'
import ScrollyTelling from '../../organisms/Slices/ScrollyTelling/ScrollyTelling.types'

export default {
  $slug: {
    type: 'Text',
    fieldset: 'SEO',
    config: {
      placeholder: 'Slug',
      label: 'Slug',
      useAsTitle: true,
    },
  },
  $tags: Group({ tag: Link('Tag', 'document', ['tag']) }, 'Tags', true),
  ...getMetaContent(['tweet', 'sharingImage']),
  $color: Select(['Apache', 'Ocean', 'Teal', 'Tosca', 'Viridian'], 'Background Color (Mandatory)', undefined, 'Ocean'),
  $date: {
    type: 'Timestamp',
    fieldset: 'Date (Mandatory)',
    config: {
      label: 'Date (Mandatory)',
      placeholder: 'Date (Mandatory)',
    },
  },
  $cover: Group(
    {
      image: Image('Cover Image (768x768, mandatory)', { width: 768, height: 768 }),
      landingImage: Image('Landing Image (1536x860, mandatory)', { width: 1536, height: 860 }, [
        {
          name: 'desktop',
          width: 960,
          height: 538,
        },
        {
          name: 'tablet',
          width: 768,
          height: 430,
        },
        {
          name: 'mobile',
          width: 375,
          height: 210,
        },
      ]),
      title: Text('Title (Mandatory) (70 characters max)'),
    },
    'Cover (Mandatory)'
  ),
  $body: Slices({
    ...FirstContents,
    ...SingleImageStory,
    ...KeyFiguresStory,
    ...Video,
    ...Documents,
    ...ScrollyTelling,
  }),
  $relatedStoriesLink: Group(
    {
      linkLabel: Text('Link Label', 'Link label'),
      link: Link('Link'),
    },
    'All stories',
    false
  ),
  $relatedStories: Group(
    {
      stories: Link('Stories', 'document', ['stories'], true, 'Related Stories'),
    },
    'Related Stories',
    true,
    'Related Stories'
  ),
}

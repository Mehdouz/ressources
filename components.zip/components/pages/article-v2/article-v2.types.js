import { Group, Image, Link, Select, Slices, Text } from '../../../../tools/prismic/backup-types/generic-type'
import { getMetaContent } from '../../molecules/MetaContent/MetaContent.types'
import anchorBlock from '../../organisms/Slices/AnchorBlock/AnchorBlock.types'
import breakpointsImages from '../../organisms/Slices/BreakpointsImages/BreakpointsImages.types'
import cardsBlock from '../../organisms/Slices/CardsBlock/CardsBlock.types'
import carousel from '../../organisms/Slices/Carousel/Carousel.types'
import cover from '../../organisms/Slices/Cover/Cover.types'
import { ctaBlockGroup } from '../../organisms/Slices/CtaBlock/CtaBlock.types'
import ctaDoubleBlock from '../../organisms/Slices/CtaDoubleBlock/CtaDoubleBlock.types'
import documents from '../../organisms/Slices/Documents/Documents.types'
import doubleImage from '../../organisms/Slices/DoubleImage/DoubleImage.types'
import earnings from '../../organisms/Slices/Earnings/Earnings.types'
import highlight from '../../organisms/Slices/Highlight/Highlight.types'
import horizontalChart from '../../organisms/Slices/HorizontalChart/HorizontalChart.types'
import iframeBlock from '../../organisms/Slices/IframeBlock/IframeBlock.types'
import longQuote from '../../organisms/Slices/LongQuote/LongQuote.types'
import paragraph from '../../organisms/Slices/Paragraph/Paragraph.types'
import paragraphRelatedContent from '../../organisms/Slices/ParagraphRelatedContent/ParagraphRelatedContent.types'
import simpleCardDeck from '../../organisms/Slices/SimpleCardDeck/SimpleCardDeck.types'
import singleImage from '../../organisms/Slices/SingleImage/SingleImage.types'
import spotlightIllustration from '../../organisms/Slices/SpotlightIllustration/SpotlightIllustration.types'
import suggestedNewsletter from '../../organisms/Slices/SuggestedNewsletter/SuggestedNewsletter.types'
import threeFiguresSlice from '../../organisms/Slices/ThreeFigures/ThreeFigures.types'
import { thumbnailGallery } from '../../organisms/Slices/ThumbnailGallery/ThumbnailGallery.types'
import titleWithSubtitle from '../../organisms/Slices/TitleWithSubtitle/TitleWithSubtitle.types'
import tweets from '../../organisms/Slices/Tweets/Tweets.types'
import twoFiguresSlice from '../../organisms/Slices/TwoFigures/TwoFigures.types'
import videoEmbedded from '../../organisms/Slices/VideoEmbedded/VideoEmbedded.types'

export default {
  $slug: {
    type: 'Text',
    fieldset: 'Slug',
    config: {
      placeholder: 'Slug',
      label: 'Slug',
      useAsTitle: true,
    },
  },
  $canonical: Link('Canonical URL', 'web', undefined, undefined, 'https://my-url.com'),
  $theme: Link('Topic', 'document', ['theme-v2']),
  $date: {
    type: 'Timestamp',
    fieldset: 'Date',
    config: {
      label: 'Date',
      placeholder: 'Date',
    },
  },
  $hideDate: Select(['No', 'Yes'], 'Hide date ?', undefined, 'No'),
  $typeArticle: Select(['News', 'Press-News', 'Insights'], 'Type'),
  $contentType: Text('Content Type (optional)', 'Use short labels and refer to the existing classification for consistency'),
  ...getMetaContent(['seoDescription', 'tweet', 'sharingImage', 'sharingDescription', 'title', 'summary', 'summaryStructured']),
  $author: Group(
    {
      referenceAuthor: Link('Reference Author', 'document', ['person']),
      fullName: Text('Full Name'),
      role: Text('Role'),
      avatar: Image('Avatar'),
    },
    'Author'
  ),
  $kind: Select(['News', 'Op-ed', 'Appointment'], 'Kind'),
  $body: Slices({
    ...cover,
    ...simpleCardDeck,
    ...videoEmbedded,
    ...longQuote,
    ...highlight,
    ...paragraph,
    ...doubleImage,
    ...singleImage,
    ...horizontalChart,
    ...earnings,
    anchorBlock,
    ...spotlightIllustration,
    ...documents,
    ...carousel,
    ...threeFiguresSlice,
    ...twoFiguresSlice,
    ...paragraphRelatedContent,
    ...iframeBlock,
    ...breakpointsImages,
    ...suggestedNewsletter,
    ...thumbnailGallery,
    ...tweets,
    ...cardsBlock,
    ...titleWithSubtitle,
    ...ctaBlockGroup,
    ...ctaDoubleBlock,
    suggested_publication: {
      fieldset: 'Paragraph with related publication module',
      type: 'Group',
      config: {
        repeat: false,
        fields: {
          anchorPoint: {
            type: 'Text',
            config: {
              placeholder: 'Lorem ipsum label',
              label: 'Anchor Label',
            },
          },
          publication: {
            type: 'Link',
            config: {
              select: 'document',
              masks: ['publication'],
              placeholder: 'Publication',
            },
          },
          paragraph: {
            type: 'StructuredText',
            config: {
              placeholder: 'Paragraph',
            },
          },
          title: {
            type: 'Text',
            config: {
              placeholder: 'replacement title',
            },
          },
        },
      },
    },
  }),
  $related_articles: {
    type: 'Group',
    fieldset: 'Related articles',
    config: {
      fields: {
        article: {
          type: 'Link',
          config: {
            select: 'document',
            masks: ['article-v2'],
            placeholder: 'News',
          },
        },
      },
    },
  },
}

import React from 'react'
import axacomClient from '@axacom-client/clients/axacom'
import log from '@axacom-client/logger'
import { camelCase } from 'lodash/string'
import { ErrorSliceBoundary } from '@axacom-client/components/organisms/Error/Error'
import * as components from '@axacom-client/components/organisms/Slices'
import { ArticleHeader } from '@axacom-client/components/organisms/ArticleHeader/ArticleHeader'
import { timeToSentence, wordsReadTime } from '@axacom-client/services/string-service'
import { getBodyAsString } from '@axacom-client/services/document-service'
import { augmentSlices } from '@axacom-client/services/article-service'
import RelatedArticles from '@axacom-client/components/organisms/RelatedArticles/RelatedArticles'
import ArticleTheme from '@axacom-client/components/organisms/ArticleTheme/ArticleTheme'
import ArticleStickyHeader from '@axacom-client/components/organisms/ArticleStickyHeader/ArticleStickyHeader'

export default function ArticleV2(props) {
  const { author, cover, date, theme, readTime, body, related_articles, typeArticle } = props

  return (
    <>
      <ArticleStickyHeader title={cover?.title} />
      <ArticleHeader author={author} cover={cover} date={date} theme={theme} readTime={readTime} typeArticle={typeArticle} />
      {body &&
        body.map((slice, index) => {
          const Component = components[camelCase(slice.sliceType)]
          if (Component) {
            return (
              /* preparing for react suspense */
              <ErrorSliceBoundary sliceType={slice.sliceType} key={index}>
                <Component {...slice.value} key={index} />
              </ErrorSliceBoundary>
            )
          }
        })}
      <ArticleTheme theme={theme} />
      <RelatedArticles articles={related_articles} />
    </>
  )
}

export const getArticleV2ProcData = async ({ language, slug }) => {
  log.debug('[ArticleV2] getInitialProps')

  const document = (await axacomClient().get(`/_api/documents/article-v2`, { params: { language, slug } })).data
  const topic = document?.theme?.id

  // Prevent having empty object that can be returned from contribution
  document.related_articles = document.related_articles
    .filter(({ article }) => !!article?.id)
    .filter(({ article }) => article.id !== document.id)
    .map((originalArticle) => originalArticle?.article)

  const missingItems = 4 - document.related_articles.length

  if (missingItems <= 0) {
    document.related_articles = document.related_articles.slice(0, 4)
  } else {
    // Query 6 last articles (based on stories.date) from prismic
    const articles = (await axacomClient().get(`/_api/articles-with-topic`, { params: { language, slug, size: 6, topic } })).data || []

    // Filter to prevent duplicate articles & not having the original document in related stories
    const filteredArticles = articles.filter((article) => document.related_articles.every(({ contribArticle }) => article.id !== contribArticle?.id)).filter((article) => article.id !== document.id)
    const relatedArticles = filteredArticles.map((article) => ({ ...article }))

    // Add queried stories from prismic to the original ones from the contribution
    document.related_articles.push(...relatedArticles.slice(0, missingItems))
  }

  // Put cover on first level of the doc & on related articles
  document?.body?.forEach((slice, index) => {
    if (slice?.sliceType === 'cover') {
      document.cover = { ...slice.value }
      document.body.splice(index, 1)
    }
  })

  document?.related_articles?.forEach((article) => {
    article?.body?.forEach((slice, sliceIndex) => {
      if (slice.sliceType === 'cover') {
        article.cover = { ...slice.value }
        article.body.splice(sliceIndex, 1)
      }
    })
  })

  // Augment Slices
  document.body = augmentSlices(document.body)

  // Add readtime to document
  const timeWords = wordsReadTime(getBodyAsString(document)).wordTime
  document.readTime = timeToSentence(timeWords, language, false)

  return document
}

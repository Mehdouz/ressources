import longQuote from '../../organisms/Slices/LongQuote/LongQuote.types'
import paragraph from '../../organisms/Slices/Paragraph/Paragraph.types'
import highlight from '../../organisms/Slices/Highlight/Highlight.types'
import documents from '../../organisms/Slices/Documents/Documents.types'
import { Select } from '../../../../tools/prismic/backup-types/generic-type'

export default {
  $deactivateProfile: Select(['No', 'Yes'], 'Deactivate profile ?', undefined, 'No'),
  $isAxaMember: Select(['Yes', 'No'], 'Member of AXA ?', undefined, 'Yes'),
  $avatar: {
    type: 'Image',
    config: {
      placeholder: 'Avatar',
      constraint: {
        width: 100,
        height: 100,
      },
    },
  },
  $lastname: {
    type: 'Text',
    config: {
      placeholder: 'Last name',
      label: 'Last name',
      useAsTitle: true,
    },
  },
  $firstname: {
    type: 'Text',
    config: {
      placeholder: 'First name',
      label: 'First name',
    },
  },
  $slug: {
    type: 'Text',
    fieldset: 'SEO',
    config: {
      placeholder: 'Slug',
      label: 'Slug',
    },
  },
  $seoDescription: {
    type: 'Text',
    config: {
      placeholder: 'SEO Description',
      label: 'SEO Description',
    },
  },
  $tweet: {
    type: 'Text',
    fieldset: 'Social network sharing',
    config: {
      placeholder: 'Tweet',
      label: 'Tweet',
    },
  },
  $sharingImage: {
    type: 'Image',
    config: {
      placeholder: 'Sharing image',
      constraint: {
        width: 1200,
        height: 630,
      },
      thumbnails: [
        {
          name: 'facebook',
          width: 600,
          height: 315,
        },
        {
          name: 'linkedin',
          width: 180,
          height: 110,
        },
        {
          name: 'twitter',
          width: 120,
          height: 120,
        },
      ],
    },
  },
  $sharingDescription: {
    type: 'Text',
    config: {
      placeholder: 'Sharing Description',
      label: 'Sharing Description',
    },
  },
  $role: {
    type: 'Text',
    fieldset: 'Infos',
    config: {
      placeholder: 'Role',
      label: 'Role',
    },
  },
  $shortRole: {
    type: 'Text',
    config: {
      placeholder: 'Short role appear on the organization chart',
      label: 'Short role (Organization Chart)',
    },
  },
  $shortDescription1: {
    type: 'Text',
    config: {
      placeholder: 'Line 1 (role or start mandate)',
      label: 'Short description (Chart)',
    },
  },
  $shortDescription2: {
    type: 'Text',
    config: {
      placeholder: 'Line 2 (role or end mandate)',
      label: 'Short description (Chart)',
    },
  },
  $organizationLink: {
    type: 'Group',
    fieldset: 'Organization Charts',
    config: {
      fields: {
        organizationChart: {
          type: 'Link',
          config: {
            placeholder: 'Organization charts',
            select: 'document',
            masks: ['organization-chart'],
          },
        },
        organizationRanking: {
          type: 'Number',
          config: {
            label: 'Ranking',
          },
        },
      },
    },
  },
  $facebook: {
    type: 'Text',
    fieldset: 'Social accounts',
    config: {
      placeholder: 'https://www.facebook.com/myaccount',
      label: 'Facebook',
    },
  },
  $twitter: {
    type: 'Text',
    config: {
      placeholder: 'https://twitter.com/myaccount',
      label: 'Twitter',
    },
  },
  $linkedin: {
    type: 'Text',
    config: {
      placeholder: 'https://www.linkedin.com/in/myaccount',
      label: 'Linkedin',
    },
  },
  $birthdate: {
    type: 'Date',
    fieldset: 'Birth date',
    config: {
      placeholder: 'Birth date',
      label: 'Birth date',
    },
  },
  $nationality: {
    type: 'Text',
    fieldset: 'Nationality',
    config: {
      placeholder: 'Nationality',
      label: 'Nationality (profile)',
    },
  },
  $content: {
    type: 'Slices',
    fieldset: 'Content',
    config: {
      choices: {
        ...longQuote,
        ...paragraph,
        ...highlight,
        ...documents,
      },
    },
  },
}

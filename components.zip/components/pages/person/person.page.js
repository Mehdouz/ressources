import React from 'react'
import * as components from '@axacom-client/components/organisms/Slices'
import { ErrorSliceBoundary } from '@axacom-client/components/organisms/Error/Error'
import log from '@axacom-client/logger'
import { getDocumentData } from '@axacom-client/repositories/documents'
import { camelCase } from 'lodash/string'
import PersonHeader from '@axacom-client/components/organisms/PersonHeader/PersonHeader'
import { ClientError } from '@axacom-client/domains/errors'

export default function PersonPage({ avatar, birthdate, content, firstname, lastname, nationality, role, shortRole, organizationLink, facebook, linkedin, twitter }) {
  return (
    <>
      <PersonHeader
        avatar={avatar}
        birthdate={birthdate}
        organizationLink={organizationLink}
        firstname={firstname}
        lastname={lastname}
        nationality={nationality}
        role={role}
        shortRole={shortRole}
        facebook={facebook}
        linkedin={linkedin}
        twitter={twitter}
      />
      {content &&
        content.map((slice, index) => {
          const Component = components[camelCase(slice.sliceType)]
          if (Component)
            return (
              <ErrorSliceBoundary sliceType={slice.sliceType} key={index}>
                <Component {...slice.value} />
              </ErrorSliceBoundary>
            )
        })}
    </>
  )
}

export const getPersonProcData = async ({ query }) => {
  log.debug('[Person] getPersonProcData')
  const document = await getDocumentData('person', query)

  if (document?.deactivateProfile === 'Yes') {
    throw new ClientError('Not Found', 404)
  }

  return document
}

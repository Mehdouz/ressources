import React, { useState, useEffect } from 'react'
import log from '@axacom-client/logger'
import axacomClient from '@axacom-client/clients/axacom'
import * as components from '@axacom-client/components/organisms/Slices'
import { ErrorSliceBoundary } from '@axacom-client/components/organisms/Error/Error'
import { camelCase } from 'lodash/string'
import EventHeader from '@axacom-client/components/organisms/EventHeader/EventHeader'
import { BackToTop } from '@axacom-client/components/molecules/BackToTop/BackToTop'
import { colors } from '@axacom-client/base/style/variables'
import { getWindow } from '@axacom-client/services/window-service'
import { useScroll } from 'framer-motion/dist/framer-motion'

export default function Event({ title, eventBodyContent, description, eventTimeStart, eventTimeEnd, eventLink, streetAddress, streetAddress2, zipcode, city, country }) {
  const [isBackToTopVisible, setIsBackToTopVisible] = useState(false)
  const { scrollY } = useScroll()

  useEffect(() => {
    return scrollY.onChange((latest) => {
      if (latest >= getWindow().innerHeight * 0.7) {
        setIsBackToTopVisible(true)
      } else {
        setIsBackToTopVisible(false)
      }
    })
  }, [scrollY])

  return (
    <>
      <EventHeader
        title={title}
        description={description}
        eventTimeStart={eventTimeStart}
        eventTimeEnd={eventTimeEnd}
        streetAddress={streetAddress}
        streetAddress2={streetAddress2}
        zipcode={zipcode}
        city={city}
        country={country}
        eventLink={eventLink}
        $hasSlices={eventBodyContent?.length > 0}
      />
      {eventBodyContent &&
        eventBodyContent.map((slice, index) => {
          const Component = components[camelCase(slice.sliceType)]
          if (Component)
            return (
              <ErrorSliceBoundary sliceType={slice.sliceType} key={index}>
                <Component {...slice.value} />
              </ErrorSliceBoundary>
            )
        })}
      {isBackToTopVisible && <BackToTop color={colors.brandBlue} />}
    </>
  )
}

export const getEventProcData = async ({ language, slug, translation, sectionReferrer }) => {
  log.debug('[Event] getInitialProps')

  const document = (await axacomClient().get(`/_api/events/${slug}`, { params: { language, translation, sectionReferrer } })).data

  return document
}

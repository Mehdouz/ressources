import paragraph from '../../organisms/Slices/Paragraph/Paragraph.types'
import documentsSlice from '../../organisms/Slices/Documents/Documents.types'
import breakpointsImages from '../../organisms/Slices/BreakpointsImages/BreakpointsImages.types'
import contactList from '../../organisms/Slices/ContactList/ContactList.types'
import longQuote from '../../organisms/Slices/LongQuote/LongQuote.types'

export default {
  $slug: {
    type: 'Text',
    fieldset: 'SEO',
    config: {
      label: 'slug',
      placeholder: 'Slug',
      useAsTitle: true,
    },
  },
  $seoDescription: {
    type: 'Text',
    config: {
      label: 'SEO Description',
      placeholder: 'SEO Description',
    },
  },
  $tweet: {
    type: 'Text',
    fieldset: 'Social network sharing',
    config: {
      placeholder: 'Tweet',
      label: 'Tweet',
    },
  },
  $sharingImage: {
    type: 'Image',
    config: {
      placeholder: 'Sharing image',
      constraint: {
        width: 1200,
        height: 630,
      },
    },
  },
  $sharingDescription: {
    type: 'Text',
    config: {
      placeholder: 'Sharing Description',
      label: 'Sharing Description',
    },
  },
  $title: {
    type: 'Text',
    fieldset: 'Infos',
    config: {
      placeholder: 'Title event',
      label: 'Title',
    },
  },
  $description: {
    type: 'Text',
    config: {
      placeholder: 'Description',
      label: 'Description',
    },
  },
  $eventLink: {
    type: 'Text',
    config: {
      placeholder: 'Online event URL',
      label: 'Online event URL',
    },
  },
  eventTimeStart_en: {
    type: 'Timestamp',
    fieldset: 'Time start and end',
    config: {
      label: 'Time start (MANDATORY)',
    },
  },
  eventTimeEnd_en: {
    type: 'Timestamp',
    config: {
      label: 'Time end (MANDATORY)',
    },
  },
  audiences_en: {
    type: 'Group',
    fieldset: 'Event type',
    config: {
      fields: {
        audience: {
          type: 'Link',
          config: {
            select: 'document',
            masks: ['audience'],
            placeholder: 'Event type',
          },
        },
      },
    },
  },
  $streetAddress: {
    type: 'Text',
    fieldset: 'Address',
    config: {
      placeholder: 'Street address',
      label: 'Street address',
    },
  },
  $streetAddress2: {
    type: 'Text',
    config: {
      placeholder: 'Street address (line 2)',
      label: 'Street address (line 2)',
    },
  },
  $city: {
    type: 'Text',
    config: {
      placeholder: 'City',
      label: 'City',
    },
  },
  $zipcode: {
    type: 'Text',
    config: {
      placeholder: 'Zipcode',
      label: 'Zipcode',
    },
  },
  $country: {
    type: 'Text',
    config: {
      placeholder: 'Country',
      label: 'Country',
    },
  },
  $eventBodyContent: {
    type: 'Slices',
    fieldset: 'Content',
    config: {
      choices: {
        ...paragraph,
        ...contactList,
        ...longQuote,
        ...documentsSlice,
        ...breakpointsImages,
      },
    },
  },
}

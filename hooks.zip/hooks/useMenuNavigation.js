import React from 'react'

export default function useMenuNavigation() {
  const [stateMenu, setStateMenu] = React.useState([])

  function clamp(nb, min = 0, max = 1) {
    return Math.min(Math.max(nb, min), max)
  }

  // reset the entire menu
  function resetMenu() {
    setStateMenu([])
  }

  function goToNextLevel(indexToAdd) {
    const newState = [...stateMenu]
    newState.push(indexToAdd)
    setStateMenu(newState)
  }

  // change the current menu
  function changeCurrentMenu(indexToChange) {
    const newState = [...stateMenu]
    if (newState.length >= 1) {
      newState[newState.length - 1] = indexToChange
    } else {
      if (newState.length === 0) {
        newState.push(indexToChange)
      }
    }
    setStateMenu(newState)
  }

  // lift up only one level above the current one
  function backMenu() {
    const newState = [...stateMenu]
    newState.splice(-1, 1)
    setStateMenu(newState)
  }

  // go to a specific menu level (from anywhere)
  function goToMenu(stateToApply) {
    const newState = validateTree(stateToApply)
    if (newState) setStateMenu(newState)
  }

  function hasMenuLevel(menuLevel) {
    return typeof stateMenu[clamp(menuLevel - 1, 0, 2)] === 'number'
  }

  return {
    stateMenu,
    goToNextLevel,
    resetMenu,
    changeCurrentMenu,
    backMenu,
    goToMenu,
    hasMenuLevel,
  }
}

function validateTree(state) {
  return state
}

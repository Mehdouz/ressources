import React from 'react'

// Inspired from https://github.com/streamich/react-use/blob/master/docs/useFirstMountState.md
const useFirstMountState = () => {
  const isMount = React.useRef(true)

  if (isMount.current) {
    isMount.current = false
    return true
  }

  return isMount.current
}

export default useFirstMountState

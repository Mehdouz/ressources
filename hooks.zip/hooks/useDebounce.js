import { useRef, useMemo, useEffect } from 'react'
import _debounce from 'lodash/debounce'

const useDebounce = (callback, ms = 1000) => {
  const ref = useRef()

  useEffect(() => {
    ref.current = callback
  }, [callback])

  const debouncedCallback = useMemo(() => {
    const func = () => {
      ref.current?.()
    }

    return _debounce(func, ms)
  }, [])

  return debouncedCallback
}

export default useDebounce

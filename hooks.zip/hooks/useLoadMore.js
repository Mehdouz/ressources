import { useEffect, useReducer } from 'react'
import { useGlobalContext } from '@axacom-client/store/GlobalContext'
import log from '@axacom-client/logger'
import axacomClient from '@axacom-client/clients/axacom'

function reducer(state, action) {
  let newState = {}

  switch (action.type) {
    case 'loading':
      newState = { loading: true }
      break
    case 'onLoaded':
      newState = {
        loading: false,
        success: true,
        total: action.payload.pageCount,
        page: action.payload.page,
        hasMoreItems: action.payload.page < action.payload.pageCount,
        data: action.payload.results,
      }
      break
    case 'updatingFilters':
      newState = { activeFilters: action.payload, loading: true, data: [] }
      break
    case 'onUpdatedFilters':
      newState = {
        data: action.payload.results,
        total: action.payload.pageCount,
        page: action.payload.page,
        hasMoreItems: action.payload.page < action.payload.pageCount,
        loading: false,
      }
      break
    case 'loadMore':
      if (Array.isArray(state.data) && state.data.length > 0) {
        newState.data = [...state.data, ...action.payload.results]
      }
      newState = {
        loading: false,
        success: true,
        total: action.payload.pageCount,
        page: action.payload.page,
        hasMoreItems: action.payload.page < action.payload.pageCount,
        data: newState.data ? newState.data : action.payload.results,
      }
      break
    case 'error':
      newState = { loading: false, success: false, error: true }
      break
  }
  return { ...state, ...newState }
}

function useLoadMore({ size, customType }) {
  const { i18n } = useGlobalContext()
  const locale = i18n.language

  const validCustomTypes = ['stories', 'articles']

  const [state, dispatch] = useReducer(reducer, {
    loading: false,
    success: false,
    error: false,
    page: 1,
    hasMoreItems: false,
    data: [],
    filters: [],
    activeFilters: [],
    total: 0,
  })

  if (!validCustomTypes.some((element) => element === customType)) {
    log.error('[AllStories] Enter a valid custom type')
    throw new Error()
  }

  useEffect(() => {
    dispatch({ type: 'loading' })

    async function fetchData() {
      const { results, page, pageCount } = (await axacomClient().get(`/_api/${customType}-with-tags`, { params: { size, language: locale, page: 1 } })).data
      dispatch({ type: 'onLoaded', payload: { page, pageCount, results } })
    }

    fetchData().catch((e) => {
      log.error('[AllStories] Error onLoaded stories', e)
      dispatch({ type: 'error' })
    })
  }, [])

  const setActiveFilters = async (newFilters) => {
    dispatch({ type: 'updatingFilters', payload: newFilters })
    try {
      const { results, page, pageCount } = (await axacomClient().get(`/_api/${customType}-with-tags`, { params: { size, language: locale, page: 1, tags: newFilters.map((filter) => filter.id) } }))
        .data
      dispatch({ type: 'onUpdatedFilters', payload: { results, page, pageCount } })
    } catch (error) {
      log.error('[AllStories] Error on setActiveFilters', error)
      dispatch({ type: 'error' })
    }
  }

  const loadMore = async () => {
    dispatch({ type: 'loading' })
    try {
      const { results, page, pageCount } = (
        await axacomClient().get(`/_api/${customType}-with-tags`, { params: { size, language: locale, page: state.page + 1, tags: state.activeFilters.map((filter) => filter.id) } })
      ).data
      dispatch({ type: 'loadMore', payload: { results, page, pageCount } })
    } catch (e) {
      log.error('[AllStories] Error on loadMore', e)
      dispatch({ type: 'error' })
    }
  }

  return {
    ...state,
    setActiveFilters,
    loadMore,
  }
}

export default useLoadMore

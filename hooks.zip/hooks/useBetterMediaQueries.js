import { useEffect, useState } from 'react'
import { useMediaQuery } from 'react-responsive'

export default function useBetterMediaQueries(query, ssrValue) {
  const [isSsr, setIsSsr] = useState(true)
  const useMediaQueryValue = useMediaQuery(query)

  useEffect(() => {
    setIsSsr(false)
  }, [])

  return isSsr ? ssrValue : useMediaQueryValue
}

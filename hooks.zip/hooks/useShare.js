import { stringify } from 'query-string'
import { getDocument, getLocation, windowOpen } from '@axacom-client/services/window-service'

export function useShare({ title }) {
  const url = getLocation('href')
  const content = getDocument()?.querySelector("meta[property='og:description']")?.getAttribute('content')
  const tweet = getDocument()?.querySelector("meta[name='twitter:tweet']")?.getAttribute('content')
  const via = 'AXA'
  const hashtags = ['AXA']

  const networkUrl = {
    facebook: 'https://www.facebook.com/sharer/sharer.php?' + stringify({ u: url, quote: content, hashtag: hashtags }),
    twitter: 'https://twitter.com/share?' + stringify({ hashtags: hashtags ? hashtags.join(',') : '', text: title ? title : tweet, url: url, via: via }),
    linkedin: 'https://www.linkedin.com/shareArticle?' + stringify({ url: url, title: title, summary: content, mini: true }),
    mail: 'mailto:?' + stringify({ subject: title, body: url }),
  }

  function onShare(social) {
    windowOpen(networkUrl[social], '_blank', 'width=600,height=400')
  }

  return { onShare }
}

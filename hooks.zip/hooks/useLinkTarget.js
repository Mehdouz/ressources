import { useGlobalContext } from '@axacom-client/store/GlobalContext'

export default function useLinkTarget(url) {
  const { domain } = useGlobalContext()

  return url.startsWith('/') || url.includes(domain) ? '_self' : '_blank'
}

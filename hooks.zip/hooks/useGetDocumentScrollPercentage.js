import { useEffect, useState } from 'react'
import { getDocument, getScrollY, windowAddEventListener, windowRemoveEventListener } from '@axacom-client/services/window-service'

export default function useGetDocumentScrollPercentage() {
  const [scrollPercentage, setScrollPercentage] = useState(0)

  useEffect(() => {
    windowAddEventListener('scroll', onScroll)

    return () => {
      // eslint-disable-next-line no-undef
      windowRemoveEventListener('scroll', onScroll)
    }
  }, [])

  function onScroll() {
    const windowHeight = getDocument().documentElement.scrollHeight - getDocument().documentElement.clientHeight
    setScrollPercentage(((getScrollY() / windowHeight) * 100).toFixed(2))
  }

  return scrollPercentage
}
